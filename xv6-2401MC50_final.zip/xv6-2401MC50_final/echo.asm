
_echo:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 08             	sub    $0x8,%esp
  14:	8b 31                	mov    (%ecx),%esi
  16:	8b 79 04             	mov    0x4(%ecx),%edi
  19:	83 fe 01             	cmp    $0x1,%esi
  1c:	7e 41                	jle    5f <main+0x5f>
  1e:	8b 47 04             	mov    0x4(%edi),%eax
  21:	83 fe 02             	cmp    $0x2,%esi
  24:	74 24                	je     4a <main+0x4a>
  26:	bb 02 00 00 00       	mov    $0x2,%ebx
  2b:	90                   	nop
  2c:	68 50 06 00 00       	push   $0x650
  31:	50                   	push   %eax
  32:	68 52 06 00 00       	push   $0x652
  37:	6a 01                	push   $0x1
  39:	e8 2e 03 00 00       	call   36c <printf>
  3e:	43                   	inc    %ebx
  3f:	8b 44 9f fc          	mov    -0x4(%edi,%ebx,4),%eax
  43:	83 c4 10             	add    $0x10,%esp
  46:	39 f3                	cmp    %esi,%ebx
  48:	75 e2                	jne    2c <main+0x2c>
  4a:	68 57 06 00 00       	push   $0x657
  4f:	50                   	push   %eax
  50:	68 52 06 00 00       	push   $0x652
  55:	6a 01                	push   $0x1
  57:	e8 10 03 00 00       	call   36c <printf>
  5c:	83 c4 10             	add    $0x10,%esp
  5f:	e8 c3 01 00 00       	call   227 <exit>

00000064 <strcpy>:
  64:	55                   	push   %ebp
  65:	89 e5                	mov    %esp,%ebp
  67:	53                   	push   %ebx
  68:	8b 4d 08             	mov    0x8(%ebp),%ecx
  6b:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  6e:	31 c0                	xor    %eax,%eax
  70:	8a 14 03             	mov    (%ebx,%eax,1),%dl
  73:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  76:	40                   	inc    %eax
  77:	84 d2                	test   %dl,%dl
  79:	75 f5                	jne    70 <strcpy+0xc>
  7b:	89 c8                	mov    %ecx,%eax
  7d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  80:	c9                   	leave  
  81:	c3                   	ret    
  82:	66 90                	xchg   %ax,%ax

00000084 <strcmp>:
  84:	55                   	push   %ebp
  85:	89 e5                	mov    %esp,%ebp
  87:	53                   	push   %ebx
  88:	8b 55 08             	mov    0x8(%ebp),%edx
  8b:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  8e:	0f b6 02             	movzbl (%edx),%eax
  91:	84 c0                	test   %al,%al
  93:	75 10                	jne    a5 <strcmp+0x21>
  95:	eb 2a                	jmp    c1 <strcmp+0x3d>
  97:	90                   	nop
  98:	42                   	inc    %edx
  99:	8d 4b 01             	lea    0x1(%ebx),%ecx
  9c:	0f b6 02             	movzbl (%edx),%eax
  9f:	84 c0                	test   %al,%al
  a1:	74 11                	je     b4 <strcmp+0x30>
  a3:	89 cb                	mov    %ecx,%ebx
  a5:	0f b6 0b             	movzbl (%ebx),%ecx
  a8:	38 c1                	cmp    %al,%cl
  aa:	74 ec                	je     98 <strcmp+0x14>
  ac:	29 c8                	sub    %ecx,%eax
  ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  b1:	c9                   	leave  
  b2:	c3                   	ret    
  b3:	90                   	nop
  b4:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
  b8:	31 c0                	xor    %eax,%eax
  ba:	29 c8                	sub    %ecx,%eax
  bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  bf:	c9                   	leave  
  c0:	c3                   	ret    
  c1:	0f b6 0b             	movzbl (%ebx),%ecx
  c4:	31 c0                	xor    %eax,%eax
  c6:	eb e4                	jmp    ac <strcmp+0x28>

000000c8 <strlen>:
  c8:	55                   	push   %ebp
  c9:	89 e5                	mov    %esp,%ebp
  cb:	8b 55 08             	mov    0x8(%ebp),%edx
  ce:	80 3a 00             	cmpb   $0x0,(%edx)
  d1:	74 15                	je     e8 <strlen+0x20>
  d3:	31 c0                	xor    %eax,%eax
  d5:	8d 76 00             	lea    0x0(%esi),%esi
  d8:	40                   	inc    %eax
  d9:	89 c1                	mov    %eax,%ecx
  db:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
  df:	75 f7                	jne    d8 <strlen+0x10>
  e1:	89 c8                	mov    %ecx,%eax
  e3:	5d                   	pop    %ebp
  e4:	c3                   	ret    
  e5:	8d 76 00             	lea    0x0(%esi),%esi
  e8:	31 c9                	xor    %ecx,%ecx
  ea:	89 c8                	mov    %ecx,%eax
  ec:	5d                   	pop    %ebp
  ed:	c3                   	ret    
  ee:	66 90                	xchg   %ax,%ax

000000f0 <memset>:
  f0:	55                   	push   %ebp
  f1:	89 e5                	mov    %esp,%ebp
  f3:	57                   	push   %edi
  f4:	8b 7d 08             	mov    0x8(%ebp),%edi
  f7:	8b 4d 10             	mov    0x10(%ebp),%ecx
  fa:	8b 45 0c             	mov    0xc(%ebp),%eax
  fd:	fc                   	cld    
  fe:	f3 aa                	rep stos %al,%es:(%edi)
 100:	8b 45 08             	mov    0x8(%ebp),%eax
 103:	8b 7d fc             	mov    -0x4(%ebp),%edi
 106:	c9                   	leave  
 107:	c3                   	ret    

00000108 <strchr>:
 108:	55                   	push   %ebp
 109:	89 e5                	mov    %esp,%ebp
 10b:	8b 45 08             	mov    0x8(%ebp),%eax
 10e:	8a 4d 0c             	mov    0xc(%ebp),%cl
 111:	8a 10                	mov    (%eax),%dl
 113:	84 d2                	test   %dl,%dl
 115:	75 0c                	jne    123 <strchr+0x1b>
 117:	eb 13                	jmp    12c <strchr+0x24>
 119:	8d 76 00             	lea    0x0(%esi),%esi
 11c:	40                   	inc    %eax
 11d:	8a 10                	mov    (%eax),%dl
 11f:	84 d2                	test   %dl,%dl
 121:	74 09                	je     12c <strchr+0x24>
 123:	38 d1                	cmp    %dl,%cl
 125:	75 f5                	jne    11c <strchr+0x14>
 127:	5d                   	pop    %ebp
 128:	c3                   	ret    
 129:	8d 76 00             	lea    0x0(%esi),%esi
 12c:	31 c0                	xor    %eax,%eax
 12e:	5d                   	pop    %ebp
 12f:	c3                   	ret    

00000130 <gets>:
 130:	55                   	push   %ebp
 131:	89 e5                	mov    %esp,%ebp
 133:	57                   	push   %edi
 134:	56                   	push   %esi
 135:	53                   	push   %ebx
 136:	83 ec 1c             	sub    $0x1c,%esp
 139:	31 db                	xor    %ebx,%ebx
 13b:	8d 75 e7             	lea    -0x19(%ebp),%esi
 13e:	eb 24                	jmp    164 <gets+0x34>
 140:	50                   	push   %eax
 141:	6a 01                	push   $0x1
 143:	56                   	push   %esi
 144:	6a 00                	push   $0x0
 146:	e8 f4 00 00 00       	call   23f <read>
 14b:	83 c4 10             	add    $0x10,%esp
 14e:	85 c0                	test   %eax,%eax
 150:	7e 1a                	jle    16c <gets+0x3c>
 152:	8a 45 e7             	mov    -0x19(%ebp),%al
 155:	8b 55 08             	mov    0x8(%ebp),%edx
 158:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 15c:	3c 0a                	cmp    $0xa,%al
 15e:	74 0e                	je     16e <gets+0x3e>
 160:	3c 0d                	cmp    $0xd,%al
 162:	74 0a                	je     16e <gets+0x3e>
 164:	89 df                	mov    %ebx,%edi
 166:	43                   	inc    %ebx
 167:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 16a:	7c d4                	jl     140 <gets+0x10>
 16c:	89 fb                	mov    %edi,%ebx
 16e:	8b 45 08             	mov    0x8(%ebp),%eax
 171:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 175:	8d 65 f4             	lea    -0xc(%ebp),%esp
 178:	5b                   	pop    %ebx
 179:	5e                   	pop    %esi
 17a:	5f                   	pop    %edi
 17b:	5d                   	pop    %ebp
 17c:	c3                   	ret    
 17d:	8d 76 00             	lea    0x0(%esi),%esi

00000180 <stat>:
 180:	55                   	push   %ebp
 181:	89 e5                	mov    %esp,%ebp
 183:	56                   	push   %esi
 184:	53                   	push   %ebx
 185:	83 ec 08             	sub    $0x8,%esp
 188:	6a 00                	push   $0x0
 18a:	ff 75 08             	pushl  0x8(%ebp)
 18d:	e8 d5 00 00 00       	call   267 <open>
 192:	83 c4 10             	add    $0x10,%esp
 195:	85 c0                	test   %eax,%eax
 197:	78 27                	js     1c0 <stat+0x40>
 199:	89 c3                	mov    %eax,%ebx
 19b:	83 ec 08             	sub    $0x8,%esp
 19e:	ff 75 0c             	pushl  0xc(%ebp)
 1a1:	50                   	push   %eax
 1a2:	e8 d8 00 00 00       	call   27f <fstat>
 1a7:	89 c6                	mov    %eax,%esi
 1a9:	89 1c 24             	mov    %ebx,(%esp)
 1ac:	e8 9e 00 00 00       	call   24f <close>
 1b1:	83 c4 10             	add    $0x10,%esp
 1b4:	89 f0                	mov    %esi,%eax
 1b6:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1b9:	5b                   	pop    %ebx
 1ba:	5e                   	pop    %esi
 1bb:	5d                   	pop    %ebp
 1bc:	c3                   	ret    
 1bd:	8d 76 00             	lea    0x0(%esi),%esi
 1c0:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1c5:	eb ed                	jmp    1b4 <stat+0x34>
 1c7:	90                   	nop

000001c8 <atoi>:
 1c8:	55                   	push   %ebp
 1c9:	89 e5                	mov    %esp,%ebp
 1cb:	53                   	push   %ebx
 1cc:	8b 4d 08             	mov    0x8(%ebp),%ecx
 1cf:	0f be 01             	movsbl (%ecx),%eax
 1d2:	8d 50 d0             	lea    -0x30(%eax),%edx
 1d5:	80 fa 09             	cmp    $0x9,%dl
 1d8:	ba 00 00 00 00       	mov    $0x0,%edx
 1dd:	77 16                	ja     1f5 <atoi+0x2d>
 1df:	90                   	nop
 1e0:	41                   	inc    %ecx
 1e1:	8d 14 92             	lea    (%edx,%edx,4),%edx
 1e4:	01 d2                	add    %edx,%edx
 1e6:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 1ea:	0f be 01             	movsbl (%ecx),%eax
 1ed:	8d 58 d0             	lea    -0x30(%eax),%ebx
 1f0:	80 fb 09             	cmp    $0x9,%bl
 1f3:	76 eb                	jbe    1e0 <atoi+0x18>
 1f5:	89 d0                	mov    %edx,%eax
 1f7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1fa:	c9                   	leave  
 1fb:	c3                   	ret    

000001fc <memmove>:
 1fc:	55                   	push   %ebp
 1fd:	89 e5                	mov    %esp,%ebp
 1ff:	57                   	push   %edi
 200:	56                   	push   %esi
 201:	8b 55 08             	mov    0x8(%ebp),%edx
 204:	8b 75 0c             	mov    0xc(%ebp),%esi
 207:	8b 45 10             	mov    0x10(%ebp),%eax
 20a:	85 c0                	test   %eax,%eax
 20c:	7e 0b                	jle    219 <memmove+0x1d>
 20e:	01 d0                	add    %edx,%eax
 210:	89 d7                	mov    %edx,%edi
 212:	66 90                	xchg   %ax,%ax
 214:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 215:	39 f8                	cmp    %edi,%eax
 217:	75 fb                	jne    214 <memmove+0x18>
 219:	89 d0                	mov    %edx,%eax
 21b:	5e                   	pop    %esi
 21c:	5f                   	pop    %edi
 21d:	5d                   	pop    %ebp
 21e:	c3                   	ret    

0000021f <fork>:
 21f:	b8 01 00 00 00       	mov    $0x1,%eax
 224:	cd 40                	int    $0x40
 226:	c3                   	ret    

00000227 <exit>:
 227:	b8 02 00 00 00       	mov    $0x2,%eax
 22c:	cd 40                	int    $0x40
 22e:	c3                   	ret    

0000022f <wait>:
 22f:	b8 03 00 00 00       	mov    $0x3,%eax
 234:	cd 40                	int    $0x40
 236:	c3                   	ret    

00000237 <pipe>:
 237:	b8 04 00 00 00       	mov    $0x4,%eax
 23c:	cd 40                	int    $0x40
 23e:	c3                   	ret    

0000023f <read>:
 23f:	b8 05 00 00 00       	mov    $0x5,%eax
 244:	cd 40                	int    $0x40
 246:	c3                   	ret    

00000247 <write>:
 247:	b8 10 00 00 00       	mov    $0x10,%eax
 24c:	cd 40                	int    $0x40
 24e:	c3                   	ret    

0000024f <close>:
 24f:	b8 15 00 00 00       	mov    $0x15,%eax
 254:	cd 40                	int    $0x40
 256:	c3                   	ret    

00000257 <kill>:
 257:	b8 06 00 00 00       	mov    $0x6,%eax
 25c:	cd 40                	int    $0x40
 25e:	c3                   	ret    

0000025f <exec>:
 25f:	b8 07 00 00 00       	mov    $0x7,%eax
 264:	cd 40                	int    $0x40
 266:	c3                   	ret    

00000267 <open>:
 267:	b8 0f 00 00 00       	mov    $0xf,%eax
 26c:	cd 40                	int    $0x40
 26e:	c3                   	ret    

0000026f <mknod>:
 26f:	b8 11 00 00 00       	mov    $0x11,%eax
 274:	cd 40                	int    $0x40
 276:	c3                   	ret    

00000277 <unlink>:
 277:	b8 12 00 00 00       	mov    $0x12,%eax
 27c:	cd 40                	int    $0x40
 27e:	c3                   	ret    

0000027f <fstat>:
 27f:	b8 08 00 00 00       	mov    $0x8,%eax
 284:	cd 40                	int    $0x40
 286:	c3                   	ret    

00000287 <link>:
 287:	b8 13 00 00 00       	mov    $0x13,%eax
 28c:	cd 40                	int    $0x40
 28e:	c3                   	ret    

0000028f <mkdir>:
 28f:	b8 14 00 00 00       	mov    $0x14,%eax
 294:	cd 40                	int    $0x40
 296:	c3                   	ret    

00000297 <chdir>:
 297:	b8 09 00 00 00       	mov    $0x9,%eax
 29c:	cd 40                	int    $0x40
 29e:	c3                   	ret    

0000029f <dup>:
 29f:	b8 0a 00 00 00       	mov    $0xa,%eax
 2a4:	cd 40                	int    $0x40
 2a6:	c3                   	ret    

000002a7 <getpid>:
 2a7:	b8 0b 00 00 00       	mov    $0xb,%eax
 2ac:	cd 40                	int    $0x40
 2ae:	c3                   	ret    

000002af <sbrk>:
 2af:	b8 0c 00 00 00       	mov    $0xc,%eax
 2b4:	cd 40                	int    $0x40
 2b6:	c3                   	ret    

000002b7 <sleep>:
 2b7:	b8 0d 00 00 00       	mov    $0xd,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <uptime>:
 2bf:	b8 0e 00 00 00       	mov    $0xe,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <mprotect>:
 2c7:	b8 16 00 00 00       	mov    $0x16,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <munprotect>:
 2cf:	b8 17 00 00 00       	mov    $0x17,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <set_priority>:
 2d7:	b8 18 00 00 00       	mov    $0x18,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret    
 2df:	90                   	nop

000002e0 <printint>:
 2e0:	55                   	push   %ebp
 2e1:	89 e5                	mov    %esp,%ebp
 2e3:	57                   	push   %edi
 2e4:	56                   	push   %esi
 2e5:	53                   	push   %ebx
 2e6:	83 ec 3c             	sub    $0x3c,%esp
 2e9:	89 45 c0             	mov    %eax,-0x40(%ebp)
 2ec:	89 cb                	mov    %ecx,%ebx
 2ee:	8b 4d 08             	mov    0x8(%ebp),%ecx
 2f1:	85 c9                	test   %ecx,%ecx
 2f3:	74 04                	je     2f9 <printint+0x19>
 2f5:	85 d2                	test   %edx,%edx
 2f7:	78 6b                	js     364 <printint+0x84>
 2f9:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 2fc:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 303:	31 c9                	xor    %ecx,%ecx
 305:	8d 75 d7             	lea    -0x29(%ebp),%esi
 308:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 30b:	31 d2                	xor    %edx,%edx
 30d:	f7 f3                	div    %ebx
 30f:	89 cf                	mov    %ecx,%edi
 311:	8d 49 01             	lea    0x1(%ecx),%ecx
 314:	8a 92 b8 06 00 00    	mov    0x6b8(%edx),%dl
 31a:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 31e:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 321:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 324:	39 da                	cmp    %ebx,%edx
 326:	73 e0                	jae    308 <printint+0x28>
 328:	8b 55 08             	mov    0x8(%ebp),%edx
 32b:	85 d2                	test   %edx,%edx
 32d:	74 07                	je     336 <printint+0x56>
 32f:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 334:	89 cf                	mov    %ecx,%edi
 336:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 339:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 33d:	8d 76 00             	lea    0x0(%esi),%esi
 340:	8a 07                	mov    (%edi),%al
 342:	88 45 d7             	mov    %al,-0x29(%ebp)
 345:	50                   	push   %eax
 346:	6a 01                	push   $0x1
 348:	56                   	push   %esi
 349:	ff 75 c0             	pushl  -0x40(%ebp)
 34c:	e8 f6 fe ff ff       	call   247 <write>
 351:	89 f8                	mov    %edi,%eax
 353:	4f                   	dec    %edi
 354:	83 c4 10             	add    $0x10,%esp
 357:	39 d8                	cmp    %ebx,%eax
 359:	75 e5                	jne    340 <printint+0x60>
 35b:	8d 65 f4             	lea    -0xc(%ebp),%esp
 35e:	5b                   	pop    %ebx
 35f:	5e                   	pop    %esi
 360:	5f                   	pop    %edi
 361:	5d                   	pop    %ebp
 362:	c3                   	ret    
 363:	90                   	nop
 364:	f7 da                	neg    %edx
 366:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 369:	eb 98                	jmp    303 <printint+0x23>
 36b:	90                   	nop

0000036c <printf>:
 36c:	55                   	push   %ebp
 36d:	89 e5                	mov    %esp,%ebp
 36f:	57                   	push   %edi
 370:	56                   	push   %esi
 371:	53                   	push   %ebx
 372:	83 ec 2c             	sub    $0x2c,%esp
 375:	8b 75 08             	mov    0x8(%ebp),%esi
 378:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 37b:	8a 13                	mov    (%ebx),%dl
 37d:	84 d2                	test   %dl,%dl
 37f:	74 5c                	je     3dd <printf+0x71>
 381:	43                   	inc    %ebx
 382:	8d 45 10             	lea    0x10(%ebp),%eax
 385:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 388:	31 ff                	xor    %edi,%edi
 38a:	eb 20                	jmp    3ac <printf+0x40>
 38c:	83 f8 25             	cmp    $0x25,%eax
 38f:	74 3f                	je     3d0 <printf+0x64>
 391:	88 55 e7             	mov    %dl,-0x19(%ebp)
 394:	50                   	push   %eax
 395:	6a 01                	push   $0x1
 397:	8d 45 e7             	lea    -0x19(%ebp),%eax
 39a:	50                   	push   %eax
 39b:	56                   	push   %esi
 39c:	e8 a6 fe ff ff       	call   247 <write>
 3a1:	83 c4 10             	add    $0x10,%esp
 3a4:	43                   	inc    %ebx
 3a5:	8a 53 ff             	mov    -0x1(%ebx),%dl
 3a8:	84 d2                	test   %dl,%dl
 3aa:	74 31                	je     3dd <printf+0x71>
 3ac:	0f b6 c2             	movzbl %dl,%eax
 3af:	85 ff                	test   %edi,%edi
 3b1:	74 d9                	je     38c <printf+0x20>
 3b3:	83 ff 25             	cmp    $0x25,%edi
 3b6:	75 ec                	jne    3a4 <printf+0x38>
 3b8:	83 f8 25             	cmp    $0x25,%eax
 3bb:	0f 84 03 01 00 00    	je     4c4 <printf+0x158>
 3c1:	83 e8 63             	sub    $0x63,%eax
 3c4:	83 f8 15             	cmp    $0x15,%eax
 3c7:	77 1f                	ja     3e8 <printf+0x7c>
 3c9:	ff 24 85 60 06 00 00 	jmp    *0x660(,%eax,4)
 3d0:	bf 25 00 00 00       	mov    $0x25,%edi
 3d5:	43                   	inc    %ebx
 3d6:	8a 53 ff             	mov    -0x1(%ebx),%dl
 3d9:	84 d2                	test   %dl,%dl
 3db:	75 cf                	jne    3ac <printf+0x40>
 3dd:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3e0:	5b                   	pop    %ebx
 3e1:	5e                   	pop    %esi
 3e2:	5f                   	pop    %edi
 3e3:	5d                   	pop    %ebp
 3e4:	c3                   	ret    
 3e5:	8d 76 00             	lea    0x0(%esi),%esi
 3e8:	88 55 d0             	mov    %dl,-0x30(%ebp)
 3eb:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 3ef:	50                   	push   %eax
 3f0:	6a 01                	push   $0x1
 3f2:	8d 7d e7             	lea    -0x19(%ebp),%edi
 3f5:	57                   	push   %edi
 3f6:	56                   	push   %esi
 3f7:	e8 4b fe ff ff       	call   247 <write>
 3fc:	8a 55 d0             	mov    -0x30(%ebp),%dl
 3ff:	88 55 e7             	mov    %dl,-0x19(%ebp)
 402:	83 c4 0c             	add    $0xc,%esp
 405:	6a 01                	push   $0x1
 407:	57                   	push   %edi
 408:	56                   	push   %esi
 409:	e8 39 fe ff ff       	call   247 <write>
 40e:	83 c4 10             	add    $0x10,%esp
 411:	31 ff                	xor    %edi,%edi
 413:	eb 8f                	jmp    3a4 <printf+0x38>
 415:	8d 76 00             	lea    0x0(%esi),%esi
 418:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 41b:	8b 17                	mov    (%edi),%edx
 41d:	83 ec 0c             	sub    $0xc,%esp
 420:	6a 00                	push   $0x0
 422:	b9 10 00 00 00       	mov    $0x10,%ecx
 427:	89 f0                	mov    %esi,%eax
 429:	e8 b2 fe ff ff       	call   2e0 <printint>
 42e:	83 c7 04             	add    $0x4,%edi
 431:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 434:	83 c4 10             	add    $0x10,%esp
 437:	31 ff                	xor    %edi,%edi
 439:	e9 66 ff ff ff       	jmp    3a4 <printf+0x38>
 43e:	66 90                	xchg   %ax,%ax
 440:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 443:	8b 10                	mov    (%eax),%edx
 445:	83 c0 04             	add    $0x4,%eax
 448:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 44b:	85 d2                	test   %edx,%edx
 44d:	0f 84 81 00 00 00    	je     4d4 <printf+0x168>
 453:	8a 02                	mov    (%edx),%al
 455:	84 c0                	test   %al,%al
 457:	0f 84 80 00 00 00    	je     4dd <printf+0x171>
 45d:	8d 7d e7             	lea    -0x19(%ebp),%edi
 460:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 463:	89 d3                	mov    %edx,%ebx
 465:	8d 76 00             	lea    0x0(%esi),%esi
 468:	88 45 e7             	mov    %al,-0x19(%ebp)
 46b:	50                   	push   %eax
 46c:	6a 01                	push   $0x1
 46e:	57                   	push   %edi
 46f:	56                   	push   %esi
 470:	e8 d2 fd ff ff       	call   247 <write>
 475:	43                   	inc    %ebx
 476:	8a 03                	mov    (%ebx),%al
 478:	83 c4 10             	add    $0x10,%esp
 47b:	84 c0                	test   %al,%al
 47d:	75 e9                	jne    468 <printf+0xfc>
 47f:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 482:	31 ff                	xor    %edi,%edi
 484:	e9 1b ff ff ff       	jmp    3a4 <printf+0x38>
 489:	8d 76 00             	lea    0x0(%esi),%esi
 48c:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 48f:	8b 17                	mov    (%edi),%edx
 491:	83 ec 0c             	sub    $0xc,%esp
 494:	6a 01                	push   $0x1
 496:	b9 0a 00 00 00       	mov    $0xa,%ecx
 49b:	eb 8a                	jmp    427 <printf+0xbb>
 49d:	8d 76 00             	lea    0x0(%esi),%esi
 4a0:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 4a3:	8b 00                	mov    (%eax),%eax
 4a5:	88 45 e7             	mov    %al,-0x19(%ebp)
 4a8:	51                   	push   %ecx
 4a9:	6a 01                	push   $0x1
 4ab:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4ae:	57                   	push   %edi
 4af:	56                   	push   %esi
 4b0:	e8 92 fd ff ff       	call   247 <write>
 4b5:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 4b9:	83 c4 10             	add    $0x10,%esp
 4bc:	31 ff                	xor    %edi,%edi
 4be:	e9 e1 fe ff ff       	jmp    3a4 <printf+0x38>
 4c3:	90                   	nop
 4c4:	88 55 e7             	mov    %dl,-0x19(%ebp)
 4c7:	52                   	push   %edx
 4c8:	6a 01                	push   $0x1
 4ca:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4cd:	e9 35 ff ff ff       	jmp    407 <printf+0x9b>
 4d2:	66 90                	xchg   %ax,%ax
 4d4:	b0 28                	mov    $0x28,%al
 4d6:	ba 59 06 00 00       	mov    $0x659,%edx
 4db:	eb 80                	jmp    45d <printf+0xf1>
 4dd:	31 ff                	xor    %edi,%edi
 4df:	e9 c0 fe ff ff       	jmp    3a4 <printf+0x38>

000004e4 <free>:
 4e4:	55                   	push   %ebp
 4e5:	89 e5                	mov    %esp,%ebp
 4e7:	57                   	push   %edi
 4e8:	56                   	push   %esi
 4e9:	53                   	push   %ebx
 4ea:	8b 5d 08             	mov    0x8(%ebp),%ebx
 4ed:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 4f0:	a1 cc 06 00 00       	mov    0x6cc,%eax
 4f5:	8d 76 00             	lea    0x0(%esi),%esi
 4f8:	89 c2                	mov    %eax,%edx
 4fa:	8b 00                	mov    (%eax),%eax
 4fc:	39 ca                	cmp    %ecx,%edx
 4fe:	73 2c                	jae    52c <free+0x48>
 500:	39 c1                	cmp    %eax,%ecx
 502:	72 04                	jb     508 <free+0x24>
 504:	39 c2                	cmp    %eax,%edx
 506:	72 f0                	jb     4f8 <free+0x14>
 508:	8b 73 fc             	mov    -0x4(%ebx),%esi
 50b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 50e:	39 f8                	cmp    %edi,%eax
 510:	74 2c                	je     53e <free+0x5a>
 512:	89 43 f8             	mov    %eax,-0x8(%ebx)
 515:	8b 42 04             	mov    0x4(%edx),%eax
 518:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 51b:	39 f1                	cmp    %esi,%ecx
 51d:	74 36                	je     555 <free+0x71>
 51f:	89 0a                	mov    %ecx,(%edx)
 521:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 527:	5b                   	pop    %ebx
 528:	5e                   	pop    %esi
 529:	5f                   	pop    %edi
 52a:	5d                   	pop    %ebp
 52b:	c3                   	ret    
 52c:	39 c2                	cmp    %eax,%edx
 52e:	72 c8                	jb     4f8 <free+0x14>
 530:	39 c1                	cmp    %eax,%ecx
 532:	73 c4                	jae    4f8 <free+0x14>
 534:	8b 73 fc             	mov    -0x4(%ebx),%esi
 537:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 53a:	39 f8                	cmp    %edi,%eax
 53c:	75 d4                	jne    512 <free+0x2e>
 53e:	03 70 04             	add    0x4(%eax),%esi
 541:	89 73 fc             	mov    %esi,-0x4(%ebx)
 544:	8b 02                	mov    (%edx),%eax
 546:	8b 00                	mov    (%eax),%eax
 548:	89 43 f8             	mov    %eax,-0x8(%ebx)
 54b:	8b 42 04             	mov    0x4(%edx),%eax
 54e:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 551:	39 f1                	cmp    %esi,%ecx
 553:	75 ca                	jne    51f <free+0x3b>
 555:	03 43 fc             	add    -0x4(%ebx),%eax
 558:	89 42 04             	mov    %eax,0x4(%edx)
 55b:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 55e:	89 0a                	mov    %ecx,(%edx)
 560:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 566:	5b                   	pop    %ebx
 567:	5e                   	pop    %esi
 568:	5f                   	pop    %edi
 569:	5d                   	pop    %ebp
 56a:	c3                   	ret    
 56b:	90                   	nop

0000056c <malloc>:
 56c:	55                   	push   %ebp
 56d:	89 e5                	mov    %esp,%ebp
 56f:	57                   	push   %edi
 570:	56                   	push   %esi
 571:	53                   	push   %ebx
 572:	83 ec 0c             	sub    $0xc,%esp
 575:	8b 45 08             	mov    0x8(%ebp),%eax
 578:	8d 78 07             	lea    0x7(%eax),%edi
 57b:	c1 ef 03             	shr    $0x3,%edi
 57e:	47                   	inc    %edi
 57f:	8b 15 cc 06 00 00    	mov    0x6cc,%edx
 585:	85 d2                	test   %edx,%edx
 587:	0f 84 93 00 00 00    	je     620 <malloc+0xb4>
 58d:	8b 02                	mov    (%edx),%eax
 58f:	8b 48 04             	mov    0x4(%eax),%ecx
 592:	39 f9                	cmp    %edi,%ecx
 594:	73 62                	jae    5f8 <malloc+0x8c>
 596:	89 fb                	mov    %edi,%ebx
 598:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 59e:	72 78                	jb     618 <malloc+0xac>
 5a0:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 5a7:	eb 0e                	jmp    5b7 <malloc+0x4b>
 5a9:	8d 76 00             	lea    0x0(%esi),%esi
 5ac:	89 c2                	mov    %eax,%edx
 5ae:	8b 02                	mov    (%edx),%eax
 5b0:	8b 48 04             	mov    0x4(%eax),%ecx
 5b3:	39 f9                	cmp    %edi,%ecx
 5b5:	73 41                	jae    5f8 <malloc+0x8c>
 5b7:	39 05 cc 06 00 00    	cmp    %eax,0x6cc
 5bd:	75 ed                	jne    5ac <malloc+0x40>
 5bf:	83 ec 0c             	sub    $0xc,%esp
 5c2:	56                   	push   %esi
 5c3:	e8 e7 fc ff ff       	call   2af <sbrk>
 5c8:	83 c4 10             	add    $0x10,%esp
 5cb:	83 f8 ff             	cmp    $0xffffffff,%eax
 5ce:	74 1c                	je     5ec <malloc+0x80>
 5d0:	89 58 04             	mov    %ebx,0x4(%eax)
 5d3:	83 ec 0c             	sub    $0xc,%esp
 5d6:	83 c0 08             	add    $0x8,%eax
 5d9:	50                   	push   %eax
 5da:	e8 05 ff ff ff       	call   4e4 <free>
 5df:	8b 15 cc 06 00 00    	mov    0x6cc,%edx
 5e5:	83 c4 10             	add    $0x10,%esp
 5e8:	85 d2                	test   %edx,%edx
 5ea:	75 c2                	jne    5ae <malloc+0x42>
 5ec:	31 c0                	xor    %eax,%eax
 5ee:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5f1:	5b                   	pop    %ebx
 5f2:	5e                   	pop    %esi
 5f3:	5f                   	pop    %edi
 5f4:	5d                   	pop    %ebp
 5f5:	c3                   	ret    
 5f6:	66 90                	xchg   %ax,%ax
 5f8:	39 cf                	cmp    %ecx,%edi
 5fa:	74 4c                	je     648 <malloc+0xdc>
 5fc:	29 f9                	sub    %edi,%ecx
 5fe:	89 48 04             	mov    %ecx,0x4(%eax)
 601:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 604:	89 78 04             	mov    %edi,0x4(%eax)
 607:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 60d:	83 c0 08             	add    $0x8,%eax
 610:	8d 65 f4             	lea    -0xc(%ebp),%esp
 613:	5b                   	pop    %ebx
 614:	5e                   	pop    %esi
 615:	5f                   	pop    %edi
 616:	5d                   	pop    %ebp
 617:	c3                   	ret    
 618:	bb 00 10 00 00       	mov    $0x1000,%ebx
 61d:	eb 81                	jmp    5a0 <malloc+0x34>
 61f:	90                   	nop
 620:	c7 05 cc 06 00 00 d0 	movl   $0x6d0,0x6cc
 627:	06 00 00 
 62a:	c7 05 d0 06 00 00 d0 	movl   $0x6d0,0x6d0
 631:	06 00 00 
 634:	c7 05 d4 06 00 00 00 	movl   $0x0,0x6d4
 63b:	00 00 00 
 63e:	b8 d0 06 00 00       	mov    $0x6d0,%eax
 643:	e9 4e ff ff ff       	jmp    596 <malloc+0x2a>
 648:	8b 08                	mov    (%eax),%ecx
 64a:	89 0a                	mov    %ecx,(%edx)
 64c:	eb b9                	jmp    607 <malloc+0x9b>
