
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 90 10 00       	mov    $0x109000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc d0 55 11 80       	mov    $0x801155d0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 80 2c 10 80       	mov    $0x80102c80,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax

80100034 <binit>:
80100034:	55                   	push   %ebp
80100035:	89 e5                	mov    %esp,%ebp
80100037:	53                   	push   %ebx
80100038:	83 ec 0c             	sub    $0xc,%esp
8010003b:	68 00 6b 10 80       	push   $0x80106b00
80100040:	68 20 a5 10 80       	push   $0x8010a520
80100045:	e8 02 3f 00 00       	call   80103f4c <initlock>
8010004a:	c7 05 6c ec 10 80 1c 	movl   $0x8010ec1c,0x8010ec6c
80100051:	ec 10 80 
80100054:	c7 05 70 ec 10 80 1c 	movl   $0x8010ec1c,0x8010ec70
8010005b:	ec 10 80 
8010005e:	83 c4 10             	add    $0x10,%esp
80100061:	b8 1c ec 10 80       	mov    $0x8010ec1c,%eax
80100066:	bb 54 a5 10 80       	mov    $0x8010a554,%ebx
8010006b:	eb 05                	jmp    80100072 <binit+0x3e>
8010006d:	8d 76 00             	lea    0x0(%esi),%esi
80100070:	89 d3                	mov    %edx,%ebx
80100072:	89 43 54             	mov    %eax,0x54(%ebx)
80100075:	c7 43 50 1c ec 10 80 	movl   $0x8010ec1c,0x50(%ebx)
8010007c:	83 ec 08             	sub    $0x8,%esp
8010007f:	68 07 6b 10 80       	push   $0x80106b07
80100084:	8d 43 0c             	lea    0xc(%ebx),%eax
80100087:	50                   	push   %eax
80100088:	e8 b3 3d 00 00       	call   80103e40 <initsleeplock>
8010008d:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
80100092:	89 58 50             	mov    %ebx,0x50(%eax)
80100095:	89 1d 70 ec 10 80    	mov    %ebx,0x8010ec70
8010009b:	8d 93 5c 02 00 00    	lea    0x25c(%ebx),%edx
801000a1:	89 d8                	mov    %ebx,%eax
801000a3:	83 c4 10             	add    $0x10,%esp
801000a6:	81 fb c0 e9 10 80    	cmp    $0x8010e9c0,%ebx
801000ac:	75 c2                	jne    80100070 <binit+0x3c>
801000ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000b1:	c9                   	leave  
801000b2:	c3                   	ret    
801000b3:	90                   	nop

801000b4 <bread>:
801000b4:	55                   	push   %ebp
801000b5:	89 e5                	mov    %esp,%ebp
801000b7:	57                   	push   %edi
801000b8:	56                   	push   %esi
801000b9:	53                   	push   %ebx
801000ba:	83 ec 18             	sub    $0x18,%esp
801000bd:	8b 75 08             	mov    0x8(%ebp),%esi
801000c0:	8b 7d 0c             	mov    0xc(%ebp),%edi
801000c3:	68 20 a5 10 80       	push   $0x8010a520
801000c8:	e8 3f 40 00 00       	call   8010410c <acquire>
801000cd:	8b 1d 70 ec 10 80    	mov    0x8010ec70,%ebx
801000d3:	83 c4 10             	add    $0x10,%esp
801000d6:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
801000dc:	75 0d                	jne    801000eb <bread+0x37>
801000de:	eb 1c                	jmp    801000fc <bread+0x48>
801000e0:	8b 5b 54             	mov    0x54(%ebx),%ebx
801000e3:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
801000e9:	74 11                	je     801000fc <bread+0x48>
801000eb:	3b 73 04             	cmp    0x4(%ebx),%esi
801000ee:	75 f0                	jne    801000e0 <bread+0x2c>
801000f0:	3b 7b 08             	cmp    0x8(%ebx),%edi
801000f3:	75 eb                	jne    801000e0 <bread+0x2c>
801000f5:	ff 43 4c             	incl   0x4c(%ebx)
801000f8:	eb 3c                	jmp    80100136 <bread+0x82>
801000fa:	66 90                	xchg   %ax,%ax
801000fc:	8b 1d 6c ec 10 80    	mov    0x8010ec6c,%ebx
80100102:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
80100108:	75 0d                	jne    80100117 <bread+0x63>
8010010a:	eb 6a                	jmp    80100176 <bread+0xc2>
8010010c:	8b 5b 50             	mov    0x50(%ebx),%ebx
8010010f:	81 fb 1c ec 10 80    	cmp    $0x8010ec1c,%ebx
80100115:	74 5f                	je     80100176 <bread+0xc2>
80100117:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010011a:	85 c0                	test   %eax,%eax
8010011c:	75 ee                	jne    8010010c <bread+0x58>
8010011e:	f6 03 04             	testb  $0x4,(%ebx)
80100121:	75 e9                	jne    8010010c <bread+0x58>
80100123:	89 73 04             	mov    %esi,0x4(%ebx)
80100126:	89 7b 08             	mov    %edi,0x8(%ebx)
80100129:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
8010012f:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
80100136:	83 ec 0c             	sub    $0xc,%esp
80100139:	68 20 a5 10 80       	push   $0x8010a520
8010013e:	e8 69 3f 00 00       	call   801040ac <release>
80100143:	8d 43 0c             	lea    0xc(%ebx),%eax
80100146:	89 04 24             	mov    %eax,(%esp)
80100149:	e8 26 3d 00 00       	call   80103e74 <acquiresleep>
8010014e:	83 c4 10             	add    $0x10,%esp
80100151:	f6 03 02             	testb  $0x2,(%ebx)
80100154:	74 0a                	je     80100160 <bread+0xac>
80100156:	89 d8                	mov    %ebx,%eax
80100158:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010015b:	5b                   	pop    %ebx
8010015c:	5e                   	pop    %esi
8010015d:	5f                   	pop    %edi
8010015e:	5d                   	pop    %ebp
8010015f:	c3                   	ret    
80100160:	83 ec 0c             	sub    $0xc,%esp
80100163:	53                   	push   %ebx
80100164:	e8 1b 1f 00 00       	call   80102084 <iderw>
80100169:	83 c4 10             	add    $0x10,%esp
8010016c:	89 d8                	mov    %ebx,%eax
8010016e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100171:	5b                   	pop    %ebx
80100172:	5e                   	pop    %esi
80100173:	5f                   	pop    %edi
80100174:	5d                   	pop    %ebp
80100175:	c3                   	ret    
80100176:	83 ec 0c             	sub    $0xc,%esp
80100179:	68 0e 6b 10 80       	push   $0x80106b0e
8010017e:	e8 b5 01 00 00       	call   80100338 <panic>
80100183:	90                   	nop

80100184 <bwrite>:
80100184:	55                   	push   %ebp
80100185:	89 e5                	mov    %esp,%ebp
80100187:	53                   	push   %ebx
80100188:	83 ec 10             	sub    $0x10,%esp
8010018b:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010018e:	8d 43 0c             	lea    0xc(%ebx),%eax
80100191:	50                   	push   %eax
80100192:	e8 6d 3d 00 00       	call   80103f04 <holdingsleep>
80100197:	83 c4 10             	add    $0x10,%esp
8010019a:	85 c0                	test   %eax,%eax
8010019c:	74 0f                	je     801001ad <bwrite+0x29>
8010019e:	83 0b 04             	orl    $0x4,(%ebx)
801001a1:	89 5d 08             	mov    %ebx,0x8(%ebp)
801001a4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001a7:	c9                   	leave  
801001a8:	e9 d7 1e 00 00       	jmp    80102084 <iderw>
801001ad:	83 ec 0c             	sub    $0xc,%esp
801001b0:	68 1f 6b 10 80       	push   $0x80106b1f
801001b5:	e8 7e 01 00 00       	call   80100338 <panic>
801001ba:	66 90                	xchg   %ax,%ax

801001bc <brelse>:
801001bc:	55                   	push   %ebp
801001bd:	89 e5                	mov    %esp,%ebp
801001bf:	56                   	push   %esi
801001c0:	53                   	push   %ebx
801001c1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801001c4:	8d 73 0c             	lea    0xc(%ebx),%esi
801001c7:	83 ec 0c             	sub    $0xc,%esp
801001ca:	56                   	push   %esi
801001cb:	e8 34 3d 00 00       	call   80103f04 <holdingsleep>
801001d0:	83 c4 10             	add    $0x10,%esp
801001d3:	85 c0                	test   %eax,%eax
801001d5:	74 61                	je     80100238 <brelse+0x7c>
801001d7:	83 ec 0c             	sub    $0xc,%esp
801001da:	56                   	push   %esi
801001db:	e8 e8 3c 00 00       	call   80103ec8 <releasesleep>
801001e0:	c7 04 24 20 a5 10 80 	movl   $0x8010a520,(%esp)
801001e7:	e8 20 3f 00 00       	call   8010410c <acquire>
801001ec:	8b 43 4c             	mov    0x4c(%ebx),%eax
801001ef:	48                   	dec    %eax
801001f0:	89 43 4c             	mov    %eax,0x4c(%ebx)
801001f3:	83 c4 10             	add    $0x10,%esp
801001f6:	85 c0                	test   %eax,%eax
801001f8:	75 2c                	jne    80100226 <brelse+0x6a>
801001fa:	8b 53 54             	mov    0x54(%ebx),%edx
801001fd:	8b 43 50             	mov    0x50(%ebx),%eax
80100200:	89 42 50             	mov    %eax,0x50(%edx)
80100203:	8b 53 54             	mov    0x54(%ebx),%edx
80100206:	89 50 54             	mov    %edx,0x54(%eax)
80100209:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
8010020e:	89 43 54             	mov    %eax,0x54(%ebx)
80100211:	c7 43 50 1c ec 10 80 	movl   $0x8010ec1c,0x50(%ebx)
80100218:	a1 70 ec 10 80       	mov    0x8010ec70,%eax
8010021d:	89 58 50             	mov    %ebx,0x50(%eax)
80100220:	89 1d 70 ec 10 80    	mov    %ebx,0x8010ec70
80100226:	c7 45 08 20 a5 10 80 	movl   $0x8010a520,0x8(%ebp)
8010022d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100230:	5b                   	pop    %ebx
80100231:	5e                   	pop    %esi
80100232:	5d                   	pop    %ebp
80100233:	e9 74 3e 00 00       	jmp    801040ac <release>
80100238:	83 ec 0c             	sub    $0xc,%esp
8010023b:	68 26 6b 10 80       	push   $0x80106b26
80100240:	e8 f3 00 00 00       	call   80100338 <panic>
80100245:	66 90                	xchg   %ax,%ax
80100247:	90                   	nop

80100248 <consoleread>:
80100248:	55                   	push   %ebp
80100249:	89 e5                	mov    %esp,%ebp
8010024b:	57                   	push   %edi
8010024c:	56                   	push   %esi
8010024d:	53                   	push   %ebx
8010024e:	83 ec 18             	sub    $0x18,%esp
80100251:	8b 7d 08             	mov    0x8(%ebp),%edi
80100254:	8b 5d 10             	mov    0x10(%ebp),%ebx
80100257:	57                   	push   %edi
80100258:	e8 7f 14 00 00       	call   801016dc <iunlock>
8010025d:	89 de                	mov    %ebx,%esi
8010025f:	c7 04 24 20 ef 10 80 	movl   $0x8010ef20,(%esp)
80100266:	e8 a1 3e 00 00       	call   8010410c <acquire>
8010026b:	83 c4 10             	add    $0x10,%esp
8010026e:	85 db                	test   %ebx,%ebx
80100270:	0f 8e 93 00 00 00    	jle    80100309 <consoleread+0xc1>
80100276:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
8010027b:	39 05 04 ef 10 80    	cmp    %eax,0x8010ef04
80100281:	74 27                	je     801002aa <consoleread+0x62>
80100283:	eb 57                	jmp    801002dc <consoleread+0x94>
80100285:	8d 76 00             	lea    0x0(%esi),%esi
80100288:	83 ec 08             	sub    $0x8,%esp
8010028b:	68 20 ef 10 80       	push   $0x8010ef20
80100290:	68 00 ef 10 80       	push   $0x8010ef00
80100295:	e8 6e 39 00 00       	call   80103c08 <sleep>
8010029a:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
8010029f:	83 c4 10             	add    $0x10,%esp
801002a2:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
801002a8:	75 32                	jne    801002dc <consoleread+0x94>
801002aa:	e8 65 32 00 00       	call   80103514 <myproc>
801002af:	8b 40 28             	mov    0x28(%eax),%eax
801002b2:	85 c0                	test   %eax,%eax
801002b4:	74 d2                	je     80100288 <consoleread+0x40>
801002b6:	83 ec 0c             	sub    $0xc,%esp
801002b9:	68 20 ef 10 80       	push   $0x8010ef20
801002be:	e8 e9 3d 00 00       	call   801040ac <release>
801002c3:	89 3c 24             	mov    %edi,(%esp)
801002c6:	e8 49 13 00 00       	call   80101614 <ilock>
801002cb:	83 c4 10             	add    $0x10,%esp
801002ce:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801002d3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801002d6:	5b                   	pop    %ebx
801002d7:	5e                   	pop    %esi
801002d8:	5f                   	pop    %edi
801002d9:	5d                   	pop    %ebp
801002da:	c3                   	ret    
801002db:	90                   	nop
801002dc:	8d 50 01             	lea    0x1(%eax),%edx
801002df:	89 15 00 ef 10 80    	mov    %edx,0x8010ef00
801002e5:	89 c2                	mov    %eax,%edx
801002e7:	83 e2 7f             	and    $0x7f,%edx
801002ea:	0f be 8a 80 ee 10 80 	movsbl -0x7fef1180(%edx),%ecx
801002f1:	80 f9 04             	cmp    $0x4,%cl
801002f4:	74 37                	je     8010032d <consoleread+0xe5>
801002f6:	ff 45 0c             	incl   0xc(%ebp)
801002f9:	8b 45 0c             	mov    0xc(%ebp),%eax
801002fc:	88 48 ff             	mov    %cl,-0x1(%eax)
801002ff:	4b                   	dec    %ebx
80100300:	83 f9 0a             	cmp    $0xa,%ecx
80100303:	0f 85 65 ff ff ff    	jne    8010026e <consoleread+0x26>
80100309:	83 ec 0c             	sub    $0xc,%esp
8010030c:	68 20 ef 10 80       	push   $0x8010ef20
80100311:	e8 96 3d 00 00       	call   801040ac <release>
80100316:	89 3c 24             	mov    %edi,(%esp)
80100319:	e8 f6 12 00 00       	call   80101614 <ilock>
8010031e:	89 f0                	mov    %esi,%eax
80100320:	29 d8                	sub    %ebx,%eax
80100322:	83 c4 10             	add    $0x10,%esp
80100325:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100328:	5b                   	pop    %ebx
80100329:	5e                   	pop    %esi
8010032a:	5f                   	pop    %edi
8010032b:	5d                   	pop    %ebp
8010032c:	c3                   	ret    
8010032d:	39 f3                	cmp    %esi,%ebx
8010032f:	73 d8                	jae    80100309 <consoleread+0xc1>
80100331:	a3 00 ef 10 80       	mov    %eax,0x8010ef00
80100336:	eb d1                	jmp    80100309 <consoleread+0xc1>

80100338 <panic>:
80100338:	55                   	push   %ebp
80100339:	89 e5                	mov    %esp,%ebp
8010033b:	56                   	push   %esi
8010033c:	53                   	push   %ebx
8010033d:	83 ec 30             	sub    $0x30,%esp
80100340:	fa                   	cli    
80100341:	c7 05 54 ef 10 80 00 	movl   $0x0,0x8010ef54
80100348:	00 00 00 
8010034b:	e8 9c 22 00 00       	call   801025ec <lapicid>
80100350:	83 ec 08             	sub    $0x8,%esp
80100353:	50                   	push   %eax
80100354:	68 2d 6b 10 80       	push   $0x80106b2d
80100359:	e8 ca 02 00 00       	call   80100628 <cprintf>
8010035e:	58                   	pop    %eax
8010035f:	ff 75 08             	pushl  0x8(%ebp)
80100362:	e8 c1 02 00 00       	call   80100628 <cprintf>
80100367:	c7 04 24 63 74 10 80 	movl   $0x80107463,(%esp)
8010036e:	e8 b5 02 00 00       	call   80100628 <cprintf>
80100373:	5a                   	pop    %edx
80100374:	59                   	pop    %ecx
80100375:	8d 5d d0             	lea    -0x30(%ebp),%ebx
80100378:	53                   	push   %ebx
80100379:	8d 45 08             	lea    0x8(%ebp),%eax
8010037c:	50                   	push   %eax
8010037d:	e8 e6 3b 00 00       	call   80103f68 <getcallerpcs>
80100382:	8d 75 f8             	lea    -0x8(%ebp),%esi
80100385:	83 c4 10             	add    $0x10,%esp
80100388:	83 ec 08             	sub    $0x8,%esp
8010038b:	ff 33                	pushl  (%ebx)
8010038d:	68 41 6b 10 80       	push   $0x80106b41
80100392:	e8 91 02 00 00       	call   80100628 <cprintf>
80100397:	83 c3 04             	add    $0x4,%ebx
8010039a:	83 c4 10             	add    $0x10,%esp
8010039d:	39 f3                	cmp    %esi,%ebx
8010039f:	75 e7                	jne    80100388 <panic+0x50>
801003a1:	c7 05 58 ef 10 80 01 	movl   $0x1,0x8010ef58
801003a8:	00 00 00 
801003ab:	eb fe                	jmp    801003ab <panic+0x73>
801003ad:	8d 76 00             	lea    0x0(%esi),%esi

801003b0 <consputc.part.0>:
801003b0:	55                   	push   %ebp
801003b1:	89 e5                	mov    %esp,%ebp
801003b3:	57                   	push   %edi
801003b4:	56                   	push   %esi
801003b5:	53                   	push   %ebx
801003b6:	83 ec 1c             	sub    $0x1c,%esp
801003b9:	3d 00 01 00 00       	cmp    $0x100,%eax
801003be:	0f 84 b4 00 00 00    	je     80100478 <consputc.part.0+0xc8>
801003c4:	89 c6                	mov    %eax,%esi
801003c6:	83 ec 0c             	sub    $0xc,%esp
801003c9:	50                   	push   %eax
801003ca:	e8 65 52 00 00       	call   80105634 <uartputc>
801003cf:	bf d4 03 00 00       	mov    $0x3d4,%edi
801003d4:	b0 0e                	mov    $0xe,%al
801003d6:	89 fa                	mov    %edi,%edx
801003d8:	ee                   	out    %al,(%dx)
801003d9:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
801003de:	89 ca                	mov    %ecx,%edx
801003e0:	ec                   	in     (%dx),%al
801003e1:	0f b6 d8             	movzbl %al,%ebx
801003e4:	c1 e3 08             	shl    $0x8,%ebx
801003e7:	b0 0f                	mov    $0xf,%al
801003e9:	89 fa                	mov    %edi,%edx
801003eb:	ee                   	out    %al,(%dx)
801003ec:	89 ca                	mov    %ecx,%edx
801003ee:	ec                   	in     (%dx),%al
801003ef:	0f b6 c8             	movzbl %al,%ecx
801003f2:	09 d9                	or     %ebx,%ecx
801003f4:	83 c4 10             	add    $0x10,%esp
801003f7:	83 fe 0a             	cmp    $0xa,%esi
801003fa:	75 64                	jne    80100460 <consputc.part.0+0xb0>
801003fc:	bb 50 00 00 00       	mov    $0x50,%ebx
80100401:	89 c8                	mov    %ecx,%eax
80100403:	99                   	cltd   
80100404:	f7 fb                	idiv   %ebx
80100406:	29 d3                	sub    %edx,%ebx
80100408:	01 cb                	add    %ecx,%ebx
8010040a:	81 fb d0 07 00 00    	cmp    $0x7d0,%ebx
80100410:	0f 8f 0e 01 00 00    	jg     80100524 <consputc.part.0+0x174>
80100416:	81 fb 7f 07 00 00    	cmp    $0x77f,%ebx
8010041c:	0f 8f aa 00 00 00    	jg     801004cc <consputc.part.0+0x11c>
80100422:	0f b6 c7             	movzbl %bh,%eax
80100425:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100428:	88 d9                	mov    %bl,%cl
8010042a:	01 db                	add    %ebx,%ebx
8010042c:	8d bb 00 80 0b 80    	lea    -0x7ff48000(%ebx),%edi
80100432:	be d4 03 00 00       	mov    $0x3d4,%esi
80100437:	b0 0e                	mov    $0xe,%al
80100439:	89 f2                	mov    %esi,%edx
8010043b:	ee                   	out    %al,(%dx)
8010043c:	bb d5 03 00 00       	mov    $0x3d5,%ebx
80100441:	8a 45 e4             	mov    -0x1c(%ebp),%al
80100444:	89 da                	mov    %ebx,%edx
80100446:	ee                   	out    %al,(%dx)
80100447:	b0 0f                	mov    $0xf,%al
80100449:	89 f2                	mov    %esi,%edx
8010044b:	ee                   	out    %al,(%dx)
8010044c:	88 c8                	mov    %cl,%al
8010044e:	89 da                	mov    %ebx,%edx
80100450:	ee                   	out    %al,(%dx)
80100451:	66 c7 07 20 07       	movw   $0x720,(%edi)
80100456:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100459:	5b                   	pop    %ebx
8010045a:	5e                   	pop    %esi
8010045b:	5f                   	pop    %edi
8010045c:	5d                   	pop    %ebp
8010045d:	c3                   	ret    
8010045e:	66 90                	xchg   %ax,%ax
80100460:	8d 59 01             	lea    0x1(%ecx),%ebx
80100463:	89 f0                	mov    %esi,%eax
80100465:	0f b6 f0             	movzbl %al,%esi
80100468:	81 ce 00 07 00 00    	or     $0x700,%esi
8010046e:	66 89 b4 09 00 80 0b 	mov    %si,-0x7ff48000(%ecx,%ecx,1)
80100475:	80 
80100476:	eb 92                	jmp    8010040a <consputc.part.0+0x5a>
80100478:	83 ec 0c             	sub    $0xc,%esp
8010047b:	6a 08                	push   $0x8
8010047d:	e8 b2 51 00 00       	call   80105634 <uartputc>
80100482:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
80100489:	e8 a6 51 00 00       	call   80105634 <uartputc>
8010048e:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
80100495:	e8 9a 51 00 00       	call   80105634 <uartputc>
8010049a:	be d4 03 00 00       	mov    $0x3d4,%esi
8010049f:	b0 0e                	mov    $0xe,%al
801004a1:	89 f2                	mov    %esi,%edx
801004a3:	ee                   	out    %al,(%dx)
801004a4:	bb d5 03 00 00       	mov    $0x3d5,%ebx
801004a9:	89 da                	mov    %ebx,%edx
801004ab:	ec                   	in     (%dx),%al
801004ac:	0f b6 c8             	movzbl %al,%ecx
801004af:	c1 e1 08             	shl    $0x8,%ecx
801004b2:	b0 0f                	mov    $0xf,%al
801004b4:	89 f2                	mov    %esi,%edx
801004b6:	ee                   	out    %al,(%dx)
801004b7:	89 da                	mov    %ebx,%edx
801004b9:	ec                   	in     (%dx),%al
801004ba:	0f b6 d8             	movzbl %al,%ebx
801004bd:	83 c4 10             	add    $0x10,%esp
801004c0:	09 cb                	or     %ecx,%ebx
801004c2:	74 50                	je     80100514 <consputc.part.0+0x164>
801004c4:	4b                   	dec    %ebx
801004c5:	e9 40 ff ff ff       	jmp    8010040a <consputc.part.0+0x5a>
801004ca:	66 90                	xchg   %ax,%ax
801004cc:	50                   	push   %eax
801004cd:	68 60 0e 00 00       	push   $0xe60
801004d2:	68 a0 80 0b 80       	push   $0x800b80a0
801004d7:	68 00 80 0b 80       	push   $0x800b8000
801004dc:	e8 67 3d 00 00       	call   80104248 <memmove>
801004e1:	8d 73 b0             	lea    -0x50(%ebx),%esi
801004e4:	8d 84 1b 60 ff ff ff 	lea    -0xa0(%ebx,%ebx,1),%eax
801004eb:	8d b8 00 80 0b 80    	lea    -0x7ff48000(%eax),%edi
801004f1:	83 c4 0c             	add    $0xc,%esp
801004f4:	b8 80 07 00 00       	mov    $0x780,%eax
801004f9:	29 f0                	sub    %esi,%eax
801004fb:	01 c0                	add    %eax,%eax
801004fd:	50                   	push   %eax
801004fe:	6a 00                	push   $0x0
80100500:	57                   	push   %edi
80100501:	e8 c6 3c 00 00       	call   801041cc <memset>
80100506:	89 f1                	mov    %esi,%ecx
80100508:	83 c4 10             	add    $0x10,%esp
8010050b:	c6 45 e4 07          	movb   $0x7,-0x1c(%ebp)
8010050f:	e9 1e ff ff ff       	jmp    80100432 <consputc.part.0+0x82>
80100514:	bf 00 80 0b 80       	mov    $0x800b8000,%edi
80100519:	31 c9                	xor    %ecx,%ecx
8010051b:	c6 45 e4 00          	movb   $0x0,-0x1c(%ebp)
8010051f:	e9 0e ff ff ff       	jmp    80100432 <consputc.part.0+0x82>
80100524:	83 ec 0c             	sub    $0xc,%esp
80100527:	68 45 6b 10 80       	push   $0x80106b45
8010052c:	e8 07 fe ff ff       	call   80100338 <panic>
80100531:	8d 76 00             	lea    0x0(%esi),%esi

80100534 <consolewrite>:
80100534:	55                   	push   %ebp
80100535:	89 e5                	mov    %esp,%ebp
80100537:	57                   	push   %edi
80100538:	56                   	push   %esi
80100539:	53                   	push   %ebx
8010053a:	83 ec 18             	sub    $0x18,%esp
8010053d:	8b 5d 10             	mov    0x10(%ebp),%ebx
80100540:	ff 75 08             	pushl  0x8(%ebp)
80100543:	e8 94 11 00 00       	call   801016dc <iunlock>
80100548:	c7 04 24 20 ef 10 80 	movl   $0x8010ef20,(%esp)
8010054f:	e8 b8 3b 00 00       	call   8010410c <acquire>
80100554:	83 c4 10             	add    $0x10,%esp
80100557:	85 db                	test   %ebx,%ebx
80100559:	7e 23                	jle    8010057e <consolewrite+0x4a>
8010055b:	8b 75 0c             	mov    0xc(%ebp),%esi
8010055e:	8d 3c 1e             	lea    (%esi,%ebx,1),%edi
80100561:	0f b6 06             	movzbl (%esi),%eax
80100564:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
8010056a:	85 d2                	test   %edx,%edx
8010056c:	74 06                	je     80100574 <consolewrite+0x40>
8010056e:	fa                   	cli    
8010056f:	eb fe                	jmp    8010056f <consolewrite+0x3b>
80100571:	8d 76 00             	lea    0x0(%esi),%esi
80100574:	e8 37 fe ff ff       	call   801003b0 <consputc.part.0>
80100579:	46                   	inc    %esi
8010057a:	39 f7                	cmp    %esi,%edi
8010057c:	75 e3                	jne    80100561 <consolewrite+0x2d>
8010057e:	83 ec 0c             	sub    $0xc,%esp
80100581:	68 20 ef 10 80       	push   $0x8010ef20
80100586:	e8 21 3b 00 00       	call   801040ac <release>
8010058b:	58                   	pop    %eax
8010058c:	ff 75 08             	pushl  0x8(%ebp)
8010058f:	e8 80 10 00 00       	call   80101614 <ilock>
80100594:	89 d8                	mov    %ebx,%eax
80100596:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100599:	5b                   	pop    %ebx
8010059a:	5e                   	pop    %esi
8010059b:	5f                   	pop    %edi
8010059c:	5d                   	pop    %ebp
8010059d:	c3                   	ret    
8010059e:	66 90                	xchg   %ax,%ax

801005a0 <printint>:
801005a0:	55                   	push   %ebp
801005a1:	89 e5                	mov    %esp,%ebp
801005a3:	57                   	push   %edi
801005a4:	56                   	push   %esi
801005a5:	53                   	push   %ebx
801005a6:	83 ec 2c             	sub    $0x2c,%esp
801005a9:	89 c6                	mov    %eax,%esi
801005ab:	89 d3                	mov    %edx,%ebx
801005ad:	85 c9                	test   %ecx,%ecx
801005af:	74 04                	je     801005b5 <printint+0x15>
801005b1:	85 c0                	test   %eax,%eax
801005b3:	78 63                	js     80100618 <printint+0x78>
801005b5:	89 f1                	mov    %esi,%ecx
801005b7:	31 c0                	xor    %eax,%eax
801005b9:	31 f6                	xor    %esi,%esi
801005bb:	89 45 d0             	mov    %eax,-0x30(%ebp)
801005be:	66 90                	xchg   %ax,%ax
801005c0:	89 c8                	mov    %ecx,%eax
801005c2:	31 d2                	xor    %edx,%edx
801005c4:	f7 f3                	div    %ebx
801005c6:	89 f7                	mov    %esi,%edi
801005c8:	8d 76 01             	lea    0x1(%esi),%esi
801005cb:	8a 92 70 6b 10 80    	mov    -0x7fef9490(%edx),%dl
801005d1:	88 55 d7             	mov    %dl,-0x29(%ebp)
801005d4:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
801005d8:	89 ca                	mov    %ecx,%edx
801005da:	89 c1                	mov    %eax,%ecx
801005dc:	39 da                	cmp    %ebx,%edx
801005de:	73 e0                	jae    801005c0 <printint+0x20>
801005e0:	8b 45 d0             	mov    -0x30(%ebp),%eax
801005e3:	85 c0                	test   %eax,%eax
801005e5:	74 07                	je     801005ee <printint+0x4e>
801005e7:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
801005ec:	89 f7                	mov    %esi,%edi
801005ee:	8d 75 d8             	lea    -0x28(%ebp),%esi
801005f1:	8d 5c 3d d8          	lea    -0x28(%ebp,%edi,1),%ebx
801005f5:	0f be 03             	movsbl (%ebx),%eax
801005f8:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
801005fe:	85 d2                	test   %edx,%edx
80100600:	74 06                	je     80100608 <printint+0x68>
80100602:	fa                   	cli    
80100603:	eb fe                	jmp    80100603 <printint+0x63>
80100605:	8d 76 00             	lea    0x0(%esi),%esi
80100608:	e8 a3 fd ff ff       	call   801003b0 <consputc.part.0>
8010060d:	8d 43 ff             	lea    -0x1(%ebx),%eax
80100610:	39 f3                	cmp    %esi,%ebx
80100612:	74 0c                	je     80100620 <printint+0x80>
80100614:	89 c3                	mov    %eax,%ebx
80100616:	eb dd                	jmp    801005f5 <printint+0x55>
80100618:	89 c8                	mov    %ecx,%eax
8010061a:	f7 de                	neg    %esi
8010061c:	89 f1                	mov    %esi,%ecx
8010061e:	eb 99                	jmp    801005b9 <printint+0x19>
80100620:	83 c4 2c             	add    $0x2c,%esp
80100623:	5b                   	pop    %ebx
80100624:	5e                   	pop    %esi
80100625:	5f                   	pop    %edi
80100626:	5d                   	pop    %ebp
80100627:	c3                   	ret    

80100628 <cprintf>:
80100628:	55                   	push   %ebp
80100629:	89 e5                	mov    %esp,%ebp
8010062b:	57                   	push   %edi
8010062c:	56                   	push   %esi
8010062d:	53                   	push   %ebx
8010062e:	83 ec 1c             	sub    $0x1c,%esp
80100631:	8b 3d 54 ef 10 80    	mov    0x8010ef54,%edi
80100637:	8b 75 08             	mov    0x8(%ebp),%esi
8010063a:	85 ff                	test   %edi,%edi
8010063c:	0f 85 1e 01 00 00    	jne    80100760 <cprintf+0x138>
80100642:	85 f6                	test   %esi,%esi
80100644:	0f 84 bc 01 00 00    	je     80100806 <cprintf+0x1de>
8010064a:	0f b6 06             	movzbl (%esi),%eax
8010064d:	85 c0                	test   %eax,%eax
8010064f:	74 67                	je     801006b8 <cprintf+0x90>
80100651:	8d 55 0c             	lea    0xc(%ebp),%edx
80100654:	31 db                	xor    %ebx,%ebx
80100656:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80100659:	89 d7                	mov    %edx,%edi
8010065b:	83 f8 25             	cmp    $0x25,%eax
8010065e:	0f 85 c4 00 00 00    	jne    80100728 <cprintf+0x100>
80100664:	43                   	inc    %ebx
80100665:	0f b6 0c 1e          	movzbl (%esi,%ebx,1),%ecx
80100669:	85 c9                	test   %ecx,%ecx
8010066b:	74 40                	je     801006ad <cprintf+0x85>
8010066d:	83 f9 70             	cmp    $0x70,%ecx
80100670:	0f 84 8b 00 00 00    	je     80100701 <cprintf+0xd9>
80100676:	7f 48                	jg     801006c0 <cprintf+0x98>
80100678:	83 f9 25             	cmp    $0x25,%ecx
8010067b:	0f 84 b7 00 00 00    	je     80100738 <cprintf+0x110>
80100681:	83 f9 64             	cmp    $0x64,%ecx
80100684:	0f 85 0e 01 00 00    	jne    80100798 <cprintf+0x170>
8010068a:	8d 47 04             	lea    0x4(%edi),%eax
8010068d:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100690:	8b 07                	mov    (%edi),%eax
80100692:	b9 01 00 00 00       	mov    $0x1,%ecx
80100697:	ba 0a 00 00 00       	mov    $0xa,%edx
8010069c:	e8 ff fe ff ff       	call   801005a0 <printint>
801006a1:	8b 7d e0             	mov    -0x20(%ebp),%edi
801006a4:	43                   	inc    %ebx
801006a5:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
801006a9:	85 c0                	test   %eax,%eax
801006ab:	75 ae                	jne    8010065b <cprintf+0x33>
801006ad:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801006b0:	85 ff                	test   %edi,%edi
801006b2:	0f 85 cb 00 00 00    	jne    80100783 <cprintf+0x15b>
801006b8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801006bb:	5b                   	pop    %ebx
801006bc:	5e                   	pop    %esi
801006bd:	5f                   	pop    %edi
801006be:	5d                   	pop    %ebp
801006bf:	c3                   	ret    
801006c0:	83 f9 73             	cmp    $0x73,%ecx
801006c3:	75 33                	jne    801006f8 <cprintf+0xd0>
801006c5:	8d 47 04             	lea    0x4(%edi),%eax
801006c8:	8b 17                	mov    (%edi),%edx
801006ca:	85 d2                	test   %edx,%edx
801006cc:	0f 85 f6 00 00 00    	jne    801007c8 <cprintf+0x1a0>
801006d2:	b1 28                	mov    $0x28,%cl
801006d4:	bf 58 6b 10 80       	mov    $0x80106b58,%edi
801006d9:	89 5d e0             	mov    %ebx,-0x20(%ebp)
801006dc:	89 fb                	mov    %edi,%ebx
801006de:	89 f7                	mov    %esi,%edi
801006e0:	89 c6                	mov    %eax,%esi
801006e2:	0f be c1             	movsbl %cl,%eax
801006e5:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
801006eb:	85 d2                	test   %edx,%edx
801006ed:	0f 84 e8 00 00 00    	je     801007db <cprintf+0x1b3>
801006f3:	fa                   	cli    
801006f4:	eb fe                	jmp    801006f4 <cprintf+0xcc>
801006f6:	66 90                	xchg   %ax,%ax
801006f8:	83 f9 78             	cmp    $0x78,%ecx
801006fb:	0f 85 97 00 00 00    	jne    80100798 <cprintf+0x170>
80100701:	8d 47 04             	lea    0x4(%edi),%eax
80100704:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100707:	8b 07                	mov    (%edi),%eax
80100709:	31 c9                	xor    %ecx,%ecx
8010070b:	ba 10 00 00 00       	mov    $0x10,%edx
80100710:	e8 8b fe ff ff       	call   801005a0 <printint>
80100715:	8b 7d e0             	mov    -0x20(%ebp),%edi
80100718:	43                   	inc    %ebx
80100719:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
8010071d:	85 c0                	test   %eax,%eax
8010071f:	0f 85 36 ff ff ff    	jne    8010065b <cprintf+0x33>
80100725:	eb 86                	jmp    801006ad <cprintf+0x85>
80100727:	90                   	nop
80100728:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
8010072e:	85 c9                	test   %ecx,%ecx
80100730:	74 15                	je     80100747 <cprintf+0x11f>
80100732:	fa                   	cli    
80100733:	eb fe                	jmp    80100733 <cprintf+0x10b>
80100735:	8d 76 00             	lea    0x0(%esi),%esi
80100738:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
8010073e:	85 c9                	test   %ecx,%ecx
80100740:	75 7e                	jne    801007c0 <cprintf+0x198>
80100742:	b8 25 00 00 00       	mov    $0x25,%eax
80100747:	e8 64 fc ff ff       	call   801003b0 <consputc.part.0>
8010074c:	43                   	inc    %ebx
8010074d:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
80100751:	85 c0                	test   %eax,%eax
80100753:	0f 85 02 ff ff ff    	jne    8010065b <cprintf+0x33>
80100759:	e9 4f ff ff ff       	jmp    801006ad <cprintf+0x85>
8010075e:	66 90                	xchg   %ax,%ax
80100760:	83 ec 0c             	sub    $0xc,%esp
80100763:	68 20 ef 10 80       	push   $0x8010ef20
80100768:	e8 9f 39 00 00       	call   8010410c <acquire>
8010076d:	83 c4 10             	add    $0x10,%esp
80100770:	85 f6                	test   %esi,%esi
80100772:	0f 84 8e 00 00 00    	je     80100806 <cprintf+0x1de>
80100778:	0f b6 06             	movzbl (%esi),%eax
8010077b:	85 c0                	test   %eax,%eax
8010077d:	0f 85 ce fe ff ff    	jne    80100651 <cprintf+0x29>
80100783:	83 ec 0c             	sub    $0xc,%esp
80100786:	68 20 ef 10 80       	push   $0x8010ef20
8010078b:	e8 1c 39 00 00       	call   801040ac <release>
80100790:	83 c4 10             	add    $0x10,%esp
80100793:	e9 20 ff ff ff       	jmp    801006b8 <cprintf+0x90>
80100798:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
8010079e:	85 d2                	test   %edx,%edx
801007a0:	75 22                	jne    801007c4 <cprintf+0x19c>
801007a2:	89 4d e0             	mov    %ecx,-0x20(%ebp)
801007a5:	b8 25 00 00 00       	mov    $0x25,%eax
801007aa:	e8 01 fc ff ff       	call   801003b0 <consputc.part.0>
801007af:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
801007b4:	85 c0                	test   %eax,%eax
801007b6:	8b 4d e0             	mov    -0x20(%ebp),%ecx
801007b9:	74 3f                	je     801007fa <cprintf+0x1d2>
801007bb:	fa                   	cli    
801007bc:	eb fe                	jmp    801007bc <cprintf+0x194>
801007be:	66 90                	xchg   %ax,%ax
801007c0:	fa                   	cli    
801007c1:	eb fe                	jmp    801007c1 <cprintf+0x199>
801007c3:	90                   	nop
801007c4:	fa                   	cli    
801007c5:	eb fe                	jmp    801007c5 <cprintf+0x19d>
801007c7:	90                   	nop
801007c8:	89 d7                	mov    %edx,%edi
801007ca:	8a 0a                	mov    (%edx),%cl
801007cc:	84 c9                	test   %cl,%cl
801007ce:	0f 85 05 ff ff ff    	jne    801006d9 <cprintf+0xb1>
801007d4:	89 c7                	mov    %eax,%edi
801007d6:	e9 c9 fe ff ff       	jmp    801006a4 <cprintf+0x7c>
801007db:	e8 d0 fb ff ff       	call   801003b0 <consputc.part.0>
801007e0:	43                   	inc    %ebx
801007e1:	0f be 03             	movsbl (%ebx),%eax
801007e4:	84 c0                	test   %al,%al
801007e6:	0f 85 f9 fe ff ff    	jne    801006e5 <cprintf+0xbd>
801007ec:	8b 5d e0             	mov    -0x20(%ebp),%ebx
801007ef:	89 f0                	mov    %esi,%eax
801007f1:	89 fe                	mov    %edi,%esi
801007f3:	89 c7                	mov    %eax,%edi
801007f5:	e9 aa fe ff ff       	jmp    801006a4 <cprintf+0x7c>
801007fa:	89 c8                	mov    %ecx,%eax
801007fc:	e8 af fb ff ff       	call   801003b0 <consputc.part.0>
80100801:	e9 9e fe ff ff       	jmp    801006a4 <cprintf+0x7c>
80100806:	83 ec 0c             	sub    $0xc,%esp
80100809:	68 5f 6b 10 80       	push   $0x80106b5f
8010080e:	e8 25 fb ff ff       	call   80100338 <panic>
80100813:	90                   	nop

80100814 <consoleintr>:
80100814:	55                   	push   %ebp
80100815:	89 e5                	mov    %esp,%ebp
80100817:	57                   	push   %edi
80100818:	56                   	push   %esi
80100819:	53                   	push   %ebx
8010081a:	83 ec 28             	sub    $0x28,%esp
8010081d:	8b 7d 08             	mov    0x8(%ebp),%edi
80100820:	68 20 ef 10 80       	push   $0x8010ef20
80100825:	e8 e2 38 00 00       	call   8010410c <acquire>
8010082a:	83 c4 10             	add    $0x10,%esp
8010082d:	31 f6                	xor    %esi,%esi
8010082f:	eb 1a                	jmp    8010084b <consoleintr+0x37>
80100831:	8d 76 00             	lea    0x0(%esi),%esi
80100834:	83 f8 08             	cmp    $0x8,%eax
80100837:	0f 84 e7 00 00 00    	je     80100924 <consoleintr+0x110>
8010083d:	83 f8 10             	cmp    $0x10,%eax
80100840:	0f 85 39 01 00 00    	jne    8010097f <consoleintr+0x16b>
80100846:	be 01 00 00 00       	mov    $0x1,%esi
8010084b:	ff d7                	call   *%edi
8010084d:	85 c0                	test   %eax,%eax
8010084f:	0f 88 f3 00 00 00    	js     80100948 <consoleintr+0x134>
80100855:	83 f8 15             	cmp    $0x15,%eax
80100858:	0f 84 8d 00 00 00    	je     801008eb <consoleintr+0xd7>
8010085e:	7e d4                	jle    80100834 <consoleintr+0x20>
80100860:	83 f8 7f             	cmp    $0x7f,%eax
80100863:	0f 84 bb 00 00 00    	je     80100924 <consoleintr+0x110>
80100869:	8b 1d 08 ef 10 80    	mov    0x8010ef08,%ebx
8010086f:	89 da                	mov    %ebx,%edx
80100871:	2b 15 00 ef 10 80    	sub    0x8010ef00,%edx
80100877:	83 fa 7f             	cmp    $0x7f,%edx
8010087a:	77 cf                	ja     8010084b <consoleintr+0x37>
8010087c:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
80100882:	89 da                	mov    %ebx,%edx
80100884:	83 e2 7f             	and    $0x7f,%edx
80100887:	43                   	inc    %ebx
80100888:	89 1d 08 ef 10 80    	mov    %ebx,0x8010ef08
8010088e:	88 82 80 ee 10 80    	mov    %al,-0x7fef1180(%edx)
80100894:	85 c9                	test   %ecx,%ecx
80100896:	0f 85 3d 01 00 00    	jne    801009d9 <consoleintr+0x1c5>
8010089c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010089f:	e8 0c fb ff ff       	call   801003b0 <consputc.part.0>
801008a4:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801008a7:	8b 0d 08 ef 10 80    	mov    0x8010ef08,%ecx
801008ad:	83 f8 0a             	cmp    $0xa,%eax
801008b0:	74 14                	je     801008c6 <consoleintr+0xb2>
801008b2:	83 f8 04             	cmp    $0x4,%eax
801008b5:	74 0f                	je     801008c6 <consoleintr+0xb2>
801008b7:	a1 00 ef 10 80       	mov    0x8010ef00,%eax
801008bc:	8d 90 80 00 00 00    	lea    0x80(%eax),%edx
801008c2:	39 ca                	cmp    %ecx,%edx
801008c4:	75 85                	jne    8010084b <consoleintr+0x37>
801008c6:	89 0d 04 ef 10 80    	mov    %ecx,0x8010ef04
801008cc:	83 ec 0c             	sub    $0xc,%esp
801008cf:	68 00 ef 10 80       	push   $0x8010ef00
801008d4:	e8 eb 33 00 00       	call   80103cc4 <wakeup>
801008d9:	83 c4 10             	add    $0x10,%esp
801008dc:	e9 6a ff ff ff       	jmp    8010084b <consoleintr+0x37>
801008e1:	b8 00 01 00 00       	mov    $0x100,%eax
801008e6:	e8 c5 fa ff ff       	call   801003b0 <consputc.part.0>
801008eb:	a1 08 ef 10 80       	mov    0x8010ef08,%eax
801008f0:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
801008f6:	0f 84 4f ff ff ff    	je     8010084b <consoleintr+0x37>
801008fc:	48                   	dec    %eax
801008fd:	89 c2                	mov    %eax,%edx
801008ff:	83 e2 7f             	and    $0x7f,%edx
80100902:	80 ba 80 ee 10 80 0a 	cmpb   $0xa,-0x7fef1180(%edx)
80100909:	0f 84 3c ff ff ff    	je     8010084b <consoleintr+0x37>
8010090f:	a3 08 ef 10 80       	mov    %eax,0x8010ef08
80100914:	8b 15 58 ef 10 80    	mov    0x8010ef58,%edx
8010091a:	85 d2                	test   %edx,%edx
8010091c:	74 c3                	je     801008e1 <consoleintr+0xcd>
8010091e:	fa                   	cli    
8010091f:	eb fe                	jmp    8010091f <consoleintr+0x10b>
80100921:	8d 76 00             	lea    0x0(%esi),%esi
80100924:	a1 08 ef 10 80       	mov    0x8010ef08,%eax
80100929:	3b 05 04 ef 10 80    	cmp    0x8010ef04,%eax
8010092f:	0f 84 16 ff ff ff    	je     8010084b <consoleintr+0x37>
80100935:	48                   	dec    %eax
80100936:	a3 08 ef 10 80       	mov    %eax,0x8010ef08
8010093b:	a1 58 ef 10 80       	mov    0x8010ef58,%eax
80100940:	85 c0                	test   %eax,%eax
80100942:	74 20                	je     80100964 <consoleintr+0x150>
80100944:	fa                   	cli    
80100945:	eb fe                	jmp    80100945 <consoleintr+0x131>
80100947:	90                   	nop
80100948:	83 ec 0c             	sub    $0xc,%esp
8010094b:	68 20 ef 10 80       	push   $0x8010ef20
80100950:	e8 57 37 00 00       	call   801040ac <release>
80100955:	83 c4 10             	add    $0x10,%esp
80100958:	85 f6                	test   %esi,%esi
8010095a:	75 17                	jne    80100973 <consoleintr+0x15f>
8010095c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010095f:	5b                   	pop    %ebx
80100960:	5e                   	pop    %esi
80100961:	5f                   	pop    %edi
80100962:	5d                   	pop    %ebp
80100963:	c3                   	ret    
80100964:	b8 00 01 00 00       	mov    $0x100,%eax
80100969:	e8 42 fa ff ff       	call   801003b0 <consputc.part.0>
8010096e:	e9 d8 fe ff ff       	jmp    8010084b <consoleintr+0x37>
80100973:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100976:	5b                   	pop    %ebx
80100977:	5e                   	pop    %esi
80100978:	5f                   	pop    %edi
80100979:	5d                   	pop    %ebp
8010097a:	e9 15 34 00 00       	jmp    80103d94 <procdump>
8010097f:	85 c0                	test   %eax,%eax
80100981:	0f 84 c4 fe ff ff    	je     8010084b <consoleintr+0x37>
80100987:	8b 1d 08 ef 10 80    	mov    0x8010ef08,%ebx
8010098d:	89 da                	mov    %ebx,%edx
8010098f:	2b 15 00 ef 10 80    	sub    0x8010ef00,%edx
80100995:	83 fa 7f             	cmp    $0x7f,%edx
80100998:	0f 87 ad fe ff ff    	ja     8010084b <consoleintr+0x37>
8010099e:	8b 0d 58 ef 10 80    	mov    0x8010ef58,%ecx
801009a4:	89 da                	mov    %ebx,%edx
801009a6:	83 e2 7f             	and    $0x7f,%edx
801009a9:	43                   	inc    %ebx
801009aa:	83 f8 0d             	cmp    $0xd,%eax
801009ad:	0f 85 d5 fe ff ff    	jne    80100888 <consoleintr+0x74>
801009b3:	89 1d 08 ef 10 80    	mov    %ebx,0x8010ef08
801009b9:	c6 82 80 ee 10 80 0a 	movb   $0xa,-0x7fef1180(%edx)
801009c0:	85 c9                	test   %ecx,%ecx
801009c2:	75 15                	jne    801009d9 <consoleintr+0x1c5>
801009c4:	b8 0a 00 00 00       	mov    $0xa,%eax
801009c9:	e8 e2 f9 ff ff       	call   801003b0 <consputc.part.0>
801009ce:	8b 0d 08 ef 10 80    	mov    0x8010ef08,%ecx
801009d4:	e9 ed fe ff ff       	jmp    801008c6 <consoleintr+0xb2>
801009d9:	fa                   	cli    
801009da:	eb fe                	jmp    801009da <consoleintr+0x1c6>

801009dc <consoleinit>:
801009dc:	55                   	push   %ebp
801009dd:	89 e5                	mov    %esp,%ebp
801009df:	83 ec 10             	sub    $0x10,%esp
801009e2:	68 68 6b 10 80       	push   $0x80106b68
801009e7:	68 20 ef 10 80       	push   $0x8010ef20
801009ec:	e8 5b 35 00 00       	call   80103f4c <initlock>
801009f1:	c7 05 0c f9 10 80 34 	movl   $0x80100534,0x8010f90c
801009f8:	05 10 80 
801009fb:	c7 05 08 f9 10 80 48 	movl   $0x80100248,0x8010f908
80100a02:	02 10 80 
80100a05:	c7 05 54 ef 10 80 01 	movl   $0x1,0x8010ef54
80100a0c:	00 00 00 
80100a0f:	58                   	pop    %eax
80100a10:	5a                   	pop    %edx
80100a11:	6a 00                	push   $0x0
80100a13:	6a 01                	push   $0x1
80100a15:	e8 ea 17 00 00       	call   80102204 <ioapicenable>
80100a1a:	83 c4 10             	add    $0x10,%esp
80100a1d:	c9                   	leave  
80100a1e:	c3                   	ret    
80100a1f:	90                   	nop

80100a20 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100a20:	55                   	push   %ebp
80100a21:	89 e5                	mov    %esp,%ebp
80100a23:	57                   	push   %edi
80100a24:	56                   	push   %esi
80100a25:	53                   	push   %ebx
80100a26:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100a2c:	e8 e3 2a 00 00       	call   80103514 <myproc>
80100a31:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)

  begin_op();
80100a37:	e8 90 1f 00 00       	call   801029cc <begin_op>

  if((ip = namei(path)) == 0){
80100a3c:	83 ec 0c             	sub    $0xc,%esp
80100a3f:	ff 75 08             	pushl  0x8(%ebp)
80100a42:	e8 59 14 00 00       	call   80101ea0 <namei>
80100a47:	83 c4 10             	add    $0x10,%esp
80100a4a:	85 c0                	test   %eax,%eax
80100a4c:	0f 84 10 03 00 00    	je     80100d62 <exec+0x342>
80100a52:	89 c7                	mov    %eax,%edi
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100a54:	83 ec 0c             	sub    $0xc,%esp
80100a57:	50                   	push   %eax
80100a58:	e8 b7 0b 00 00       	call   80101614 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100a5d:	6a 34                	push   $0x34
80100a5f:	6a 00                	push   $0x0
80100a61:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100a67:	50                   	push   %eax
80100a68:	57                   	push   %edi
80100a69:	e8 76 0e 00 00       	call   801018e4 <readi>
80100a6e:	83 c4 20             	add    $0x20,%esp
80100a71:	83 f8 34             	cmp    $0x34,%eax
80100a74:	0f 85 f9 00 00 00    	jne    80100b73 <exec+0x153>
    goto bad;
  if(elf.magic != ELF_MAGIC)
80100a7a:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
80100a81:	45 4c 46 
80100a84:	0f 85 e9 00 00 00    	jne    80100b73 <exec+0x153>
    goto bad;

  if((pgdir = setupkvm()) == 0)
80100a8a:	e8 59 5d 00 00       	call   801067e8 <setupkvm>
80100a8f:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)
80100a95:	85 c0                	test   %eax,%eax
80100a97:	0f 84 d6 00 00 00    	je     80100b73 <exec+0x153>
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100a9d:	8b b5 40 ff ff ff    	mov    -0xc0(%ebp),%esi
80100aa3:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
80100aaa:	00 
80100aab:	0f 84 81 02 00 00    	je     80100d32 <exec+0x312>
  sz = 0;
80100ab1:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100ab8:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100abb:	31 db                	xor    %ebx,%ebx
80100abd:	e9 84 00 00 00       	jmp    80100b46 <exec+0x126>
80100ac2:	66 90                	xchg   %ax,%ax
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
80100ac4:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100acb:	75 6a                	jne    80100b37 <exec+0x117>
      continue;
    if(ph.memsz < ph.filesz)
80100acd:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100ad3:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100ad9:	0f 82 83 00 00 00    	jb     80100b62 <exec+0x142>
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100adf:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100ae5:	72 7b                	jb     80100b62 <exec+0x142>
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100ae7:	51                   	push   %ecx
80100ae8:	50                   	push   %eax
80100ae9:	ff b5 f0 fe ff ff    	pushl  -0x110(%ebp)
80100aef:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100af5:	e8 62 5b 00 00       	call   8010665c <allocuvm>
80100afa:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100b00:	83 c4 10             	add    $0x10,%esp
80100b03:	85 c0                	test   %eax,%eax
80100b05:	74 5b                	je     80100b62 <exec+0x142>
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
80100b07:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100b0d:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100b12:	75 4e                	jne    80100b62 <exec+0x142>
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100b14:	83 ec 0c             	sub    $0xc,%esp
80100b17:	ff b5 14 ff ff ff    	pushl  -0xec(%ebp)
80100b1d:	ff b5 08 ff ff ff    	pushl  -0xf8(%ebp)
80100b23:	57                   	push   %edi
80100b24:	50                   	push   %eax
80100b25:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100b2b:	e8 68 5a 00 00       	call   80106598 <loaduvm>
80100b30:	83 c4 20             	add    $0x20,%esp
80100b33:	85 c0                	test   %eax,%eax
80100b35:	78 2b                	js     80100b62 <exec+0x142>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100b37:	43                   	inc    %ebx
80100b38:	83 c6 20             	add    $0x20,%esi
80100b3b:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80100b42:	39 d8                	cmp    %ebx,%eax
80100b44:	7e 4e                	jle    80100b94 <exec+0x174>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100b46:	6a 20                	push   $0x20
80100b48:	56                   	push   %esi
80100b49:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100b4f:	50                   	push   %eax
80100b50:	57                   	push   %edi
80100b51:	e8 8e 0d 00 00       	call   801018e4 <readi>
80100b56:	83 c4 10             	add    $0x10,%esp
80100b59:	83 f8 20             	cmp    $0x20,%eax
80100b5c:	0f 84 62 ff ff ff    	je     80100ac4 <exec+0xa4>
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
80100b62:	83 ec 0c             	sub    $0xc,%esp
80100b65:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100b6b:	e8 08 5c 00 00       	call   80106778 <freevm>
  if(ip){
80100b70:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80100b73:	83 ec 0c             	sub    $0xc,%esp
80100b76:	57                   	push   %edi
80100b77:	e8 ec 0c 00 00       	call   80101868 <iunlockput>
    end_op();
80100b7c:	e8 b3 1e 00 00       	call   80102a34 <end_op>
80100b81:	83 c4 10             	add    $0x10,%esp
    return -1;
80100b84:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  }
  return -1;
}
80100b89:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100b8c:	5b                   	pop    %ebx
80100b8d:	5e                   	pop    %esi
80100b8e:	5f                   	pop    %edi
80100b8f:	5d                   	pop    %ebp
80100b90:	c3                   	ret    
80100b91:	8d 76 00             	lea    0x0(%esi),%esi
  sz = PGROUNDUP(sz);
80100b94:	8b b5 f0 fe ff ff    	mov    -0x110(%ebp),%esi
80100b9a:	81 c6 ff 0f 00 00    	add    $0xfff,%esi
80100ba0:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ba6:	8d 9e 00 20 00 00    	lea    0x2000(%esi),%ebx
  iunlockput(ip);
80100bac:	83 ec 0c             	sub    $0xc,%esp
80100baf:	57                   	push   %edi
80100bb0:	e8 b3 0c 00 00       	call   80101868 <iunlockput>
  end_op();
80100bb5:	e8 7a 1e 00 00       	call   80102a34 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100bba:	83 c4 0c             	add    $0xc,%esp
80100bbd:	53                   	push   %ebx
80100bbe:	56                   	push   %esi
80100bbf:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
80100bc5:	56                   	push   %esi
80100bc6:	e8 91 5a 00 00       	call   8010665c <allocuvm>
80100bcb:	89 c7                	mov    %eax,%edi
80100bcd:	83 c4 10             	add    $0x10,%esp
80100bd0:	85 c0                	test   %eax,%eax
80100bd2:	74 7e                	je     80100c52 <exec+0x232>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100bd4:	83 ec 08             	sub    $0x8,%esp
80100bd7:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
80100bdd:	50                   	push   %eax
80100bde:	56                   	push   %esi
80100bdf:	e8 94 5c 00 00       	call   80106878 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100be4:	8b 45 0c             	mov    0xc(%ebp),%eax
80100be7:	8b 10                	mov    (%eax),%edx
80100be9:	83 c4 10             	add    $0x10,%esp
  sp = sz;
80100bec:	89 fb                	mov    %edi,%ebx
  for(argc = 0; argv[argc]; argc++) {
80100bee:	85 d2                	test   %edx,%edx
80100bf0:	0f 84 48 01 00 00    	je     80100d3e <exec+0x31e>
80100bf6:	31 f6                	xor    %esi,%esi
80100bf8:	89 bd f0 fe ff ff    	mov    %edi,-0x110(%ebp)
80100bfe:	8b 7d 0c             	mov    0xc(%ebp),%edi
80100c01:	eb 1f                	jmp    80100c22 <exec+0x202>
80100c03:	90                   	nop
    ustack[3+argc] = sp;
80100c04:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
80100c0a:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
  for(argc = 0; argv[argc]; argc++) {
80100c11:	8d 46 01             	lea    0x1(%esi),%eax
80100c14:	8b 14 87             	mov    (%edi,%eax,4),%edx
80100c17:	85 d2                	test   %edx,%edx
80100c19:	74 4d                	je     80100c68 <exec+0x248>
    if(argc >= MAXARG)
80100c1b:	83 f8 20             	cmp    $0x20,%eax
80100c1e:	74 32                	je     80100c52 <exec+0x232>
80100c20:	89 c6                	mov    %eax,%esi
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100c22:	83 ec 0c             	sub    $0xc,%esp
80100c25:	52                   	push   %edx
80100c26:	e8 1d 37 00 00       	call   80104348 <strlen>
80100c2b:	29 c3                	sub    %eax,%ebx
80100c2d:	4b                   	dec    %ebx
80100c2e:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100c31:	5a                   	pop    %edx
80100c32:	ff 34 b7             	pushl  (%edi,%esi,4)
80100c35:	e8 0e 37 00 00       	call   80104348 <strlen>
80100c3a:	40                   	inc    %eax
80100c3b:	50                   	push   %eax
80100c3c:	ff 34 b7             	pushl  (%edi,%esi,4)
80100c3f:	53                   	push   %ebx
80100c40:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100c46:	e8 d1 5d 00 00       	call   80106a1c <copyout>
80100c4b:	83 c4 20             	add    $0x20,%esp
80100c4e:	85 c0                	test   %eax,%eax
80100c50:	79 b2                	jns    80100c04 <exec+0x1e4>
    freevm(pgdir);
80100c52:	83 ec 0c             	sub    $0xc,%esp
80100c55:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100c5b:	e8 18 5b 00 00       	call   80106778 <freevm>
80100c60:	83 c4 10             	add    $0x10,%esp
80100c63:	e9 1c ff ff ff       	jmp    80100b84 <exec+0x164>
  ustack[3+argc] = 0;
80100c68:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
80100c6e:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100c74:	8d 46 04             	lea    0x4(%esi),%eax
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100c77:	8d 14 b5 08 00 00 00 	lea    0x8(,%esi,4),%edx
  sp -= (3+argc+1) * 4;
80100c7e:	8d 72 0c             	lea    0xc(%edx),%esi
  ustack[3+argc] = 0;
80100c81:	c7 84 85 58 ff ff ff 	movl   $0x0,-0xa8(%ebp,%eax,4)
80100c88:	00 00 00 00 
  ustack[0] = 0xffffffff;  // fake return PC
80100c8c:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100c93:	ff ff ff 
  ustack[1] = argc;
80100c96:	8b 85 f0 fe ff ff    	mov    -0x110(%ebp),%eax
80100c9c:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100ca2:	89 d8                	mov    %ebx,%eax
80100ca4:	29 d0                	sub    %edx,%eax
80100ca6:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%ebp)
  sp -= (3+argc+1) * 4;
80100cac:	29 f3                	sub    %esi,%ebx
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100cae:	56                   	push   %esi
80100caf:	51                   	push   %ecx
80100cb0:	53                   	push   %ebx
80100cb1:	ff b5 f4 fe ff ff    	pushl  -0x10c(%ebp)
80100cb7:	e8 60 5d 00 00       	call   80106a1c <copyout>
80100cbc:	83 c4 10             	add    $0x10,%esp
80100cbf:	85 c0                	test   %eax,%eax
80100cc1:	78 8f                	js     80100c52 <exec+0x232>
  for(last=s=path; *s; s++)
80100cc3:	8b 45 08             	mov    0x8(%ebp),%eax
80100cc6:	8a 00                	mov    (%eax),%al
80100cc8:	8b 55 08             	mov    0x8(%ebp),%edx
80100ccb:	84 c0                	test   %al,%al
80100ccd:	74 12                	je     80100ce1 <exec+0x2c1>
80100ccf:	89 d1                	mov    %edx,%ecx
80100cd1:	8d 76 00             	lea    0x0(%esi),%esi
      last = s+1;
80100cd4:	41                   	inc    %ecx
    if(*s == '/')
80100cd5:	3c 2f                	cmp    $0x2f,%al
80100cd7:	75 02                	jne    80100cdb <exec+0x2bb>
      last = s+1;
80100cd9:	89 ca                	mov    %ecx,%edx
  for(last=s=path; *s; s++)
80100cdb:	8a 01                	mov    (%ecx),%al
80100cdd:	84 c0                	test   %al,%al
80100cdf:	75 f3                	jne    80100cd4 <exec+0x2b4>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100ce1:	50                   	push   %eax
80100ce2:	6a 10                	push   $0x10
80100ce4:	52                   	push   %edx
80100ce5:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
80100ceb:	8d 46 70             	lea    0x70(%esi),%eax
80100cee:	50                   	push   %eax
80100cef:	e8 20 36 00 00       	call   80104314 <safestrcpy>
  oldpgdir = curproc->pgdir;
80100cf4:	89 f0                	mov    %esi,%eax
80100cf6:	8b 76 04             	mov    0x4(%esi),%esi
  curproc->pgdir = pgdir;
80100cf9:	8b 8d f4 fe ff ff    	mov    -0x10c(%ebp),%ecx
80100cff:	89 48 04             	mov    %ecx,0x4(%eax)
  curproc->sz = sz;
80100d02:	89 38                	mov    %edi,(%eax)
  curproc->tf->eip = elf.entry;  // main
80100d04:	89 c1                	mov    %eax,%ecx
80100d06:	8b 40 1c             	mov    0x1c(%eax),%eax
80100d09:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100d0f:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100d12:	8b 41 1c             	mov    0x1c(%ecx),%eax
80100d15:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80100d18:	89 0c 24             	mov    %ecx,(%esp)
80100d1b:	e8 08 57 00 00       	call   80106428 <switchuvm>
  freevm(oldpgdir);
80100d20:	89 34 24             	mov    %esi,(%esp)
80100d23:	e8 50 5a 00 00       	call   80106778 <freevm>
  return 0;
80100d28:	83 c4 10             	add    $0x10,%esp
80100d2b:	31 c0                	xor    %eax,%eax
80100d2d:	e9 57 fe ff ff       	jmp    80100b89 <exec+0x169>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100d32:	bb 00 20 00 00       	mov    $0x2000,%ebx
80100d37:	31 f6                	xor    %esi,%esi
80100d39:	e9 6e fe ff ff       	jmp    80100bac <exec+0x18c>
  for(argc = 0; argv[argc]; argc++) {
80100d3e:	be 10 00 00 00       	mov    $0x10,%esi
80100d43:	ba 04 00 00 00       	mov    $0x4,%edx
80100d48:	b8 03 00 00 00       	mov    $0x3,%eax
80100d4d:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100d54:	00 00 00 
80100d57:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
80100d5d:	e9 1f ff ff ff       	jmp    80100c81 <exec+0x261>
    end_op();
80100d62:	e8 cd 1c 00 00       	call   80102a34 <end_op>
    cprintf("exec: fail\n");
80100d67:	83 ec 0c             	sub    $0xc,%esp
80100d6a:	68 81 6b 10 80       	push   $0x80106b81
80100d6f:	e8 b4 f8 ff ff       	call   80100628 <cprintf>
    return -1;
80100d74:	83 c4 10             	add    $0x10,%esp
80100d77:	e9 08 fe ff ff       	jmp    80100b84 <exec+0x164>

80100d7c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100d7c:	55                   	push   %ebp
80100d7d:	89 e5                	mov    %esp,%ebp
80100d7f:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100d82:	68 8d 6b 10 80       	push   $0x80106b8d
80100d87:	68 60 ef 10 80       	push   $0x8010ef60
80100d8c:	e8 bb 31 00 00       	call   80103f4c <initlock>
}
80100d91:	83 c4 10             	add    $0x10,%esp
80100d94:	c9                   	leave  
80100d95:	c3                   	ret    
80100d96:	66 90                	xchg   %ax,%ax

80100d98 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100d98:	55                   	push   %ebp
80100d99:	89 e5                	mov    %esp,%ebp
80100d9b:	53                   	push   %ebx
80100d9c:	83 ec 10             	sub    $0x10,%esp
  struct file *f;

  acquire(&ftable.lock);
80100d9f:	68 60 ef 10 80       	push   $0x8010ef60
80100da4:	e8 63 33 00 00       	call   8010410c <acquire>
80100da9:	83 c4 10             	add    $0x10,%esp
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100dac:	bb 94 ef 10 80       	mov    $0x8010ef94,%ebx
80100db1:	eb 0c                	jmp    80100dbf <filealloc+0x27>
80100db3:	90                   	nop
80100db4:	83 c3 18             	add    $0x18,%ebx
80100db7:	81 fb f4 f8 10 80    	cmp    $0x8010f8f4,%ebx
80100dbd:	74 25                	je     80100de4 <filealloc+0x4c>
    if(f->ref == 0){
80100dbf:	8b 43 04             	mov    0x4(%ebx),%eax
80100dc2:	85 c0                	test   %eax,%eax
80100dc4:	75 ee                	jne    80100db4 <filealloc+0x1c>
      f->ref = 1;
80100dc6:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100dcd:	83 ec 0c             	sub    $0xc,%esp
80100dd0:	68 60 ef 10 80       	push   $0x8010ef60
80100dd5:	e8 d2 32 00 00       	call   801040ac <release>
      return f;
80100dda:	83 c4 10             	add    $0x10,%esp
    }
  }
  release(&ftable.lock);
  return 0;
}
80100ddd:	89 d8                	mov    %ebx,%eax
80100ddf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100de2:	c9                   	leave  
80100de3:	c3                   	ret    
  release(&ftable.lock);
80100de4:	83 ec 0c             	sub    $0xc,%esp
80100de7:	68 60 ef 10 80       	push   $0x8010ef60
80100dec:	e8 bb 32 00 00       	call   801040ac <release>
  return 0;
80100df1:	83 c4 10             	add    $0x10,%esp
80100df4:	31 db                	xor    %ebx,%ebx
}
80100df6:	89 d8                	mov    %ebx,%eax
80100df8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100dfb:	c9                   	leave  
80100dfc:	c3                   	ret    
80100dfd:	8d 76 00             	lea    0x0(%esi),%esi

80100e00 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100e00:	55                   	push   %ebp
80100e01:	89 e5                	mov    %esp,%ebp
80100e03:	53                   	push   %ebx
80100e04:	83 ec 10             	sub    $0x10,%esp
80100e07:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100e0a:	68 60 ef 10 80       	push   $0x8010ef60
80100e0f:	e8 f8 32 00 00       	call   8010410c <acquire>
  if(f->ref < 1)
80100e14:	8b 43 04             	mov    0x4(%ebx),%eax
80100e17:	83 c4 10             	add    $0x10,%esp
80100e1a:	85 c0                	test   %eax,%eax
80100e1c:	7e 18                	jle    80100e36 <filedup+0x36>
    panic("filedup");
  f->ref++;
80100e1e:	40                   	inc    %eax
80100e1f:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100e22:	83 ec 0c             	sub    $0xc,%esp
80100e25:	68 60 ef 10 80       	push   $0x8010ef60
80100e2a:	e8 7d 32 00 00       	call   801040ac <release>
  return f;
}
80100e2f:	89 d8                	mov    %ebx,%eax
80100e31:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100e34:	c9                   	leave  
80100e35:	c3                   	ret    
    panic("filedup");
80100e36:	83 ec 0c             	sub    $0xc,%esp
80100e39:	68 94 6b 10 80       	push   $0x80106b94
80100e3e:	e8 f5 f4 ff ff       	call   80100338 <panic>
80100e43:	90                   	nop

80100e44 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100e44:	55                   	push   %ebp
80100e45:	89 e5                	mov    %esp,%ebp
80100e47:	57                   	push   %edi
80100e48:	56                   	push   %esi
80100e49:	53                   	push   %ebx
80100e4a:	83 ec 28             	sub    $0x28,%esp
80100e4d:	8b 7d 08             	mov    0x8(%ebp),%edi
  struct file ff;

  acquire(&ftable.lock);
80100e50:	68 60 ef 10 80       	push   $0x8010ef60
80100e55:	e8 b2 32 00 00       	call   8010410c <acquire>
  if(f->ref < 1)
80100e5a:	8b 57 04             	mov    0x4(%edi),%edx
80100e5d:	83 c4 10             	add    $0x10,%esp
80100e60:	85 d2                	test   %edx,%edx
80100e62:	0f 8e 8d 00 00 00    	jle    80100ef5 <fileclose+0xb1>
    panic("fileclose");
  if(--f->ref > 0){
80100e68:	4a                   	dec    %edx
80100e69:	89 57 04             	mov    %edx,0x4(%edi)
80100e6c:	75 3a                	jne    80100ea8 <fileclose+0x64>
    release(&ftable.lock);
    return;
  }
  ff = *f;
80100e6e:	8b 1f                	mov    (%edi),%ebx
80100e70:	8a 47 09             	mov    0x9(%edi),%al
80100e73:	88 45 e7             	mov    %al,-0x19(%ebp)
80100e76:	8b 77 0c             	mov    0xc(%edi),%esi
80100e79:	8b 47 10             	mov    0x10(%edi),%eax
80100e7c:	89 45 e0             	mov    %eax,-0x20(%ebp)
  f->ref = 0;
  f->type = FD_NONE;
80100e7f:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
  release(&ftable.lock);
80100e85:	83 ec 0c             	sub    $0xc,%esp
80100e88:	68 60 ef 10 80       	push   $0x8010ef60
80100e8d:	e8 1a 32 00 00       	call   801040ac <release>

  if(ff.type == FD_PIPE)
80100e92:	83 c4 10             	add    $0x10,%esp
80100e95:	83 fb 01             	cmp    $0x1,%ebx
80100e98:	74 42                	je     80100edc <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  else if(ff.type == FD_INODE){
80100e9a:	83 fb 02             	cmp    $0x2,%ebx
80100e9d:	74 1d                	je     80100ebc <fileclose+0x78>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100e9f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ea2:	5b                   	pop    %ebx
80100ea3:	5e                   	pop    %esi
80100ea4:	5f                   	pop    %edi
80100ea5:	5d                   	pop    %ebp
80100ea6:	c3                   	ret    
80100ea7:	90                   	nop
    release(&ftable.lock);
80100ea8:	c7 45 08 60 ef 10 80 	movl   $0x8010ef60,0x8(%ebp)
}
80100eaf:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100eb2:	5b                   	pop    %ebx
80100eb3:	5e                   	pop    %esi
80100eb4:	5f                   	pop    %edi
80100eb5:	5d                   	pop    %ebp
    release(&ftable.lock);
80100eb6:	e9 f1 31 00 00       	jmp    801040ac <release>
80100ebb:	90                   	nop
    begin_op();
80100ebc:	e8 0b 1b 00 00       	call   801029cc <begin_op>
    iput(ff.ip);
80100ec1:	83 ec 0c             	sub    $0xc,%esp
80100ec4:	ff 75 e0             	pushl  -0x20(%ebp)
80100ec7:	e8 54 08 00 00       	call   80101720 <iput>
    end_op();
80100ecc:	83 c4 10             	add    $0x10,%esp
}
80100ecf:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ed2:	5b                   	pop    %ebx
80100ed3:	5e                   	pop    %esi
80100ed4:	5f                   	pop    %edi
80100ed5:	5d                   	pop    %ebp
    end_op();
80100ed6:	e9 59 1b 00 00       	jmp    80102a34 <end_op>
80100edb:	90                   	nop
    pipeclose(ff.pipe, ff.writable);
80100edc:	83 ec 08             	sub    $0x8,%esp
80100edf:	0f be 45 e7          	movsbl -0x19(%ebp),%eax
80100ee3:	50                   	push   %eax
80100ee4:	56                   	push   %esi
80100ee5:	e8 ea 21 00 00       	call   801030d4 <pipeclose>
80100eea:	83 c4 10             	add    $0x10,%esp
}
80100eed:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100ef0:	5b                   	pop    %ebx
80100ef1:	5e                   	pop    %esi
80100ef2:	5f                   	pop    %edi
80100ef3:	5d                   	pop    %ebp
80100ef4:	c3                   	ret    
    panic("fileclose");
80100ef5:	83 ec 0c             	sub    $0xc,%esp
80100ef8:	68 9c 6b 10 80       	push   $0x80106b9c
80100efd:	e8 36 f4 ff ff       	call   80100338 <panic>
80100f02:	66 90                	xchg   %ax,%ax

80100f04 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80100f04:	55                   	push   %ebp
80100f05:	89 e5                	mov    %esp,%ebp
80100f07:	53                   	push   %ebx
80100f08:	53                   	push   %ebx
80100f09:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80100f0c:	83 3b 02             	cmpl   $0x2,(%ebx)
80100f0f:	75 2b                	jne    80100f3c <filestat+0x38>
    ilock(f->ip);
80100f11:	83 ec 0c             	sub    $0xc,%esp
80100f14:	ff 73 10             	pushl  0x10(%ebx)
80100f17:	e8 f8 06 00 00       	call   80101614 <ilock>
    stati(f->ip, st);
80100f1c:	58                   	pop    %eax
80100f1d:	5a                   	pop    %edx
80100f1e:	ff 75 0c             	pushl  0xc(%ebp)
80100f21:	ff 73 10             	pushl  0x10(%ebx)
80100f24:	e8 8f 09 00 00       	call   801018b8 <stati>
    iunlock(f->ip);
80100f29:	59                   	pop    %ecx
80100f2a:	ff 73 10             	pushl  0x10(%ebx)
80100f2d:	e8 aa 07 00 00       	call   801016dc <iunlock>
    return 0;
80100f32:	83 c4 10             	add    $0x10,%esp
80100f35:	31 c0                	xor    %eax,%eax
  }
  return -1;
}
80100f37:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f3a:	c9                   	leave  
80100f3b:	c3                   	ret    
  return -1;
80100f3c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100f41:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100f44:	c9                   	leave  
80100f45:	c3                   	ret    
80100f46:	66 90                	xchg   %ax,%ax

80100f48 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80100f48:	55                   	push   %ebp
80100f49:	89 e5                	mov    %esp,%ebp
80100f4b:	57                   	push   %edi
80100f4c:	56                   	push   %esi
80100f4d:	53                   	push   %ebx
80100f4e:	83 ec 1c             	sub    $0x1c,%esp
80100f51:	8b 5d 08             	mov    0x8(%ebp),%ebx
80100f54:	8b 75 0c             	mov    0xc(%ebp),%esi
80100f57:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
80100f5a:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80100f5e:	74 60                	je     80100fc0 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
80100f60:	8b 03                	mov    (%ebx),%eax
80100f62:	83 f8 01             	cmp    $0x1,%eax
80100f65:	74 45                	je     80100fac <fileread+0x64>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100f67:	83 f8 02             	cmp    $0x2,%eax
80100f6a:	75 5b                	jne    80100fc7 <fileread+0x7f>
    ilock(f->ip);
80100f6c:	83 ec 0c             	sub    $0xc,%esp
80100f6f:	ff 73 10             	pushl  0x10(%ebx)
80100f72:	e8 9d 06 00 00       	call   80101614 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80100f77:	57                   	push   %edi
80100f78:	ff 73 14             	pushl  0x14(%ebx)
80100f7b:	56                   	push   %esi
80100f7c:	ff 73 10             	pushl  0x10(%ebx)
80100f7f:	e8 60 09 00 00       	call   801018e4 <readi>
80100f84:	83 c4 20             	add    $0x20,%esp
80100f87:	85 c0                	test   %eax,%eax
80100f89:	7e 03                	jle    80100f8e <fileread+0x46>
      f->off += r;
80100f8b:	01 43 14             	add    %eax,0x14(%ebx)
80100f8e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    iunlock(f->ip);
80100f91:	83 ec 0c             	sub    $0xc,%esp
80100f94:	ff 73 10             	pushl  0x10(%ebx)
80100f97:	e8 40 07 00 00       	call   801016dc <iunlock>
    return r;
80100f9c:	83 c4 10             	add    $0x10,%esp
80100f9f:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  }
  panic("fileread");
}
80100fa2:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fa5:	5b                   	pop    %ebx
80100fa6:	5e                   	pop    %esi
80100fa7:	5f                   	pop    %edi
80100fa8:	5d                   	pop    %ebp
80100fa9:	c3                   	ret    
80100faa:	66 90                	xchg   %ax,%ax
    return piperead(f->pipe, addr, n);
80100fac:	8b 43 0c             	mov    0xc(%ebx),%eax
80100faf:	89 45 08             	mov    %eax,0x8(%ebp)
}
80100fb2:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fb5:	5b                   	pop    %ebx
80100fb6:	5e                   	pop    %esi
80100fb7:	5f                   	pop    %edi
80100fb8:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
80100fb9:	e9 b6 22 00 00       	jmp    80103274 <piperead>
80100fbe:	66 90                	xchg   %ax,%ax
    return -1;
80100fc0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100fc5:	eb db                	jmp    80100fa2 <fileread+0x5a>
  panic("fileread");
80100fc7:	83 ec 0c             	sub    $0xc,%esp
80100fca:	68 a6 6b 10 80       	push   $0x80106ba6
80100fcf:	e8 64 f3 ff ff       	call   80100338 <panic>

80100fd4 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80100fd4:	55                   	push   %ebp
80100fd5:	89 e5                	mov    %esp,%ebp
80100fd7:	57                   	push   %edi
80100fd8:	56                   	push   %esi
80100fd9:	53                   	push   %ebx
80100fda:	83 ec 1c             	sub    $0x1c,%esp
80100fdd:	8b 5d 08             	mov    0x8(%ebp),%ebx
80100fe0:	8b 45 0c             	mov    0xc(%ebp),%eax
80100fe3:	89 45 dc             	mov    %eax,-0x24(%ebp)
80100fe6:	8b 45 10             	mov    0x10(%ebp),%eax
80100fe9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  int r;

  if(f->writable == 0)
80100fec:	80 7b 09 00          	cmpb   $0x0,0x9(%ebx)
80100ff0:	0f 84 b3 00 00 00    	je     801010a9 <filewrite+0xd5>
    return -1;
  if(f->type == FD_PIPE)
80100ff6:	8b 03                	mov    (%ebx),%eax
80100ff8:	83 f8 01             	cmp    $0x1,%eax
80100ffb:	0f 84 b7 00 00 00    	je     801010b8 <filewrite+0xe4>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
80101001:	83 f8 02             	cmp    $0x2,%eax
80101004:	0f 85 c0 00 00 00    	jne    801010ca <filewrite+0xf6>
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
8010100a:	31 f6                	xor    %esi,%esi
    while(i < n){
8010100c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010100f:	85 c0                	test   %eax,%eax
80101011:	7f 2c                	jg     8010103f <filewrite+0x6b>
80101013:	e9 8c 00 00 00       	jmp    801010a4 <filewrite+0xd0>
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
80101018:	01 43 14             	add    %eax,0x14(%ebx)
8010101b:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
8010101e:	83 ec 0c             	sub    $0xc,%esp
80101021:	ff 73 10             	pushl  0x10(%ebx)
80101024:	e8 b3 06 00 00       	call   801016dc <iunlock>
      end_op();
80101029:	e8 06 1a 00 00       	call   80102a34 <end_op>

      if(r < 0)
        break;
      if(r != n1)
8010102e:	83 c4 10             	add    $0x10,%esp
80101031:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101034:	39 c7                	cmp    %eax,%edi
80101036:	75 5f                	jne    80101097 <filewrite+0xc3>
        panic("short filewrite");
      i += r;
80101038:	01 fe                	add    %edi,%esi
    while(i < n){
8010103a:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
8010103d:	7e 65                	jle    801010a4 <filewrite+0xd0>
      int n1 = n - i;
8010103f:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80101042:	29 f7                	sub    %esi,%edi
      if(n1 > max)
80101044:	81 ff 00 06 00 00    	cmp    $0x600,%edi
8010104a:	7e 05                	jle    80101051 <filewrite+0x7d>
8010104c:	bf 00 06 00 00       	mov    $0x600,%edi
      begin_op();
80101051:	e8 76 19 00 00       	call   801029cc <begin_op>
      ilock(f->ip);
80101056:	83 ec 0c             	sub    $0xc,%esp
80101059:	ff 73 10             	pushl  0x10(%ebx)
8010105c:	e8 b3 05 00 00       	call   80101614 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80101061:	57                   	push   %edi
80101062:	ff 73 14             	pushl  0x14(%ebx)
80101065:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101068:	01 f0                	add    %esi,%eax
8010106a:	50                   	push   %eax
8010106b:	ff 73 10             	pushl  0x10(%ebx)
8010106e:	e8 71 09 00 00       	call   801019e4 <writei>
80101073:	83 c4 20             	add    $0x20,%esp
80101076:	85 c0                	test   %eax,%eax
80101078:	7f 9e                	jg     80101018 <filewrite+0x44>
8010107a:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
8010107d:	83 ec 0c             	sub    $0xc,%esp
80101080:	ff 73 10             	pushl  0x10(%ebx)
80101083:	e8 54 06 00 00       	call   801016dc <iunlock>
      end_op();
80101088:	e8 a7 19 00 00       	call   80102a34 <end_op>
      if(r < 0)
8010108d:	83 c4 10             	add    $0x10,%esp
80101090:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101093:	85 c0                	test   %eax,%eax
80101095:	75 0d                	jne    801010a4 <filewrite+0xd0>
        panic("short filewrite");
80101097:	83 ec 0c             	sub    $0xc,%esp
8010109a:	68 af 6b 10 80       	push   $0x80106baf
8010109f:	e8 94 f2 ff ff       	call   80100338 <panic>
    }
    return i == n ? n : -1;
801010a4:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
801010a7:	74 05                	je     801010ae <filewrite+0xda>
    return -1;
801010a9:	be ff ff ff ff       	mov    $0xffffffff,%esi
  }
  panic("filewrite");
}
801010ae:	89 f0                	mov    %esi,%eax
801010b0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801010b3:	5b                   	pop    %ebx
801010b4:	5e                   	pop    %esi
801010b5:	5f                   	pop    %edi
801010b6:	5d                   	pop    %ebp
801010b7:	c3                   	ret    
    return pipewrite(f->pipe, addr, n);
801010b8:	8b 43 0c             	mov    0xc(%ebx),%eax
801010bb:	89 45 08             	mov    %eax,0x8(%ebp)
}
801010be:	8d 65 f4             	lea    -0xc(%ebp),%esp
801010c1:	5b                   	pop    %ebx
801010c2:	5e                   	pop    %esi
801010c3:	5f                   	pop    %edi
801010c4:	5d                   	pop    %ebp
    return pipewrite(f->pipe, addr, n);
801010c5:	e9 a2 20 00 00       	jmp    8010316c <pipewrite>
  panic("filewrite");
801010ca:	83 ec 0c             	sub    $0xc,%esp
801010cd:	68 b5 6b 10 80       	push   $0x80106bb5
801010d2:	e8 61 f2 ff ff       	call   80100338 <panic>
801010d7:	90                   	nop

801010d8 <balloc>:
801010d8:	55                   	push   %ebp
801010d9:	89 e5                	mov    %esp,%ebp
801010db:	57                   	push   %edi
801010dc:	56                   	push   %esi
801010dd:	53                   	push   %ebx
801010de:	83 ec 1c             	sub    $0x1c,%esp
801010e1:	89 45 dc             	mov    %eax,-0x24(%ebp)
801010e4:	8b 0d b4 15 11 80    	mov    0x801115b4,%ecx
801010ea:	85 c9                	test   %ecx,%ecx
801010ec:	74 7f                	je     8010116d <balloc+0x95>
801010ee:	31 ff                	xor    %edi,%edi
801010f0:	83 ec 08             	sub    $0x8,%esp
801010f3:	89 f8                	mov    %edi,%eax
801010f5:	c1 f8 0c             	sar    $0xc,%eax
801010f8:	03 05 cc 15 11 80    	add    0x801115cc,%eax
801010fe:	50                   	push   %eax
801010ff:	ff 75 dc             	pushl  -0x24(%ebp)
80101102:	e8 ad ef ff ff       	call   801000b4 <bread>
80101107:	89 c3                	mov    %eax,%ebx
80101109:	a1 b4 15 11 80       	mov    0x801115b4,%eax
8010110e:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101111:	89 fe                	mov    %edi,%esi
80101113:	83 c4 10             	add    $0x10,%esp
80101116:	31 c0                	xor    %eax,%eax
80101118:	89 7d d8             	mov    %edi,-0x28(%ebp)
8010111b:	eb 2c                	jmp    80101149 <balloc+0x71>
8010111d:	8d 76 00             	lea    0x0(%esi),%esi
80101120:	89 c1                	mov    %eax,%ecx
80101122:	83 e1 07             	and    $0x7,%ecx
80101125:	ba 01 00 00 00       	mov    $0x1,%edx
8010112a:	d3 e2                	shl    %cl,%edx
8010112c:	89 55 e4             	mov    %edx,-0x1c(%ebp)
8010112f:	89 c1                	mov    %eax,%ecx
80101131:	c1 f9 03             	sar    $0x3,%ecx
80101134:	0f b6 7c 0b 5c       	movzbl 0x5c(%ebx,%ecx,1),%edi
80101139:	89 fa                	mov    %edi,%edx
8010113b:	85 7d e4             	test   %edi,-0x1c(%ebp)
8010113e:	74 3c                	je     8010117c <balloc+0xa4>
80101140:	40                   	inc    %eax
80101141:	46                   	inc    %esi
80101142:	3d 00 10 00 00       	cmp    $0x1000,%eax
80101147:	74 07                	je     80101150 <balloc+0x78>
80101149:	8b 7d e0             	mov    -0x20(%ebp),%edi
8010114c:	39 fe                	cmp    %edi,%esi
8010114e:	72 d0                	jb     80101120 <balloc+0x48>
80101150:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101153:	83 ec 0c             	sub    $0xc,%esp
80101156:	53                   	push   %ebx
80101157:	e8 60 f0 ff ff       	call   801001bc <brelse>
8010115c:	81 c7 00 10 00 00    	add    $0x1000,%edi
80101162:	83 c4 10             	add    $0x10,%esp
80101165:	3b 3d b4 15 11 80    	cmp    0x801115b4,%edi
8010116b:	72 83                	jb     801010f0 <balloc+0x18>
8010116d:	83 ec 0c             	sub    $0xc,%esp
80101170:	68 bf 6b 10 80       	push   $0x80106bbf
80101175:	e8 be f1 ff ff       	call   80100338 <panic>
8010117a:	66 90                	xchg   %ax,%ax
8010117c:	0b 55 e4             	or     -0x1c(%ebp),%edx
8010117f:	88 54 0b 5c          	mov    %dl,0x5c(%ebx,%ecx,1)
80101183:	83 ec 0c             	sub    $0xc,%esp
80101186:	53                   	push   %ebx
80101187:	e8 fc 19 00 00       	call   80102b88 <log_write>
8010118c:	89 1c 24             	mov    %ebx,(%esp)
8010118f:	e8 28 f0 ff ff       	call   801001bc <brelse>
80101194:	58                   	pop    %eax
80101195:	5a                   	pop    %edx
80101196:	56                   	push   %esi
80101197:	ff 75 dc             	pushl  -0x24(%ebp)
8010119a:	e8 15 ef ff ff       	call   801000b4 <bread>
8010119f:	89 c3                	mov    %eax,%ebx
801011a1:	83 c4 0c             	add    $0xc,%esp
801011a4:	68 00 02 00 00       	push   $0x200
801011a9:	6a 00                	push   $0x0
801011ab:	8d 40 5c             	lea    0x5c(%eax),%eax
801011ae:	50                   	push   %eax
801011af:	e8 18 30 00 00       	call   801041cc <memset>
801011b4:	89 1c 24             	mov    %ebx,(%esp)
801011b7:	e8 cc 19 00 00       	call   80102b88 <log_write>
801011bc:	89 1c 24             	mov    %ebx,(%esp)
801011bf:	e8 f8 ef ff ff       	call   801001bc <brelse>
801011c4:	89 f0                	mov    %esi,%eax
801011c6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801011c9:	5b                   	pop    %ebx
801011ca:	5e                   	pop    %esi
801011cb:	5f                   	pop    %edi
801011cc:	5d                   	pop    %ebp
801011cd:	c3                   	ret    
801011ce:	66 90                	xchg   %ax,%ax

801011d0 <iget>:
801011d0:	55                   	push   %ebp
801011d1:	89 e5                	mov    %esp,%ebp
801011d3:	57                   	push   %edi
801011d4:	56                   	push   %esi
801011d5:	53                   	push   %ebx
801011d6:	83 ec 28             	sub    $0x28,%esp
801011d9:	89 c6                	mov    %eax,%esi
801011db:	89 55 e4             	mov    %edx,-0x1c(%ebp)
801011de:	68 60 f9 10 80       	push   $0x8010f960
801011e3:	e8 24 2f 00 00       	call   8010410c <acquire>
801011e8:	83 c4 10             	add    $0x10,%esp
801011eb:	31 ff                	xor    %edi,%edi
801011ed:	bb 94 f9 10 80       	mov    $0x8010f994,%ebx
801011f2:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801011f5:	eb 13                	jmp    8010120a <iget+0x3a>
801011f7:	90                   	nop
801011f8:	39 33                	cmp    %esi,(%ebx)
801011fa:	74 64                	je     80101260 <iget+0x90>
801011fc:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101202:	81 fb b4 15 11 80    	cmp    $0x801115b4,%ebx
80101208:	74 22                	je     8010122c <iget+0x5c>
8010120a:	8b 43 08             	mov    0x8(%ebx),%eax
8010120d:	85 c0                	test   %eax,%eax
8010120f:	7f e7                	jg     801011f8 <iget+0x28>
80101211:	85 ff                	test   %edi,%edi
80101213:	75 e7                	jne    801011fc <iget+0x2c>
80101215:	85 c0                	test   %eax,%eax
80101217:	75 6c                	jne    80101285 <iget+0xb5>
80101219:	89 df                	mov    %ebx,%edi
8010121b:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101221:	81 fb b4 15 11 80    	cmp    $0x801115b4,%ebx
80101227:	75 e1                	jne    8010120a <iget+0x3a>
80101229:	8d 76 00             	lea    0x0(%esi),%esi
8010122c:	85 ff                	test   %edi,%edi
8010122e:	74 73                	je     801012a3 <iget+0xd3>
80101230:	89 37                	mov    %esi,(%edi)
80101232:	89 57 04             	mov    %edx,0x4(%edi)
80101235:	c7 47 08 01 00 00 00 	movl   $0x1,0x8(%edi)
8010123c:	c7 47 4c 00 00 00 00 	movl   $0x0,0x4c(%edi)
80101243:	83 ec 0c             	sub    $0xc,%esp
80101246:	68 60 f9 10 80       	push   $0x8010f960
8010124b:	e8 5c 2e 00 00       	call   801040ac <release>
80101250:	83 c4 10             	add    $0x10,%esp
80101253:	89 f8                	mov    %edi,%eax
80101255:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101258:	5b                   	pop    %ebx
80101259:	5e                   	pop    %esi
8010125a:	5f                   	pop    %edi
8010125b:	5d                   	pop    %ebp
8010125c:	c3                   	ret    
8010125d:	8d 76 00             	lea    0x0(%esi),%esi
80101260:	39 53 04             	cmp    %edx,0x4(%ebx)
80101263:	75 97                	jne    801011fc <iget+0x2c>
80101265:	40                   	inc    %eax
80101266:	89 43 08             	mov    %eax,0x8(%ebx)
80101269:	83 ec 0c             	sub    $0xc,%esp
8010126c:	68 60 f9 10 80       	push   $0x8010f960
80101271:	e8 36 2e 00 00       	call   801040ac <release>
80101276:	83 c4 10             	add    $0x10,%esp
80101279:	89 df                	mov    %ebx,%edi
8010127b:	89 f8                	mov    %edi,%eax
8010127d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101280:	5b                   	pop    %ebx
80101281:	5e                   	pop    %esi
80101282:	5f                   	pop    %edi
80101283:	5d                   	pop    %ebp
80101284:	c3                   	ret    
80101285:	81 c3 90 00 00 00    	add    $0x90,%ebx
8010128b:	81 fb b4 15 11 80    	cmp    $0x801115b4,%ebx
80101291:	74 10                	je     801012a3 <iget+0xd3>
80101293:	8b 43 08             	mov    0x8(%ebx),%eax
80101296:	85 c0                	test   %eax,%eax
80101298:	0f 8f 5a ff ff ff    	jg     801011f8 <iget+0x28>
8010129e:	e9 72 ff ff ff       	jmp    80101215 <iget+0x45>
801012a3:	83 ec 0c             	sub    $0xc,%esp
801012a6:	68 d5 6b 10 80       	push   $0x80106bd5
801012ab:	e8 88 f0 ff ff       	call   80100338 <panic>

801012b0 <bfree>:
801012b0:	55                   	push   %ebp
801012b1:	89 e5                	mov    %esp,%ebp
801012b3:	56                   	push   %esi
801012b4:	53                   	push   %ebx
801012b5:	89 c1                	mov    %eax,%ecx
801012b7:	89 d3                	mov    %edx,%ebx
801012b9:	83 ec 08             	sub    $0x8,%esp
801012bc:	89 d0                	mov    %edx,%eax
801012be:	c1 e8 0c             	shr    $0xc,%eax
801012c1:	03 05 cc 15 11 80    	add    0x801115cc,%eax
801012c7:	50                   	push   %eax
801012c8:	51                   	push   %ecx
801012c9:	e8 e6 ed ff ff       	call   801000b4 <bread>
801012ce:	89 c6                	mov    %eax,%esi
801012d0:	89 d9                	mov    %ebx,%ecx
801012d2:	83 e1 07             	and    $0x7,%ecx
801012d5:	b8 01 00 00 00       	mov    $0x1,%eax
801012da:	d3 e0                	shl    %cl,%eax
801012dc:	c1 fb 03             	sar    $0x3,%ebx
801012df:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
801012e5:	0f b6 4c 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%ecx
801012ea:	83 c4 10             	add    $0x10,%esp
801012ed:	85 c1                	test   %eax,%ecx
801012ef:	74 23                	je     80101314 <bfree+0x64>
801012f1:	f7 d0                	not    %eax
801012f3:	21 c8                	and    %ecx,%eax
801012f5:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
801012f9:	83 ec 0c             	sub    $0xc,%esp
801012fc:	56                   	push   %esi
801012fd:	e8 86 18 00 00       	call   80102b88 <log_write>
80101302:	89 34 24             	mov    %esi,(%esp)
80101305:	e8 b2 ee ff ff       	call   801001bc <brelse>
8010130a:	83 c4 10             	add    $0x10,%esp
8010130d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101310:	5b                   	pop    %ebx
80101311:	5e                   	pop    %esi
80101312:	5d                   	pop    %ebp
80101313:	c3                   	ret    
80101314:	83 ec 0c             	sub    $0xc,%esp
80101317:	68 e5 6b 10 80       	push   $0x80106be5
8010131c:	e8 17 f0 ff ff       	call   80100338 <panic>
80101321:	8d 76 00             	lea    0x0(%esi),%esi

80101324 <bmap>:
80101324:	55                   	push   %ebp
80101325:	89 e5                	mov    %esp,%ebp
80101327:	57                   	push   %edi
80101328:	56                   	push   %esi
80101329:	53                   	push   %ebx
8010132a:	83 ec 1c             	sub    $0x1c,%esp
8010132d:	89 c6                	mov    %eax,%esi
8010132f:	83 fa 0b             	cmp    $0xb,%edx
80101332:	76 7c                	jbe    801013b0 <bmap+0x8c>
80101334:	8d 5a f4             	lea    -0xc(%edx),%ebx
80101337:	83 fb 7f             	cmp    $0x7f,%ebx
8010133a:	0f 87 8e 00 00 00    	ja     801013ce <bmap+0xaa>
80101340:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101346:	85 c0                	test   %eax,%eax
80101348:	74 56                	je     801013a0 <bmap+0x7c>
8010134a:	83 ec 08             	sub    $0x8,%esp
8010134d:	50                   	push   %eax
8010134e:	ff 36                	pushl  (%esi)
80101350:	e8 5f ed ff ff       	call   801000b4 <bread>
80101355:	89 c7                	mov    %eax,%edi
80101357:	8d 5c 98 5c          	lea    0x5c(%eax,%ebx,4),%ebx
8010135b:	8b 03                	mov    (%ebx),%eax
8010135d:	83 c4 10             	add    $0x10,%esp
80101360:	85 c0                	test   %eax,%eax
80101362:	74 1c                	je     80101380 <bmap+0x5c>
80101364:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101367:	83 ec 0c             	sub    $0xc,%esp
8010136a:	57                   	push   %edi
8010136b:	e8 4c ee ff ff       	call   801001bc <brelse>
80101370:	83 c4 10             	add    $0x10,%esp
80101373:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101376:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101379:	5b                   	pop    %ebx
8010137a:	5e                   	pop    %esi
8010137b:	5f                   	pop    %edi
8010137c:	5d                   	pop    %ebp
8010137d:	c3                   	ret    
8010137e:	66 90                	xchg   %ax,%ax
80101380:	8b 06                	mov    (%esi),%eax
80101382:	e8 51 fd ff ff       	call   801010d8 <balloc>
80101387:	89 03                	mov    %eax,(%ebx)
80101389:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010138c:	83 ec 0c             	sub    $0xc,%esp
8010138f:	57                   	push   %edi
80101390:	e8 f3 17 00 00       	call   80102b88 <log_write>
80101395:	83 c4 10             	add    $0x10,%esp
80101398:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010139b:	eb c7                	jmp    80101364 <bmap+0x40>
8010139d:	8d 76 00             	lea    0x0(%esi),%esi
801013a0:	8b 06                	mov    (%esi),%eax
801013a2:	e8 31 fd ff ff       	call   801010d8 <balloc>
801013a7:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
801013ad:	eb 9b                	jmp    8010134a <bmap+0x26>
801013af:	90                   	nop
801013b0:	8d 5a 14             	lea    0x14(%edx),%ebx
801013b3:	8b 44 98 0c          	mov    0xc(%eax,%ebx,4),%eax
801013b7:	85 c0                	test   %eax,%eax
801013b9:	75 bb                	jne    80101376 <bmap+0x52>
801013bb:	8b 06                	mov    (%esi),%eax
801013bd:	e8 16 fd ff ff       	call   801010d8 <balloc>
801013c2:	89 44 9e 0c          	mov    %eax,0xc(%esi,%ebx,4)
801013c6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801013c9:	5b                   	pop    %ebx
801013ca:	5e                   	pop    %esi
801013cb:	5f                   	pop    %edi
801013cc:	5d                   	pop    %ebp
801013cd:	c3                   	ret    
801013ce:	83 ec 0c             	sub    $0xc,%esp
801013d1:	68 f8 6b 10 80       	push   $0x80106bf8
801013d6:	e8 5d ef ff ff       	call   80100338 <panic>
801013db:	90                   	nop

801013dc <readsb>:
801013dc:	55                   	push   %ebp
801013dd:	89 e5                	mov    %esp,%ebp
801013df:	56                   	push   %esi
801013e0:	53                   	push   %ebx
801013e1:	8b 75 0c             	mov    0xc(%ebp),%esi
801013e4:	83 ec 08             	sub    $0x8,%esp
801013e7:	6a 01                	push   $0x1
801013e9:	ff 75 08             	pushl  0x8(%ebp)
801013ec:	e8 c3 ec ff ff       	call   801000b4 <bread>
801013f1:	89 c3                	mov    %eax,%ebx
801013f3:	83 c4 0c             	add    $0xc,%esp
801013f6:	6a 1c                	push   $0x1c
801013f8:	8d 40 5c             	lea    0x5c(%eax),%eax
801013fb:	50                   	push   %eax
801013fc:	56                   	push   %esi
801013fd:	e8 46 2e 00 00       	call   80104248 <memmove>
80101402:	83 c4 10             	add    $0x10,%esp
80101405:	89 5d 08             	mov    %ebx,0x8(%ebp)
80101408:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010140b:	5b                   	pop    %ebx
8010140c:	5e                   	pop    %esi
8010140d:	5d                   	pop    %ebp
8010140e:	e9 a9 ed ff ff       	jmp    801001bc <brelse>
80101413:	90                   	nop

80101414 <iinit>:
80101414:	55                   	push   %ebp
80101415:	89 e5                	mov    %esp,%ebp
80101417:	53                   	push   %ebx
80101418:	83 ec 0c             	sub    $0xc,%esp
8010141b:	68 0b 6c 10 80       	push   $0x80106c0b
80101420:	68 60 f9 10 80       	push   $0x8010f960
80101425:	e8 22 2b 00 00       	call   80103f4c <initlock>
8010142a:	bb a0 f9 10 80       	mov    $0x8010f9a0,%ebx
8010142f:	83 c4 10             	add    $0x10,%esp
80101432:	66 90                	xchg   %ax,%ax
80101434:	83 ec 08             	sub    $0x8,%esp
80101437:	68 12 6c 10 80       	push   $0x80106c12
8010143c:	53                   	push   %ebx
8010143d:	e8 fe 29 00 00       	call   80103e40 <initsleeplock>
80101442:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101448:	83 c4 10             	add    $0x10,%esp
8010144b:	81 fb c0 15 11 80    	cmp    $0x801115c0,%ebx
80101451:	75 e1                	jne    80101434 <iinit+0x20>
80101453:	83 ec 08             	sub    $0x8,%esp
80101456:	6a 01                	push   $0x1
80101458:	ff 75 08             	pushl  0x8(%ebp)
8010145b:	e8 54 ec ff ff       	call   801000b4 <bread>
80101460:	89 c3                	mov    %eax,%ebx
80101462:	83 c4 0c             	add    $0xc,%esp
80101465:	6a 1c                	push   $0x1c
80101467:	8d 40 5c             	lea    0x5c(%eax),%eax
8010146a:	50                   	push   %eax
8010146b:	68 b4 15 11 80       	push   $0x801115b4
80101470:	e8 d3 2d 00 00       	call   80104248 <memmove>
80101475:	89 1c 24             	mov    %ebx,(%esp)
80101478:	e8 3f ed ff ff       	call   801001bc <brelse>
8010147d:	ff 35 cc 15 11 80    	pushl  0x801115cc
80101483:	ff 35 c8 15 11 80    	pushl  0x801115c8
80101489:	ff 35 c4 15 11 80    	pushl  0x801115c4
8010148f:	ff 35 c0 15 11 80    	pushl  0x801115c0
80101495:	ff 35 bc 15 11 80    	pushl  0x801115bc
8010149b:	ff 35 b8 15 11 80    	pushl  0x801115b8
801014a1:	ff 35 b4 15 11 80    	pushl  0x801115b4
801014a7:	68 78 6c 10 80       	push   $0x80106c78
801014ac:	e8 77 f1 ff ff       	call   80100628 <cprintf>
801014b1:	83 c4 30             	add    $0x30,%esp
801014b4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801014b7:	c9                   	leave  
801014b8:	c3                   	ret    
801014b9:	8d 76 00             	lea    0x0(%esi),%esi

801014bc <ialloc>:
801014bc:	55                   	push   %ebp
801014bd:	89 e5                	mov    %esp,%ebp
801014bf:	57                   	push   %edi
801014c0:	56                   	push   %esi
801014c1:	53                   	push   %ebx
801014c2:	83 ec 1c             	sub    $0x1c,%esp
801014c5:	8b 75 08             	mov    0x8(%ebp),%esi
801014c8:	8b 45 0c             	mov    0xc(%ebp),%eax
801014cb:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801014ce:	83 3d bc 15 11 80 01 	cmpl   $0x1,0x801115bc
801014d5:	0f 86 84 00 00 00    	jbe    8010155f <ialloc+0xa3>
801014db:	bf 01 00 00 00       	mov    $0x1,%edi
801014e0:	eb 17                	jmp    801014f9 <ialloc+0x3d>
801014e2:	66 90                	xchg   %ax,%ax
801014e4:	83 ec 0c             	sub    $0xc,%esp
801014e7:	53                   	push   %ebx
801014e8:	e8 cf ec ff ff       	call   801001bc <brelse>
801014ed:	47                   	inc    %edi
801014ee:	83 c4 10             	add    $0x10,%esp
801014f1:	3b 3d bc 15 11 80    	cmp    0x801115bc,%edi
801014f7:	73 66                	jae    8010155f <ialloc+0xa3>
801014f9:	83 ec 08             	sub    $0x8,%esp
801014fc:	89 f8                	mov    %edi,%eax
801014fe:	c1 e8 03             	shr    $0x3,%eax
80101501:	03 05 c8 15 11 80    	add    0x801115c8,%eax
80101507:	50                   	push   %eax
80101508:	56                   	push   %esi
80101509:	e8 a6 eb ff ff       	call   801000b4 <bread>
8010150e:	89 c3                	mov    %eax,%ebx
80101510:	89 f8                	mov    %edi,%eax
80101512:	83 e0 07             	and    $0x7,%eax
80101515:	c1 e0 06             	shl    $0x6,%eax
80101518:	8d 4c 03 5c          	lea    0x5c(%ebx,%eax,1),%ecx
8010151c:	83 c4 10             	add    $0x10,%esp
8010151f:	66 83 39 00          	cmpw   $0x0,(%ecx)
80101523:	75 bf                	jne    801014e4 <ialloc+0x28>
80101525:	50                   	push   %eax
80101526:	6a 40                	push   $0x40
80101528:	6a 00                	push   $0x0
8010152a:	51                   	push   %ecx
8010152b:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010152e:	e8 99 2c 00 00       	call   801041cc <memset>
80101533:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101536:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101539:	66 89 01             	mov    %ax,(%ecx)
8010153c:	89 1c 24             	mov    %ebx,(%esp)
8010153f:	e8 44 16 00 00       	call   80102b88 <log_write>
80101544:	89 1c 24             	mov    %ebx,(%esp)
80101547:	e8 70 ec ff ff       	call   801001bc <brelse>
8010154c:	83 c4 10             	add    $0x10,%esp
8010154f:	89 fa                	mov    %edi,%edx
80101551:	89 f0                	mov    %esi,%eax
80101553:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101556:	5b                   	pop    %ebx
80101557:	5e                   	pop    %esi
80101558:	5f                   	pop    %edi
80101559:	5d                   	pop    %ebp
8010155a:	e9 71 fc ff ff       	jmp    801011d0 <iget>
8010155f:	83 ec 0c             	sub    $0xc,%esp
80101562:	68 18 6c 10 80       	push   $0x80106c18
80101567:	e8 cc ed ff ff       	call   80100338 <panic>

8010156c <iupdate>:
8010156c:	55                   	push   %ebp
8010156d:	89 e5                	mov    %esp,%ebp
8010156f:	56                   	push   %esi
80101570:	53                   	push   %ebx
80101571:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101574:	83 ec 08             	sub    $0x8,%esp
80101577:	8b 43 04             	mov    0x4(%ebx),%eax
8010157a:	c1 e8 03             	shr    $0x3,%eax
8010157d:	03 05 c8 15 11 80    	add    0x801115c8,%eax
80101583:	50                   	push   %eax
80101584:	ff 33                	pushl  (%ebx)
80101586:	e8 29 eb ff ff       	call   801000b4 <bread>
8010158b:	89 c6                	mov    %eax,%esi
8010158d:	8b 43 04             	mov    0x4(%ebx),%eax
80101590:	83 e0 07             	and    $0x7,%eax
80101593:	c1 e0 06             	shl    $0x6,%eax
80101596:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
8010159a:	8b 53 50             	mov    0x50(%ebx),%edx
8010159d:	66 89 10             	mov    %dx,(%eax)
801015a0:	66 8b 53 52          	mov    0x52(%ebx),%dx
801015a4:	66 89 50 02          	mov    %dx,0x2(%eax)
801015a8:	8b 53 54             	mov    0x54(%ebx),%edx
801015ab:	66 89 50 04          	mov    %dx,0x4(%eax)
801015af:	66 8b 53 56          	mov    0x56(%ebx),%dx
801015b3:	66 89 50 06          	mov    %dx,0x6(%eax)
801015b7:	8b 53 58             	mov    0x58(%ebx),%edx
801015ba:	89 50 08             	mov    %edx,0x8(%eax)
801015bd:	83 c4 0c             	add    $0xc,%esp
801015c0:	6a 34                	push   $0x34
801015c2:	83 c3 5c             	add    $0x5c,%ebx
801015c5:	53                   	push   %ebx
801015c6:	83 c0 0c             	add    $0xc,%eax
801015c9:	50                   	push   %eax
801015ca:	e8 79 2c 00 00       	call   80104248 <memmove>
801015cf:	89 34 24             	mov    %esi,(%esp)
801015d2:	e8 b1 15 00 00       	call   80102b88 <log_write>
801015d7:	83 c4 10             	add    $0x10,%esp
801015da:	89 75 08             	mov    %esi,0x8(%ebp)
801015dd:	8d 65 f8             	lea    -0x8(%ebp),%esp
801015e0:	5b                   	pop    %ebx
801015e1:	5e                   	pop    %esi
801015e2:	5d                   	pop    %ebp
801015e3:	e9 d4 eb ff ff       	jmp    801001bc <brelse>

801015e8 <idup>:
801015e8:	55                   	push   %ebp
801015e9:	89 e5                	mov    %esp,%ebp
801015eb:	53                   	push   %ebx
801015ec:	83 ec 10             	sub    $0x10,%esp
801015ef:	8b 5d 08             	mov    0x8(%ebp),%ebx
801015f2:	68 60 f9 10 80       	push   $0x8010f960
801015f7:	e8 10 2b 00 00       	call   8010410c <acquire>
801015fc:	ff 43 08             	incl   0x8(%ebx)
801015ff:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
80101606:	e8 a1 2a 00 00       	call   801040ac <release>
8010160b:	89 d8                	mov    %ebx,%eax
8010160d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101610:	c9                   	leave  
80101611:	c3                   	ret    
80101612:	66 90                	xchg   %ax,%ax

80101614 <ilock>:
80101614:	55                   	push   %ebp
80101615:	89 e5                	mov    %esp,%ebp
80101617:	56                   	push   %esi
80101618:	53                   	push   %ebx
80101619:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010161c:	85 db                	test   %ebx,%ebx
8010161e:	0f 84 a9 00 00 00    	je     801016cd <ilock+0xb9>
80101624:	8b 53 08             	mov    0x8(%ebx),%edx
80101627:	85 d2                	test   %edx,%edx
80101629:	0f 8e 9e 00 00 00    	jle    801016cd <ilock+0xb9>
8010162f:	83 ec 0c             	sub    $0xc,%esp
80101632:	8d 43 0c             	lea    0xc(%ebx),%eax
80101635:	50                   	push   %eax
80101636:	e8 39 28 00 00       	call   80103e74 <acquiresleep>
8010163b:	83 c4 10             	add    $0x10,%esp
8010163e:	8b 43 4c             	mov    0x4c(%ebx),%eax
80101641:	85 c0                	test   %eax,%eax
80101643:	74 07                	je     8010164c <ilock+0x38>
80101645:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101648:	5b                   	pop    %ebx
80101649:	5e                   	pop    %esi
8010164a:	5d                   	pop    %ebp
8010164b:	c3                   	ret    
8010164c:	83 ec 08             	sub    $0x8,%esp
8010164f:	8b 43 04             	mov    0x4(%ebx),%eax
80101652:	c1 e8 03             	shr    $0x3,%eax
80101655:	03 05 c8 15 11 80    	add    0x801115c8,%eax
8010165b:	50                   	push   %eax
8010165c:	ff 33                	pushl  (%ebx)
8010165e:	e8 51 ea ff ff       	call   801000b4 <bread>
80101663:	89 c6                	mov    %eax,%esi
80101665:	8b 43 04             	mov    0x4(%ebx),%eax
80101668:	83 e0 07             	and    $0x7,%eax
8010166b:	c1 e0 06             	shl    $0x6,%eax
8010166e:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
80101672:	8b 10                	mov    (%eax),%edx
80101674:	66 89 53 50          	mov    %dx,0x50(%ebx)
80101678:	66 8b 50 02          	mov    0x2(%eax),%dx
8010167c:	66 89 53 52          	mov    %dx,0x52(%ebx)
80101680:	8b 50 04             	mov    0x4(%eax),%edx
80101683:	66 89 53 54          	mov    %dx,0x54(%ebx)
80101687:	66 8b 50 06          	mov    0x6(%eax),%dx
8010168b:	66 89 53 56          	mov    %dx,0x56(%ebx)
8010168f:	8b 50 08             	mov    0x8(%eax),%edx
80101692:	89 53 58             	mov    %edx,0x58(%ebx)
80101695:	83 c4 0c             	add    $0xc,%esp
80101698:	6a 34                	push   $0x34
8010169a:	83 c0 0c             	add    $0xc,%eax
8010169d:	50                   	push   %eax
8010169e:	8d 43 5c             	lea    0x5c(%ebx),%eax
801016a1:	50                   	push   %eax
801016a2:	e8 a1 2b 00 00       	call   80104248 <memmove>
801016a7:	89 34 24             	mov    %esi,(%esp)
801016aa:	e8 0d eb ff ff       	call   801001bc <brelse>
801016af:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
801016b6:	83 c4 10             	add    $0x10,%esp
801016b9:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
801016be:	75 85                	jne    80101645 <ilock+0x31>
801016c0:	83 ec 0c             	sub    $0xc,%esp
801016c3:	68 30 6c 10 80       	push   $0x80106c30
801016c8:	e8 6b ec ff ff       	call   80100338 <panic>
801016cd:	83 ec 0c             	sub    $0xc,%esp
801016d0:	68 2a 6c 10 80       	push   $0x80106c2a
801016d5:	e8 5e ec ff ff       	call   80100338 <panic>
801016da:	66 90                	xchg   %ax,%ax

801016dc <iunlock>:
801016dc:	55                   	push   %ebp
801016dd:	89 e5                	mov    %esp,%ebp
801016df:	56                   	push   %esi
801016e0:	53                   	push   %ebx
801016e1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801016e4:	85 db                	test   %ebx,%ebx
801016e6:	74 28                	je     80101710 <iunlock+0x34>
801016e8:	8d 73 0c             	lea    0xc(%ebx),%esi
801016eb:	83 ec 0c             	sub    $0xc,%esp
801016ee:	56                   	push   %esi
801016ef:	e8 10 28 00 00       	call   80103f04 <holdingsleep>
801016f4:	83 c4 10             	add    $0x10,%esp
801016f7:	85 c0                	test   %eax,%eax
801016f9:	74 15                	je     80101710 <iunlock+0x34>
801016fb:	8b 43 08             	mov    0x8(%ebx),%eax
801016fe:	85 c0                	test   %eax,%eax
80101700:	7e 0e                	jle    80101710 <iunlock+0x34>
80101702:	89 75 08             	mov    %esi,0x8(%ebp)
80101705:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101708:	5b                   	pop    %ebx
80101709:	5e                   	pop    %esi
8010170a:	5d                   	pop    %ebp
8010170b:	e9 b8 27 00 00       	jmp    80103ec8 <releasesleep>
80101710:	83 ec 0c             	sub    $0xc,%esp
80101713:	68 3f 6c 10 80       	push   $0x80106c3f
80101718:	e8 1b ec ff ff       	call   80100338 <panic>
8010171d:	8d 76 00             	lea    0x0(%esi),%esi

80101720 <iput>:
80101720:	55                   	push   %ebp
80101721:	89 e5                	mov    %esp,%ebp
80101723:	57                   	push   %edi
80101724:	56                   	push   %esi
80101725:	53                   	push   %ebx
80101726:	83 ec 28             	sub    $0x28,%esp
80101729:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010172c:	8d 7b 0c             	lea    0xc(%ebx),%edi
8010172f:	57                   	push   %edi
80101730:	e8 3f 27 00 00       	call   80103e74 <acquiresleep>
80101735:	83 c4 10             	add    $0x10,%esp
80101738:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010173b:	85 c0                	test   %eax,%eax
8010173d:	74 07                	je     80101746 <iput+0x26>
8010173f:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80101744:	74 2e                	je     80101774 <iput+0x54>
80101746:	83 ec 0c             	sub    $0xc,%esp
80101749:	57                   	push   %edi
8010174a:	e8 79 27 00 00       	call   80103ec8 <releasesleep>
8010174f:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
80101756:	e8 b1 29 00 00       	call   8010410c <acquire>
8010175b:	ff 4b 08             	decl   0x8(%ebx)
8010175e:	83 c4 10             	add    $0x10,%esp
80101761:	c7 45 08 60 f9 10 80 	movl   $0x8010f960,0x8(%ebp)
80101768:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010176b:	5b                   	pop    %ebx
8010176c:	5e                   	pop    %esi
8010176d:	5f                   	pop    %edi
8010176e:	5d                   	pop    %ebp
8010176f:	e9 38 29 00 00       	jmp    801040ac <release>
80101774:	83 ec 0c             	sub    $0xc,%esp
80101777:	68 60 f9 10 80       	push   $0x8010f960
8010177c:	e8 8b 29 00 00       	call   8010410c <acquire>
80101781:	8b 73 08             	mov    0x8(%ebx),%esi
80101784:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
8010178b:	e8 1c 29 00 00       	call   801040ac <release>
80101790:	83 c4 10             	add    $0x10,%esp
80101793:	4e                   	dec    %esi
80101794:	75 b0                	jne    80101746 <iput+0x26>
80101796:	8d 73 5c             	lea    0x5c(%ebx),%esi
80101799:	8d 8b 8c 00 00 00    	lea    0x8c(%ebx),%ecx
8010179f:	89 7d e4             	mov    %edi,-0x1c(%ebp)
801017a2:	89 df                	mov    %ebx,%edi
801017a4:	89 cb                	mov    %ecx,%ebx
801017a6:	eb 07                	jmp    801017af <iput+0x8f>
801017a8:	83 c6 04             	add    $0x4,%esi
801017ab:	39 de                	cmp    %ebx,%esi
801017ad:	74 15                	je     801017c4 <iput+0xa4>
801017af:	8b 16                	mov    (%esi),%edx
801017b1:	85 d2                	test   %edx,%edx
801017b3:	74 f3                	je     801017a8 <iput+0x88>
801017b5:	8b 07                	mov    (%edi),%eax
801017b7:	e8 f4 fa ff ff       	call   801012b0 <bfree>
801017bc:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
801017c2:	eb e4                	jmp    801017a8 <iput+0x88>
801017c4:	89 fb                	mov    %edi,%ebx
801017c6:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801017c9:	8b 83 8c 00 00 00    	mov    0x8c(%ebx),%eax
801017cf:	85 c0                	test   %eax,%eax
801017d1:	75 2d                	jne    80101800 <iput+0xe0>
801017d3:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
801017da:	83 ec 0c             	sub    $0xc,%esp
801017dd:	53                   	push   %ebx
801017de:	e8 89 fd ff ff       	call   8010156c <iupdate>
801017e3:	66 c7 43 50 00 00    	movw   $0x0,0x50(%ebx)
801017e9:	89 1c 24             	mov    %ebx,(%esp)
801017ec:	e8 7b fd ff ff       	call   8010156c <iupdate>
801017f1:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
801017f8:	83 c4 10             	add    $0x10,%esp
801017fb:	e9 46 ff ff ff       	jmp    80101746 <iput+0x26>
80101800:	83 ec 08             	sub    $0x8,%esp
80101803:	50                   	push   %eax
80101804:	ff 33                	pushl  (%ebx)
80101806:	e8 a9 e8 ff ff       	call   801000b4 <bread>
8010180b:	8d 70 5c             	lea    0x5c(%eax),%esi
8010180e:	8d 88 5c 02 00 00    	lea    0x25c(%eax),%ecx
80101814:	83 c4 10             	add    $0x10,%esp
80101817:	89 7d e4             	mov    %edi,-0x1c(%ebp)
8010181a:	89 45 e0             	mov    %eax,-0x20(%ebp)
8010181d:	89 cf                	mov    %ecx,%edi
8010181f:	eb 0a                	jmp    8010182b <iput+0x10b>
80101821:	8d 76 00             	lea    0x0(%esi),%esi
80101824:	83 c6 04             	add    $0x4,%esi
80101827:	39 fe                	cmp    %edi,%esi
80101829:	74 0f                	je     8010183a <iput+0x11a>
8010182b:	8b 16                	mov    (%esi),%edx
8010182d:	85 d2                	test   %edx,%edx
8010182f:	74 f3                	je     80101824 <iput+0x104>
80101831:	8b 03                	mov    (%ebx),%eax
80101833:	e8 78 fa ff ff       	call   801012b0 <bfree>
80101838:	eb ea                	jmp    80101824 <iput+0x104>
8010183a:	8b 7d e4             	mov    -0x1c(%ebp),%edi
8010183d:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101840:	83 ec 0c             	sub    $0xc,%esp
80101843:	50                   	push   %eax
80101844:	e8 73 e9 ff ff       	call   801001bc <brelse>
80101849:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
8010184f:	8b 03                	mov    (%ebx),%eax
80101851:	e8 5a fa ff ff       	call   801012b0 <bfree>
80101856:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
8010185d:	00 00 00 
80101860:	83 c4 10             	add    $0x10,%esp
80101863:	e9 6b ff ff ff       	jmp    801017d3 <iput+0xb3>

80101868 <iunlockput>:
80101868:	55                   	push   %ebp
80101869:	89 e5                	mov    %esp,%ebp
8010186b:	56                   	push   %esi
8010186c:	53                   	push   %ebx
8010186d:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101870:	85 db                	test   %ebx,%ebx
80101872:	74 34                	je     801018a8 <iunlockput+0x40>
80101874:	8d 73 0c             	lea    0xc(%ebx),%esi
80101877:	83 ec 0c             	sub    $0xc,%esp
8010187a:	56                   	push   %esi
8010187b:	e8 84 26 00 00       	call   80103f04 <holdingsleep>
80101880:	83 c4 10             	add    $0x10,%esp
80101883:	85 c0                	test   %eax,%eax
80101885:	74 21                	je     801018a8 <iunlockput+0x40>
80101887:	8b 43 08             	mov    0x8(%ebx),%eax
8010188a:	85 c0                	test   %eax,%eax
8010188c:	7e 1a                	jle    801018a8 <iunlockput+0x40>
8010188e:	83 ec 0c             	sub    $0xc,%esp
80101891:	56                   	push   %esi
80101892:	e8 31 26 00 00       	call   80103ec8 <releasesleep>
80101897:	83 c4 10             	add    $0x10,%esp
8010189a:	89 5d 08             	mov    %ebx,0x8(%ebp)
8010189d:	8d 65 f8             	lea    -0x8(%ebp),%esp
801018a0:	5b                   	pop    %ebx
801018a1:	5e                   	pop    %esi
801018a2:	5d                   	pop    %ebp
801018a3:	e9 78 fe ff ff       	jmp    80101720 <iput>
801018a8:	83 ec 0c             	sub    $0xc,%esp
801018ab:	68 3f 6c 10 80       	push   $0x80106c3f
801018b0:	e8 83 ea ff ff       	call   80100338 <panic>
801018b5:	8d 76 00             	lea    0x0(%esi),%esi

801018b8 <stati>:
801018b8:	55                   	push   %ebp
801018b9:	89 e5                	mov    %esp,%ebp
801018bb:	8b 55 08             	mov    0x8(%ebp),%edx
801018be:	8b 45 0c             	mov    0xc(%ebp),%eax
801018c1:	8b 0a                	mov    (%edx),%ecx
801018c3:	89 48 04             	mov    %ecx,0x4(%eax)
801018c6:	8b 4a 04             	mov    0x4(%edx),%ecx
801018c9:	89 48 08             	mov    %ecx,0x8(%eax)
801018cc:	8b 4a 50             	mov    0x50(%edx),%ecx
801018cf:	66 89 08             	mov    %cx,(%eax)
801018d2:	66 8b 4a 56          	mov    0x56(%edx),%cx
801018d6:	66 89 48 0c          	mov    %cx,0xc(%eax)
801018da:	8b 52 58             	mov    0x58(%edx),%edx
801018dd:	89 50 10             	mov    %edx,0x10(%eax)
801018e0:	5d                   	pop    %ebp
801018e1:	c3                   	ret    
801018e2:	66 90                	xchg   %ax,%ax

801018e4 <readi>:
801018e4:	55                   	push   %ebp
801018e5:	89 e5                	mov    %esp,%ebp
801018e7:	57                   	push   %edi
801018e8:	56                   	push   %esi
801018e9:	53                   	push   %ebx
801018ea:	83 ec 1c             	sub    $0x1c,%esp
801018ed:	8b 45 08             	mov    0x8(%ebp),%eax
801018f0:	89 45 d8             	mov    %eax,-0x28(%ebp)
801018f3:	8b 75 0c             	mov    0xc(%ebp),%esi
801018f6:	89 75 e0             	mov    %esi,-0x20(%ebp)
801018f9:	8b 7d 10             	mov    0x10(%ebp),%edi
801018fc:	8b 75 14             	mov    0x14(%ebp),%esi
801018ff:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80101902:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
80101907:	0f 84 af 00 00 00    	je     801019bc <readi+0xd8>
8010190d:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101910:	8b 50 58             	mov    0x58(%eax),%edx
80101913:	39 fa                	cmp    %edi,%edx
80101915:	0f 82 c2 00 00 00    	jb     801019dd <readi+0xf9>
8010191b:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010191e:	31 c0                	xor    %eax,%eax
80101920:	01 f9                	add    %edi,%ecx
80101922:	0f 92 c0             	setb   %al
80101925:	89 c3                	mov    %eax,%ebx
80101927:	0f 82 b0 00 00 00    	jb     801019dd <readi+0xf9>
8010192d:	39 ca                	cmp    %ecx,%edx
8010192f:	72 7f                	jb     801019b0 <readi+0xcc>
80101931:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101934:	85 f6                	test   %esi,%esi
80101936:	74 6a                	je     801019a2 <readi+0xbe>
80101938:	89 de                	mov    %ebx,%esi
8010193a:	66 90                	xchg   %ax,%ax
8010193c:	89 fa                	mov    %edi,%edx
8010193e:	c1 ea 09             	shr    $0x9,%edx
80101941:	8b 5d d8             	mov    -0x28(%ebp),%ebx
80101944:	89 d8                	mov    %ebx,%eax
80101946:	e8 d9 f9 ff ff       	call   80101324 <bmap>
8010194b:	83 ec 08             	sub    $0x8,%esp
8010194e:	50                   	push   %eax
8010194f:	ff 33                	pushl  (%ebx)
80101951:	e8 5e e7 ff ff       	call   801000b4 <bread>
80101956:	89 c2                	mov    %eax,%edx
80101958:	89 f8                	mov    %edi,%eax
8010195a:	25 ff 01 00 00       	and    $0x1ff,%eax
8010195f:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101962:	29 f1                	sub    %esi,%ecx
80101964:	bb 00 02 00 00       	mov    $0x200,%ebx
80101969:	29 c3                	sub    %eax,%ebx
8010196b:	83 c4 10             	add    $0x10,%esp
8010196e:	39 d9                	cmp    %ebx,%ecx
80101970:	73 02                	jae    80101974 <readi+0x90>
80101972:	89 cb                	mov    %ecx,%ebx
80101974:	51                   	push   %ecx
80101975:	53                   	push   %ebx
80101976:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
8010197a:	89 55 dc             	mov    %edx,-0x24(%ebp)
8010197d:	50                   	push   %eax
8010197e:	ff 75 e0             	pushl  -0x20(%ebp)
80101981:	e8 c2 28 00 00       	call   80104248 <memmove>
80101986:	8b 55 dc             	mov    -0x24(%ebp),%edx
80101989:	89 14 24             	mov    %edx,(%esp)
8010198c:	e8 2b e8 ff ff       	call   801001bc <brelse>
80101991:	01 de                	add    %ebx,%esi
80101993:	01 df                	add    %ebx,%edi
80101995:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101998:	83 c4 10             	add    $0x10,%esp
8010199b:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010199e:	39 c6                	cmp    %eax,%esi
801019a0:	72 9a                	jb     8010193c <readi+0x58>
801019a2:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801019a5:	8d 65 f4             	lea    -0xc(%ebp),%esp
801019a8:	5b                   	pop    %ebx
801019a9:	5e                   	pop    %esi
801019aa:	5f                   	pop    %edi
801019ab:	5d                   	pop    %ebp
801019ac:	c3                   	ret    
801019ad:	8d 76 00             	lea    0x0(%esi),%esi
801019b0:	29 fa                	sub    %edi,%edx
801019b2:	89 55 e4             	mov    %edx,-0x1c(%ebp)
801019b5:	e9 77 ff ff ff       	jmp    80101931 <readi+0x4d>
801019ba:	66 90                	xchg   %ax,%ax
801019bc:	0f bf 40 52          	movswl 0x52(%eax),%eax
801019c0:	66 83 f8 09          	cmp    $0x9,%ax
801019c4:	77 17                	ja     801019dd <readi+0xf9>
801019c6:	8b 04 c5 00 f9 10 80 	mov    -0x7fef0700(,%eax,8),%eax
801019cd:	85 c0                	test   %eax,%eax
801019cf:	74 0c                	je     801019dd <readi+0xf9>
801019d1:	89 75 10             	mov    %esi,0x10(%ebp)
801019d4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801019d7:	5b                   	pop    %ebx
801019d8:	5e                   	pop    %esi
801019d9:	5f                   	pop    %edi
801019da:	5d                   	pop    %ebp
801019db:	ff e0                	jmp    *%eax
801019dd:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801019e2:	eb c1                	jmp    801019a5 <readi+0xc1>

801019e4 <writei>:
801019e4:	55                   	push   %ebp
801019e5:	89 e5                	mov    %esp,%ebp
801019e7:	57                   	push   %edi
801019e8:	56                   	push   %esi
801019e9:	53                   	push   %ebx
801019ea:	83 ec 1c             	sub    $0x1c,%esp
801019ed:	8b 45 08             	mov    0x8(%ebp),%eax
801019f0:	89 45 d8             	mov    %eax,-0x28(%ebp)
801019f3:	8b 75 0c             	mov    0xc(%ebp),%esi
801019f6:	89 75 dc             	mov    %esi,-0x24(%ebp)
801019f9:	8b 7d 10             	mov    0x10(%ebp),%edi
801019fc:	8b 75 14             	mov    0x14(%ebp),%esi
801019ff:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80101a02:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
80101a07:	0f 84 b7 00 00 00    	je     80101ac4 <writei+0xe0>
80101a0d:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101a10:	39 78 58             	cmp    %edi,0x58(%eax)
80101a13:	0f 82 e0 00 00 00    	jb     80101af9 <writei+0x115>
80101a19:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101a1c:	89 f2                	mov    %esi,%edx
80101a1e:	31 c0                	xor    %eax,%eax
80101a20:	01 fa                	add    %edi,%edx
80101a22:	0f 92 c0             	setb   %al
80101a25:	0f 82 ce 00 00 00    	jb     80101af9 <writei+0x115>
80101a2b:	81 fa 00 18 01 00    	cmp    $0x11800,%edx
80101a31:	0f 87 c2 00 00 00    	ja     80101af9 <writei+0x115>
80101a37:	85 f6                	test   %esi,%esi
80101a39:	74 7c                	je     80101ab7 <writei+0xd3>
80101a3b:	89 c6                	mov    %eax,%esi
80101a3d:	89 7d e0             	mov    %edi,-0x20(%ebp)
80101a40:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101a43:	89 da                	mov    %ebx,%edx
80101a45:	c1 ea 09             	shr    $0x9,%edx
80101a48:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101a4b:	89 f8                	mov    %edi,%eax
80101a4d:	e8 d2 f8 ff ff       	call   80101324 <bmap>
80101a52:	83 ec 08             	sub    $0x8,%esp
80101a55:	50                   	push   %eax
80101a56:	ff 37                	pushl  (%edi)
80101a58:	e8 57 e6 ff ff       	call   801000b4 <bread>
80101a5d:	89 c7                	mov    %eax,%edi
80101a5f:	89 d8                	mov    %ebx,%eax
80101a61:	25 ff 01 00 00       	and    $0x1ff,%eax
80101a66:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101a69:	29 f1                	sub    %esi,%ecx
80101a6b:	bb 00 02 00 00       	mov    $0x200,%ebx
80101a70:	29 c3                	sub    %eax,%ebx
80101a72:	83 c4 10             	add    $0x10,%esp
80101a75:	39 d9                	cmp    %ebx,%ecx
80101a77:	73 02                	jae    80101a7b <writei+0x97>
80101a79:	89 cb                	mov    %ecx,%ebx
80101a7b:	52                   	push   %edx
80101a7c:	53                   	push   %ebx
80101a7d:	ff 75 dc             	pushl  -0x24(%ebp)
80101a80:	8d 44 07 5c          	lea    0x5c(%edi,%eax,1),%eax
80101a84:	50                   	push   %eax
80101a85:	e8 be 27 00 00       	call   80104248 <memmove>
80101a8a:	89 3c 24             	mov    %edi,(%esp)
80101a8d:	e8 f6 10 00 00       	call   80102b88 <log_write>
80101a92:	89 3c 24             	mov    %edi,(%esp)
80101a95:	e8 22 e7 ff ff       	call   801001bc <brelse>
80101a9a:	01 de                	add    %ebx,%esi
80101a9c:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101a9f:	01 5d dc             	add    %ebx,-0x24(%ebp)
80101aa2:	83 c4 10             	add    $0x10,%esp
80101aa5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101aa8:	39 c6                	cmp    %eax,%esi
80101aaa:	72 94                	jb     80101a40 <writei+0x5c>
80101aac:	8b 7d e0             	mov    -0x20(%ebp),%edi
80101aaf:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101ab2:	39 78 58             	cmp    %edi,0x58(%eax)
80101ab5:	72 31                	jb     80101ae8 <writei+0x104>
80101ab7:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101aba:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101abd:	5b                   	pop    %ebx
80101abe:	5e                   	pop    %esi
80101abf:	5f                   	pop    %edi
80101ac0:	5d                   	pop    %ebp
80101ac1:	c3                   	ret    
80101ac2:	66 90                	xchg   %ax,%ax
80101ac4:	0f bf 40 52          	movswl 0x52(%eax),%eax
80101ac8:	66 83 f8 09          	cmp    $0x9,%ax
80101acc:	77 2b                	ja     80101af9 <writei+0x115>
80101ace:	8b 04 c5 04 f9 10 80 	mov    -0x7fef06fc(,%eax,8),%eax
80101ad5:	85 c0                	test   %eax,%eax
80101ad7:	74 20                	je     80101af9 <writei+0x115>
80101ad9:	89 75 10             	mov    %esi,0x10(%ebp)
80101adc:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101adf:	5b                   	pop    %ebx
80101ae0:	5e                   	pop    %esi
80101ae1:	5f                   	pop    %edi
80101ae2:	5d                   	pop    %ebp
80101ae3:	ff e0                	jmp    *%eax
80101ae5:	8d 76 00             	lea    0x0(%esi),%esi
80101ae8:	89 78 58             	mov    %edi,0x58(%eax)
80101aeb:	83 ec 0c             	sub    $0xc,%esp
80101aee:	50                   	push   %eax
80101aef:	e8 78 fa ff ff       	call   8010156c <iupdate>
80101af4:	83 c4 10             	add    $0x10,%esp
80101af7:	eb be                	jmp    80101ab7 <writei+0xd3>
80101af9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101afe:	eb ba                	jmp    80101aba <writei+0xd6>

80101b00 <namecmp>:
80101b00:	55                   	push   %ebp
80101b01:	89 e5                	mov    %esp,%ebp
80101b03:	83 ec 0c             	sub    $0xc,%esp
80101b06:	6a 0e                	push   $0xe
80101b08:	ff 75 0c             	pushl  0xc(%ebp)
80101b0b:	ff 75 08             	pushl  0x8(%ebp)
80101b0e:	e8 81 27 00 00       	call   80104294 <strncmp>
80101b13:	c9                   	leave  
80101b14:	c3                   	ret    
80101b15:	8d 76 00             	lea    0x0(%esi),%esi

80101b18 <dirlookup>:
80101b18:	55                   	push   %ebp
80101b19:	89 e5                	mov    %esp,%ebp
80101b1b:	57                   	push   %edi
80101b1c:	56                   	push   %esi
80101b1d:	53                   	push   %ebx
80101b1e:	83 ec 1c             	sub    $0x1c,%esp
80101b21:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101b24:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80101b29:	75 7d                	jne    80101ba8 <dirlookup+0x90>
80101b2b:	8b 4b 58             	mov    0x58(%ebx),%ecx
80101b2e:	85 c9                	test   %ecx,%ecx
80101b30:	74 3d                	je     80101b6f <dirlookup+0x57>
80101b32:	31 ff                	xor    %edi,%edi
80101b34:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101b37:	90                   	nop
80101b38:	6a 10                	push   $0x10
80101b3a:	57                   	push   %edi
80101b3b:	56                   	push   %esi
80101b3c:	53                   	push   %ebx
80101b3d:	e8 a2 fd ff ff       	call   801018e4 <readi>
80101b42:	83 c4 10             	add    $0x10,%esp
80101b45:	83 f8 10             	cmp    $0x10,%eax
80101b48:	75 51                	jne    80101b9b <dirlookup+0x83>
80101b4a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101b4f:	74 16                	je     80101b67 <dirlookup+0x4f>
80101b51:	52                   	push   %edx
80101b52:	6a 0e                	push   $0xe
80101b54:	8d 45 da             	lea    -0x26(%ebp),%eax
80101b57:	50                   	push   %eax
80101b58:	ff 75 0c             	pushl  0xc(%ebp)
80101b5b:	e8 34 27 00 00       	call   80104294 <strncmp>
80101b60:	83 c4 10             	add    $0x10,%esp
80101b63:	85 c0                	test   %eax,%eax
80101b65:	74 15                	je     80101b7c <dirlookup+0x64>
80101b67:	83 c7 10             	add    $0x10,%edi
80101b6a:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101b6d:	72 c9                	jb     80101b38 <dirlookup+0x20>
80101b6f:	31 c0                	xor    %eax,%eax
80101b71:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101b74:	5b                   	pop    %ebx
80101b75:	5e                   	pop    %esi
80101b76:	5f                   	pop    %edi
80101b77:	5d                   	pop    %ebp
80101b78:	c3                   	ret    
80101b79:	8d 76 00             	lea    0x0(%esi),%esi
80101b7c:	8b 45 10             	mov    0x10(%ebp),%eax
80101b7f:	85 c0                	test   %eax,%eax
80101b81:	74 05                	je     80101b88 <dirlookup+0x70>
80101b83:	8b 45 10             	mov    0x10(%ebp),%eax
80101b86:	89 38                	mov    %edi,(%eax)
80101b88:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
80101b8c:	8b 03                	mov    (%ebx),%eax
80101b8e:	e8 3d f6 ff ff       	call   801011d0 <iget>
80101b93:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101b96:	5b                   	pop    %ebx
80101b97:	5e                   	pop    %esi
80101b98:	5f                   	pop    %edi
80101b99:	5d                   	pop    %ebp
80101b9a:	c3                   	ret    
80101b9b:	83 ec 0c             	sub    $0xc,%esp
80101b9e:	68 59 6c 10 80       	push   $0x80106c59
80101ba3:	e8 90 e7 ff ff       	call   80100338 <panic>
80101ba8:	83 ec 0c             	sub    $0xc,%esp
80101bab:	68 47 6c 10 80       	push   $0x80106c47
80101bb0:	e8 83 e7 ff ff       	call   80100338 <panic>
80101bb5:	8d 76 00             	lea    0x0(%esi),%esi

80101bb8 <namex>:
80101bb8:	55                   	push   %ebp
80101bb9:	89 e5                	mov    %esp,%ebp
80101bbb:	57                   	push   %edi
80101bbc:	56                   	push   %esi
80101bbd:	53                   	push   %ebx
80101bbe:	83 ec 1c             	sub    $0x1c,%esp
80101bc1:	89 c3                	mov    %eax,%ebx
80101bc3:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101bc6:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80101bc9:	80 38 2f             	cmpb   $0x2f,(%eax)
80101bcc:	0f 84 42 01 00 00    	je     80101d14 <namex+0x15c>
80101bd2:	e8 3d 19 00 00       	call   80103514 <myproc>
80101bd7:	8b 70 6c             	mov    0x6c(%eax),%esi
80101bda:	83 ec 0c             	sub    $0xc,%esp
80101bdd:	68 60 f9 10 80       	push   $0x8010f960
80101be2:	e8 25 25 00 00       	call   8010410c <acquire>
80101be7:	ff 46 08             	incl   0x8(%esi)
80101bea:	c7 04 24 60 f9 10 80 	movl   $0x8010f960,(%esp)
80101bf1:	e8 b6 24 00 00       	call   801040ac <release>
80101bf6:	83 c4 10             	add    $0x10,%esp
80101bf9:	eb 02                	jmp    80101bfd <namex+0x45>
80101bfb:	90                   	nop
80101bfc:	43                   	inc    %ebx
80101bfd:	8a 03                	mov    (%ebx),%al
80101bff:	3c 2f                	cmp    $0x2f,%al
80101c01:	74 f9                	je     80101bfc <namex+0x44>
80101c03:	84 c0                	test   %al,%al
80101c05:	0f 84 ed 00 00 00    	je     80101cf8 <namex+0x140>
80101c0b:	8a 03                	mov    (%ebx),%al
80101c0d:	89 df                	mov    %ebx,%edi
80101c0f:	3c 2f                	cmp    $0x2f,%al
80101c11:	75 0c                	jne    80101c1f <namex+0x67>
80101c13:	e9 f5 00 00 00       	jmp    80101d0d <namex+0x155>
80101c18:	47                   	inc    %edi
80101c19:	8a 07                	mov    (%edi),%al
80101c1b:	3c 2f                	cmp    $0x2f,%al
80101c1d:	74 04                	je     80101c23 <namex+0x6b>
80101c1f:	84 c0                	test   %al,%al
80101c21:	75 f5                	jne    80101c18 <namex+0x60>
80101c23:	89 f8                	mov    %edi,%eax
80101c25:	29 d8                	sub    %ebx,%eax
80101c27:	83 f8 0d             	cmp    $0xd,%eax
80101c2a:	0f 8e a4 00 00 00    	jle    80101cd4 <namex+0x11c>
80101c30:	51                   	push   %ecx
80101c31:	6a 0e                	push   $0xe
80101c33:	53                   	push   %ebx
80101c34:	ff 75 e4             	pushl  -0x1c(%ebp)
80101c37:	e8 0c 26 00 00       	call   80104248 <memmove>
80101c3c:	83 c4 10             	add    $0x10,%esp
80101c3f:	89 fb                	mov    %edi,%ebx
80101c41:	80 3f 2f             	cmpb   $0x2f,(%edi)
80101c44:	75 08                	jne    80101c4e <namex+0x96>
80101c46:	66 90                	xchg   %ax,%ax
80101c48:	43                   	inc    %ebx
80101c49:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101c4c:	74 fa                	je     80101c48 <namex+0x90>
80101c4e:	83 ec 0c             	sub    $0xc,%esp
80101c51:	56                   	push   %esi
80101c52:	e8 bd f9 ff ff       	call   80101614 <ilock>
80101c57:	83 c4 10             	add    $0x10,%esp
80101c5a:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80101c5f:	0f 85 c5 00 00 00    	jne    80101d2a <namex+0x172>
80101c65:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101c68:	85 c0                	test   %eax,%eax
80101c6a:	74 09                	je     80101c75 <namex+0xbd>
80101c6c:	80 3b 00             	cmpb   $0x0,(%ebx)
80101c6f:	0f 84 2c 01 00 00    	je     80101da1 <namex+0x1e9>
80101c75:	50                   	push   %eax
80101c76:	6a 00                	push   $0x0
80101c78:	ff 75 e4             	pushl  -0x1c(%ebp)
80101c7b:	56                   	push   %esi
80101c7c:	e8 97 fe ff ff       	call   80101b18 <dirlookup>
80101c81:	89 c7                	mov    %eax,%edi
80101c83:	8d 56 0c             	lea    0xc(%esi),%edx
80101c86:	83 c4 10             	add    $0x10,%esp
80101c89:	85 c0                	test   %eax,%eax
80101c8b:	0f 84 db 00 00 00    	je     80101d6c <namex+0x1b4>
80101c91:	83 ec 0c             	sub    $0xc,%esp
80101c94:	52                   	push   %edx
80101c95:	89 55 e0             	mov    %edx,-0x20(%ebp)
80101c98:	e8 67 22 00 00       	call   80103f04 <holdingsleep>
80101c9d:	83 c4 10             	add    $0x10,%esp
80101ca0:	85 c0                	test   %eax,%eax
80101ca2:	0f 84 39 01 00 00    	je     80101de1 <namex+0x229>
80101ca8:	8b 46 08             	mov    0x8(%esi),%eax
80101cab:	85 c0                	test   %eax,%eax
80101cad:	0f 8e 2e 01 00 00    	jle    80101de1 <namex+0x229>
80101cb3:	83 ec 0c             	sub    $0xc,%esp
80101cb6:	8b 55 e0             	mov    -0x20(%ebp),%edx
80101cb9:	52                   	push   %edx
80101cba:	e8 09 22 00 00       	call   80103ec8 <releasesleep>
80101cbf:	89 34 24             	mov    %esi,(%esp)
80101cc2:	e8 59 fa ff ff       	call   80101720 <iput>
80101cc7:	83 c4 10             	add    $0x10,%esp
80101cca:	89 fe                	mov    %edi,%esi
80101ccc:	e9 2c ff ff ff       	jmp    80101bfd <namex+0x45>
80101cd1:	8d 76 00             	lea    0x0(%esi),%esi
80101cd4:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101cd7:	8d 14 01             	lea    (%ecx,%eax,1),%edx
80101cda:	89 55 e0             	mov    %edx,-0x20(%ebp)
80101cdd:	52                   	push   %edx
80101cde:	50                   	push   %eax
80101cdf:	53                   	push   %ebx
80101ce0:	ff 75 e4             	pushl  -0x1c(%ebp)
80101ce3:	e8 60 25 00 00       	call   80104248 <memmove>
80101ce8:	8b 55 e0             	mov    -0x20(%ebp),%edx
80101ceb:	c6 02 00             	movb   $0x0,(%edx)
80101cee:	83 c4 10             	add    $0x10,%esp
80101cf1:	89 fb                	mov    %edi,%ebx
80101cf3:	e9 49 ff ff ff       	jmp    80101c41 <namex+0x89>
80101cf8:	8b 5d dc             	mov    -0x24(%ebp),%ebx
80101cfb:	85 db                	test   %ebx,%ebx
80101cfd:	0f 85 ce 00 00 00    	jne    80101dd1 <namex+0x219>
80101d03:	89 f0                	mov    %esi,%eax
80101d05:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d08:	5b                   	pop    %ebx
80101d09:	5e                   	pop    %esi
80101d0a:	5f                   	pop    %edi
80101d0b:	5d                   	pop    %ebp
80101d0c:	c3                   	ret    
80101d0d:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101d10:	31 c0                	xor    %eax,%eax
80101d12:	eb c6                	jmp    80101cda <namex+0x122>
80101d14:	ba 01 00 00 00       	mov    $0x1,%edx
80101d19:	b8 01 00 00 00       	mov    $0x1,%eax
80101d1e:	e8 ad f4 ff ff       	call   801011d0 <iget>
80101d23:	89 c6                	mov    %eax,%esi
80101d25:	e9 d3 fe ff ff       	jmp    80101bfd <namex+0x45>
80101d2a:	8d 5e 0c             	lea    0xc(%esi),%ebx
80101d2d:	83 ec 0c             	sub    $0xc,%esp
80101d30:	53                   	push   %ebx
80101d31:	e8 ce 21 00 00       	call   80103f04 <holdingsleep>
80101d36:	83 c4 10             	add    $0x10,%esp
80101d39:	85 c0                	test   %eax,%eax
80101d3b:	0f 84 a0 00 00 00    	je     80101de1 <namex+0x229>
80101d41:	8b 56 08             	mov    0x8(%esi),%edx
80101d44:	85 d2                	test   %edx,%edx
80101d46:	0f 8e 95 00 00 00    	jle    80101de1 <namex+0x229>
80101d4c:	83 ec 0c             	sub    $0xc,%esp
80101d4f:	53                   	push   %ebx
80101d50:	e8 73 21 00 00       	call   80103ec8 <releasesleep>
80101d55:	89 34 24             	mov    %esi,(%esp)
80101d58:	e8 c3 f9 ff ff       	call   80101720 <iput>
80101d5d:	83 c4 10             	add    $0x10,%esp
80101d60:	31 f6                	xor    %esi,%esi
80101d62:	89 f0                	mov    %esi,%eax
80101d64:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d67:	5b                   	pop    %ebx
80101d68:	5e                   	pop    %esi
80101d69:	5f                   	pop    %edi
80101d6a:	5d                   	pop    %ebp
80101d6b:	c3                   	ret    
80101d6c:	83 ec 0c             	sub    $0xc,%esp
80101d6f:	52                   	push   %edx
80101d70:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80101d73:	e8 8c 21 00 00       	call   80103f04 <holdingsleep>
80101d78:	83 c4 10             	add    $0x10,%esp
80101d7b:	85 c0                	test   %eax,%eax
80101d7d:	74 62                	je     80101de1 <namex+0x229>
80101d7f:	8b 46 08             	mov    0x8(%esi),%eax
80101d82:	85 c0                	test   %eax,%eax
80101d84:	7e 5b                	jle    80101de1 <namex+0x229>
80101d86:	83 ec 0c             	sub    $0xc,%esp
80101d89:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101d8c:	52                   	push   %edx
80101d8d:	e8 36 21 00 00       	call   80103ec8 <releasesleep>
80101d92:	89 34 24             	mov    %esi,(%esp)
80101d95:	e8 86 f9 ff ff       	call   80101720 <iput>
80101d9a:	83 c4 10             	add    $0x10,%esp
80101d9d:	31 f6                	xor    %esi,%esi
80101d9f:	eb c1                	jmp    80101d62 <namex+0x1aa>
80101da1:	8d 5e 0c             	lea    0xc(%esi),%ebx
80101da4:	83 ec 0c             	sub    $0xc,%esp
80101da7:	53                   	push   %ebx
80101da8:	e8 57 21 00 00       	call   80103f04 <holdingsleep>
80101dad:	83 c4 10             	add    $0x10,%esp
80101db0:	85 c0                	test   %eax,%eax
80101db2:	74 2d                	je     80101de1 <namex+0x229>
80101db4:	8b 46 08             	mov    0x8(%esi),%eax
80101db7:	85 c0                	test   %eax,%eax
80101db9:	7e 26                	jle    80101de1 <namex+0x229>
80101dbb:	83 ec 0c             	sub    $0xc,%esp
80101dbe:	53                   	push   %ebx
80101dbf:	e8 04 21 00 00       	call   80103ec8 <releasesleep>
80101dc4:	83 c4 10             	add    $0x10,%esp
80101dc7:	89 f0                	mov    %esi,%eax
80101dc9:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101dcc:	5b                   	pop    %ebx
80101dcd:	5e                   	pop    %esi
80101dce:	5f                   	pop    %edi
80101dcf:	5d                   	pop    %ebp
80101dd0:	c3                   	ret    
80101dd1:	83 ec 0c             	sub    $0xc,%esp
80101dd4:	56                   	push   %esi
80101dd5:	e8 46 f9 ff ff       	call   80101720 <iput>
80101dda:	83 c4 10             	add    $0x10,%esp
80101ddd:	31 f6                	xor    %esi,%esi
80101ddf:	eb 81                	jmp    80101d62 <namex+0x1aa>
80101de1:	83 ec 0c             	sub    $0xc,%esp
80101de4:	68 3f 6c 10 80       	push   $0x80106c3f
80101de9:	e8 4a e5 ff ff       	call   80100338 <panic>
80101dee:	66 90                	xchg   %ax,%ax

80101df0 <dirlink>:
80101df0:	55                   	push   %ebp
80101df1:	89 e5                	mov    %esp,%ebp
80101df3:	57                   	push   %edi
80101df4:	56                   	push   %esi
80101df5:	53                   	push   %ebx
80101df6:	83 ec 20             	sub    $0x20,%esp
80101df9:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101dfc:	6a 00                	push   $0x0
80101dfe:	ff 75 0c             	pushl  0xc(%ebp)
80101e01:	53                   	push   %ebx
80101e02:	e8 11 fd ff ff       	call   80101b18 <dirlookup>
80101e07:	83 c4 10             	add    $0x10,%esp
80101e0a:	85 c0                	test   %eax,%eax
80101e0c:	75 65                	jne    80101e73 <dirlink+0x83>
80101e0e:	8b 7b 58             	mov    0x58(%ebx),%edi
80101e11:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101e14:	85 ff                	test   %edi,%edi
80101e16:	74 29                	je     80101e41 <dirlink+0x51>
80101e18:	31 ff                	xor    %edi,%edi
80101e1a:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101e1d:	eb 09                	jmp    80101e28 <dirlink+0x38>
80101e1f:	90                   	nop
80101e20:	83 c7 10             	add    $0x10,%edi
80101e23:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101e26:	73 19                	jae    80101e41 <dirlink+0x51>
80101e28:	6a 10                	push   $0x10
80101e2a:	57                   	push   %edi
80101e2b:	56                   	push   %esi
80101e2c:	53                   	push   %ebx
80101e2d:	e8 b2 fa ff ff       	call   801018e4 <readi>
80101e32:	83 c4 10             	add    $0x10,%esp
80101e35:	83 f8 10             	cmp    $0x10,%eax
80101e38:	75 4c                	jne    80101e86 <dirlink+0x96>
80101e3a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101e3f:	75 df                	jne    80101e20 <dirlink+0x30>
80101e41:	50                   	push   %eax
80101e42:	6a 0e                	push   $0xe
80101e44:	ff 75 0c             	pushl  0xc(%ebp)
80101e47:	8d 45 da             	lea    -0x26(%ebp),%eax
80101e4a:	50                   	push   %eax
80101e4b:	e8 7c 24 00 00       	call   801042cc <strncpy>
80101e50:	8b 45 10             	mov    0x10(%ebp),%eax
80101e53:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
80101e57:	6a 10                	push   $0x10
80101e59:	57                   	push   %edi
80101e5a:	56                   	push   %esi
80101e5b:	53                   	push   %ebx
80101e5c:	e8 83 fb ff ff       	call   801019e4 <writei>
80101e61:	83 c4 20             	add    $0x20,%esp
80101e64:	83 f8 10             	cmp    $0x10,%eax
80101e67:	75 2a                	jne    80101e93 <dirlink+0xa3>
80101e69:	31 c0                	xor    %eax,%eax
80101e6b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101e6e:	5b                   	pop    %ebx
80101e6f:	5e                   	pop    %esi
80101e70:	5f                   	pop    %edi
80101e71:	5d                   	pop    %ebp
80101e72:	c3                   	ret    
80101e73:	83 ec 0c             	sub    $0xc,%esp
80101e76:	50                   	push   %eax
80101e77:	e8 a4 f8 ff ff       	call   80101720 <iput>
80101e7c:	83 c4 10             	add    $0x10,%esp
80101e7f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101e84:	eb e5                	jmp    80101e6b <dirlink+0x7b>
80101e86:	83 ec 0c             	sub    $0xc,%esp
80101e89:	68 68 6c 10 80       	push   $0x80106c68
80101e8e:	e8 a5 e4 ff ff       	call   80100338 <panic>
80101e93:	83 ec 0c             	sub    $0xc,%esp
80101e96:	68 4a 72 10 80       	push   $0x8010724a
80101e9b:	e8 98 e4 ff ff       	call   80100338 <panic>

80101ea0 <namei>:
80101ea0:	55                   	push   %ebp
80101ea1:	89 e5                	mov    %esp,%ebp
80101ea3:	83 ec 18             	sub    $0x18,%esp
80101ea6:	8d 4d ea             	lea    -0x16(%ebp),%ecx
80101ea9:	31 d2                	xor    %edx,%edx
80101eab:	8b 45 08             	mov    0x8(%ebp),%eax
80101eae:	e8 05 fd ff ff       	call   80101bb8 <namex>
80101eb3:	c9                   	leave  
80101eb4:	c3                   	ret    
80101eb5:	8d 76 00             	lea    0x0(%esi),%esi

80101eb8 <nameiparent>:
80101eb8:	55                   	push   %ebp
80101eb9:	89 e5                	mov    %esp,%ebp
80101ebb:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80101ebe:	ba 01 00 00 00       	mov    $0x1,%edx
80101ec3:	8b 45 08             	mov    0x8(%ebp),%eax
80101ec6:	5d                   	pop    %ebp
80101ec7:	e9 ec fc ff ff       	jmp    80101bb8 <namex>

80101ecc <idestart>:
80101ecc:	55                   	push   %ebp
80101ecd:	89 e5                	mov    %esp,%ebp
80101ecf:	57                   	push   %edi
80101ed0:	56                   	push   %esi
80101ed1:	53                   	push   %ebx
80101ed2:	83 ec 0c             	sub    $0xc,%esp
80101ed5:	85 c0                	test   %eax,%eax
80101ed7:	0f 84 99 00 00 00    	je     80101f76 <idestart+0xaa>
80101edd:	89 c3                	mov    %eax,%ebx
80101edf:	8b 70 08             	mov    0x8(%eax),%esi
80101ee2:	81 fe e7 03 00 00    	cmp    $0x3e7,%esi
80101ee8:	77 7f                	ja     80101f69 <idestart+0x9d>
80101eea:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
80101eef:	90                   	nop
80101ef0:	89 ca                	mov    %ecx,%edx
80101ef2:	ec                   	in     (%dx),%al
80101ef3:	83 e0 c0             	and    $0xffffffc0,%eax
80101ef6:	3c 40                	cmp    $0x40,%al
80101ef8:	75 f6                	jne    80101ef0 <idestart+0x24>
80101efa:	31 ff                	xor    %edi,%edi
80101efc:	ba f6 03 00 00       	mov    $0x3f6,%edx
80101f01:	89 f8                	mov    %edi,%eax
80101f03:	ee                   	out    %al,(%dx)
80101f04:	b0 01                	mov    $0x1,%al
80101f06:	ba f2 01 00 00       	mov    $0x1f2,%edx
80101f0b:	ee                   	out    %al,(%dx)
80101f0c:	ba f3 01 00 00       	mov    $0x1f3,%edx
80101f11:	89 f0                	mov    %esi,%eax
80101f13:	ee                   	out    %al,(%dx)
80101f14:	89 f0                	mov    %esi,%eax
80101f16:	c1 f8 08             	sar    $0x8,%eax
80101f19:	ba f4 01 00 00       	mov    $0x1f4,%edx
80101f1e:	ee                   	out    %al,(%dx)
80101f1f:	ba f5 01 00 00       	mov    $0x1f5,%edx
80101f24:	89 f8                	mov    %edi,%eax
80101f26:	ee                   	out    %al,(%dx)
80101f27:	8a 43 04             	mov    0x4(%ebx),%al
80101f2a:	c1 e0 04             	shl    $0x4,%eax
80101f2d:	83 e0 10             	and    $0x10,%eax
80101f30:	83 c8 e0             	or     $0xffffffe0,%eax
80101f33:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101f38:	ee                   	out    %al,(%dx)
80101f39:	f6 03 04             	testb  $0x4,(%ebx)
80101f3c:	75 0e                	jne    80101f4c <idestart+0x80>
80101f3e:	b0 20                	mov    $0x20,%al
80101f40:	89 ca                	mov    %ecx,%edx
80101f42:	ee                   	out    %al,(%dx)
80101f43:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f46:	5b                   	pop    %ebx
80101f47:	5e                   	pop    %esi
80101f48:	5f                   	pop    %edi
80101f49:	5d                   	pop    %ebp
80101f4a:	c3                   	ret    
80101f4b:	90                   	nop
80101f4c:	b0 30                	mov    $0x30,%al
80101f4e:	89 ca                	mov    %ecx,%edx
80101f50:	ee                   	out    %al,(%dx)
80101f51:	8d 73 5c             	lea    0x5c(%ebx),%esi
80101f54:	b9 80 00 00 00       	mov    $0x80,%ecx
80101f59:	ba f0 01 00 00       	mov    $0x1f0,%edx
80101f5e:	fc                   	cld    
80101f5f:	f3 6f                	rep outsl %ds:(%esi),(%dx)
80101f61:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f64:	5b                   	pop    %ebx
80101f65:	5e                   	pop    %esi
80101f66:	5f                   	pop    %edi
80101f67:	5d                   	pop    %ebp
80101f68:	c3                   	ret    
80101f69:	83 ec 0c             	sub    $0xc,%esp
80101f6c:	68 d4 6c 10 80       	push   $0x80106cd4
80101f71:	e8 c2 e3 ff ff       	call   80100338 <panic>
80101f76:	83 ec 0c             	sub    $0xc,%esp
80101f79:	68 cb 6c 10 80       	push   $0x80106ccb
80101f7e:	e8 b5 e3 ff ff       	call   80100338 <panic>
80101f83:	90                   	nop

80101f84 <ideinit>:
80101f84:	55                   	push   %ebp
80101f85:	89 e5                	mov    %esp,%ebp
80101f87:	83 ec 10             	sub    $0x10,%esp
80101f8a:	68 e6 6c 10 80       	push   $0x80106ce6
80101f8f:	68 00 16 11 80       	push   $0x80111600
80101f94:	e8 b3 1f 00 00       	call   80103f4c <initlock>
80101f99:	58                   	pop    %eax
80101f9a:	5a                   	pop    %edx
80101f9b:	a1 84 17 11 80       	mov    0x80111784,%eax
80101fa0:	48                   	dec    %eax
80101fa1:	50                   	push   %eax
80101fa2:	6a 0e                	push   $0xe
80101fa4:	e8 5b 02 00 00       	call   80102204 <ioapicenable>
80101fa9:	83 c4 10             	add    $0x10,%esp
80101fac:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
80101fb1:	8d 76 00             	lea    0x0(%esi),%esi
80101fb4:	89 ca                	mov    %ecx,%edx
80101fb6:	ec                   	in     (%dx),%al
80101fb7:	83 e0 c0             	and    $0xffffffc0,%eax
80101fba:	3c 40                	cmp    $0x40,%al
80101fbc:	75 f6                	jne    80101fb4 <ideinit+0x30>
80101fbe:	b0 f0                	mov    $0xf0,%al
80101fc0:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101fc5:	ee                   	out    %al,(%dx)
80101fc6:	89 ca                	mov    %ecx,%edx
80101fc8:	ec                   	in     (%dx),%al
80101fc9:	84 c0                	test   %al,%al
80101fcb:	75 13                	jne    80101fe0 <ideinit+0x5c>
80101fcd:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
80101fd2:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101fd7:	90                   	nop
80101fd8:	49                   	dec    %ecx
80101fd9:	74 0f                	je     80101fea <ideinit+0x66>
80101fdb:	ec                   	in     (%dx),%al
80101fdc:	84 c0                	test   %al,%al
80101fde:	74 f8                	je     80101fd8 <ideinit+0x54>
80101fe0:	c7 05 e0 15 11 80 01 	movl   $0x1,0x801115e0
80101fe7:	00 00 00 
80101fea:	b0 e0                	mov    $0xe0,%al
80101fec:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101ff1:	ee                   	out    %al,(%dx)
80101ff2:	c9                   	leave  
80101ff3:	c3                   	ret    

80101ff4 <ideintr>:
80101ff4:	55                   	push   %ebp
80101ff5:	89 e5                	mov    %esp,%ebp
80101ff7:	57                   	push   %edi
80101ff8:	56                   	push   %esi
80101ff9:	53                   	push   %ebx
80101ffa:	83 ec 18             	sub    $0x18,%esp
80101ffd:	68 00 16 11 80       	push   $0x80111600
80102002:	e8 05 21 00 00       	call   8010410c <acquire>
80102007:	8b 1d e4 15 11 80    	mov    0x801115e4,%ebx
8010200d:	83 c4 10             	add    $0x10,%esp
80102010:	85 db                	test   %ebx,%ebx
80102012:	74 5b                	je     8010206f <ideintr+0x7b>
80102014:	8b 43 58             	mov    0x58(%ebx),%eax
80102017:	a3 e4 15 11 80       	mov    %eax,0x801115e4
8010201c:	8b 33                	mov    (%ebx),%esi
8010201e:	f7 c6 04 00 00 00    	test   $0x4,%esi
80102024:	75 27                	jne    8010204d <ideintr+0x59>
80102026:	ba f7 01 00 00       	mov    $0x1f7,%edx
8010202b:	90                   	nop
8010202c:	ec                   	in     (%dx),%al
8010202d:	88 c1                	mov    %al,%cl
8010202f:	83 e1 c0             	and    $0xffffffc0,%ecx
80102032:	80 f9 40             	cmp    $0x40,%cl
80102035:	75 f5                	jne    8010202c <ideintr+0x38>
80102037:	a8 21                	test   $0x21,%al
80102039:	75 12                	jne    8010204d <ideintr+0x59>
8010203b:	8d 7b 5c             	lea    0x5c(%ebx),%edi
8010203e:	b9 80 00 00 00       	mov    $0x80,%ecx
80102043:	ba f0 01 00 00       	mov    $0x1f0,%edx
80102048:	fc                   	cld    
80102049:	f3 6d                	rep insl (%dx),%es:(%edi)
8010204b:	8b 33                	mov    (%ebx),%esi
8010204d:	83 e6 fb             	and    $0xfffffffb,%esi
80102050:	83 ce 02             	or     $0x2,%esi
80102053:	89 33                	mov    %esi,(%ebx)
80102055:	83 ec 0c             	sub    $0xc,%esp
80102058:	53                   	push   %ebx
80102059:	e8 66 1c 00 00       	call   80103cc4 <wakeup>
8010205e:	a1 e4 15 11 80       	mov    0x801115e4,%eax
80102063:	83 c4 10             	add    $0x10,%esp
80102066:	85 c0                	test   %eax,%eax
80102068:	74 05                	je     8010206f <ideintr+0x7b>
8010206a:	e8 5d fe ff ff       	call   80101ecc <idestart>
8010206f:	83 ec 0c             	sub    $0xc,%esp
80102072:	68 00 16 11 80       	push   $0x80111600
80102077:	e8 30 20 00 00       	call   801040ac <release>
8010207c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010207f:	5b                   	pop    %ebx
80102080:	5e                   	pop    %esi
80102081:	5f                   	pop    %edi
80102082:	5d                   	pop    %ebp
80102083:	c3                   	ret    

80102084 <iderw>:
80102084:	55                   	push   %ebp
80102085:	89 e5                	mov    %esp,%ebp
80102087:	53                   	push   %ebx
80102088:	83 ec 10             	sub    $0x10,%esp
8010208b:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010208e:	8d 43 0c             	lea    0xc(%ebx),%eax
80102091:	50                   	push   %eax
80102092:	e8 6d 1e 00 00       	call   80103f04 <holdingsleep>
80102097:	83 c4 10             	add    $0x10,%esp
8010209a:	85 c0                	test   %eax,%eax
8010209c:	0f 84 b7 00 00 00    	je     80102159 <iderw+0xd5>
801020a2:	8b 03                	mov    (%ebx),%eax
801020a4:	83 e0 06             	and    $0x6,%eax
801020a7:	83 f8 02             	cmp    $0x2,%eax
801020aa:	0f 84 9c 00 00 00    	je     8010214c <iderw+0xc8>
801020b0:	8b 53 04             	mov    0x4(%ebx),%edx
801020b3:	85 d2                	test   %edx,%edx
801020b5:	74 09                	je     801020c0 <iderw+0x3c>
801020b7:	a1 e0 15 11 80       	mov    0x801115e0,%eax
801020bc:	85 c0                	test   %eax,%eax
801020be:	74 7f                	je     8010213f <iderw+0xbb>
801020c0:	83 ec 0c             	sub    $0xc,%esp
801020c3:	68 00 16 11 80       	push   $0x80111600
801020c8:	e8 3f 20 00 00       	call   8010410c <acquire>
801020cd:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
801020d4:	a1 e4 15 11 80       	mov    0x801115e4,%eax
801020d9:	83 c4 10             	add    $0x10,%esp
801020dc:	85 c0                	test   %eax,%eax
801020de:	74 58                	je     80102138 <iderw+0xb4>
801020e0:	89 c2                	mov    %eax,%edx
801020e2:	8b 40 58             	mov    0x58(%eax),%eax
801020e5:	85 c0                	test   %eax,%eax
801020e7:	75 f7                	jne    801020e0 <iderw+0x5c>
801020e9:	83 c2 58             	add    $0x58,%edx
801020ec:	89 1a                	mov    %ebx,(%edx)
801020ee:	39 1d e4 15 11 80    	cmp    %ebx,0x801115e4
801020f4:	74 36                	je     8010212c <iderw+0xa8>
801020f6:	8b 03                	mov    (%ebx),%eax
801020f8:	83 e0 06             	and    $0x6,%eax
801020fb:	83 f8 02             	cmp    $0x2,%eax
801020fe:	74 1b                	je     8010211b <iderw+0x97>
80102100:	83 ec 08             	sub    $0x8,%esp
80102103:	68 00 16 11 80       	push   $0x80111600
80102108:	53                   	push   %ebx
80102109:	e8 fa 1a 00 00       	call   80103c08 <sleep>
8010210e:	8b 03                	mov    (%ebx),%eax
80102110:	83 e0 06             	and    $0x6,%eax
80102113:	83 c4 10             	add    $0x10,%esp
80102116:	83 f8 02             	cmp    $0x2,%eax
80102119:	75 e5                	jne    80102100 <iderw+0x7c>
8010211b:	c7 45 08 00 16 11 80 	movl   $0x80111600,0x8(%ebp)
80102122:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102125:	c9                   	leave  
80102126:	e9 81 1f 00 00       	jmp    801040ac <release>
8010212b:	90                   	nop
8010212c:	89 d8                	mov    %ebx,%eax
8010212e:	e8 99 fd ff ff       	call   80101ecc <idestart>
80102133:	eb c1                	jmp    801020f6 <iderw+0x72>
80102135:	8d 76 00             	lea    0x0(%esi),%esi
80102138:	ba e4 15 11 80       	mov    $0x801115e4,%edx
8010213d:	eb ad                	jmp    801020ec <iderw+0x68>
8010213f:	83 ec 0c             	sub    $0xc,%esp
80102142:	68 15 6d 10 80       	push   $0x80106d15
80102147:	e8 ec e1 ff ff       	call   80100338 <panic>
8010214c:	83 ec 0c             	sub    $0xc,%esp
8010214f:	68 00 6d 10 80       	push   $0x80106d00
80102154:	e8 df e1 ff ff       	call   80100338 <panic>
80102159:	83 ec 0c             	sub    $0xc,%esp
8010215c:	68 ea 6c 10 80       	push   $0x80106cea
80102161:	e8 d2 e1 ff ff       	call   80100338 <panic>
80102166:	66 90                	xchg   %ax,%ax

80102168 <ioapicinit>:
80102168:	55                   	push   %ebp
80102169:	89 e5                	mov    %esp,%ebp
8010216b:	56                   	push   %esi
8010216c:	53                   	push   %ebx
8010216d:	c7 05 34 16 11 80 00 	movl   $0xfec00000,0x80111634
80102174:	00 c0 fe 
80102177:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
8010217e:	00 00 00 
80102181:	8b 15 34 16 11 80    	mov    0x80111634,%edx
80102187:	8b 72 10             	mov    0x10(%edx),%esi
8010218a:	c1 ee 10             	shr    $0x10,%esi
8010218d:	89 f0                	mov    %esi,%eax
8010218f:	0f b6 f0             	movzbl %al,%esi
80102192:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
80102198:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
8010219e:	8b 43 10             	mov    0x10(%ebx),%eax
801021a1:	0f b6 15 80 17 11 80 	movzbl 0x80111780,%edx
801021a8:	c1 e8 18             	shr    $0x18,%eax
801021ab:	39 c2                	cmp    %eax,%edx
801021ad:	74 16                	je     801021c5 <ioapicinit+0x5d>
801021af:	83 ec 0c             	sub    $0xc,%esp
801021b2:	68 34 6d 10 80       	push   $0x80106d34
801021b7:	e8 6c e4 ff ff       	call   80100628 <cprintf>
801021bc:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
801021c2:	83 c4 10             	add    $0x10,%esp
801021c5:	ba 10 00 00 00       	mov    $0x10,%edx
801021ca:	31 c0                	xor    %eax,%eax
801021cc:	8d 48 20             	lea    0x20(%eax),%ecx
801021cf:	81 c9 00 00 01 00    	or     $0x10000,%ecx
801021d5:	89 13                	mov    %edx,(%ebx)
801021d7:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
801021dd:	89 4b 10             	mov    %ecx,0x10(%ebx)
801021e0:	8d 4a 01             	lea    0x1(%edx),%ecx
801021e3:	89 0b                	mov    %ecx,(%ebx)
801021e5:	8b 1d 34 16 11 80    	mov    0x80111634,%ebx
801021eb:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
801021f2:	40                   	inc    %eax
801021f3:	83 c2 02             	add    $0x2,%edx
801021f6:	39 c6                	cmp    %eax,%esi
801021f8:	7d d2                	jge    801021cc <ioapicinit+0x64>
801021fa:	8d 65 f8             	lea    -0x8(%ebp),%esp
801021fd:	5b                   	pop    %ebx
801021fe:	5e                   	pop    %esi
801021ff:	5d                   	pop    %ebp
80102200:	c3                   	ret    
80102201:	8d 76 00             	lea    0x0(%esi),%esi

80102204 <ioapicenable>:
80102204:	55                   	push   %ebp
80102205:	89 e5                	mov    %esp,%ebp
80102207:	8b 45 08             	mov    0x8(%ebp),%eax
8010220a:	8d 50 20             	lea    0x20(%eax),%edx
8010220d:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
80102211:	8b 0d 34 16 11 80    	mov    0x80111634,%ecx
80102217:	89 01                	mov    %eax,(%ecx)
80102219:	8b 0d 34 16 11 80    	mov    0x80111634,%ecx
8010221f:	89 51 10             	mov    %edx,0x10(%ecx)
80102222:	8b 55 0c             	mov    0xc(%ebp),%edx
80102225:	c1 e2 18             	shl    $0x18,%edx
80102228:	40                   	inc    %eax
80102229:	89 01                	mov    %eax,(%ecx)
8010222b:	a1 34 16 11 80       	mov    0x80111634,%eax
80102230:	89 50 10             	mov    %edx,0x10(%eax)
80102233:	5d                   	pop    %ebp
80102234:	c3                   	ret    
80102235:	66 90                	xchg   %ax,%ax
80102237:	90                   	nop

80102238 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102238:	55                   	push   %ebp
80102239:	89 e5                	mov    %esp,%ebp
8010223b:	53                   	push   %ebx
8010223c:	53                   	push   %ebx
8010223d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
80102240:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80102246:	75 70                	jne    801022b8 <kfree+0x80>
80102248:	81 fb d0 55 11 80    	cmp    $0x801155d0,%ebx
8010224e:	72 68                	jb     801022b8 <kfree+0x80>
80102250:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80102256:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
8010225b:	77 5b                	ja     801022b8 <kfree+0x80>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
8010225d:	52                   	push   %edx
8010225e:	68 00 10 00 00       	push   $0x1000
80102263:	6a 01                	push   $0x1
80102265:	53                   	push   %ebx
80102266:	e8 61 1f 00 00       	call   801041cc <memset>

  if(kmem.use_lock)
8010226b:	83 c4 10             	add    $0x10,%esp
8010226e:	8b 0d 74 16 11 80    	mov    0x80111674,%ecx
80102274:	85 c9                	test   %ecx,%ecx
80102276:	75 1c                	jne    80102294 <kfree+0x5c>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
80102278:	a1 78 16 11 80       	mov    0x80111678,%eax
8010227d:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
8010227f:	89 1d 78 16 11 80    	mov    %ebx,0x80111678
  if(kmem.use_lock)
80102285:	a1 74 16 11 80       	mov    0x80111674,%eax
8010228a:	85 c0                	test   %eax,%eax
8010228c:	75 1a                	jne    801022a8 <kfree+0x70>
    release(&kmem.lock);
}
8010228e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102291:	c9                   	leave  
80102292:	c3                   	ret    
80102293:	90                   	nop
    acquire(&kmem.lock);
80102294:	83 ec 0c             	sub    $0xc,%esp
80102297:	68 40 16 11 80       	push   $0x80111640
8010229c:	e8 6b 1e 00 00       	call   8010410c <acquire>
801022a1:	83 c4 10             	add    $0x10,%esp
801022a4:	eb d2                	jmp    80102278 <kfree+0x40>
801022a6:	66 90                	xchg   %ax,%ax
    release(&kmem.lock);
801022a8:	c7 45 08 40 16 11 80 	movl   $0x80111640,0x8(%ebp)
}
801022af:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801022b2:	c9                   	leave  
    release(&kmem.lock);
801022b3:	e9 f4 1d 00 00       	jmp    801040ac <release>
    panic("kfree");
801022b8:	83 ec 0c             	sub    $0xc,%esp
801022bb:	68 66 6d 10 80       	push   $0x80106d66
801022c0:	e8 73 e0 ff ff       	call   80100338 <panic>
801022c5:	8d 76 00             	lea    0x0(%esi),%esi

801022c8 <freerange>:
{
801022c8:	55                   	push   %ebp
801022c9:	89 e5                	mov    %esp,%ebp
801022cb:	56                   	push   %esi
801022cc:	53                   	push   %ebx
801022cd:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801022d0:	8b 45 08             	mov    0x8(%ebp),%eax
801022d3:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801022d9:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801022df:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801022e5:	39 de                	cmp    %ebx,%esi
801022e7:	72 1f                	jb     80102308 <freerange+0x40>
801022e9:	8d 76 00             	lea    0x0(%esi),%esi
    kfree(p);
801022ec:	83 ec 0c             	sub    $0xc,%esp
801022ef:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
801022f5:	50                   	push   %eax
801022f6:	e8 3d ff ff ff       	call   80102238 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801022fb:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102301:	83 c4 10             	add    $0x10,%esp
80102304:	39 de                	cmp    %ebx,%esi
80102306:	73 e4                	jae    801022ec <freerange+0x24>
}
80102308:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010230b:	5b                   	pop    %ebx
8010230c:	5e                   	pop    %esi
8010230d:	5d                   	pop    %ebp
8010230e:	c3                   	ret    
8010230f:	90                   	nop

80102310 <kinit2>:
{
80102310:	55                   	push   %ebp
80102311:	89 e5                	mov    %esp,%ebp
80102313:	56                   	push   %esi
80102314:	53                   	push   %ebx
80102315:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
80102318:	8b 45 08             	mov    0x8(%ebp),%eax
8010231b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102321:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102327:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010232d:	39 de                	cmp    %ebx,%esi
8010232f:	72 1f                	jb     80102350 <kinit2+0x40>
80102331:	8d 76 00             	lea    0x0(%esi),%esi
    kfree(p);
80102334:	83 ec 0c             	sub    $0xc,%esp
80102337:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
8010233d:	50                   	push   %eax
8010233e:	e8 f5 fe ff ff       	call   80102238 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102343:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80102349:	83 c4 10             	add    $0x10,%esp
8010234c:	39 de                	cmp    %ebx,%esi
8010234e:	73 e4                	jae    80102334 <kinit2+0x24>
  kmem.use_lock = 1;
80102350:	c7 05 74 16 11 80 01 	movl   $0x1,0x80111674
80102357:	00 00 00 
}
8010235a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010235d:	5b                   	pop    %ebx
8010235e:	5e                   	pop    %esi
8010235f:	5d                   	pop    %ebp
80102360:	c3                   	ret    
80102361:	8d 76 00             	lea    0x0(%esi),%esi

80102364 <kinit1>:
{
80102364:	55                   	push   %ebp
80102365:	89 e5                	mov    %esp,%ebp
80102367:	56                   	push   %esi
80102368:	53                   	push   %ebx
80102369:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
8010236c:	83 ec 08             	sub    $0x8,%esp
8010236f:	68 6c 6d 10 80       	push   $0x80106d6c
80102374:	68 40 16 11 80       	push   $0x80111640
80102379:	e8 ce 1b 00 00       	call   80103f4c <initlock>
  kmem.use_lock = 0;
8010237e:	c7 05 74 16 11 80 00 	movl   $0x0,0x80111674
80102385:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
80102388:	8b 45 08             	mov    0x8(%ebp),%eax
8010238b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102391:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102397:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010239d:	83 c4 10             	add    $0x10,%esp
801023a0:	39 de                	cmp    %ebx,%esi
801023a2:	72 1c                	jb     801023c0 <kinit1+0x5c>
    kfree(p);
801023a4:	83 ec 0c             	sub    $0xc,%esp
801023a7:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
801023ad:	50                   	push   %eax
801023ae:	e8 85 fe ff ff       	call   80102238 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801023b3:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801023b9:	83 c4 10             	add    $0x10,%esp
801023bc:	39 de                	cmp    %ebx,%esi
801023be:	73 e4                	jae    801023a4 <kinit1+0x40>
}
801023c0:	8d 65 f8             	lea    -0x8(%ebp),%esp
801023c3:	5b                   	pop    %ebx
801023c4:	5e                   	pop    %esi
801023c5:	5d                   	pop    %ebp
801023c6:	c3                   	ret    
801023c7:	90                   	nop

801023c8 <kalloc>:
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
801023c8:	a1 74 16 11 80       	mov    0x80111674,%eax
801023cd:	85 c0                	test   %eax,%eax
801023cf:	75 17                	jne    801023e8 <kalloc+0x20>
    acquire(&kmem.lock);
  r = kmem.freelist;
801023d1:	a1 78 16 11 80       	mov    0x80111678,%eax
  if(r)
801023d6:	85 c0                	test   %eax,%eax
801023d8:	74 0a                	je     801023e4 <kalloc+0x1c>
    kmem.freelist = r->next;
801023da:	8b 10                	mov    (%eax),%edx
801023dc:	89 15 78 16 11 80    	mov    %edx,0x80111678
  if(kmem.use_lock)
801023e2:	c3                   	ret    
801023e3:	90                   	nop
    release(&kmem.lock);
  return (char*)r;
}
801023e4:	c3                   	ret    
801023e5:	8d 76 00             	lea    0x0(%esi),%esi
{
801023e8:	55                   	push   %ebp
801023e9:	89 e5                	mov    %esp,%ebp
801023eb:	83 ec 24             	sub    $0x24,%esp
    acquire(&kmem.lock);
801023ee:	68 40 16 11 80       	push   $0x80111640
801023f3:	e8 14 1d 00 00       	call   8010410c <acquire>
  r = kmem.freelist;
801023f8:	a1 78 16 11 80       	mov    0x80111678,%eax
  if(r)
801023fd:	83 c4 10             	add    $0x10,%esp
  if(kmem.use_lock)
80102400:	8b 15 74 16 11 80    	mov    0x80111674,%edx
  if(r)
80102406:	85 c0                	test   %eax,%eax
80102408:	74 08                	je     80102412 <kalloc+0x4a>
    kmem.freelist = r->next;
8010240a:	8b 08                	mov    (%eax),%ecx
8010240c:	89 0d 78 16 11 80    	mov    %ecx,0x80111678
  if(kmem.use_lock)
80102412:	85 d2                	test   %edx,%edx
80102414:	74 16                	je     8010242c <kalloc+0x64>
80102416:	89 45 f4             	mov    %eax,-0xc(%ebp)
    release(&kmem.lock);
80102419:	83 ec 0c             	sub    $0xc,%esp
8010241c:	68 40 16 11 80       	push   $0x80111640
80102421:	e8 86 1c 00 00       	call   801040ac <release>
80102426:	83 c4 10             	add    $0x10,%esp
80102429:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
8010242c:	c9                   	leave  
8010242d:	c3                   	ret    
8010242e:	66 90                	xchg   %ax,%ax

80102430 <kbdgetc>:
static inline uchar
inb(ushort port)
{
  uchar data;

  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102430:	ba 64 00 00 00       	mov    $0x64,%edx
80102435:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80102436:	a8 01                	test   $0x1,%al
80102438:	0f 84 aa 00 00 00    	je     801024e8 <kbdgetc+0xb8>
{
8010243e:	55                   	push   %ebp
8010243f:	89 e5                	mov    %esp,%ebp
80102441:	53                   	push   %ebx
80102442:	ba 60 00 00 00       	mov    $0x60,%edx
80102447:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);
80102448:	0f b6 d8             	movzbl %al,%ebx

  if(data == 0xE0){
    shift |= E0ESC;
8010244b:	8b 0d 7c 16 11 80    	mov    0x8011167c,%ecx
  if(data == 0xE0){
80102451:	3c e0                	cmp    $0xe0,%al
80102453:	74 5b                	je     801024b0 <kbdgetc+0x80>
    return 0;
  } else if(data & 0x80){
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
80102455:	89 ca                	mov    %ecx,%edx
80102457:	83 e2 40             	and    $0x40,%edx
  } else if(data & 0x80){
8010245a:	84 c0                	test   %al,%al
8010245c:	78 66                	js     801024c4 <kbdgetc+0x94>
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
8010245e:	85 d2                	test   %edx,%edx
80102460:	74 09                	je     8010246b <kbdgetc+0x3b>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
80102462:	83 c8 80             	or     $0xffffff80,%eax
80102465:	0f b6 d8             	movzbl %al,%ebx
    shift &= ~E0ESC;
80102468:	83 e1 bf             	and    $0xffffffbf,%ecx
  }

  shift |= shiftcode[data];
8010246b:	0f b6 93 a0 6e 10 80 	movzbl -0x7fef9160(%ebx),%edx
80102472:	09 ca                	or     %ecx,%edx
  shift ^= togglecode[data];
80102474:	0f b6 83 a0 6d 10 80 	movzbl -0x7fef9260(%ebx),%eax
8010247b:	31 c2                	xor    %eax,%edx
8010247d:	89 15 7c 16 11 80    	mov    %edx,0x8011167c
  c = charcode[shift & (CTL | SHIFT)][data];
80102483:	89 d0                	mov    %edx,%eax
80102485:	83 e0 03             	and    $0x3,%eax
80102488:	8b 04 85 80 6d 10 80 	mov    -0x7fef9280(,%eax,4),%eax
8010248f:	0f b6 04 18          	movzbl (%eax,%ebx,1),%eax
  if(shift & CAPSLOCK){
80102493:	83 e2 08             	and    $0x8,%edx
80102496:	74 13                	je     801024ab <kbdgetc+0x7b>
    if('a' <= c && c <= 'z')
80102498:	8d 50 9f             	lea    -0x61(%eax),%edx
8010249b:	83 fa 19             	cmp    $0x19,%edx
8010249e:	76 40                	jbe    801024e0 <kbdgetc+0xb0>
      c += 'A' - 'a';
    else if('A' <= c && c <= 'Z')
801024a0:	8d 50 bf             	lea    -0x41(%eax),%edx
801024a3:	83 fa 19             	cmp    $0x19,%edx
801024a6:	77 03                	ja     801024ab <kbdgetc+0x7b>
      c += 'a' - 'A';
801024a8:	83 c0 20             	add    $0x20,%eax
  }
  return c;
}
801024ab:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801024ae:	c9                   	leave  
801024af:	c3                   	ret    
    shift |= E0ESC;
801024b0:	89 c8                	mov    %ecx,%eax
801024b2:	83 c8 40             	or     $0x40,%eax
    shift &= ~(shiftcode[data] | E0ESC);
801024b5:	a3 7c 16 11 80       	mov    %eax,0x8011167c
    return 0;
801024ba:	31 c0                	xor    %eax,%eax
}
801024bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801024bf:	c9                   	leave  
801024c0:	c3                   	ret    
801024c1:	8d 76 00             	lea    0x0(%esi),%esi
    data = (shift & E0ESC ? data : data & 0x7F);
801024c4:	85 d2                	test   %edx,%edx
801024c6:	75 05                	jne    801024cd <kbdgetc+0x9d>
801024c8:	89 c3                	mov    %eax,%ebx
801024ca:	83 e3 7f             	and    $0x7f,%ebx
    shift &= ~(shiftcode[data] | E0ESC);
801024cd:	8a 83 a0 6e 10 80    	mov    -0x7fef9160(%ebx),%al
801024d3:	83 c8 40             	or     $0x40,%eax
801024d6:	0f b6 c0             	movzbl %al,%eax
801024d9:	f7 d0                	not    %eax
801024db:	21 c8                	and    %ecx,%eax
    return 0;
801024dd:	eb d6                	jmp    801024b5 <kbdgetc+0x85>
801024df:	90                   	nop
      c += 'A' - 'a';
801024e0:	83 e8 20             	sub    $0x20,%eax
}
801024e3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801024e6:	c9                   	leave  
801024e7:	c3                   	ret    
    return -1;
801024e8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801024ed:	c3                   	ret    
801024ee:	66 90                	xchg   %ax,%ax

801024f0 <kbdintr>:

void
kbdintr(void)
{
801024f0:	55                   	push   %ebp
801024f1:	89 e5                	mov    %esp,%ebp
801024f3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
801024f6:	68 30 24 10 80       	push   $0x80102430
801024fb:	e8 14 e3 ff ff       	call   80100814 <consoleintr>
}
80102500:	83 c4 10             	add    $0x10,%esp
80102503:	c9                   	leave  
80102504:	c3                   	ret    
80102505:	66 90                	xchg   %ax,%ax
80102507:	90                   	nop

80102508 <lapicinit>:
80102508:	a1 80 16 11 80       	mov    0x80111680,%eax
8010250d:	85 c0                	test   %eax,%eax
8010250f:	0f 84 c3 00 00 00    	je     801025d8 <lapicinit+0xd0>
80102515:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
8010251c:	01 00 00 
8010251f:	8b 50 20             	mov    0x20(%eax),%edx
80102522:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
80102529:	00 00 00 
8010252c:	8b 50 20             	mov    0x20(%eax),%edx
8010252f:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
80102536:	00 02 00 
80102539:	8b 50 20             	mov    0x20(%eax),%edx
8010253c:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
80102543:	96 98 00 
80102546:	8b 50 20             	mov    0x20(%eax),%edx
80102549:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
80102550:	00 01 00 
80102553:	8b 50 20             	mov    0x20(%eax),%edx
80102556:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
8010255d:	00 01 00 
80102560:	8b 50 20             	mov    0x20(%eax),%edx
80102563:	8b 50 30             	mov    0x30(%eax),%edx
80102566:	c1 ea 10             	shr    $0x10,%edx
80102569:	81 e2 fc 00 00 00    	and    $0xfc,%edx
8010256f:	75 6b                	jne    801025dc <lapicinit+0xd4>
80102571:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
80102578:	00 00 00 
8010257b:	8b 50 20             	mov    0x20(%eax),%edx
8010257e:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
80102585:	00 00 00 
80102588:	8b 50 20             	mov    0x20(%eax),%edx
8010258b:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
80102592:	00 00 00 
80102595:	8b 50 20             	mov    0x20(%eax),%edx
80102598:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
8010259f:	00 00 00 
801025a2:	8b 50 20             	mov    0x20(%eax),%edx
801025a5:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
801025ac:	00 00 00 
801025af:	8b 50 20             	mov    0x20(%eax),%edx
801025b2:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
801025b9:	85 08 00 
801025bc:	8b 50 20             	mov    0x20(%eax),%edx
801025bf:	90                   	nop
801025c0:	8b 90 00 03 00 00    	mov    0x300(%eax),%edx
801025c6:	80 e6 10             	and    $0x10,%dh
801025c9:	75 f5                	jne    801025c0 <lapicinit+0xb8>
801025cb:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
801025d2:	00 00 00 
801025d5:	8b 40 20             	mov    0x20(%eax),%eax
801025d8:	c3                   	ret    
801025d9:	8d 76 00             	lea    0x0(%esi),%esi
801025dc:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
801025e3:	00 01 00 
801025e6:	8b 50 20             	mov    0x20(%eax),%edx
801025e9:	eb 86                	jmp    80102571 <lapicinit+0x69>
801025eb:	90                   	nop

801025ec <lapicid>:
801025ec:	a1 80 16 11 80       	mov    0x80111680,%eax
801025f1:	85 c0                	test   %eax,%eax
801025f3:	74 07                	je     801025fc <lapicid+0x10>
801025f5:	8b 40 20             	mov    0x20(%eax),%eax
801025f8:	c1 e8 18             	shr    $0x18,%eax
801025fb:	c3                   	ret    
801025fc:	31 c0                	xor    %eax,%eax
801025fe:	c3                   	ret    
801025ff:	90                   	nop

80102600 <lapiceoi>:
80102600:	a1 80 16 11 80       	mov    0x80111680,%eax
80102605:	85 c0                	test   %eax,%eax
80102607:	74 0d                	je     80102616 <lapiceoi+0x16>
80102609:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102610:	00 00 00 
80102613:	8b 40 20             	mov    0x20(%eax),%eax
80102616:	c3                   	ret    
80102617:	90                   	nop

80102618 <microdelay>:
80102618:	c3                   	ret    
80102619:	8d 76 00             	lea    0x0(%esi),%esi

8010261c <lapicstartap>:
8010261c:	55                   	push   %ebp
8010261d:	89 e5                	mov    %esp,%ebp
8010261f:	53                   	push   %ebx
80102620:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102623:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80102626:	b0 0f                	mov    $0xf,%al
80102628:	ba 70 00 00 00       	mov    $0x70,%edx
8010262d:	ee                   	out    %al,(%dx)
8010262e:	b0 0a                	mov    $0xa,%al
80102630:	ba 71 00 00 00       	mov    $0x71,%edx
80102635:	ee                   	out    %al,(%dx)
80102636:	66 c7 05 67 04 00 80 	movw   $0x0,0x80000467
8010263d:	00 00 
8010263f:	89 c8                	mov    %ecx,%eax
80102641:	c1 e8 04             	shr    $0x4,%eax
80102644:	66 a3 69 04 00 80    	mov    %ax,0x80000469
8010264a:	a1 80 16 11 80       	mov    0x80111680,%eax
8010264f:	c1 e3 18             	shl    $0x18,%ebx
80102652:	89 da                	mov    %ebx,%edx
80102654:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
8010265a:	8b 58 20             	mov    0x20(%eax),%ebx
8010265d:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
80102664:	c5 00 00 
80102667:	8b 58 20             	mov    0x20(%eax),%ebx
8010266a:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
80102671:	85 00 00 
80102674:	8b 58 20             	mov    0x20(%eax),%ebx
80102677:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
8010267d:	8b 58 20             	mov    0x20(%eax),%ebx
80102680:	c1 e9 0c             	shr    $0xc,%ecx
80102683:	80 cd 06             	or     $0x6,%ch
80102686:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
8010268c:	8b 58 20             	mov    0x20(%eax),%ebx
8010268f:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
80102695:	8b 50 20             	mov    0x20(%eax),%edx
80102698:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
8010269e:	8b 40 20             	mov    0x20(%eax),%eax
801026a1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801026a4:	c9                   	leave  
801026a5:	c3                   	ret    
801026a6:	66 90                	xchg   %ax,%ax

801026a8 <cmostime>:
801026a8:	55                   	push   %ebp
801026a9:	89 e5                	mov    %esp,%ebp
801026ab:	57                   	push   %edi
801026ac:	56                   	push   %esi
801026ad:	53                   	push   %ebx
801026ae:	83 ec 4c             	sub    $0x4c,%esp
801026b1:	b0 0b                	mov    $0xb,%al
801026b3:	ba 70 00 00 00       	mov    $0x70,%edx
801026b8:	ee                   	out    %al,(%dx)
801026b9:	ba 71 00 00 00       	mov    $0x71,%edx
801026be:	ec                   	in     (%dx),%al
801026bf:	83 e0 04             	and    $0x4,%eax
801026c2:	89 c6                	mov    %eax,%esi
801026c4:	bb 70 00 00 00       	mov    $0x70,%ebx
801026c9:	8d 76 00             	lea    0x0(%esi),%esi
801026cc:	31 c0                	xor    %eax,%eax
801026ce:	89 da                	mov    %ebx,%edx
801026d0:	ee                   	out    %al,(%dx)
801026d1:	bf 71 00 00 00       	mov    $0x71,%edi
801026d6:	89 fa                	mov    %edi,%edx
801026d8:	ec                   	in     (%dx),%al
801026d9:	88 45 b7             	mov    %al,-0x49(%ebp)
801026dc:	b0 02                	mov    $0x2,%al
801026de:	89 da                	mov    %ebx,%edx
801026e0:	ee                   	out    %al,(%dx)
801026e1:	89 fa                	mov    %edi,%edx
801026e3:	ec                   	in     (%dx),%al
801026e4:	88 45 b6             	mov    %al,-0x4a(%ebp)
801026e7:	b0 04                	mov    $0x4,%al
801026e9:	89 da                	mov    %ebx,%edx
801026eb:	ee                   	out    %al,(%dx)
801026ec:	89 fa                	mov    %edi,%edx
801026ee:	ec                   	in     (%dx),%al
801026ef:	88 45 b5             	mov    %al,-0x4b(%ebp)
801026f2:	b0 07                	mov    $0x7,%al
801026f4:	89 da                	mov    %ebx,%edx
801026f6:	ee                   	out    %al,(%dx)
801026f7:	89 fa                	mov    %edi,%edx
801026f9:	ec                   	in     (%dx),%al
801026fa:	88 45 b4             	mov    %al,-0x4c(%ebp)
801026fd:	b0 08                	mov    $0x8,%al
801026ff:	89 da                	mov    %ebx,%edx
80102701:	ee                   	out    %al,(%dx)
80102702:	89 fa                	mov    %edi,%edx
80102704:	ec                   	in     (%dx),%al
80102705:	88 45 b3             	mov    %al,-0x4d(%ebp)
80102708:	b0 09                	mov    $0x9,%al
8010270a:	89 da                	mov    %ebx,%edx
8010270c:	ee                   	out    %al,(%dx)
8010270d:	89 fa                	mov    %edi,%edx
8010270f:	ec                   	in     (%dx),%al
80102710:	0f b6 c8             	movzbl %al,%ecx
80102713:	b0 0a                	mov    $0xa,%al
80102715:	89 da                	mov    %ebx,%edx
80102717:	ee                   	out    %al,(%dx)
80102718:	89 fa                	mov    %edi,%edx
8010271a:	ec                   	in     (%dx),%al
8010271b:	84 c0                	test   %al,%al
8010271d:	78 ad                	js     801026cc <cmostime+0x24>
8010271f:	0f b6 45 b7          	movzbl -0x49(%ebp),%eax
80102723:	89 45 b8             	mov    %eax,-0x48(%ebp)
80102726:	0f b6 45 b6          	movzbl -0x4a(%ebp),%eax
8010272a:	89 45 bc             	mov    %eax,-0x44(%ebp)
8010272d:	0f b6 45 b5          	movzbl -0x4b(%ebp),%eax
80102731:	89 45 c0             	mov    %eax,-0x40(%ebp)
80102734:	0f b6 45 b4          	movzbl -0x4c(%ebp),%eax
80102738:	89 45 c4             	mov    %eax,-0x3c(%ebp)
8010273b:	0f b6 45 b3          	movzbl -0x4d(%ebp),%eax
8010273f:	89 45 c8             	mov    %eax,-0x38(%ebp)
80102742:	89 4d cc             	mov    %ecx,-0x34(%ebp)
80102745:	31 c0                	xor    %eax,%eax
80102747:	89 da                	mov    %ebx,%edx
80102749:	ee                   	out    %al,(%dx)
8010274a:	89 fa                	mov    %edi,%edx
8010274c:	ec                   	in     (%dx),%al
8010274d:	0f b6 c0             	movzbl %al,%eax
80102750:	89 45 d0             	mov    %eax,-0x30(%ebp)
80102753:	b0 02                	mov    $0x2,%al
80102755:	89 da                	mov    %ebx,%edx
80102757:	ee                   	out    %al,(%dx)
80102758:	89 fa                	mov    %edi,%edx
8010275a:	ec                   	in     (%dx),%al
8010275b:	0f b6 c0             	movzbl %al,%eax
8010275e:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80102761:	b0 04                	mov    $0x4,%al
80102763:	89 da                	mov    %ebx,%edx
80102765:	ee                   	out    %al,(%dx)
80102766:	89 fa                	mov    %edi,%edx
80102768:	ec                   	in     (%dx),%al
80102769:	0f b6 c0             	movzbl %al,%eax
8010276c:	89 45 d8             	mov    %eax,-0x28(%ebp)
8010276f:	b0 07                	mov    $0x7,%al
80102771:	89 da                	mov    %ebx,%edx
80102773:	ee                   	out    %al,(%dx)
80102774:	89 fa                	mov    %edi,%edx
80102776:	ec                   	in     (%dx),%al
80102777:	0f b6 c0             	movzbl %al,%eax
8010277a:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010277d:	b0 08                	mov    $0x8,%al
8010277f:	89 da                	mov    %ebx,%edx
80102781:	ee                   	out    %al,(%dx)
80102782:	89 fa                	mov    %edi,%edx
80102784:	ec                   	in     (%dx),%al
80102785:	0f b6 c0             	movzbl %al,%eax
80102788:	89 45 e0             	mov    %eax,-0x20(%ebp)
8010278b:	b0 09                	mov    $0x9,%al
8010278d:	89 da                	mov    %ebx,%edx
8010278f:	ee                   	out    %al,(%dx)
80102790:	89 fa                	mov    %edi,%edx
80102792:	ec                   	in     (%dx),%al
80102793:	0f b6 c0             	movzbl %al,%eax
80102796:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80102799:	50                   	push   %eax
8010279a:	6a 18                	push   $0x18
8010279c:	8d 45 d0             	lea    -0x30(%ebp),%eax
8010279f:	50                   	push   %eax
801027a0:	8d 45 b8             	lea    -0x48(%ebp),%eax
801027a3:	50                   	push   %eax
801027a4:	e8 67 1a 00 00       	call   80104210 <memcmp>
801027a9:	83 c4 10             	add    $0x10,%esp
801027ac:	85 c0                	test   %eax,%eax
801027ae:	0f 85 18 ff ff ff    	jne    801026cc <cmostime+0x24>
801027b4:	89 f0                	mov    %esi,%eax
801027b6:	84 c0                	test   %al,%al
801027b8:	75 7e                	jne    80102838 <cmostime+0x190>
801027ba:	8b 55 b8             	mov    -0x48(%ebp),%edx
801027bd:	89 d0                	mov    %edx,%eax
801027bf:	c1 e8 04             	shr    $0x4,%eax
801027c2:	8d 04 80             	lea    (%eax,%eax,4),%eax
801027c5:	01 c0                	add    %eax,%eax
801027c7:	83 e2 0f             	and    $0xf,%edx
801027ca:	01 d0                	add    %edx,%eax
801027cc:	89 45 b8             	mov    %eax,-0x48(%ebp)
801027cf:	8b 55 bc             	mov    -0x44(%ebp),%edx
801027d2:	89 d0                	mov    %edx,%eax
801027d4:	c1 e8 04             	shr    $0x4,%eax
801027d7:	8d 04 80             	lea    (%eax,%eax,4),%eax
801027da:	01 c0                	add    %eax,%eax
801027dc:	83 e2 0f             	and    $0xf,%edx
801027df:	01 d0                	add    %edx,%eax
801027e1:	89 45 bc             	mov    %eax,-0x44(%ebp)
801027e4:	8b 55 c0             	mov    -0x40(%ebp),%edx
801027e7:	89 d0                	mov    %edx,%eax
801027e9:	c1 e8 04             	shr    $0x4,%eax
801027ec:	8d 04 80             	lea    (%eax,%eax,4),%eax
801027ef:	01 c0                	add    %eax,%eax
801027f1:	83 e2 0f             	and    $0xf,%edx
801027f4:	01 d0                	add    %edx,%eax
801027f6:	89 45 c0             	mov    %eax,-0x40(%ebp)
801027f9:	8b 55 c4             	mov    -0x3c(%ebp),%edx
801027fc:	89 d0                	mov    %edx,%eax
801027fe:	c1 e8 04             	shr    $0x4,%eax
80102801:	8d 04 80             	lea    (%eax,%eax,4),%eax
80102804:	01 c0                	add    %eax,%eax
80102806:	83 e2 0f             	and    $0xf,%edx
80102809:	01 d0                	add    %edx,%eax
8010280b:	89 45 c4             	mov    %eax,-0x3c(%ebp)
8010280e:	8b 55 c8             	mov    -0x38(%ebp),%edx
80102811:	89 d0                	mov    %edx,%eax
80102813:	c1 e8 04             	shr    $0x4,%eax
80102816:	8d 04 80             	lea    (%eax,%eax,4),%eax
80102819:	01 c0                	add    %eax,%eax
8010281b:	83 e2 0f             	and    $0xf,%edx
8010281e:	01 d0                	add    %edx,%eax
80102820:	89 45 c8             	mov    %eax,-0x38(%ebp)
80102823:	8b 55 cc             	mov    -0x34(%ebp),%edx
80102826:	89 d0                	mov    %edx,%eax
80102828:	c1 e8 04             	shr    $0x4,%eax
8010282b:	8d 04 80             	lea    (%eax,%eax,4),%eax
8010282e:	01 c0                	add    %eax,%eax
80102830:	83 e2 0f             	and    $0xf,%edx
80102833:	01 d0                	add    %edx,%eax
80102835:	89 45 cc             	mov    %eax,-0x34(%ebp)
80102838:	b9 06 00 00 00       	mov    $0x6,%ecx
8010283d:	8b 7d 08             	mov    0x8(%ebp),%edi
80102840:	8d 75 b8             	lea    -0x48(%ebp),%esi
80102843:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
80102845:	8b 45 08             	mov    0x8(%ebp),%eax
80102848:	81 40 14 d0 07 00 00 	addl   $0x7d0,0x14(%eax)
8010284f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102852:	5b                   	pop    %ebx
80102853:	5e                   	pop    %esi
80102854:	5f                   	pop    %edi
80102855:	5d                   	pop    %ebp
80102856:	c3                   	ret    
80102857:	90                   	nop

80102858 <install_trans>:
80102858:	8b 0d e8 16 11 80    	mov    0x801116e8,%ecx
8010285e:	85 c9                	test   %ecx,%ecx
80102860:	7e 7e                	jle    801028e0 <install_trans+0x88>
80102862:	55                   	push   %ebp
80102863:	89 e5                	mov    %esp,%ebp
80102865:	57                   	push   %edi
80102866:	56                   	push   %esi
80102867:	53                   	push   %ebx
80102868:	83 ec 0c             	sub    $0xc,%esp
8010286b:	31 ff                	xor    %edi,%edi
8010286d:	8d 76 00             	lea    0x0(%esi),%esi
80102870:	83 ec 08             	sub    $0x8,%esp
80102873:	a1 d4 16 11 80       	mov    0x801116d4,%eax
80102878:	01 f8                	add    %edi,%eax
8010287a:	40                   	inc    %eax
8010287b:	50                   	push   %eax
8010287c:	ff 35 e4 16 11 80    	pushl  0x801116e4
80102882:	e8 2d d8 ff ff       	call   801000b4 <bread>
80102887:	89 c6                	mov    %eax,%esi
80102889:	58                   	pop    %eax
8010288a:	5a                   	pop    %edx
8010288b:	ff 34 bd ec 16 11 80 	pushl  -0x7feee914(,%edi,4)
80102892:	ff 35 e4 16 11 80    	pushl  0x801116e4
80102898:	e8 17 d8 ff ff       	call   801000b4 <bread>
8010289d:	89 c3                	mov    %eax,%ebx
8010289f:	83 c4 0c             	add    $0xc,%esp
801028a2:	68 00 02 00 00       	push   $0x200
801028a7:	8d 46 5c             	lea    0x5c(%esi),%eax
801028aa:	50                   	push   %eax
801028ab:	8d 43 5c             	lea    0x5c(%ebx),%eax
801028ae:	50                   	push   %eax
801028af:	e8 94 19 00 00       	call   80104248 <memmove>
801028b4:	89 1c 24             	mov    %ebx,(%esp)
801028b7:	e8 c8 d8 ff ff       	call   80100184 <bwrite>
801028bc:	89 34 24             	mov    %esi,(%esp)
801028bf:	e8 f8 d8 ff ff       	call   801001bc <brelse>
801028c4:	89 1c 24             	mov    %ebx,(%esp)
801028c7:	e8 f0 d8 ff ff       	call   801001bc <brelse>
801028cc:	47                   	inc    %edi
801028cd:	83 c4 10             	add    $0x10,%esp
801028d0:	39 3d e8 16 11 80    	cmp    %edi,0x801116e8
801028d6:	7f 98                	jg     80102870 <install_trans+0x18>
801028d8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801028db:	5b                   	pop    %ebx
801028dc:	5e                   	pop    %esi
801028dd:	5f                   	pop    %edi
801028de:	5d                   	pop    %ebp
801028df:	c3                   	ret    
801028e0:	c3                   	ret    
801028e1:	8d 76 00             	lea    0x0(%esi),%esi

801028e4 <write_head>:
801028e4:	55                   	push   %ebp
801028e5:	89 e5                	mov    %esp,%ebp
801028e7:	53                   	push   %ebx
801028e8:	83 ec 0c             	sub    $0xc,%esp
801028eb:	ff 35 d4 16 11 80    	pushl  0x801116d4
801028f1:	ff 35 e4 16 11 80    	pushl  0x801116e4
801028f7:	e8 b8 d7 ff ff       	call   801000b4 <bread>
801028fc:	89 c3                	mov    %eax,%ebx
801028fe:	a1 e8 16 11 80       	mov    0x801116e8,%eax
80102903:	89 43 5c             	mov    %eax,0x5c(%ebx)
80102906:	83 c4 10             	add    $0x10,%esp
80102909:	85 c0                	test   %eax,%eax
8010290b:	7e 13                	jle    80102920 <write_head+0x3c>
8010290d:	31 d2                	xor    %edx,%edx
8010290f:	90                   	nop
80102910:	8b 0c 95 ec 16 11 80 	mov    -0x7feee914(,%edx,4),%ecx
80102917:	89 4c 93 60          	mov    %ecx,0x60(%ebx,%edx,4)
8010291b:	42                   	inc    %edx
8010291c:	39 d0                	cmp    %edx,%eax
8010291e:	75 f0                	jne    80102910 <write_head+0x2c>
80102920:	83 ec 0c             	sub    $0xc,%esp
80102923:	53                   	push   %ebx
80102924:	e8 5b d8 ff ff       	call   80100184 <bwrite>
80102929:	89 1c 24             	mov    %ebx,(%esp)
8010292c:	e8 8b d8 ff ff       	call   801001bc <brelse>
80102931:	83 c4 10             	add    $0x10,%esp
80102934:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102937:	c9                   	leave  
80102938:	c3                   	ret    
80102939:	8d 76 00             	lea    0x0(%esi),%esi

8010293c <initlog>:
8010293c:	55                   	push   %ebp
8010293d:	89 e5                	mov    %esp,%ebp
8010293f:	53                   	push   %ebx
80102940:	83 ec 2c             	sub    $0x2c,%esp
80102943:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102946:	68 a0 6f 10 80       	push   $0x80106fa0
8010294b:	68 a0 16 11 80       	push   $0x801116a0
80102950:	e8 f7 15 00 00       	call   80103f4c <initlock>
80102955:	58                   	pop    %eax
80102956:	5a                   	pop    %edx
80102957:	8d 45 dc             	lea    -0x24(%ebp),%eax
8010295a:	50                   	push   %eax
8010295b:	53                   	push   %ebx
8010295c:	e8 7b ea ff ff       	call   801013dc <readsb>
80102961:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102964:	a3 d4 16 11 80       	mov    %eax,0x801116d4
80102969:	8b 55 e8             	mov    -0x18(%ebp),%edx
8010296c:	89 15 d8 16 11 80    	mov    %edx,0x801116d8
80102972:	89 1d e4 16 11 80    	mov    %ebx,0x801116e4
80102978:	59                   	pop    %ecx
80102979:	5a                   	pop    %edx
8010297a:	50                   	push   %eax
8010297b:	53                   	push   %ebx
8010297c:	e8 33 d7 ff ff       	call   801000b4 <bread>
80102981:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102984:	89 1d e8 16 11 80    	mov    %ebx,0x801116e8
8010298a:	83 c4 10             	add    $0x10,%esp
8010298d:	85 db                	test   %ebx,%ebx
8010298f:	7e 13                	jle    801029a4 <initlog+0x68>
80102991:	31 d2                	xor    %edx,%edx
80102993:	90                   	nop
80102994:	8b 4c 90 60          	mov    0x60(%eax,%edx,4),%ecx
80102998:	89 0c 95 ec 16 11 80 	mov    %ecx,-0x7feee914(,%edx,4)
8010299f:	42                   	inc    %edx
801029a0:	39 d3                	cmp    %edx,%ebx
801029a2:	75 f0                	jne    80102994 <initlog+0x58>
801029a4:	83 ec 0c             	sub    $0xc,%esp
801029a7:	50                   	push   %eax
801029a8:	e8 0f d8 ff ff       	call   801001bc <brelse>
801029ad:	e8 a6 fe ff ff       	call   80102858 <install_trans>
801029b2:	c7 05 e8 16 11 80 00 	movl   $0x0,0x801116e8
801029b9:	00 00 00 
801029bc:	e8 23 ff ff ff       	call   801028e4 <write_head>
801029c1:	83 c4 10             	add    $0x10,%esp
801029c4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801029c7:	c9                   	leave  
801029c8:	c3                   	ret    
801029c9:	8d 76 00             	lea    0x0(%esi),%esi

801029cc <begin_op>:
801029cc:	55                   	push   %ebp
801029cd:	89 e5                	mov    %esp,%ebp
801029cf:	83 ec 14             	sub    $0x14,%esp
801029d2:	68 a0 16 11 80       	push   $0x801116a0
801029d7:	e8 30 17 00 00       	call   8010410c <acquire>
801029dc:	83 c4 10             	add    $0x10,%esp
801029df:	eb 18                	jmp    801029f9 <begin_op+0x2d>
801029e1:	8d 76 00             	lea    0x0(%esi),%esi
801029e4:	83 ec 08             	sub    $0x8,%esp
801029e7:	68 a0 16 11 80       	push   $0x801116a0
801029ec:	68 a0 16 11 80       	push   $0x801116a0
801029f1:	e8 12 12 00 00       	call   80103c08 <sleep>
801029f6:	83 c4 10             	add    $0x10,%esp
801029f9:	a1 e0 16 11 80       	mov    0x801116e0,%eax
801029fe:	85 c0                	test   %eax,%eax
80102a00:	75 e2                	jne    801029e4 <begin_op+0x18>
80102a02:	a1 dc 16 11 80       	mov    0x801116dc,%eax
80102a07:	8d 50 01             	lea    0x1(%eax),%edx
80102a0a:	8d 44 80 05          	lea    0x5(%eax,%eax,4),%eax
80102a0e:	01 c0                	add    %eax,%eax
80102a10:	03 05 e8 16 11 80    	add    0x801116e8,%eax
80102a16:	83 f8 1e             	cmp    $0x1e,%eax
80102a19:	7f c9                	jg     801029e4 <begin_op+0x18>
80102a1b:	89 15 dc 16 11 80    	mov    %edx,0x801116dc
80102a21:	83 ec 0c             	sub    $0xc,%esp
80102a24:	68 a0 16 11 80       	push   $0x801116a0
80102a29:	e8 7e 16 00 00       	call   801040ac <release>
80102a2e:	83 c4 10             	add    $0x10,%esp
80102a31:	c9                   	leave  
80102a32:	c3                   	ret    
80102a33:	90                   	nop

80102a34 <end_op>:
80102a34:	55                   	push   %ebp
80102a35:	89 e5                	mov    %esp,%ebp
80102a37:	57                   	push   %edi
80102a38:	56                   	push   %esi
80102a39:	53                   	push   %ebx
80102a3a:	83 ec 18             	sub    $0x18,%esp
80102a3d:	68 a0 16 11 80       	push   $0x801116a0
80102a42:	e8 c5 16 00 00       	call   8010410c <acquire>
80102a47:	a1 dc 16 11 80       	mov    0x801116dc,%eax
80102a4c:	8d 58 ff             	lea    -0x1(%eax),%ebx
80102a4f:	89 1d dc 16 11 80    	mov    %ebx,0x801116dc
80102a55:	83 c4 10             	add    $0x10,%esp
80102a58:	8b 35 e0 16 11 80    	mov    0x801116e0,%esi
80102a5e:	85 f6                	test   %esi,%esi
80102a60:	0f 85 12 01 00 00    	jne    80102b78 <end_op+0x144>
80102a66:	85 db                	test   %ebx,%ebx
80102a68:	0f 85 e6 00 00 00    	jne    80102b54 <end_op+0x120>
80102a6e:	c7 05 e0 16 11 80 01 	movl   $0x1,0x801116e0
80102a75:	00 00 00 
80102a78:	83 ec 0c             	sub    $0xc,%esp
80102a7b:	68 a0 16 11 80       	push   $0x801116a0
80102a80:	e8 27 16 00 00       	call   801040ac <release>
80102a85:	83 c4 10             	add    $0x10,%esp
80102a88:	8b 0d e8 16 11 80    	mov    0x801116e8,%ecx
80102a8e:	85 c9                	test   %ecx,%ecx
80102a90:	7f 3a                	jg     80102acc <end_op+0x98>
80102a92:	83 ec 0c             	sub    $0xc,%esp
80102a95:	68 a0 16 11 80       	push   $0x801116a0
80102a9a:	e8 6d 16 00 00       	call   8010410c <acquire>
80102a9f:	c7 05 e0 16 11 80 00 	movl   $0x0,0x801116e0
80102aa6:	00 00 00 
80102aa9:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
80102ab0:	e8 0f 12 00 00       	call   80103cc4 <wakeup>
80102ab5:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
80102abc:	e8 eb 15 00 00       	call   801040ac <release>
80102ac1:	83 c4 10             	add    $0x10,%esp
80102ac4:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102ac7:	5b                   	pop    %ebx
80102ac8:	5e                   	pop    %esi
80102ac9:	5f                   	pop    %edi
80102aca:	5d                   	pop    %ebp
80102acb:	c3                   	ret    
80102acc:	83 ec 08             	sub    $0x8,%esp
80102acf:	a1 d4 16 11 80       	mov    0x801116d4,%eax
80102ad4:	01 d8                	add    %ebx,%eax
80102ad6:	40                   	inc    %eax
80102ad7:	50                   	push   %eax
80102ad8:	ff 35 e4 16 11 80    	pushl  0x801116e4
80102ade:	e8 d1 d5 ff ff       	call   801000b4 <bread>
80102ae3:	89 c6                	mov    %eax,%esi
80102ae5:	58                   	pop    %eax
80102ae6:	5a                   	pop    %edx
80102ae7:	ff 34 9d ec 16 11 80 	pushl  -0x7feee914(,%ebx,4)
80102aee:	ff 35 e4 16 11 80    	pushl  0x801116e4
80102af4:	e8 bb d5 ff ff       	call   801000b4 <bread>
80102af9:	89 c7                	mov    %eax,%edi
80102afb:	83 c4 0c             	add    $0xc,%esp
80102afe:	68 00 02 00 00       	push   $0x200
80102b03:	8d 40 5c             	lea    0x5c(%eax),%eax
80102b06:	50                   	push   %eax
80102b07:	8d 46 5c             	lea    0x5c(%esi),%eax
80102b0a:	50                   	push   %eax
80102b0b:	e8 38 17 00 00       	call   80104248 <memmove>
80102b10:	89 34 24             	mov    %esi,(%esp)
80102b13:	e8 6c d6 ff ff       	call   80100184 <bwrite>
80102b18:	89 3c 24             	mov    %edi,(%esp)
80102b1b:	e8 9c d6 ff ff       	call   801001bc <brelse>
80102b20:	89 34 24             	mov    %esi,(%esp)
80102b23:	e8 94 d6 ff ff       	call   801001bc <brelse>
80102b28:	43                   	inc    %ebx
80102b29:	83 c4 10             	add    $0x10,%esp
80102b2c:	3b 1d e8 16 11 80    	cmp    0x801116e8,%ebx
80102b32:	7c 98                	jl     80102acc <end_op+0x98>
80102b34:	e8 ab fd ff ff       	call   801028e4 <write_head>
80102b39:	e8 1a fd ff ff       	call   80102858 <install_trans>
80102b3e:	c7 05 e8 16 11 80 00 	movl   $0x0,0x801116e8
80102b45:	00 00 00 
80102b48:	e8 97 fd ff ff       	call   801028e4 <write_head>
80102b4d:	e9 40 ff ff ff       	jmp    80102a92 <end_op+0x5e>
80102b52:	66 90                	xchg   %ax,%ax
80102b54:	83 ec 0c             	sub    $0xc,%esp
80102b57:	68 a0 16 11 80       	push   $0x801116a0
80102b5c:	e8 63 11 00 00       	call   80103cc4 <wakeup>
80102b61:	c7 04 24 a0 16 11 80 	movl   $0x801116a0,(%esp)
80102b68:	e8 3f 15 00 00       	call   801040ac <release>
80102b6d:	83 c4 10             	add    $0x10,%esp
80102b70:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102b73:	5b                   	pop    %ebx
80102b74:	5e                   	pop    %esi
80102b75:	5f                   	pop    %edi
80102b76:	5d                   	pop    %ebp
80102b77:	c3                   	ret    
80102b78:	83 ec 0c             	sub    $0xc,%esp
80102b7b:	68 a4 6f 10 80       	push   $0x80106fa4
80102b80:	e8 b3 d7 ff ff       	call   80100338 <panic>
80102b85:	8d 76 00             	lea    0x0(%esi),%esi

80102b88 <log_write>:
80102b88:	55                   	push   %ebp
80102b89:	89 e5                	mov    %esp,%ebp
80102b8b:	53                   	push   %ebx
80102b8c:	52                   	push   %edx
80102b8d:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102b90:	8b 15 e8 16 11 80    	mov    0x801116e8,%edx
80102b96:	83 fa 1d             	cmp    $0x1d,%edx
80102b99:	7f 71                	jg     80102c0c <log_write+0x84>
80102b9b:	a1 d8 16 11 80       	mov    0x801116d8,%eax
80102ba0:	48                   	dec    %eax
80102ba1:	39 c2                	cmp    %eax,%edx
80102ba3:	7d 67                	jge    80102c0c <log_write+0x84>
80102ba5:	a1 dc 16 11 80       	mov    0x801116dc,%eax
80102baa:	85 c0                	test   %eax,%eax
80102bac:	7e 6b                	jle    80102c19 <log_write+0x91>
80102bae:	83 ec 0c             	sub    $0xc,%esp
80102bb1:	68 a0 16 11 80       	push   $0x801116a0
80102bb6:	e8 51 15 00 00       	call   8010410c <acquire>
80102bbb:	8b 15 e8 16 11 80    	mov    0x801116e8,%edx
80102bc1:	83 c4 10             	add    $0x10,%esp
80102bc4:	8b 4b 08             	mov    0x8(%ebx),%ecx
80102bc7:	31 c0                	xor    %eax,%eax
80102bc9:	85 d2                	test   %edx,%edx
80102bcb:	7f 08                	jg     80102bd5 <log_write+0x4d>
80102bcd:	eb 0f                	jmp    80102bde <log_write+0x56>
80102bcf:	90                   	nop
80102bd0:	40                   	inc    %eax
80102bd1:	39 c2                	cmp    %eax,%edx
80102bd3:	74 27                	je     80102bfc <log_write+0x74>
80102bd5:	39 0c 85 ec 16 11 80 	cmp    %ecx,-0x7feee914(,%eax,4)
80102bdc:	75 f2                	jne    80102bd0 <log_write+0x48>
80102bde:	89 0c 85 ec 16 11 80 	mov    %ecx,-0x7feee914(,%eax,4)
80102be5:	39 c2                	cmp    %eax,%edx
80102be7:	74 1a                	je     80102c03 <log_write+0x7b>
80102be9:	83 0b 04             	orl    $0x4,(%ebx)
80102bec:	c7 45 08 a0 16 11 80 	movl   $0x801116a0,0x8(%ebp)
80102bf3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102bf6:	c9                   	leave  
80102bf7:	e9 b0 14 00 00       	jmp    801040ac <release>
80102bfc:	89 0c 95 ec 16 11 80 	mov    %ecx,-0x7feee914(,%edx,4)
80102c03:	42                   	inc    %edx
80102c04:	89 15 e8 16 11 80    	mov    %edx,0x801116e8
80102c0a:	eb dd                	jmp    80102be9 <log_write+0x61>
80102c0c:	83 ec 0c             	sub    $0xc,%esp
80102c0f:	68 b3 6f 10 80       	push   $0x80106fb3
80102c14:	e8 1f d7 ff ff       	call   80100338 <panic>
80102c19:	83 ec 0c             	sub    $0xc,%esp
80102c1c:	68 c9 6f 10 80       	push   $0x80106fc9
80102c21:	e8 12 d7 ff ff       	call   80100338 <panic>
80102c26:	66 90                	xchg   %ax,%ax

80102c28 <mpmain>:
80102c28:	55                   	push   %ebp
80102c29:	89 e5                	mov    %esp,%ebp
80102c2b:	53                   	push   %ebx
80102c2c:	50                   	push   %eax
80102c2d:	e8 ae 08 00 00       	call   801034e0 <cpuid>
80102c32:	89 c3                	mov    %eax,%ebx
80102c34:	e8 a7 08 00 00       	call   801034e0 <cpuid>
80102c39:	52                   	push   %edx
80102c3a:	53                   	push   %ebx
80102c3b:	50                   	push   %eax
80102c3c:	68 e4 6f 10 80       	push   $0x80106fe4
80102c41:	e8 e2 d9 ff ff       	call   80100628 <cprintf>
80102c46:	e8 7d 26 00 00       	call   801052c8 <idtinit>
80102c4b:	e8 2c 08 00 00       	call   8010347c <mycpu>
80102c50:	89 c2                	mov    %eax,%edx
80102c52:	b8 01 00 00 00       	mov    $0x1,%eax
80102c57:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
80102c5e:	e8 35 0b 00 00       	call   80103798 <scheduler>
80102c63:	90                   	nop

80102c64 <mpenter>:
80102c64:	55                   	push   %ebp
80102c65:	89 e5                	mov    %esp,%ebp
80102c67:	83 ec 08             	sub    $0x8,%esp
80102c6a:	e8 a9 37 00 00       	call   80106418 <switchkvm>
80102c6f:	e8 28 36 00 00       	call   8010629c <seginit>
80102c74:	e8 8f f8 ff ff       	call   80102508 <lapicinit>
80102c79:	e8 aa ff ff ff       	call   80102c28 <mpmain>
80102c7e:	66 90                	xchg   %ax,%ax

80102c80 <main>:
80102c80:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80102c84:	83 e4 f0             	and    $0xfffffff0,%esp
80102c87:	ff 71 fc             	pushl  -0x4(%ecx)
80102c8a:	55                   	push   %ebp
80102c8b:	89 e5                	mov    %esp,%ebp
80102c8d:	53                   	push   %ebx
80102c8e:	51                   	push   %ecx
80102c8f:	83 ec 08             	sub    $0x8,%esp
80102c92:	68 00 00 40 80       	push   $0x80400000
80102c97:	68 d0 55 11 80       	push   $0x801155d0
80102c9c:	e8 c3 f6 ff ff       	call   80102364 <kinit1>
80102ca1:	e8 b6 3b 00 00       	call   8010685c <kvmalloc>
80102ca6:	e8 61 01 00 00       	call   80102e0c <mpinit>
80102cab:	e8 58 f8 ff ff       	call   80102508 <lapicinit>
80102cb0:	e8 e7 35 00 00       	call   8010629c <seginit>
80102cb5:	e8 1a 03 00 00       	call   80102fd4 <picinit>
80102cba:	e8 a9 f4 ff ff       	call   80102168 <ioapicinit>
80102cbf:	e8 18 dd ff ff       	call   801009dc <consoleinit>
80102cc4:	e8 a3 28 00 00       	call   8010556c <uartinit>
80102cc9:	e8 92 07 00 00       	call   80103460 <pinit>
80102cce:	e8 89 25 00 00       	call   8010525c <tvinit>
80102cd3:	e8 5c d3 ff ff       	call   80100034 <binit>
80102cd8:	e8 9f e0 ff ff       	call   80100d7c <fileinit>
80102cdd:	e8 a2 f2 ff ff       	call   80101f84 <ideinit>
80102ce2:	83 c4 0c             	add    $0xc,%esp
80102ce5:	68 8a 00 00 00       	push   $0x8a
80102cea:	68 8c a4 10 80       	push   $0x8010a48c
80102cef:	68 00 70 00 80       	push   $0x80007000
80102cf4:	e8 4f 15 00 00       	call   80104248 <memmove>
80102cf9:	8b 15 84 17 11 80    	mov    0x80111784,%edx
80102cff:	8d 04 92             	lea    (%edx,%edx,4),%eax
80102d02:	01 c0                	add    %eax,%eax
80102d04:	01 d0                	add    %edx,%eax
80102d06:	c1 e0 04             	shl    $0x4,%eax
80102d09:	05 a0 17 11 80       	add    $0x801117a0,%eax
80102d0e:	83 c4 10             	add    $0x10,%esp
80102d11:	3d a0 17 11 80       	cmp    $0x801117a0,%eax
80102d16:	76 74                	jbe    80102d8c <main+0x10c>
80102d18:	bb a0 17 11 80       	mov    $0x801117a0,%ebx
80102d1d:	eb 20                	jmp    80102d3f <main+0xbf>
80102d1f:	90                   	nop
80102d20:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80102d26:	8b 15 84 17 11 80    	mov    0x80111784,%edx
80102d2c:	8d 04 92             	lea    (%edx,%edx,4),%eax
80102d2f:	01 c0                	add    %eax,%eax
80102d31:	01 d0                	add    %edx,%eax
80102d33:	c1 e0 04             	shl    $0x4,%eax
80102d36:	05 a0 17 11 80       	add    $0x801117a0,%eax
80102d3b:	39 c3                	cmp    %eax,%ebx
80102d3d:	73 4d                	jae    80102d8c <main+0x10c>
80102d3f:	e8 38 07 00 00       	call   8010347c <mycpu>
80102d44:	39 c3                	cmp    %eax,%ebx
80102d46:	74 d8                	je     80102d20 <main+0xa0>
80102d48:	e8 7b f6 ff ff       	call   801023c8 <kalloc>
80102d4d:	05 00 10 00 00       	add    $0x1000,%eax
80102d52:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
80102d57:	c7 05 f8 6f 00 80 64 	movl   $0x80102c64,0x80006ff8
80102d5e:	2c 10 80 
80102d61:	c7 05 f4 6f 00 80 00 	movl   $0x109000,0x80006ff4
80102d68:	90 10 00 
80102d6b:	83 ec 08             	sub    $0x8,%esp
80102d6e:	68 00 70 00 00       	push   $0x7000
80102d73:	0f b6 03             	movzbl (%ebx),%eax
80102d76:	50                   	push   %eax
80102d77:	e8 a0 f8 ff ff       	call   8010261c <lapicstartap>
80102d7c:	83 c4 10             	add    $0x10,%esp
80102d7f:	90                   	nop
80102d80:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80102d86:	85 c0                	test   %eax,%eax
80102d88:	74 f6                	je     80102d80 <main+0x100>
80102d8a:	eb 94                	jmp    80102d20 <main+0xa0>
80102d8c:	83 ec 08             	sub    $0x8,%esp
80102d8f:	68 00 00 00 8e       	push   $0x8e000000
80102d94:	68 00 00 40 80       	push   $0x80400000
80102d99:	e8 72 f5 ff ff       	call   80102310 <kinit2>
80102d9e:	e8 95 07 00 00       	call   80103538 <userinit>
80102da3:	e8 80 fe ff ff       	call   80102c28 <mpmain>

80102da8 <mpsearch1>:
80102da8:	55                   	push   %ebp
80102da9:	89 e5                	mov    %esp,%ebp
80102dab:	57                   	push   %edi
80102dac:	56                   	push   %esi
80102dad:	53                   	push   %ebx
80102dae:	83 ec 0c             	sub    $0xc,%esp
80102db1:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
80102db7:	8d 9c 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%ebx
80102dbe:	39 de                	cmp    %ebx,%esi
80102dc0:	72 0b                	jb     80102dcd <mpsearch1+0x25>
80102dc2:	eb 3c                	jmp    80102e00 <mpsearch1+0x58>
80102dc4:	8d 7e 10             	lea    0x10(%esi),%edi
80102dc7:	89 fe                	mov    %edi,%esi
80102dc9:	39 df                	cmp    %ebx,%edi
80102dcb:	73 33                	jae    80102e00 <mpsearch1+0x58>
80102dcd:	50                   	push   %eax
80102dce:	6a 04                	push   $0x4
80102dd0:	68 f8 6f 10 80       	push   $0x80106ff8
80102dd5:	56                   	push   %esi
80102dd6:	e8 35 14 00 00       	call   80104210 <memcmp>
80102ddb:	83 c4 10             	add    $0x10,%esp
80102dde:	85 c0                	test   %eax,%eax
80102de0:	75 e2                	jne    80102dc4 <mpsearch1+0x1c>
80102de2:	89 f2                	mov    %esi,%edx
80102de4:	8d 7e 10             	lea    0x10(%esi),%edi
80102de7:	90                   	nop
80102de8:	0f b6 0a             	movzbl (%edx),%ecx
80102deb:	01 c8                	add    %ecx,%eax
80102ded:	42                   	inc    %edx
80102dee:	39 fa                	cmp    %edi,%edx
80102df0:	75 f6                	jne    80102de8 <mpsearch1+0x40>
80102df2:	84 c0                	test   %al,%al
80102df4:	75 d1                	jne    80102dc7 <mpsearch1+0x1f>
80102df6:	89 f0                	mov    %esi,%eax
80102df8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102dfb:	5b                   	pop    %ebx
80102dfc:	5e                   	pop    %esi
80102dfd:	5f                   	pop    %edi
80102dfe:	5d                   	pop    %ebp
80102dff:	c3                   	ret    
80102e00:	31 f6                	xor    %esi,%esi
80102e02:	89 f0                	mov    %esi,%eax
80102e04:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102e07:	5b                   	pop    %ebx
80102e08:	5e                   	pop    %esi
80102e09:	5f                   	pop    %edi
80102e0a:	5d                   	pop    %ebp
80102e0b:	c3                   	ret    

80102e0c <mpinit>:
80102e0c:	55                   	push   %ebp
80102e0d:	89 e5                	mov    %esp,%ebp
80102e0f:	57                   	push   %edi
80102e10:	56                   	push   %esi
80102e11:	53                   	push   %ebx
80102e12:	83 ec 1c             	sub    $0x1c,%esp
80102e15:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80102e1c:	c1 e0 08             	shl    $0x8,%eax
80102e1f:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80102e26:	09 d0                	or     %edx,%eax
80102e28:	c1 e0 04             	shl    $0x4,%eax
80102e2b:	75 1b                	jne    80102e48 <mpinit+0x3c>
80102e2d:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80102e34:	c1 e0 08             	shl    $0x8,%eax
80102e37:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
80102e3e:	09 d0                	or     %edx,%eax
80102e40:	c1 e0 0a             	shl    $0xa,%eax
80102e43:	2d 00 04 00 00       	sub    $0x400,%eax
80102e48:	ba 00 04 00 00       	mov    $0x400,%edx
80102e4d:	e8 56 ff ff ff       	call   80102da8 <mpsearch1>
80102e52:	89 c3                	mov    %eax,%ebx
80102e54:	85 c0                	test   %eax,%eax
80102e56:	0f 84 28 01 00 00    	je     80102f84 <mpinit+0x178>
80102e5c:	8b 73 04             	mov    0x4(%ebx),%esi
80102e5f:	85 f6                	test   %esi,%esi
80102e61:	0f 84 0d 01 00 00    	je     80102f74 <mpinit+0x168>
80102e67:	8d be 00 00 00 80    	lea    -0x80000000(%esi),%edi
80102e6d:	50                   	push   %eax
80102e6e:	6a 04                	push   $0x4
80102e70:	68 fd 6f 10 80       	push   $0x80106ffd
80102e75:	57                   	push   %edi
80102e76:	e8 95 13 00 00       	call   80104210 <memcmp>
80102e7b:	83 c4 10             	add    $0x10,%esp
80102e7e:	85 c0                	test   %eax,%eax
80102e80:	0f 85 ee 00 00 00    	jne    80102f74 <mpinit+0x168>
80102e86:	8a 86 06 00 00 80    	mov    -0x7ffffffa(%esi),%al
80102e8c:	3c 01                	cmp    $0x1,%al
80102e8e:	74 08                	je     80102e98 <mpinit+0x8c>
80102e90:	3c 04                	cmp    $0x4,%al
80102e92:	0f 85 dc 00 00 00    	jne    80102f74 <mpinit+0x168>
80102e98:	0f b7 96 04 00 00 80 	movzwl -0x7ffffffc(%esi),%edx
80102e9f:	66 85 d2             	test   %dx,%dx
80102ea2:	74 1f                	je     80102ec3 <mpinit+0xb7>
80102ea4:	89 f8                	mov    %edi,%eax
80102ea6:	8d 0c 17             	lea    (%edi,%edx,1),%ecx
80102ea9:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80102eac:	31 d2                	xor    %edx,%edx
80102eae:	66 90                	xchg   %ax,%ax
80102eb0:	0f b6 08             	movzbl (%eax),%ecx
80102eb3:	01 ca                	add    %ecx,%edx
80102eb5:	40                   	inc    %eax
80102eb6:	39 45 e4             	cmp    %eax,-0x1c(%ebp)
80102eb9:	75 f5                	jne    80102eb0 <mpinit+0xa4>
80102ebb:	84 d2                	test   %dl,%dl
80102ebd:	0f 85 b1 00 00 00    	jne    80102f74 <mpinit+0x168>
80102ec3:	8b 86 24 00 00 80    	mov    -0x7fffffdc(%esi),%eax
80102ec9:	a3 80 16 11 80       	mov    %eax,0x80111680
80102ece:	8d 96 2c 00 00 80    	lea    -0x7fffffd4(%esi),%edx
80102ed4:	0f b7 8e 04 00 00 80 	movzwl -0x7ffffffc(%esi),%ecx
80102edb:	01 f9                	add    %edi,%ecx
80102edd:	be 01 00 00 00       	mov    $0x1,%esi
80102ee2:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80102ee5:	8d 76 00             	lea    0x0(%esi),%esi
80102ee8:	39 ca                	cmp    %ecx,%edx
80102eea:	73 13                	jae    80102eff <mpinit+0xf3>
80102eec:	8a 02                	mov    (%edx),%al
80102eee:	3c 02                	cmp    $0x2,%al
80102ef0:	74 46                	je     80102f38 <mpinit+0x12c>
80102ef2:	77 38                	ja     80102f2c <mpinit+0x120>
80102ef4:	84 c0                	test   %al,%al
80102ef6:	74 50                	je     80102f48 <mpinit+0x13c>
80102ef8:	83 c2 08             	add    $0x8,%edx
80102efb:	39 ca                	cmp    %ecx,%edx
80102efd:	72 ed                	jb     80102eec <mpinit+0xe0>
80102eff:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80102f02:	85 f6                	test   %esi,%esi
80102f04:	0f 84 bd 00 00 00    	je     80102fc7 <mpinit+0x1bb>
80102f0a:	80 7b 0c 00          	cmpb   $0x0,0xc(%ebx)
80102f0e:	74 12                	je     80102f22 <mpinit+0x116>
80102f10:	b0 70                	mov    $0x70,%al
80102f12:	ba 22 00 00 00       	mov    $0x22,%edx
80102f17:	ee                   	out    %al,(%dx)
80102f18:	ba 23 00 00 00       	mov    $0x23,%edx
80102f1d:	ec                   	in     (%dx),%al
80102f1e:	83 c8 01             	or     $0x1,%eax
80102f21:	ee                   	out    %al,(%dx)
80102f22:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102f25:	5b                   	pop    %ebx
80102f26:	5e                   	pop    %esi
80102f27:	5f                   	pop    %edi
80102f28:	5d                   	pop    %ebp
80102f29:	c3                   	ret    
80102f2a:	66 90                	xchg   %ax,%ax
80102f2c:	83 e8 03             	sub    $0x3,%eax
80102f2f:	3c 01                	cmp    $0x1,%al
80102f31:	76 c5                	jbe    80102ef8 <mpinit+0xec>
80102f33:	31 f6                	xor    %esi,%esi
80102f35:	eb b1                	jmp    80102ee8 <mpinit+0xdc>
80102f37:	90                   	nop
80102f38:	8a 42 01             	mov    0x1(%edx),%al
80102f3b:	a2 80 17 11 80       	mov    %al,0x80111780
80102f40:	83 c2 08             	add    $0x8,%edx
80102f43:	eb a3                	jmp    80102ee8 <mpinit+0xdc>
80102f45:	8d 76 00             	lea    0x0(%esi),%esi
80102f48:	a1 84 17 11 80       	mov    0x80111784,%eax
80102f4d:	83 f8 07             	cmp    $0x7,%eax
80102f50:	7f 19                	jg     80102f6b <mpinit+0x15f>
80102f52:	8d 3c 80             	lea    (%eax,%eax,4),%edi
80102f55:	01 ff                	add    %edi,%edi
80102f57:	01 c7                	add    %eax,%edi
80102f59:	c1 e7 04             	shl    $0x4,%edi
80102f5c:	8a 5a 01             	mov    0x1(%edx),%bl
80102f5f:	88 9f a0 17 11 80    	mov    %bl,-0x7feee860(%edi)
80102f65:	40                   	inc    %eax
80102f66:	a3 84 17 11 80       	mov    %eax,0x80111784
80102f6b:	83 c2 14             	add    $0x14,%edx
80102f6e:	e9 75 ff ff ff       	jmp    80102ee8 <mpinit+0xdc>
80102f73:	90                   	nop
80102f74:	83 ec 0c             	sub    $0xc,%esp
80102f77:	68 02 70 10 80       	push   $0x80107002
80102f7c:	e8 b7 d3 ff ff       	call   80100338 <panic>
80102f81:	8d 76 00             	lea    0x0(%esi),%esi
80102f84:	bb 00 00 0f 80       	mov    $0x800f0000,%ebx
80102f89:	eb 0e                	jmp    80102f99 <mpinit+0x18d>
80102f8b:	90                   	nop
80102f8c:	8d 73 10             	lea    0x10(%ebx),%esi
80102f8f:	89 f3                	mov    %esi,%ebx
80102f91:	81 fe 00 00 10 80    	cmp    $0x80100000,%esi
80102f97:	74 db                	je     80102f74 <mpinit+0x168>
80102f99:	52                   	push   %edx
80102f9a:	6a 04                	push   $0x4
80102f9c:	68 f8 6f 10 80       	push   $0x80106ff8
80102fa1:	53                   	push   %ebx
80102fa2:	e8 69 12 00 00       	call   80104210 <memcmp>
80102fa7:	83 c4 10             	add    $0x10,%esp
80102faa:	85 c0                	test   %eax,%eax
80102fac:	75 de                	jne    80102f8c <mpinit+0x180>
80102fae:	89 da                	mov    %ebx,%edx
80102fb0:	8d 73 10             	lea    0x10(%ebx),%esi
80102fb3:	90                   	nop
80102fb4:	0f b6 0a             	movzbl (%edx),%ecx
80102fb7:	01 c8                	add    %ecx,%eax
80102fb9:	42                   	inc    %edx
80102fba:	39 f2                	cmp    %esi,%edx
80102fbc:	75 f6                	jne    80102fb4 <mpinit+0x1a8>
80102fbe:	84 c0                	test   %al,%al
80102fc0:	75 cd                	jne    80102f8f <mpinit+0x183>
80102fc2:	e9 95 fe ff ff       	jmp    80102e5c <mpinit+0x50>
80102fc7:	83 ec 0c             	sub    $0xc,%esp
80102fca:	68 1c 70 10 80       	push   $0x8010701c
80102fcf:	e8 64 d3 ff ff       	call   80100338 <panic>

80102fd4 <picinit>:
80102fd4:	b0 ff                	mov    $0xff,%al
80102fd6:	ba 21 00 00 00       	mov    $0x21,%edx
80102fdb:	ee                   	out    %al,(%dx)
80102fdc:	ba a1 00 00 00       	mov    $0xa1,%edx
80102fe1:	ee                   	out    %al,(%dx)
80102fe2:	c3                   	ret    
80102fe3:	90                   	nop

80102fe4 <pipealloc>:
80102fe4:	55                   	push   %ebp
80102fe5:	89 e5                	mov    %esp,%ebp
80102fe7:	57                   	push   %edi
80102fe8:	56                   	push   %esi
80102fe9:	53                   	push   %ebx
80102fea:	83 ec 0c             	sub    $0xc,%esp
80102fed:	8b 75 08             	mov    0x8(%ebp),%esi
80102ff0:	8b 7d 0c             	mov    0xc(%ebp),%edi
80102ff3:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
80102ff9:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80102fff:	e8 94 dd ff ff       	call   80100d98 <filealloc>
80103004:	89 06                	mov    %eax,(%esi)
80103006:	85 c0                	test   %eax,%eax
80103008:	0f 84 a5 00 00 00    	je     801030b3 <pipealloc+0xcf>
8010300e:	e8 85 dd ff ff       	call   80100d98 <filealloc>
80103013:	89 07                	mov    %eax,(%edi)
80103015:	85 c0                	test   %eax,%eax
80103017:	0f 84 84 00 00 00    	je     801030a1 <pipealloc+0xbd>
8010301d:	e8 a6 f3 ff ff       	call   801023c8 <kalloc>
80103022:	89 c3                	mov    %eax,%ebx
80103024:	85 c0                	test   %eax,%eax
80103026:	0f 84 a0 00 00 00    	je     801030cc <pipealloc+0xe8>
8010302c:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
80103033:	00 00 00 
80103036:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
8010303d:	00 00 00 
80103040:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80103047:	00 00 00 
8010304a:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80103051:	00 00 00 
80103054:	83 ec 08             	sub    $0x8,%esp
80103057:	68 3b 70 10 80       	push   $0x8010703b
8010305c:	50                   	push   %eax
8010305d:	e8 ea 0e 00 00       	call   80103f4c <initlock>
80103062:	8b 06                	mov    (%esi),%eax
80103064:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
8010306a:	8b 06                	mov    (%esi),%eax
8010306c:	c6 40 08 01          	movb   $0x1,0x8(%eax)
80103070:	8b 06                	mov    (%esi),%eax
80103072:	c6 40 09 00          	movb   $0x0,0x9(%eax)
80103076:	8b 06                	mov    (%esi),%eax
80103078:	89 58 0c             	mov    %ebx,0xc(%eax)
8010307b:	8b 07                	mov    (%edi),%eax
8010307d:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
80103083:	8b 07                	mov    (%edi),%eax
80103085:	c6 40 08 00          	movb   $0x0,0x8(%eax)
80103089:	8b 07                	mov    (%edi),%eax
8010308b:	c6 40 09 01          	movb   $0x1,0x9(%eax)
8010308f:	8b 07                	mov    (%edi),%eax
80103091:	89 58 0c             	mov    %ebx,0xc(%eax)
80103094:	83 c4 10             	add    $0x10,%esp
80103097:	31 c0                	xor    %eax,%eax
80103099:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010309c:	5b                   	pop    %ebx
8010309d:	5e                   	pop    %esi
8010309e:	5f                   	pop    %edi
8010309f:	5d                   	pop    %ebp
801030a0:	c3                   	ret    
801030a1:	8b 06                	mov    (%esi),%eax
801030a3:	85 c0                	test   %eax,%eax
801030a5:	74 1e                	je     801030c5 <pipealloc+0xe1>
801030a7:	83 ec 0c             	sub    $0xc,%esp
801030aa:	50                   	push   %eax
801030ab:	e8 94 dd ff ff       	call   80100e44 <fileclose>
801030b0:	83 c4 10             	add    $0x10,%esp
801030b3:	8b 07                	mov    (%edi),%eax
801030b5:	85 c0                	test   %eax,%eax
801030b7:	74 0c                	je     801030c5 <pipealloc+0xe1>
801030b9:	83 ec 0c             	sub    $0xc,%esp
801030bc:	50                   	push   %eax
801030bd:	e8 82 dd ff ff       	call   80100e44 <fileclose>
801030c2:	83 c4 10             	add    $0x10,%esp
801030c5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801030ca:	eb cd                	jmp    80103099 <pipealloc+0xb5>
801030cc:	8b 06                	mov    (%esi),%eax
801030ce:	85 c0                	test   %eax,%eax
801030d0:	75 d5                	jne    801030a7 <pipealloc+0xc3>
801030d2:	eb df                	jmp    801030b3 <pipealloc+0xcf>

801030d4 <pipeclose>:
801030d4:	55                   	push   %ebp
801030d5:	89 e5                	mov    %esp,%ebp
801030d7:	56                   	push   %esi
801030d8:	53                   	push   %ebx
801030d9:	8b 5d 08             	mov    0x8(%ebp),%ebx
801030dc:	8b 75 0c             	mov    0xc(%ebp),%esi
801030df:	83 ec 0c             	sub    $0xc,%esp
801030e2:	53                   	push   %ebx
801030e3:	e8 24 10 00 00       	call   8010410c <acquire>
801030e8:	83 c4 10             	add    $0x10,%esp
801030eb:	85 f6                	test   %esi,%esi
801030ed:	74 5d                	je     8010314c <pipeclose+0x78>
801030ef:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
801030f6:	00 00 00 
801030f9:	83 ec 0c             	sub    $0xc,%esp
801030fc:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103102:	50                   	push   %eax
80103103:	e8 bc 0b 00 00       	call   80103cc4 <wakeup>
80103108:	83 c4 10             	add    $0x10,%esp
8010310b:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
80103111:	85 d2                	test   %edx,%edx
80103113:	75 0a                	jne    8010311f <pipeclose+0x4b>
80103115:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
8010311b:	85 c0                	test   %eax,%eax
8010311d:	74 11                	je     80103130 <pipeclose+0x5c>
8010311f:	89 5d 08             	mov    %ebx,0x8(%ebp)
80103122:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103125:	5b                   	pop    %ebx
80103126:	5e                   	pop    %esi
80103127:	5d                   	pop    %ebp
80103128:	e9 7f 0f 00 00       	jmp    801040ac <release>
8010312d:	8d 76 00             	lea    0x0(%esi),%esi
80103130:	83 ec 0c             	sub    $0xc,%esp
80103133:	53                   	push   %ebx
80103134:	e8 73 0f 00 00       	call   801040ac <release>
80103139:	83 c4 10             	add    $0x10,%esp
8010313c:	89 5d 08             	mov    %ebx,0x8(%ebp)
8010313f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103142:	5b                   	pop    %ebx
80103143:	5e                   	pop    %esi
80103144:	5d                   	pop    %ebp
80103145:	e9 ee f0 ff ff       	jmp    80102238 <kfree>
8010314a:	66 90                	xchg   %ax,%ax
8010314c:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80103153:	00 00 00 
80103156:	83 ec 0c             	sub    $0xc,%esp
80103159:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
8010315f:	50                   	push   %eax
80103160:	e8 5f 0b 00 00       	call   80103cc4 <wakeup>
80103165:	83 c4 10             	add    $0x10,%esp
80103168:	eb a1                	jmp    8010310b <pipeclose+0x37>
8010316a:	66 90                	xchg   %ax,%ax

8010316c <pipewrite>:
8010316c:	55                   	push   %ebp
8010316d:	89 e5                	mov    %esp,%ebp
8010316f:	57                   	push   %edi
80103170:	56                   	push   %esi
80103171:	53                   	push   %ebx
80103172:	83 ec 28             	sub    $0x28,%esp
80103175:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103178:	8b 7d 10             	mov    0x10(%ebp),%edi
8010317b:	53                   	push   %ebx
8010317c:	e8 8b 0f 00 00       	call   8010410c <acquire>
80103181:	83 c4 10             	add    $0x10,%esp
80103184:	85 ff                	test   %edi,%edi
80103186:	0f 8e c2 00 00 00    	jle    8010324e <pipewrite+0xe2>
8010318c:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
80103192:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103195:	8d 34 39             	lea    (%ecx,%edi,1),%esi
80103198:	89 75 e0             	mov    %esi,-0x20(%ebp)
8010319b:	8d b3 34 02 00 00    	lea    0x234(%ebx),%esi
801031a1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801031a4:	89 7d 10             	mov    %edi,0x10(%ebp)
801031a7:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
801031ad:	8d 90 00 02 00 00    	lea    0x200(%eax),%edx
801031b3:	8d bb 38 02 00 00    	lea    0x238(%ebx),%edi
801031b9:	39 55 e4             	cmp    %edx,-0x1c(%ebp)
801031bc:	0f 85 aa 00 00 00    	jne    8010326c <pipewrite+0x100>
801031c2:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801031c5:	eb 37                	jmp    801031fe <pipewrite+0x92>
801031c7:	90                   	nop
801031c8:	e8 47 03 00 00       	call   80103514 <myproc>
801031cd:	8b 48 28             	mov    0x28(%eax),%ecx
801031d0:	85 c9                	test   %ecx,%ecx
801031d2:	75 34                	jne    80103208 <pipewrite+0x9c>
801031d4:	83 ec 0c             	sub    $0xc,%esp
801031d7:	56                   	push   %esi
801031d8:	e8 e7 0a 00 00       	call   80103cc4 <wakeup>
801031dd:	58                   	pop    %eax
801031de:	5a                   	pop    %edx
801031df:	53                   	push   %ebx
801031e0:	57                   	push   %edi
801031e1:	e8 22 0a 00 00       	call   80103c08 <sleep>
801031e6:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
801031ec:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
801031f2:	05 00 02 00 00       	add    $0x200,%eax
801031f7:	83 c4 10             	add    $0x10,%esp
801031fa:	39 c2                	cmp    %eax,%edx
801031fc:	75 26                	jne    80103224 <pipewrite+0xb8>
801031fe:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
80103204:	85 c0                	test   %eax,%eax
80103206:	75 c0                	jne    801031c8 <pipewrite+0x5c>
80103208:	83 ec 0c             	sub    $0xc,%esp
8010320b:	53                   	push   %ebx
8010320c:	e8 9b 0e 00 00       	call   801040ac <release>
80103211:	83 c4 10             	add    $0x10,%esp
80103214:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103219:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010321c:	5b                   	pop    %ebx
8010321d:	5e                   	pop    %esi
8010321e:	5f                   	pop    %edi
8010321f:	5d                   	pop    %ebp
80103220:	c3                   	ret    
80103221:	8d 76 00             	lea    0x0(%esi),%esi
80103224:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80103227:	8d 42 01             	lea    0x1(%edx),%eax
8010322a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010322d:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
80103233:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
80103239:	8a 01                	mov    (%ecx),%al
8010323b:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
8010323f:	41                   	inc    %ecx
80103240:	8b 45 e0             	mov    -0x20(%ebp),%eax
80103243:	39 c1                	cmp    %eax,%ecx
80103245:	0f 85 5c ff ff ff    	jne    801031a7 <pipewrite+0x3b>
8010324b:	8b 7d 10             	mov    0x10(%ebp),%edi
8010324e:	83 ec 0c             	sub    $0xc,%esp
80103251:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103257:	50                   	push   %eax
80103258:	e8 67 0a 00 00       	call   80103cc4 <wakeup>
8010325d:	89 1c 24             	mov    %ebx,(%esp)
80103260:	e8 47 0e 00 00       	call   801040ac <release>
80103265:	83 c4 10             	add    $0x10,%esp
80103268:	89 f8                	mov    %edi,%eax
8010326a:	eb ad                	jmp    80103219 <pipewrite+0xad>
8010326c:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010326f:	eb b6                	jmp    80103227 <pipewrite+0xbb>
80103271:	8d 76 00             	lea    0x0(%esi),%esi

80103274 <piperead>:
80103274:	55                   	push   %ebp
80103275:	89 e5                	mov    %esp,%ebp
80103277:	57                   	push   %edi
80103278:	56                   	push   %esi
80103279:	53                   	push   %ebx
8010327a:	83 ec 18             	sub    $0x18,%esp
8010327d:	8b 75 08             	mov    0x8(%ebp),%esi
80103280:	8b 7d 0c             	mov    0xc(%ebp),%edi
80103283:	56                   	push   %esi
80103284:	e8 83 0e 00 00       	call   8010410c <acquire>
80103289:	83 c4 10             	add    $0x10,%esp
8010328c:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103292:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
80103298:	39 86 38 02 00 00    	cmp    %eax,0x238(%esi)
8010329e:	74 2f                	je     801032cf <piperead+0x5b>
801032a0:	eb 37                	jmp    801032d9 <piperead+0x65>
801032a2:	66 90                	xchg   %ax,%ax
801032a4:	e8 6b 02 00 00       	call   80103514 <myproc>
801032a9:	8b 48 28             	mov    0x28(%eax),%ecx
801032ac:	85 c9                	test   %ecx,%ecx
801032ae:	0f 85 80 00 00 00    	jne    80103334 <piperead+0xc0>
801032b4:	83 ec 08             	sub    $0x8,%esp
801032b7:	56                   	push   %esi
801032b8:	53                   	push   %ebx
801032b9:	e8 4a 09 00 00       	call   80103c08 <sleep>
801032be:	83 c4 10             	add    $0x10,%esp
801032c1:	8b 86 38 02 00 00    	mov    0x238(%esi),%eax
801032c7:	39 86 34 02 00 00    	cmp    %eax,0x234(%esi)
801032cd:	75 0a                	jne    801032d9 <piperead+0x65>
801032cf:	8b 86 40 02 00 00    	mov    0x240(%esi),%eax
801032d5:	85 c0                	test   %eax,%eax
801032d7:	75 cb                	jne    801032a4 <piperead+0x30>
801032d9:	31 db                	xor    %ebx,%ebx
801032db:	8b 55 10             	mov    0x10(%ebp),%edx
801032de:	85 d2                	test   %edx,%edx
801032e0:	7f 1d                	jg     801032ff <piperead+0x8b>
801032e2:	eb 29                	jmp    8010330d <piperead+0x99>
801032e4:	8d 48 01             	lea    0x1(%eax),%ecx
801032e7:	89 8e 34 02 00 00    	mov    %ecx,0x234(%esi)
801032ed:	25 ff 01 00 00       	and    $0x1ff,%eax
801032f2:	8a 44 06 34          	mov    0x34(%esi,%eax,1),%al
801032f6:	88 04 1f             	mov    %al,(%edi,%ebx,1)
801032f9:	43                   	inc    %ebx
801032fa:	39 5d 10             	cmp    %ebx,0x10(%ebp)
801032fd:	74 0e                	je     8010330d <piperead+0x99>
801032ff:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103305:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
8010330b:	75 d7                	jne    801032e4 <piperead+0x70>
8010330d:	83 ec 0c             	sub    $0xc,%esp
80103310:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
80103316:	50                   	push   %eax
80103317:	e8 a8 09 00 00       	call   80103cc4 <wakeup>
8010331c:	89 34 24             	mov    %esi,(%esp)
8010331f:	e8 88 0d 00 00       	call   801040ac <release>
80103324:	83 c4 10             	add    $0x10,%esp
80103327:	89 d8                	mov    %ebx,%eax
80103329:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010332c:	5b                   	pop    %ebx
8010332d:	5e                   	pop    %esi
8010332e:	5f                   	pop    %edi
8010332f:	5d                   	pop    %ebp
80103330:	c3                   	ret    
80103331:	8d 76 00             	lea    0x0(%esi),%esi
80103334:	83 ec 0c             	sub    $0xc,%esp
80103337:	56                   	push   %esi
80103338:	e8 6f 0d 00 00       	call   801040ac <release>
8010333d:	83 c4 10             	add    $0x10,%esp
80103340:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103345:	89 d8                	mov    %ebx,%eax
80103347:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010334a:	5b                   	pop    %ebx
8010334b:	5e                   	pop    %esi
8010334c:	5f                   	pop    %edi
8010334d:	5d                   	pop    %ebp
8010334e:	c3                   	ret    
8010334f:	90                   	nop

80103350 <allocproc>:
80103350:	55                   	push   %ebp
80103351:	89 e5                	mov    %esp,%ebp
80103353:	53                   	push   %ebx
80103354:	83 ec 10             	sub    $0x10,%esp
80103357:	68 20 1d 11 80       	push   $0x80111d20
8010335c:	e8 ab 0d 00 00       	call   8010410c <acquire>
80103361:	83 c4 10             	add    $0x10,%esp
80103364:	bb 54 1d 11 80       	mov    $0x80111d54,%ebx
80103369:	eb 0c                	jmp    80103377 <allocproc+0x27>
8010336b:	90                   	nop
8010336c:	83 eb 80             	sub    $0xffffff80,%ebx
8010336f:	81 fb 54 3d 11 80    	cmp    $0x80113d54,%ebx
80103375:	74 7d                	je     801033f4 <allocproc+0xa4>
80103377:	8b 4b 0c             	mov    0xc(%ebx),%ecx
8010337a:	85 c9                	test   %ecx,%ecx
8010337c:	75 ee                	jne    8010336c <allocproc+0x1c>
8010337e:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
80103385:	a1 04 a0 10 80       	mov    0x8010a004,%eax
8010338a:	8d 50 01             	lea    0x1(%eax),%edx
8010338d:	89 15 04 a0 10 80    	mov    %edx,0x8010a004
80103393:	89 43 10             	mov    %eax,0x10(%ebx)
80103396:	c7 43 14 0a 00 00 00 	movl   $0xa,0x14(%ebx)
8010339d:	83 ec 0c             	sub    $0xc,%esp
801033a0:	68 20 1d 11 80       	push   $0x80111d20
801033a5:	e8 02 0d 00 00       	call   801040ac <release>
801033aa:	e8 19 f0 ff ff       	call   801023c8 <kalloc>
801033af:	89 43 08             	mov    %eax,0x8(%ebx)
801033b2:	83 c4 10             	add    $0x10,%esp
801033b5:	85 c0                	test   %eax,%eax
801033b7:	74 54                	je     8010340d <allocproc+0xbd>
801033b9:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
801033bf:	89 53 1c             	mov    %edx,0x1c(%ebx)
801033c2:	c7 80 b0 0f 00 00 4f 	movl   $0x8010524f,0xfb0(%eax)
801033c9:	52 10 80 
801033cc:	05 9c 0f 00 00       	add    $0xf9c,%eax
801033d1:	89 43 20             	mov    %eax,0x20(%ebx)
801033d4:	52                   	push   %edx
801033d5:	6a 14                	push   $0x14
801033d7:	6a 00                	push   $0x0
801033d9:	50                   	push   %eax
801033da:	e8 ed 0d 00 00       	call   801041cc <memset>
801033df:	8b 43 20             	mov    0x20(%ebx),%eax
801033e2:	c7 40 10 18 34 10 80 	movl   $0x80103418,0x10(%eax)
801033e9:	83 c4 10             	add    $0x10,%esp
801033ec:	89 d8                	mov    %ebx,%eax
801033ee:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801033f1:	c9                   	leave  
801033f2:	c3                   	ret    
801033f3:	90                   	nop
801033f4:	83 ec 0c             	sub    $0xc,%esp
801033f7:	68 20 1d 11 80       	push   $0x80111d20
801033fc:	e8 ab 0c 00 00       	call   801040ac <release>
80103401:	83 c4 10             	add    $0x10,%esp
80103404:	31 db                	xor    %ebx,%ebx
80103406:	89 d8                	mov    %ebx,%eax
80103408:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010340b:	c9                   	leave  
8010340c:	c3                   	ret    
8010340d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
80103414:	31 db                	xor    %ebx,%ebx
80103416:	eb ee                	jmp    80103406 <allocproc+0xb6>

80103418 <forkret>:
80103418:	55                   	push   %ebp
80103419:	89 e5                	mov    %esp,%ebp
8010341b:	83 ec 14             	sub    $0x14,%esp
8010341e:	68 20 1d 11 80       	push   $0x80111d20
80103423:	e8 84 0c 00 00       	call   801040ac <release>
80103428:	83 c4 10             	add    $0x10,%esp
8010342b:	a1 00 a0 10 80       	mov    0x8010a000,%eax
80103430:	85 c0                	test   %eax,%eax
80103432:	75 04                	jne    80103438 <forkret+0x20>
80103434:	c9                   	leave  
80103435:	c3                   	ret    
80103436:	66 90                	xchg   %ax,%ax
80103438:	c7 05 00 a0 10 80 00 	movl   $0x0,0x8010a000
8010343f:	00 00 00 
80103442:	83 ec 0c             	sub    $0xc,%esp
80103445:	6a 01                	push   $0x1
80103447:	e8 c8 df ff ff       	call   80101414 <iinit>
8010344c:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
80103453:	e8 e4 f4 ff ff       	call   8010293c <initlog>
80103458:	83 c4 10             	add    $0x10,%esp
8010345b:	c9                   	leave  
8010345c:	c3                   	ret    
8010345d:	8d 76 00             	lea    0x0(%esi),%esi

80103460 <pinit>:
80103460:	55                   	push   %ebp
80103461:	89 e5                	mov    %esp,%ebp
80103463:	83 ec 10             	sub    $0x10,%esp
80103466:	68 40 70 10 80       	push   $0x80107040
8010346b:	68 20 1d 11 80       	push   $0x80111d20
80103470:	e8 d7 0a 00 00       	call   80103f4c <initlock>
80103475:	83 c4 10             	add    $0x10,%esp
80103478:	c9                   	leave  
80103479:	c3                   	ret    
8010347a:	66 90                	xchg   %ax,%ax

8010347c <mycpu>:
8010347c:	55                   	push   %ebp
8010347d:	89 e5                	mov    %esp,%ebp
8010347f:	56                   	push   %esi
80103480:	53                   	push   %ebx
80103481:	9c                   	pushf  
80103482:	58                   	pop    %eax
80103483:	f6 c4 02             	test   $0x2,%ah
80103486:	75 4b                	jne    801034d3 <mycpu+0x57>
80103488:	e8 5f f1 ff ff       	call   801025ec <lapicid>
8010348d:	89 c1                	mov    %eax,%ecx
8010348f:	8b 1d 84 17 11 80    	mov    0x80111784,%ebx
80103495:	85 db                	test   %ebx,%ebx
80103497:	7e 2d                	jle    801034c6 <mycpu+0x4a>
80103499:	31 d2                	xor    %edx,%edx
8010349b:	eb 08                	jmp    801034a5 <mycpu+0x29>
8010349d:	8d 76 00             	lea    0x0(%esi),%esi
801034a0:	42                   	inc    %edx
801034a1:	39 da                	cmp    %ebx,%edx
801034a3:	74 21                	je     801034c6 <mycpu+0x4a>
801034a5:	8d 04 92             	lea    (%edx,%edx,4),%eax
801034a8:	01 c0                	add    %eax,%eax
801034aa:	01 d0                	add    %edx,%eax
801034ac:	c1 e0 04             	shl    $0x4,%eax
801034af:	0f b6 b0 a0 17 11 80 	movzbl -0x7feee860(%eax),%esi
801034b6:	39 ce                	cmp    %ecx,%esi
801034b8:	75 e6                	jne    801034a0 <mycpu+0x24>
801034ba:	05 a0 17 11 80       	add    $0x801117a0,%eax
801034bf:	8d 65 f8             	lea    -0x8(%ebp),%esp
801034c2:	5b                   	pop    %ebx
801034c3:	5e                   	pop    %esi
801034c4:	5d                   	pop    %ebp
801034c5:	c3                   	ret    
801034c6:	83 ec 0c             	sub    $0xc,%esp
801034c9:	68 47 70 10 80       	push   $0x80107047
801034ce:	e8 65 ce ff ff       	call   80100338 <panic>
801034d3:	83 ec 0c             	sub    $0xc,%esp
801034d6:	68 24 71 10 80       	push   $0x80107124
801034db:	e8 58 ce ff ff       	call   80100338 <panic>

801034e0 <cpuid>:
801034e0:	55                   	push   %ebp
801034e1:	89 e5                	mov    %esp,%ebp
801034e3:	83 ec 08             	sub    $0x8,%esp
801034e6:	e8 91 ff ff ff       	call   8010347c <mycpu>
801034eb:	2d a0 17 11 80       	sub    $0x801117a0,%eax
801034f0:	c1 f8 04             	sar    $0x4,%eax
801034f3:	8d 0c c0             	lea    (%eax,%eax,8),%ecx
801034f6:	89 ca                	mov    %ecx,%edx
801034f8:	c1 e2 05             	shl    $0x5,%edx
801034fb:	29 ca                	sub    %ecx,%edx
801034fd:	8d 14 90             	lea    (%eax,%edx,4),%edx
80103500:	8d 0c d0             	lea    (%eax,%edx,8),%ecx
80103503:	89 ca                	mov    %ecx,%edx
80103505:	c1 e2 0f             	shl    $0xf,%edx
80103508:	29 ca                	sub    %ecx,%edx
8010350a:	8d 04 90             	lea    (%eax,%edx,4),%eax
8010350d:	f7 d8                	neg    %eax
8010350f:	c9                   	leave  
80103510:	c3                   	ret    
80103511:	8d 76 00             	lea    0x0(%esi),%esi

80103514 <myproc>:
80103514:	55                   	push   %ebp
80103515:	89 e5                	mov    %esp,%ebp
80103517:	53                   	push   %ebx
80103518:	50                   	push   %eax
80103519:	e8 aa 0a 00 00       	call   80103fc8 <pushcli>
8010351e:	e8 59 ff ff ff       	call   8010347c <mycpu>
80103523:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
80103529:	e8 e6 0a 00 00       	call   80104014 <popcli>
8010352e:	89 d8                	mov    %ebx,%eax
80103530:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103533:	c9                   	leave  
80103534:	c3                   	ret    
80103535:	8d 76 00             	lea    0x0(%esi),%esi

80103538 <userinit>:
80103538:	55                   	push   %ebp
80103539:	89 e5                	mov    %esp,%ebp
8010353b:	53                   	push   %ebx
8010353c:	51                   	push   %ecx
8010353d:	e8 0e fe ff ff       	call   80103350 <allocproc>
80103542:	89 c3                	mov    %eax,%ebx
80103544:	a3 54 3d 11 80       	mov    %eax,0x80113d54
80103549:	e8 9a 32 00 00       	call   801067e8 <setupkvm>
8010354e:	89 43 04             	mov    %eax,0x4(%ebx)
80103551:	85 c0                	test   %eax,%eax
80103553:	0f 84 b3 00 00 00    	je     8010360c <userinit+0xd4>
80103559:	52                   	push   %edx
8010355a:	68 2c 00 00 00       	push   $0x2c
8010355f:	68 60 a4 10 80       	push   $0x8010a460
80103564:	50                   	push   %eax
80103565:	e8 ba 2f 00 00       	call   80106524 <inituvm>
8010356a:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
80103570:	83 c4 0c             	add    $0xc,%esp
80103573:	6a 4c                	push   $0x4c
80103575:	6a 00                	push   $0x0
80103577:	ff 73 1c             	pushl  0x1c(%ebx)
8010357a:	e8 4d 0c 00 00       	call   801041cc <memset>
8010357f:	8b 43 1c             	mov    0x1c(%ebx),%eax
80103582:	66 c7 40 3c 1b 00    	movw   $0x1b,0x3c(%eax)
80103588:	8b 43 1c             	mov    0x1c(%ebx),%eax
8010358b:	66 c7 40 2c 23 00    	movw   $0x23,0x2c(%eax)
80103591:	8b 43 1c             	mov    0x1c(%ebx),%eax
80103594:	8b 50 2c             	mov    0x2c(%eax),%edx
80103597:	66 89 50 28          	mov    %dx,0x28(%eax)
8010359b:	8b 43 1c             	mov    0x1c(%ebx),%eax
8010359e:	8b 50 2c             	mov    0x2c(%eax),%edx
801035a1:	66 89 50 48          	mov    %dx,0x48(%eax)
801035a5:	8b 43 1c             	mov    0x1c(%ebx),%eax
801035a8:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
801035af:	8b 43 1c             	mov    0x1c(%ebx),%eax
801035b2:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
801035b9:	8b 43 1c             	mov    0x1c(%ebx),%eax
801035bc:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
801035c3:	83 c4 0c             	add    $0xc,%esp
801035c6:	6a 10                	push   $0x10
801035c8:	68 70 70 10 80       	push   $0x80107070
801035cd:	8d 43 70             	lea    0x70(%ebx),%eax
801035d0:	50                   	push   %eax
801035d1:	e8 3e 0d 00 00       	call   80104314 <safestrcpy>
801035d6:	c7 04 24 79 70 10 80 	movl   $0x80107079,(%esp)
801035dd:	e8 be e8 ff ff       	call   80101ea0 <namei>
801035e2:	89 43 6c             	mov    %eax,0x6c(%ebx)
801035e5:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
801035ec:	e8 1b 0b 00 00       	call   8010410c <acquire>
801035f1:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
801035f8:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
801035ff:	e8 a8 0a 00 00       	call   801040ac <release>
80103604:	83 c4 10             	add    $0x10,%esp
80103607:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010360a:	c9                   	leave  
8010360b:	c3                   	ret    
8010360c:	83 ec 0c             	sub    $0xc,%esp
8010360f:	68 57 70 10 80       	push   $0x80107057
80103614:	e8 1f cd ff ff       	call   80100338 <panic>
80103619:	8d 76 00             	lea    0x0(%esi),%esi

8010361c <growproc>:
8010361c:	55                   	push   %ebp
8010361d:	89 e5                	mov    %esp,%ebp
8010361f:	56                   	push   %esi
80103620:	53                   	push   %ebx
80103621:	8b 75 08             	mov    0x8(%ebp),%esi
80103624:	e8 9f 09 00 00       	call   80103fc8 <pushcli>
80103629:	e8 4e fe ff ff       	call   8010347c <mycpu>
8010362e:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
80103634:	e8 db 09 00 00       	call   80104014 <popcli>
80103639:	8b 03                	mov    (%ebx),%eax
8010363b:	85 f6                	test   %esi,%esi
8010363d:	7f 19                	jg     80103658 <growproc+0x3c>
8010363f:	75 33                	jne    80103674 <growproc+0x58>
80103641:	89 03                	mov    %eax,(%ebx)
80103643:	83 ec 0c             	sub    $0xc,%esp
80103646:	53                   	push   %ebx
80103647:	e8 dc 2d 00 00       	call   80106428 <switchuvm>
8010364c:	83 c4 10             	add    $0x10,%esp
8010364f:	31 c0                	xor    %eax,%eax
80103651:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103654:	5b                   	pop    %ebx
80103655:	5e                   	pop    %esi
80103656:	5d                   	pop    %ebp
80103657:	c3                   	ret    
80103658:	51                   	push   %ecx
80103659:	01 c6                	add    %eax,%esi
8010365b:	56                   	push   %esi
8010365c:	50                   	push   %eax
8010365d:	ff 73 04             	pushl  0x4(%ebx)
80103660:	e8 f7 2f 00 00       	call   8010665c <allocuvm>
80103665:	83 c4 10             	add    $0x10,%esp
80103668:	85 c0                	test   %eax,%eax
8010366a:	75 d5                	jne    80103641 <growproc+0x25>
8010366c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103671:	eb de                	jmp    80103651 <growproc+0x35>
80103673:	90                   	nop
80103674:	52                   	push   %edx
80103675:	01 c6                	add    %eax,%esi
80103677:	56                   	push   %esi
80103678:	50                   	push   %eax
80103679:	ff 73 04             	pushl  0x4(%ebx)
8010367c:	e8 db 30 00 00       	call   8010675c <deallocuvm>
80103681:	83 c4 10             	add    $0x10,%esp
80103684:	85 c0                	test   %eax,%eax
80103686:	75 b9                	jne    80103641 <growproc+0x25>
80103688:	eb e2                	jmp    8010366c <growproc+0x50>
8010368a:	66 90                	xchg   %ax,%ax

8010368c <fork>:
8010368c:	55                   	push   %ebp
8010368d:	89 e5                	mov    %esp,%ebp
8010368f:	57                   	push   %edi
80103690:	56                   	push   %esi
80103691:	53                   	push   %ebx
80103692:	83 ec 1c             	sub    $0x1c,%esp
80103695:	e8 2e 09 00 00       	call   80103fc8 <pushcli>
8010369a:	e8 dd fd ff ff       	call   8010347c <mycpu>
8010369f:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
801036a5:	e8 6a 09 00 00       	call   80104014 <popcli>
801036aa:	e8 a1 fc ff ff       	call   80103350 <allocproc>
801036af:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801036b2:	85 c0                	test   %eax,%eax
801036b4:	0f 84 d4 00 00 00    	je     8010378e <fork+0x102>
801036ba:	89 c7                	mov    %eax,%edi
801036bc:	83 ec 08             	sub    $0x8,%esp
801036bf:	ff 33                	pushl  (%ebx)
801036c1:	ff 73 04             	pushl  0x4(%ebx)
801036c4:	e8 f7 31 00 00       	call   801068c0 <copyuvm>
801036c9:	89 47 04             	mov    %eax,0x4(%edi)
801036cc:	83 c4 10             	add    $0x10,%esp
801036cf:	85 c0                	test   %eax,%eax
801036d1:	0f 84 98 00 00 00    	je     8010376f <fork+0xe3>
801036d7:	8b 03                	mov    (%ebx),%eax
801036d9:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801036dc:	89 01                	mov    %eax,(%ecx)
801036de:	89 c8                	mov    %ecx,%eax
801036e0:	89 59 18             	mov    %ebx,0x18(%ecx)
801036e3:	8b 73 1c             	mov    0x1c(%ebx),%esi
801036e6:	8b 79 1c             	mov    0x1c(%ecx),%edi
801036e9:	b9 13 00 00 00       	mov    $0x13,%ecx
801036ee:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
801036f0:	8b 40 1c             	mov    0x1c(%eax),%eax
801036f3:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
801036fa:	31 f6                	xor    %esi,%esi
801036fc:	8b 44 b3 2c          	mov    0x2c(%ebx,%esi,4),%eax
80103700:	85 c0                	test   %eax,%eax
80103702:	74 13                	je     80103717 <fork+0x8b>
80103704:	83 ec 0c             	sub    $0xc,%esp
80103707:	50                   	push   %eax
80103708:	e8 f3 d6 ff ff       	call   80100e00 <filedup>
8010370d:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80103710:	89 44 b2 2c          	mov    %eax,0x2c(%edx,%esi,4)
80103714:	83 c4 10             	add    $0x10,%esp
80103717:	46                   	inc    %esi
80103718:	83 fe 10             	cmp    $0x10,%esi
8010371b:	75 df                	jne    801036fc <fork+0x70>
8010371d:	83 ec 0c             	sub    $0xc,%esp
80103720:	ff 73 6c             	pushl  0x6c(%ebx)
80103723:	e8 c0 de ff ff       	call   801015e8 <idup>
80103728:	8b 7d e4             	mov    -0x1c(%ebp),%edi
8010372b:	89 47 6c             	mov    %eax,0x6c(%edi)
8010372e:	83 c4 0c             	add    $0xc,%esp
80103731:	6a 10                	push   $0x10
80103733:	83 c3 70             	add    $0x70,%ebx
80103736:	53                   	push   %ebx
80103737:	8d 47 70             	lea    0x70(%edi),%eax
8010373a:	50                   	push   %eax
8010373b:	e8 d4 0b 00 00       	call   80104314 <safestrcpy>
80103740:	8b 5f 10             	mov    0x10(%edi),%ebx
80103743:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
8010374a:	e8 bd 09 00 00       	call   8010410c <acquire>
8010374f:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
80103756:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
8010375d:	e8 4a 09 00 00       	call   801040ac <release>
80103762:	83 c4 10             	add    $0x10,%esp
80103765:	89 d8                	mov    %ebx,%eax
80103767:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010376a:	5b                   	pop    %ebx
8010376b:	5e                   	pop    %esi
8010376c:	5f                   	pop    %edi
8010376d:	5d                   	pop    %ebp
8010376e:	c3                   	ret    
8010376f:	83 ec 0c             	sub    $0xc,%esp
80103772:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103775:	ff 73 08             	pushl  0x8(%ebx)
80103778:	e8 bb ea ff ff       	call   80102238 <kfree>
8010377d:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
80103784:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
8010378b:	83 c4 10             	add    $0x10,%esp
8010378e:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103793:	eb d0                	jmp    80103765 <fork+0xd9>
80103795:	8d 76 00             	lea    0x0(%esi),%esi

80103798 <scheduler>:
80103798:	55                   	push   %ebp
80103799:	89 e5                	mov    %esp,%ebp
8010379b:	57                   	push   %edi
8010379c:	56                   	push   %esi
8010379d:	53                   	push   %ebx
8010379e:	83 ec 0c             	sub    $0xc,%esp
801037a1:	e8 d6 fc ff ff       	call   8010347c <mycpu>
801037a6:	89 c3                	mov    %eax,%ebx
801037a8:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
801037af:	00 00 00 
801037b2:	8d 70 04             	lea    0x4(%eax),%esi
801037b5:	8d 76 00             	lea    0x0(%esi),%esi
801037b8:	fb                   	sti    
801037b9:	83 ec 0c             	sub    $0xc,%esp
801037bc:	68 20 1d 11 80       	push   $0x80111d20
801037c1:	e8 46 09 00 00       	call   8010410c <acquire>
801037c6:	83 c4 10             	add    $0x10,%esp
801037c9:	31 ff                	xor    %edi,%edi
801037cb:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
801037d0:	eb 0c                	jmp    801037de <scheduler+0x46>
801037d2:	66 90                	xchg   %ax,%ax
801037d4:	83 e8 80             	sub    $0xffffff80,%eax
801037d7:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
801037dc:	74 36                	je     80103814 <scheduler+0x7c>
801037de:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
801037e2:	75 f0                	jne    801037d4 <scheduler+0x3c>
801037e4:	85 ff                	test   %edi,%edi
801037e6:	74 78                	je     80103860 <scheduler+0xc8>
801037e8:	8b 4f 14             	mov    0x14(%edi),%ecx
801037eb:	39 48 14             	cmp    %ecx,0x14(%eax)
801037ee:	7d e4                	jge    801037d4 <scheduler+0x3c>
801037f0:	8d 90 80 00 00 00    	lea    0x80(%eax),%edx
801037f6:	89 c7                	mov    %eax,%edi
801037f8:	3d d4 3c 11 80       	cmp    $0x80113cd4,%eax
801037fd:	74 15                	je     80103814 <scheduler+0x7c>
801037ff:	89 d0                	mov    %edx,%eax
80103801:	83 7a 0c 03          	cmpl   $0x3,0xc(%edx)
80103805:	74 e1                	je     801037e8 <scheduler+0x50>
80103807:	83 e8 80             	sub    $0xffffff80,%eax
8010380a:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
8010380f:	75 cd                	jne    801037de <scheduler+0x46>
80103811:	8d 76 00             	lea    0x0(%esi),%esi
80103814:	85 ff                	test   %edi,%edi
80103816:	74 33                	je     8010384b <scheduler+0xb3>
80103818:	89 bb ac 00 00 00    	mov    %edi,0xac(%ebx)
8010381e:	83 ec 0c             	sub    $0xc,%esp
80103821:	57                   	push   %edi
80103822:	e8 01 2c 00 00       	call   80106428 <switchuvm>
80103827:	c7 47 0c 04 00 00 00 	movl   $0x4,0xc(%edi)
8010382e:	58                   	pop    %eax
8010382f:	5a                   	pop    %edx
80103830:	ff 77 20             	pushl  0x20(%edi)
80103833:	56                   	push   %esi
80103834:	e8 28 0b 00 00       	call   80104361 <swtch>
80103839:	e8 da 2b 00 00       	call   80106418 <switchkvm>
8010383e:	c7 83 ac 00 00 00 00 	movl   $0x0,0xac(%ebx)
80103845:	00 00 00 
80103848:	83 c4 10             	add    $0x10,%esp
8010384b:	83 ec 0c             	sub    $0xc,%esp
8010384e:	68 20 1d 11 80       	push   $0x80111d20
80103853:	e8 54 08 00 00       	call   801040ac <release>
80103858:	83 c4 10             	add    $0x10,%esp
8010385b:	e9 58 ff ff ff       	jmp    801037b8 <scheduler+0x20>
80103860:	89 c7                	mov    %eax,%edi
80103862:	e9 6d ff ff ff       	jmp    801037d4 <scheduler+0x3c>
80103867:	90                   	nop

80103868 <setpriority>:
80103868:	55                   	push   %ebp
80103869:	89 e5                	mov    %esp,%ebp
8010386b:	56                   	push   %esi
8010386c:	53                   	push   %ebx
8010386d:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103870:	8b 75 0c             	mov    0xc(%ebp),%esi
80103873:	8d 46 ff             	lea    -0x1(%esi),%eax
80103876:	83 f8 13             	cmp    $0x13,%eax
80103879:	77 58                	ja     801038d3 <setpriority+0x6b>
8010387b:	83 ec 0c             	sub    $0xc,%esp
8010387e:	68 20 1d 11 80       	push   $0x80111d20
80103883:	e8 84 08 00 00       	call   8010410c <acquire>
80103888:	83 c4 10             	add    $0x10,%esp
8010388b:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80103890:	eb 0c                	jmp    8010389e <setpriority+0x36>
80103892:	66 90                	xchg   %ax,%ax
80103894:	83 e8 80             	sub    $0xffffff80,%eax
80103897:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
8010389c:	74 2e                	je     801038cc <setpriority+0x64>
8010389e:	8b 50 0c             	mov    0xc(%eax),%edx
801038a1:	85 d2                	test   %edx,%edx
801038a3:	74 ef                	je     80103894 <setpriority+0x2c>
801038a5:	39 58 10             	cmp    %ebx,0x10(%eax)
801038a8:	75 ea                	jne    80103894 <setpriority+0x2c>
801038aa:	8b 58 14             	mov    0x14(%eax),%ebx
801038ad:	89 70 14             	mov    %esi,0x14(%eax)
801038b0:	83 ec 0c             	sub    $0xc,%esp
801038b3:	68 20 1d 11 80       	push   $0x80111d20
801038b8:	e8 ef 07 00 00       	call   801040ac <release>
801038bd:	83 c4 10             	add    $0x10,%esp
801038c0:	89 d8                	mov    %ebx,%eax
801038c2:	8d 65 f8             	lea    -0x8(%ebp),%esp
801038c5:	5b                   	pop    %ebx
801038c6:	5e                   	pop    %esi
801038c7:	5d                   	pop    %ebp
801038c8:	c3                   	ret    
801038c9:	8d 76 00             	lea    0x0(%esi),%esi
801038cc:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801038d1:	eb dd                	jmp    801038b0 <setpriority+0x48>
801038d3:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801038d8:	eb e6                	jmp    801038c0 <setpriority+0x58>
801038da:	66 90                	xchg   %ax,%ax

801038dc <sched>:
801038dc:	55                   	push   %ebp
801038dd:	89 e5                	mov    %esp,%ebp
801038df:	56                   	push   %esi
801038e0:	53                   	push   %ebx
801038e1:	e8 e2 06 00 00       	call   80103fc8 <pushcli>
801038e6:	e8 91 fb ff ff       	call   8010347c <mycpu>
801038eb:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
801038f1:	e8 1e 07 00 00       	call   80104014 <popcli>
801038f6:	83 ec 0c             	sub    $0xc,%esp
801038f9:	68 20 1d 11 80       	push   $0x80111d20
801038fe:	e8 69 07 00 00       	call   8010406c <holding>
80103903:	83 c4 10             	add    $0x10,%esp
80103906:	85 c0                	test   %eax,%eax
80103908:	74 4f                	je     80103959 <sched+0x7d>
8010390a:	e8 6d fb ff ff       	call   8010347c <mycpu>
8010390f:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103916:	75 68                	jne    80103980 <sched+0xa4>
80103918:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
8010391c:	74 55                	je     80103973 <sched+0x97>
8010391e:	9c                   	pushf  
8010391f:	58                   	pop    %eax
80103920:	f6 c4 02             	test   $0x2,%ah
80103923:	75 41                	jne    80103966 <sched+0x8a>
80103925:	e8 52 fb ff ff       	call   8010347c <mycpu>
8010392a:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
80103930:	e8 47 fb ff ff       	call   8010347c <mycpu>
80103935:	83 ec 08             	sub    $0x8,%esp
80103938:	ff 70 04             	pushl  0x4(%eax)
8010393b:	83 c3 20             	add    $0x20,%ebx
8010393e:	53                   	push   %ebx
8010393f:	e8 1d 0a 00 00       	call   80104361 <swtch>
80103944:	e8 33 fb ff ff       	call   8010347c <mycpu>
80103949:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
8010394f:	83 c4 10             	add    $0x10,%esp
80103952:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103955:	5b                   	pop    %ebx
80103956:	5e                   	pop    %esi
80103957:	5d                   	pop    %ebp
80103958:	c3                   	ret    
80103959:	83 ec 0c             	sub    $0xc,%esp
8010395c:	68 7b 70 10 80       	push   $0x8010707b
80103961:	e8 d2 c9 ff ff       	call   80100338 <panic>
80103966:	83 ec 0c             	sub    $0xc,%esp
80103969:	68 a7 70 10 80       	push   $0x801070a7
8010396e:	e8 c5 c9 ff ff       	call   80100338 <panic>
80103973:	83 ec 0c             	sub    $0xc,%esp
80103976:	68 99 70 10 80       	push   $0x80107099
8010397b:	e8 b8 c9 ff ff       	call   80100338 <panic>
80103980:	83 ec 0c             	sub    $0xc,%esp
80103983:	68 8d 70 10 80       	push   $0x8010708d
80103988:	e8 ab c9 ff ff       	call   80100338 <panic>
8010398d:	8d 76 00             	lea    0x0(%esi),%esi

80103990 <exit>:
80103990:	55                   	push   %ebp
80103991:	89 e5                	mov    %esp,%ebp
80103993:	57                   	push   %edi
80103994:	56                   	push   %esi
80103995:	53                   	push   %ebx
80103996:	83 ec 0c             	sub    $0xc,%esp
80103999:	e8 76 fb ff ff       	call   80103514 <myproc>
8010399e:	39 05 54 3d 11 80    	cmp    %eax,0x80113d54
801039a4:	0f 84 e9 00 00 00    	je     80103a93 <exit+0x103>
801039aa:	89 c3                	mov    %eax,%ebx
801039ac:	8d 70 2c             	lea    0x2c(%eax),%esi
801039af:	8d 78 6c             	lea    0x6c(%eax),%edi
801039b2:	66 90                	xchg   %ax,%ax
801039b4:	8b 06                	mov    (%esi),%eax
801039b6:	85 c0                	test   %eax,%eax
801039b8:	74 12                	je     801039cc <exit+0x3c>
801039ba:	83 ec 0c             	sub    $0xc,%esp
801039bd:	50                   	push   %eax
801039be:	e8 81 d4 ff ff       	call   80100e44 <fileclose>
801039c3:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
801039c9:	83 c4 10             	add    $0x10,%esp
801039cc:	83 c6 04             	add    $0x4,%esi
801039cf:	39 f7                	cmp    %esi,%edi
801039d1:	75 e1                	jne    801039b4 <exit+0x24>
801039d3:	e8 f4 ef ff ff       	call   801029cc <begin_op>
801039d8:	83 ec 0c             	sub    $0xc,%esp
801039db:	ff 73 6c             	pushl  0x6c(%ebx)
801039de:	e8 3d dd ff ff       	call   80101720 <iput>
801039e3:	e8 4c f0 ff ff       	call   80102a34 <end_op>
801039e8:	c7 43 6c 00 00 00 00 	movl   $0x0,0x6c(%ebx)
801039ef:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
801039f6:	e8 11 07 00 00       	call   8010410c <acquire>
801039fb:	8b 53 18             	mov    0x18(%ebx),%edx
801039fe:	83 c4 10             	add    $0x10,%esp
80103a01:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80103a06:	eb 0a                	jmp    80103a12 <exit+0x82>
80103a08:	83 e8 80             	sub    $0xffffff80,%eax
80103a0b:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103a10:	74 1c                	je     80103a2e <exit+0x9e>
80103a12:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103a16:	75 f0                	jne    80103a08 <exit+0x78>
80103a18:	3b 50 24             	cmp    0x24(%eax),%edx
80103a1b:	75 eb                	jne    80103a08 <exit+0x78>
80103a1d:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103a24:	83 e8 80             	sub    $0xffffff80,%eax
80103a27:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103a2c:	75 e4                	jne    80103a12 <exit+0x82>
80103a2e:	8b 0d 54 3d 11 80    	mov    0x80113d54,%ecx
80103a34:	ba 54 1d 11 80       	mov    $0x80111d54,%edx
80103a39:	eb 0c                	jmp    80103a47 <exit+0xb7>
80103a3b:	90                   	nop
80103a3c:	83 ea 80             	sub    $0xffffff80,%edx
80103a3f:	81 fa 54 3d 11 80    	cmp    $0x80113d54,%edx
80103a45:	74 33                	je     80103a7a <exit+0xea>
80103a47:	39 5a 18             	cmp    %ebx,0x18(%edx)
80103a4a:	75 f0                	jne    80103a3c <exit+0xac>
80103a4c:	89 4a 18             	mov    %ecx,0x18(%edx)
80103a4f:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
80103a53:	75 e7                	jne    80103a3c <exit+0xac>
80103a55:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80103a5a:	eb 0a                	jmp    80103a66 <exit+0xd6>
80103a5c:	83 e8 80             	sub    $0xffffff80,%eax
80103a5f:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103a64:	74 d6                	je     80103a3c <exit+0xac>
80103a66:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103a6a:	75 f0                	jne    80103a5c <exit+0xcc>
80103a6c:	3b 48 24             	cmp    0x24(%eax),%ecx
80103a6f:	75 eb                	jne    80103a5c <exit+0xcc>
80103a71:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103a78:	eb e2                	jmp    80103a5c <exit+0xcc>
80103a7a:	c7 43 0c 05 00 00 00 	movl   $0x5,0xc(%ebx)
80103a81:	e8 56 fe ff ff       	call   801038dc <sched>
80103a86:	83 ec 0c             	sub    $0xc,%esp
80103a89:	68 c8 70 10 80       	push   $0x801070c8
80103a8e:	e8 a5 c8 ff ff       	call   80100338 <panic>
80103a93:	83 ec 0c             	sub    $0xc,%esp
80103a96:	68 bb 70 10 80       	push   $0x801070bb
80103a9b:	e8 98 c8 ff ff       	call   80100338 <panic>

80103aa0 <wait>:
80103aa0:	55                   	push   %ebp
80103aa1:	89 e5                	mov    %esp,%ebp
80103aa3:	56                   	push   %esi
80103aa4:	53                   	push   %ebx
80103aa5:	e8 1e 05 00 00       	call   80103fc8 <pushcli>
80103aaa:	e8 cd f9 ff ff       	call   8010347c <mycpu>
80103aaf:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
80103ab5:	e8 5a 05 00 00       	call   80104014 <popcli>
80103aba:	83 ec 0c             	sub    $0xc,%esp
80103abd:	68 20 1d 11 80       	push   $0x80111d20
80103ac2:	e8 45 06 00 00       	call   8010410c <acquire>
80103ac7:	83 c4 10             	add    $0x10,%esp
80103aca:	31 c0                	xor    %eax,%eax
80103acc:	bb 54 1d 11 80       	mov    $0x80111d54,%ebx
80103ad1:	eb 0c                	jmp    80103adf <wait+0x3f>
80103ad3:	90                   	nop
80103ad4:	83 eb 80             	sub    $0xffffff80,%ebx
80103ad7:	81 fb 54 3d 11 80    	cmp    $0x80113d54,%ebx
80103add:	74 1b                	je     80103afa <wait+0x5a>
80103adf:	39 73 18             	cmp    %esi,0x18(%ebx)
80103ae2:	75 f0                	jne    80103ad4 <wait+0x34>
80103ae4:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80103ae8:	74 5a                	je     80103b44 <wait+0xa4>
80103aea:	b8 01 00 00 00       	mov    $0x1,%eax
80103aef:	83 eb 80             	sub    $0xffffff80,%ebx
80103af2:	81 fb 54 3d 11 80    	cmp    $0x80113d54,%ebx
80103af8:	75 e5                	jne    80103adf <wait+0x3f>
80103afa:	85 c0                	test   %eax,%eax
80103afc:	0f 84 98 00 00 00    	je     80103b9a <wait+0xfa>
80103b02:	8b 46 28             	mov    0x28(%esi),%eax
80103b05:	85 c0                	test   %eax,%eax
80103b07:	0f 85 8d 00 00 00    	jne    80103b9a <wait+0xfa>
80103b0d:	e8 b6 04 00 00       	call   80103fc8 <pushcli>
80103b12:	e8 65 f9 ff ff       	call   8010347c <mycpu>
80103b17:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
80103b1d:	e8 f2 04 00 00       	call   80104014 <popcli>
80103b22:	85 db                	test   %ebx,%ebx
80103b24:	0f 84 87 00 00 00    	je     80103bb1 <wait+0x111>
80103b2a:	89 73 24             	mov    %esi,0x24(%ebx)
80103b2d:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
80103b34:	e8 a3 fd ff ff       	call   801038dc <sched>
80103b39:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
80103b40:	eb 88                	jmp    80103aca <wait+0x2a>
80103b42:	66 90                	xchg   %ax,%ax
80103b44:	8b 73 10             	mov    0x10(%ebx),%esi
80103b47:	83 ec 0c             	sub    $0xc,%esp
80103b4a:	ff 73 08             	pushl  0x8(%ebx)
80103b4d:	e8 e6 e6 ff ff       	call   80102238 <kfree>
80103b52:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
80103b59:	5a                   	pop    %edx
80103b5a:	ff 73 04             	pushl  0x4(%ebx)
80103b5d:	e8 16 2c 00 00       	call   80106778 <freevm>
80103b62:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
80103b69:	c7 43 18 00 00 00 00 	movl   $0x0,0x18(%ebx)
80103b70:	c6 43 70 00          	movb   $0x0,0x70(%ebx)
80103b74:	c7 43 28 00 00 00 00 	movl   $0x0,0x28(%ebx)
80103b7b:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
80103b82:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103b89:	e8 1e 05 00 00       	call   801040ac <release>
80103b8e:	83 c4 10             	add    $0x10,%esp
80103b91:	89 f0                	mov    %esi,%eax
80103b93:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103b96:	5b                   	pop    %ebx
80103b97:	5e                   	pop    %esi
80103b98:	5d                   	pop    %ebp
80103b99:	c3                   	ret    
80103b9a:	83 ec 0c             	sub    $0xc,%esp
80103b9d:	68 20 1d 11 80       	push   $0x80111d20
80103ba2:	e8 05 05 00 00       	call   801040ac <release>
80103ba7:	83 c4 10             	add    $0x10,%esp
80103baa:	be ff ff ff ff       	mov    $0xffffffff,%esi
80103baf:	eb e0                	jmp    80103b91 <wait+0xf1>
80103bb1:	83 ec 0c             	sub    $0xc,%esp
80103bb4:	68 d4 70 10 80       	push   $0x801070d4
80103bb9:	e8 7a c7 ff ff       	call   80100338 <panic>
80103bbe:	66 90                	xchg   %ax,%ax

80103bc0 <yield>:
80103bc0:	55                   	push   %ebp
80103bc1:	89 e5                	mov    %esp,%ebp
80103bc3:	53                   	push   %ebx
80103bc4:	83 ec 10             	sub    $0x10,%esp
80103bc7:	68 20 1d 11 80       	push   $0x80111d20
80103bcc:	e8 3b 05 00 00       	call   8010410c <acquire>
80103bd1:	e8 f2 03 00 00       	call   80103fc8 <pushcli>
80103bd6:	e8 a1 f8 ff ff       	call   8010347c <mycpu>
80103bdb:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
80103be1:	e8 2e 04 00 00       	call   80104014 <popcli>
80103be6:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
80103bed:	e8 ea fc ff ff       	call   801038dc <sched>
80103bf2:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103bf9:	e8 ae 04 00 00       	call   801040ac <release>
80103bfe:	83 c4 10             	add    $0x10,%esp
80103c01:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103c04:	c9                   	leave  
80103c05:	c3                   	ret    
80103c06:	66 90                	xchg   %ax,%ax

80103c08 <sleep>:
80103c08:	55                   	push   %ebp
80103c09:	89 e5                	mov    %esp,%ebp
80103c0b:	57                   	push   %edi
80103c0c:	56                   	push   %esi
80103c0d:	53                   	push   %ebx
80103c0e:	83 ec 0c             	sub    $0xc,%esp
80103c11:	8b 7d 08             	mov    0x8(%ebp),%edi
80103c14:	8b 75 0c             	mov    0xc(%ebp),%esi
80103c17:	e8 ac 03 00 00       	call   80103fc8 <pushcli>
80103c1c:	e8 5b f8 ff ff       	call   8010347c <mycpu>
80103c21:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
80103c27:	e8 e8 03 00 00       	call   80104014 <popcli>
80103c2c:	85 db                	test   %ebx,%ebx
80103c2e:	0f 84 83 00 00 00    	je     80103cb7 <sleep+0xaf>
80103c34:	85 f6                	test   %esi,%esi
80103c36:	74 72                	je     80103caa <sleep+0xa2>
80103c38:	81 fe 20 1d 11 80    	cmp    $0x80111d20,%esi
80103c3e:	74 4c                	je     80103c8c <sleep+0x84>
80103c40:	83 ec 0c             	sub    $0xc,%esp
80103c43:	68 20 1d 11 80       	push   $0x80111d20
80103c48:	e8 bf 04 00 00       	call   8010410c <acquire>
80103c4d:	89 34 24             	mov    %esi,(%esp)
80103c50:	e8 57 04 00 00       	call   801040ac <release>
80103c55:	89 7b 24             	mov    %edi,0x24(%ebx)
80103c58:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
80103c5f:	e8 78 fc ff ff       	call   801038dc <sched>
80103c64:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
80103c6b:	c7 04 24 20 1d 11 80 	movl   $0x80111d20,(%esp)
80103c72:	e8 35 04 00 00       	call   801040ac <release>
80103c77:	83 c4 10             	add    $0x10,%esp
80103c7a:	89 75 08             	mov    %esi,0x8(%ebp)
80103c7d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103c80:	5b                   	pop    %ebx
80103c81:	5e                   	pop    %esi
80103c82:	5f                   	pop    %edi
80103c83:	5d                   	pop    %ebp
80103c84:	e9 83 04 00 00       	jmp    8010410c <acquire>
80103c89:	8d 76 00             	lea    0x0(%esi),%esi
80103c8c:	89 7b 24             	mov    %edi,0x24(%ebx)
80103c8f:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
80103c96:	e8 41 fc ff ff       	call   801038dc <sched>
80103c9b:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
80103ca2:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103ca5:	5b                   	pop    %ebx
80103ca6:	5e                   	pop    %esi
80103ca7:	5f                   	pop    %edi
80103ca8:	5d                   	pop    %ebp
80103ca9:	c3                   	ret    
80103caa:	83 ec 0c             	sub    $0xc,%esp
80103cad:	68 da 70 10 80       	push   $0x801070da
80103cb2:	e8 81 c6 ff ff       	call   80100338 <panic>
80103cb7:	83 ec 0c             	sub    $0xc,%esp
80103cba:	68 d4 70 10 80       	push   $0x801070d4
80103cbf:	e8 74 c6 ff ff       	call   80100338 <panic>

80103cc4 <wakeup>:
80103cc4:	55                   	push   %ebp
80103cc5:	89 e5                	mov    %esp,%ebp
80103cc7:	53                   	push   %ebx
80103cc8:	83 ec 10             	sub    $0x10,%esp
80103ccb:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103cce:	68 20 1d 11 80       	push   $0x80111d20
80103cd3:	e8 34 04 00 00       	call   8010410c <acquire>
80103cd8:	83 c4 10             	add    $0x10,%esp
80103cdb:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80103ce0:	eb 0c                	jmp    80103cee <wakeup+0x2a>
80103ce2:	66 90                	xchg   %ax,%ax
80103ce4:	83 e8 80             	sub    $0xffffff80,%eax
80103ce7:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103cec:	74 1c                	je     80103d0a <wakeup+0x46>
80103cee:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103cf2:	75 f0                	jne    80103ce4 <wakeup+0x20>
80103cf4:	3b 58 24             	cmp    0x24(%eax),%ebx
80103cf7:	75 eb                	jne    80103ce4 <wakeup+0x20>
80103cf9:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103d00:	83 e8 80             	sub    $0xffffff80,%eax
80103d03:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103d08:	75 e4                	jne    80103cee <wakeup+0x2a>
80103d0a:	c7 45 08 20 1d 11 80 	movl   $0x80111d20,0x8(%ebp)
80103d11:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103d14:	c9                   	leave  
80103d15:	e9 92 03 00 00       	jmp    801040ac <release>
80103d1a:	66 90                	xchg   %ax,%ax

80103d1c <kill>:
80103d1c:	55                   	push   %ebp
80103d1d:	89 e5                	mov    %esp,%ebp
80103d1f:	53                   	push   %ebx
80103d20:	83 ec 10             	sub    $0x10,%esp
80103d23:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103d26:	68 20 1d 11 80       	push   $0x80111d20
80103d2b:	e8 dc 03 00 00       	call   8010410c <acquire>
80103d30:	83 c4 10             	add    $0x10,%esp
80103d33:	b8 54 1d 11 80       	mov    $0x80111d54,%eax
80103d38:	eb 0c                	jmp    80103d46 <kill+0x2a>
80103d3a:	66 90                	xchg   %ax,%ax
80103d3c:	83 e8 80             	sub    $0xffffff80,%eax
80103d3f:	3d 54 3d 11 80       	cmp    $0x80113d54,%eax
80103d44:	74 32                	je     80103d78 <kill+0x5c>
80103d46:	39 58 10             	cmp    %ebx,0x10(%eax)
80103d49:	75 f1                	jne    80103d3c <kill+0x20>
80103d4b:	c7 40 28 01 00 00 00 	movl   $0x1,0x28(%eax)
80103d52:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103d56:	75 07                	jne    80103d5f <kill+0x43>
80103d58:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103d5f:	83 ec 0c             	sub    $0xc,%esp
80103d62:	68 20 1d 11 80       	push   $0x80111d20
80103d67:	e8 40 03 00 00       	call   801040ac <release>
80103d6c:	83 c4 10             	add    $0x10,%esp
80103d6f:	31 c0                	xor    %eax,%eax
80103d71:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103d74:	c9                   	leave  
80103d75:	c3                   	ret    
80103d76:	66 90                	xchg   %ax,%ax
80103d78:	83 ec 0c             	sub    $0xc,%esp
80103d7b:	68 20 1d 11 80       	push   $0x80111d20
80103d80:	e8 27 03 00 00       	call   801040ac <release>
80103d85:	83 c4 10             	add    $0x10,%esp
80103d88:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103d8d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103d90:	c9                   	leave  
80103d91:	c3                   	ret    
80103d92:	66 90                	xchg   %ax,%ax

80103d94 <procdump>:
80103d94:	55                   	push   %ebp
80103d95:	89 e5                	mov    %esp,%ebp
80103d97:	57                   	push   %edi
80103d98:	56                   	push   %esi
80103d99:	53                   	push   %ebx
80103d9a:	83 ec 3c             	sub    $0x3c,%esp
80103d9d:	bb c4 1d 11 80       	mov    $0x80111dc4,%ebx
80103da2:	8d 75 e8             	lea    -0x18(%ebp),%esi
80103da5:	eb 3f                	jmp    80103de6 <procdump+0x52>
80103da7:	90                   	nop
80103da8:	8b 04 85 4c 71 10 80 	mov    -0x7fef8eb4(,%eax,4),%eax
80103daf:	85 c0                	test   %eax,%eax
80103db1:	74 3f                	je     80103df2 <procdump+0x5e>
80103db3:	53                   	push   %ebx
80103db4:	50                   	push   %eax
80103db5:	ff 73 a0             	pushl  -0x60(%ebx)
80103db8:	68 ef 70 10 80       	push   $0x801070ef
80103dbd:	e8 66 c8 ff ff       	call   80100628 <cprintf>
80103dc2:	83 c4 10             	add    $0x10,%esp
80103dc5:	83 7b 9c 02          	cmpl   $0x2,-0x64(%ebx)
80103dc9:	74 31                	je     80103dfc <procdump+0x68>
80103dcb:	83 ec 0c             	sub    $0xc,%esp
80103dce:	68 63 74 10 80       	push   $0x80107463
80103dd3:	e8 50 c8 ff ff       	call   80100628 <cprintf>
80103dd8:	83 c4 10             	add    $0x10,%esp
80103ddb:	83 eb 80             	sub    $0xffffff80,%ebx
80103dde:	81 fb c4 3d 11 80    	cmp    $0x80113dc4,%ebx
80103de4:	74 52                	je     80103e38 <procdump+0xa4>
80103de6:	8b 43 9c             	mov    -0x64(%ebx),%eax
80103de9:	85 c0                	test   %eax,%eax
80103deb:	74 ee                	je     80103ddb <procdump+0x47>
80103ded:	83 f8 05             	cmp    $0x5,%eax
80103df0:	76 b6                	jbe    80103da8 <procdump+0x14>
80103df2:	b8 eb 70 10 80       	mov    $0x801070eb,%eax
80103df7:	eb ba                	jmp    80103db3 <procdump+0x1f>
80103df9:	8d 76 00             	lea    0x0(%esi),%esi
80103dfc:	83 ec 08             	sub    $0x8,%esp
80103dff:	8d 45 c0             	lea    -0x40(%ebp),%eax
80103e02:	50                   	push   %eax
80103e03:	8b 43 b0             	mov    -0x50(%ebx),%eax
80103e06:	8b 40 0c             	mov    0xc(%eax),%eax
80103e09:	83 c0 08             	add    $0x8,%eax
80103e0c:	50                   	push   %eax
80103e0d:	e8 56 01 00 00       	call   80103f68 <getcallerpcs>
80103e12:	8d 7d c0             	lea    -0x40(%ebp),%edi
80103e15:	83 c4 10             	add    $0x10,%esp
80103e18:	8b 17                	mov    (%edi),%edx
80103e1a:	85 d2                	test   %edx,%edx
80103e1c:	74 ad                	je     80103dcb <procdump+0x37>
80103e1e:	83 ec 08             	sub    $0x8,%esp
80103e21:	52                   	push   %edx
80103e22:	68 41 6b 10 80       	push   $0x80106b41
80103e27:	e8 fc c7 ff ff       	call   80100628 <cprintf>
80103e2c:	83 c7 04             	add    $0x4,%edi
80103e2f:	83 c4 10             	add    $0x10,%esp
80103e32:	39 f7                	cmp    %esi,%edi
80103e34:	75 e2                	jne    80103e18 <procdump+0x84>
80103e36:	eb 93                	jmp    80103dcb <procdump+0x37>
80103e38:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103e3b:	5b                   	pop    %ebx
80103e3c:	5e                   	pop    %esi
80103e3d:	5f                   	pop    %edi
80103e3e:	5d                   	pop    %ebp
80103e3f:	c3                   	ret    

80103e40 <initsleeplock>:
80103e40:	55                   	push   %ebp
80103e41:	89 e5                	mov    %esp,%ebp
80103e43:	53                   	push   %ebx
80103e44:	83 ec 0c             	sub    $0xc,%esp
80103e47:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103e4a:	68 64 71 10 80       	push   $0x80107164
80103e4f:	8d 43 04             	lea    0x4(%ebx),%eax
80103e52:	50                   	push   %eax
80103e53:	e8 f4 00 00 00       	call   80103f4c <initlock>
80103e58:	8b 45 0c             	mov    0xc(%ebp),%eax
80103e5b:	89 43 38             	mov    %eax,0x38(%ebx)
80103e5e:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80103e64:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
80103e6b:	83 c4 10             	add    $0x10,%esp
80103e6e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103e71:	c9                   	leave  
80103e72:	c3                   	ret    
80103e73:	90                   	nop

80103e74 <acquiresleep>:
80103e74:	55                   	push   %ebp
80103e75:	89 e5                	mov    %esp,%ebp
80103e77:	56                   	push   %esi
80103e78:	53                   	push   %ebx
80103e79:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103e7c:	8d 73 04             	lea    0x4(%ebx),%esi
80103e7f:	83 ec 0c             	sub    $0xc,%esp
80103e82:	56                   	push   %esi
80103e83:	e8 84 02 00 00       	call   8010410c <acquire>
80103e88:	83 c4 10             	add    $0x10,%esp
80103e8b:	8b 13                	mov    (%ebx),%edx
80103e8d:	85 d2                	test   %edx,%edx
80103e8f:	74 16                	je     80103ea7 <acquiresleep+0x33>
80103e91:	8d 76 00             	lea    0x0(%esi),%esi
80103e94:	83 ec 08             	sub    $0x8,%esp
80103e97:	56                   	push   %esi
80103e98:	53                   	push   %ebx
80103e99:	e8 6a fd ff ff       	call   80103c08 <sleep>
80103e9e:	83 c4 10             	add    $0x10,%esp
80103ea1:	8b 03                	mov    (%ebx),%eax
80103ea3:	85 c0                	test   %eax,%eax
80103ea5:	75 ed                	jne    80103e94 <acquiresleep+0x20>
80103ea7:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
80103ead:	e8 62 f6 ff ff       	call   80103514 <myproc>
80103eb2:	8b 40 10             	mov    0x10(%eax),%eax
80103eb5:	89 43 3c             	mov    %eax,0x3c(%ebx)
80103eb8:	89 75 08             	mov    %esi,0x8(%ebp)
80103ebb:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103ebe:	5b                   	pop    %ebx
80103ebf:	5e                   	pop    %esi
80103ec0:	5d                   	pop    %ebp
80103ec1:	e9 e6 01 00 00       	jmp    801040ac <release>
80103ec6:	66 90                	xchg   %ax,%ax

80103ec8 <releasesleep>:
80103ec8:	55                   	push   %ebp
80103ec9:	89 e5                	mov    %esp,%ebp
80103ecb:	56                   	push   %esi
80103ecc:	53                   	push   %ebx
80103ecd:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103ed0:	8d 73 04             	lea    0x4(%ebx),%esi
80103ed3:	83 ec 0c             	sub    $0xc,%esp
80103ed6:	56                   	push   %esi
80103ed7:	e8 30 02 00 00       	call   8010410c <acquire>
80103edc:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80103ee2:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
80103ee9:	89 1c 24             	mov    %ebx,(%esp)
80103eec:	e8 d3 fd ff ff       	call   80103cc4 <wakeup>
80103ef1:	83 c4 10             	add    $0x10,%esp
80103ef4:	89 75 08             	mov    %esi,0x8(%ebp)
80103ef7:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103efa:	5b                   	pop    %ebx
80103efb:	5e                   	pop    %esi
80103efc:	5d                   	pop    %ebp
80103efd:	e9 aa 01 00 00       	jmp    801040ac <release>
80103f02:	66 90                	xchg   %ax,%ax

80103f04 <holdingsleep>:
80103f04:	55                   	push   %ebp
80103f05:	89 e5                	mov    %esp,%ebp
80103f07:	56                   	push   %esi
80103f08:	53                   	push   %ebx
80103f09:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103f0c:	8d 73 04             	lea    0x4(%ebx),%esi
80103f0f:	83 ec 0c             	sub    $0xc,%esp
80103f12:	56                   	push   %esi
80103f13:	e8 f4 01 00 00       	call   8010410c <acquire>
80103f18:	83 c4 10             	add    $0x10,%esp
80103f1b:	8b 03                	mov    (%ebx),%eax
80103f1d:	85 c0                	test   %eax,%eax
80103f1f:	75 17                	jne    80103f38 <holdingsleep+0x34>
80103f21:	31 db                	xor    %ebx,%ebx
80103f23:	83 ec 0c             	sub    $0xc,%esp
80103f26:	56                   	push   %esi
80103f27:	e8 80 01 00 00       	call   801040ac <release>
80103f2c:	89 d8                	mov    %ebx,%eax
80103f2e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103f31:	5b                   	pop    %ebx
80103f32:	5e                   	pop    %esi
80103f33:	5d                   	pop    %ebp
80103f34:	c3                   	ret    
80103f35:	8d 76 00             	lea    0x0(%esi),%esi
80103f38:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
80103f3b:	e8 d4 f5 ff ff       	call   80103514 <myproc>
80103f40:	39 58 10             	cmp    %ebx,0x10(%eax)
80103f43:	0f 94 c3             	sete   %bl
80103f46:	0f b6 db             	movzbl %bl,%ebx
80103f49:	eb d8                	jmp    80103f23 <holdingsleep+0x1f>
80103f4b:	90                   	nop

80103f4c <initlock>:
80103f4c:	55                   	push   %ebp
80103f4d:	89 e5                	mov    %esp,%ebp
80103f4f:	8b 45 08             	mov    0x8(%ebp),%eax
80103f52:	8b 55 0c             	mov    0xc(%ebp),%edx
80103f55:	89 50 04             	mov    %edx,0x4(%eax)
80103f58:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80103f5e:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
80103f65:	5d                   	pop    %ebp
80103f66:	c3                   	ret    
80103f67:	90                   	nop

80103f68 <getcallerpcs>:
80103f68:	55                   	push   %ebp
80103f69:	89 e5                	mov    %esp,%ebp
80103f6b:	53                   	push   %ebx
80103f6c:	8b 45 08             	mov    0x8(%ebp),%eax
80103f6f:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103f72:	8d 50 f8             	lea    -0x8(%eax),%edx
80103f75:	05 f8 ff ff 7f       	add    $0x7ffffff8,%eax
80103f7a:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
80103f7f:	b8 00 00 00 00       	mov    $0x0,%eax
80103f84:	76 10                	jbe    80103f96 <getcallerpcs+0x2e>
80103f86:	eb 24                	jmp    80103fac <getcallerpcs+0x44>
80103f88:	8d 9a 00 00 00 80    	lea    -0x80000000(%edx),%ebx
80103f8e:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80103f94:	77 16                	ja     80103fac <getcallerpcs+0x44>
80103f96:	8b 5a 04             	mov    0x4(%edx),%ebx
80103f99:	89 1c 81             	mov    %ebx,(%ecx,%eax,4)
80103f9c:	8b 12                	mov    (%edx),%edx
80103f9e:	40                   	inc    %eax
80103f9f:	83 f8 0a             	cmp    $0xa,%eax
80103fa2:	75 e4                	jne    80103f88 <getcallerpcs+0x20>
80103fa4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103fa7:	c9                   	leave  
80103fa8:	c3                   	ret    
80103fa9:	8d 76 00             	lea    0x0(%esi),%esi
80103fac:	8d 04 81             	lea    (%ecx,%eax,4),%eax
80103faf:	8d 51 28             	lea    0x28(%ecx),%edx
80103fb2:	66 90                	xchg   %ax,%ax
80103fb4:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
80103fba:	83 c0 04             	add    $0x4,%eax
80103fbd:	39 d0                	cmp    %edx,%eax
80103fbf:	75 f3                	jne    80103fb4 <getcallerpcs+0x4c>
80103fc1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103fc4:	c9                   	leave  
80103fc5:	c3                   	ret    
80103fc6:	66 90                	xchg   %ax,%ax

80103fc8 <pushcli>:
80103fc8:	55                   	push   %ebp
80103fc9:	89 e5                	mov    %esp,%ebp
80103fcb:	53                   	push   %ebx
80103fcc:	50                   	push   %eax
80103fcd:	9c                   	pushf  
80103fce:	5b                   	pop    %ebx
80103fcf:	fa                   	cli    
80103fd0:	e8 a7 f4 ff ff       	call   8010347c <mycpu>
80103fd5:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80103fdb:	85 d2                	test   %edx,%edx
80103fdd:	74 11                	je     80103ff0 <pushcli+0x28>
80103fdf:	e8 98 f4 ff ff       	call   8010347c <mycpu>
80103fe4:	ff 80 a4 00 00 00    	incl   0xa4(%eax)
80103fea:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103fed:	c9                   	leave  
80103fee:	c3                   	ret    
80103fef:	90                   	nop
80103ff0:	e8 87 f4 ff ff       	call   8010347c <mycpu>
80103ff5:	81 e3 00 02 00 00    	and    $0x200,%ebx
80103ffb:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80104001:	e8 76 f4 ff ff       	call   8010347c <mycpu>
80104006:	ff 80 a4 00 00 00    	incl   0xa4(%eax)
8010400c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010400f:	c9                   	leave  
80104010:	c3                   	ret    
80104011:	8d 76 00             	lea    0x0(%esi),%esi

80104014 <popcli>:
80104014:	55                   	push   %ebp
80104015:	89 e5                	mov    %esp,%ebp
80104017:	83 ec 08             	sub    $0x8,%esp
8010401a:	9c                   	pushf  
8010401b:	58                   	pop    %eax
8010401c:	f6 c4 02             	test   $0x2,%ah
8010401f:	75 31                	jne    80104052 <popcli+0x3e>
80104021:	e8 56 f4 ff ff       	call   8010347c <mycpu>
80104026:	ff 88 a4 00 00 00    	decl   0xa4(%eax)
8010402c:	78 31                	js     8010405f <popcli+0x4b>
8010402e:	e8 49 f4 ff ff       	call   8010347c <mycpu>
80104033:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80104039:	85 d2                	test   %edx,%edx
8010403b:	74 03                	je     80104040 <popcli+0x2c>
8010403d:	c9                   	leave  
8010403e:	c3                   	ret    
8010403f:	90                   	nop
80104040:	e8 37 f4 ff ff       	call   8010347c <mycpu>
80104045:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
8010404b:	85 c0                	test   %eax,%eax
8010404d:	74 ee                	je     8010403d <popcli+0x29>
8010404f:	fb                   	sti    
80104050:	c9                   	leave  
80104051:	c3                   	ret    
80104052:	83 ec 0c             	sub    $0xc,%esp
80104055:	68 6f 71 10 80       	push   $0x8010716f
8010405a:	e8 d9 c2 ff ff       	call   80100338 <panic>
8010405f:	83 ec 0c             	sub    $0xc,%esp
80104062:	68 86 71 10 80       	push   $0x80107186
80104067:	e8 cc c2 ff ff       	call   80100338 <panic>

8010406c <holding>:
8010406c:	55                   	push   %ebp
8010406d:	89 e5                	mov    %esp,%ebp
8010406f:	53                   	push   %ebx
80104070:	50                   	push   %eax
80104071:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104074:	e8 4f ff ff ff       	call   80103fc8 <pushcli>
80104079:	8b 13                	mov    (%ebx),%edx
8010407b:	85 d2                	test   %edx,%edx
8010407d:	75 11                	jne    80104090 <holding+0x24>
8010407f:	31 db                	xor    %ebx,%ebx
80104081:	e8 8e ff ff ff       	call   80104014 <popcli>
80104086:	89 d8                	mov    %ebx,%eax
80104088:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010408b:	c9                   	leave  
8010408c:	c3                   	ret    
8010408d:	8d 76 00             	lea    0x0(%esi),%esi
80104090:	8b 5b 08             	mov    0x8(%ebx),%ebx
80104093:	e8 e4 f3 ff ff       	call   8010347c <mycpu>
80104098:	39 c3                	cmp    %eax,%ebx
8010409a:	0f 94 c3             	sete   %bl
8010409d:	0f b6 db             	movzbl %bl,%ebx
801040a0:	e8 6f ff ff ff       	call   80104014 <popcli>
801040a5:	89 d8                	mov    %ebx,%eax
801040a7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801040aa:	c9                   	leave  
801040ab:	c3                   	ret    

801040ac <release>:
801040ac:	55                   	push   %ebp
801040ad:	89 e5                	mov    %esp,%ebp
801040af:	56                   	push   %esi
801040b0:	53                   	push   %ebx
801040b1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801040b4:	e8 0f ff ff ff       	call   80103fc8 <pushcli>
801040b9:	8b 03                	mov    (%ebx),%eax
801040bb:	85 c0                	test   %eax,%eax
801040bd:	75 15                	jne    801040d4 <release+0x28>
801040bf:	e8 50 ff ff ff       	call   80104014 <popcli>
801040c4:	83 ec 0c             	sub    $0xc,%esp
801040c7:	68 8d 71 10 80       	push   $0x8010718d
801040cc:	e8 67 c2 ff ff       	call   80100338 <panic>
801040d1:	8d 76 00             	lea    0x0(%esi),%esi
801040d4:	8b 73 08             	mov    0x8(%ebx),%esi
801040d7:	e8 a0 f3 ff ff       	call   8010347c <mycpu>
801040dc:	39 c6                	cmp    %eax,%esi
801040de:	75 df                	jne    801040bf <release+0x13>
801040e0:	e8 2f ff ff ff       	call   80104014 <popcli>
801040e5:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
801040ec:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
801040f3:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
801040f8:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
801040fe:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104101:	5b                   	pop    %ebx
80104102:	5e                   	pop    %esi
80104103:	5d                   	pop    %ebp
80104104:	e9 0b ff ff ff       	jmp    80104014 <popcli>
80104109:	8d 76 00             	lea    0x0(%esi),%esi

8010410c <acquire>:
8010410c:	55                   	push   %ebp
8010410d:	89 e5                	mov    %esp,%ebp
8010410f:	53                   	push   %ebx
80104110:	50                   	push   %eax
80104111:	e8 b2 fe ff ff       	call   80103fc8 <pushcli>
80104116:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104119:	e8 aa fe ff ff       	call   80103fc8 <pushcli>
8010411e:	8b 13                	mov    (%ebx),%edx
80104120:	85 d2                	test   %edx,%edx
80104122:	0f 85 80 00 00 00    	jne    801041a8 <acquire+0x9c>
80104128:	e8 e7 fe ff ff       	call   80104014 <popcli>
8010412d:	b9 01 00 00 00       	mov    $0x1,%ecx
80104132:	66 90                	xchg   %ax,%ax
80104134:	8b 55 08             	mov    0x8(%ebp),%edx
80104137:	89 c8                	mov    %ecx,%eax
80104139:	f0 87 02             	lock xchg %eax,(%edx)
8010413c:	85 c0                	test   %eax,%eax
8010413e:	75 f4                	jne    80104134 <acquire+0x28>
80104140:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
80104145:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104148:	e8 2f f3 ff ff       	call   8010347c <mycpu>
8010414d:	89 43 08             	mov    %eax,0x8(%ebx)
80104150:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104153:	8d 85 00 00 00 80    	lea    -0x80000000(%ebp),%eax
80104159:	31 d2                	xor    %edx,%edx
8010415b:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
80104160:	77 2a                	ja     8010418c <acquire+0x80>
80104162:	89 e8                	mov    %ebp,%eax
80104164:	eb 10                	jmp    80104176 <acquire+0x6a>
80104166:	66 90                	xchg   %ax,%ax
80104168:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
8010416e:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80104174:	77 16                	ja     8010418c <acquire+0x80>
80104176:	8b 58 04             	mov    0x4(%eax),%ebx
80104179:	89 5c 91 0c          	mov    %ebx,0xc(%ecx,%edx,4)
8010417d:	8b 00                	mov    (%eax),%eax
8010417f:	42                   	inc    %edx
80104180:	83 fa 0a             	cmp    $0xa,%edx
80104183:	75 e3                	jne    80104168 <acquire+0x5c>
80104185:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104188:	c9                   	leave  
80104189:	c3                   	ret    
8010418a:	66 90                	xchg   %ax,%ax
8010418c:	8d 44 91 0c          	lea    0xc(%ecx,%edx,4),%eax
80104190:	8d 51 34             	lea    0x34(%ecx),%edx
80104193:	90                   	nop
80104194:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
8010419a:	83 c0 04             	add    $0x4,%eax
8010419d:	39 c2                	cmp    %eax,%edx
8010419f:	75 f3                	jne    80104194 <acquire+0x88>
801041a1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801041a4:	c9                   	leave  
801041a5:	c3                   	ret    
801041a6:	66 90                	xchg   %ax,%ax
801041a8:	8b 5b 08             	mov    0x8(%ebx),%ebx
801041ab:	e8 cc f2 ff ff       	call   8010347c <mycpu>
801041b0:	39 c3                	cmp    %eax,%ebx
801041b2:	0f 85 70 ff ff ff    	jne    80104128 <acquire+0x1c>
801041b8:	e8 57 fe ff ff       	call   80104014 <popcli>
801041bd:	83 ec 0c             	sub    $0xc,%esp
801041c0:	68 95 71 10 80       	push   $0x80107195
801041c5:	e8 6e c1 ff ff       	call   80100338 <panic>
801041ca:	66 90                	xchg   %ax,%ax

801041cc <memset>:
801041cc:	55                   	push   %ebp
801041cd:	89 e5                	mov    %esp,%ebp
801041cf:	57                   	push   %edi
801041d0:	8b 55 08             	mov    0x8(%ebp),%edx
801041d3:	8b 4d 10             	mov    0x10(%ebp),%ecx
801041d6:	89 d0                	mov    %edx,%eax
801041d8:	09 c8                	or     %ecx,%eax
801041da:	a8 03                	test   $0x3,%al
801041dc:	75 22                	jne    80104200 <memset+0x34>
801041de:	c1 e9 02             	shr    $0x2,%ecx
801041e1:	0f b6 7d 0c          	movzbl 0xc(%ebp),%edi
801041e5:	89 f8                	mov    %edi,%eax
801041e7:	c1 e0 08             	shl    $0x8,%eax
801041ea:	01 f8                	add    %edi,%eax
801041ec:	89 c7                	mov    %eax,%edi
801041ee:	c1 e7 10             	shl    $0x10,%edi
801041f1:	01 f8                	add    %edi,%eax
801041f3:	89 d7                	mov    %edx,%edi
801041f5:	fc                   	cld    
801041f6:	f3 ab                	rep stos %eax,%es:(%edi)
801041f8:	89 d0                	mov    %edx,%eax
801041fa:	8b 7d fc             	mov    -0x4(%ebp),%edi
801041fd:	c9                   	leave  
801041fe:	c3                   	ret    
801041ff:	90                   	nop
80104200:	89 d7                	mov    %edx,%edi
80104202:	8b 45 0c             	mov    0xc(%ebp),%eax
80104205:	fc                   	cld    
80104206:	f3 aa                	rep stos %al,%es:(%edi)
80104208:	89 d0                	mov    %edx,%eax
8010420a:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010420d:	c9                   	leave  
8010420e:	c3                   	ret    
8010420f:	90                   	nop

80104210 <memcmp>:
80104210:	55                   	push   %ebp
80104211:	89 e5                	mov    %esp,%ebp
80104213:	56                   	push   %esi
80104214:	53                   	push   %ebx
80104215:	8b 55 08             	mov    0x8(%ebp),%edx
80104218:	8b 45 0c             	mov    0xc(%ebp),%eax
8010421b:	8b 75 10             	mov    0x10(%ebp),%esi
8010421e:	85 f6                	test   %esi,%esi
80104220:	74 1e                	je     80104240 <memcmp+0x30>
80104222:	01 c6                	add    %eax,%esi
80104224:	eb 08                	jmp    8010422e <memcmp+0x1e>
80104226:	66 90                	xchg   %ax,%ax
80104228:	42                   	inc    %edx
80104229:	40                   	inc    %eax
8010422a:	39 f0                	cmp    %esi,%eax
8010422c:	74 12                	je     80104240 <memcmp+0x30>
8010422e:	8a 0a                	mov    (%edx),%cl
80104230:	0f b6 18             	movzbl (%eax),%ebx
80104233:	38 d9                	cmp    %bl,%cl
80104235:	74 f1                	je     80104228 <memcmp+0x18>
80104237:	0f b6 c1             	movzbl %cl,%eax
8010423a:	29 d8                	sub    %ebx,%eax
8010423c:	5b                   	pop    %ebx
8010423d:	5e                   	pop    %esi
8010423e:	5d                   	pop    %ebp
8010423f:	c3                   	ret    
80104240:	31 c0                	xor    %eax,%eax
80104242:	5b                   	pop    %ebx
80104243:	5e                   	pop    %esi
80104244:	5d                   	pop    %ebp
80104245:	c3                   	ret    
80104246:	66 90                	xchg   %ax,%ax

80104248 <memmove>:
80104248:	55                   	push   %ebp
80104249:	89 e5                	mov    %esp,%ebp
8010424b:	57                   	push   %edi
8010424c:	56                   	push   %esi
8010424d:	8b 55 08             	mov    0x8(%ebp),%edx
80104250:	8b 75 0c             	mov    0xc(%ebp),%esi
80104253:	8b 45 10             	mov    0x10(%ebp),%eax
80104256:	39 d6                	cmp    %edx,%esi
80104258:	73 22                	jae    8010427c <memmove+0x34>
8010425a:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
8010425d:	39 ca                	cmp    %ecx,%edx
8010425f:	73 1b                	jae    8010427c <memmove+0x34>
80104261:	85 c0                	test   %eax,%eax
80104263:	74 0e                	je     80104273 <memmove+0x2b>
80104265:	48                   	dec    %eax
80104266:	66 90                	xchg   %ax,%ax
80104268:	8a 0c 06             	mov    (%esi,%eax,1),%cl
8010426b:	88 0c 02             	mov    %cl,(%edx,%eax,1)
8010426e:	83 e8 01             	sub    $0x1,%eax
80104271:	73 f5                	jae    80104268 <memmove+0x20>
80104273:	89 d0                	mov    %edx,%eax
80104275:	5e                   	pop    %esi
80104276:	5f                   	pop    %edi
80104277:	5d                   	pop    %ebp
80104278:	c3                   	ret    
80104279:	8d 76 00             	lea    0x0(%esi),%esi
8010427c:	85 c0                	test   %eax,%eax
8010427e:	74 f3                	je     80104273 <memmove+0x2b>
80104280:	01 f0                	add    %esi,%eax
80104282:	89 d7                	mov    %edx,%edi
80104284:	a4                   	movsb  %ds:(%esi),%es:(%edi)
80104285:	39 c6                	cmp    %eax,%esi
80104287:	75 fb                	jne    80104284 <memmove+0x3c>
80104289:	89 d0                	mov    %edx,%eax
8010428b:	5e                   	pop    %esi
8010428c:	5f                   	pop    %edi
8010428d:	5d                   	pop    %ebp
8010428e:	c3                   	ret    
8010428f:	90                   	nop

80104290 <memcpy>:
80104290:	eb b6                	jmp    80104248 <memmove>
80104292:	66 90                	xchg   %ax,%ax

80104294 <strncmp>:
80104294:	55                   	push   %ebp
80104295:	89 e5                	mov    %esp,%ebp
80104297:	53                   	push   %ebx
80104298:	8b 45 08             	mov    0x8(%ebp),%eax
8010429b:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010429e:	8b 55 10             	mov    0x10(%ebp),%edx
801042a1:	85 d2                	test   %edx,%edx
801042a3:	75 0c                	jne    801042b1 <strncmp+0x1d>
801042a5:	eb 1d                	jmp    801042c4 <strncmp+0x30>
801042a7:	90                   	nop
801042a8:	3a 19                	cmp    (%ecx),%bl
801042aa:	75 0b                	jne    801042b7 <strncmp+0x23>
801042ac:	40                   	inc    %eax
801042ad:	41                   	inc    %ecx
801042ae:	4a                   	dec    %edx
801042af:	74 13                	je     801042c4 <strncmp+0x30>
801042b1:	8a 18                	mov    (%eax),%bl
801042b3:	84 db                	test   %bl,%bl
801042b5:	75 f1                	jne    801042a8 <strncmp+0x14>
801042b7:	0f b6 00             	movzbl (%eax),%eax
801042ba:	0f b6 11             	movzbl (%ecx),%edx
801042bd:	29 d0                	sub    %edx,%eax
801042bf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801042c2:	c9                   	leave  
801042c3:	c3                   	ret    
801042c4:	31 c0                	xor    %eax,%eax
801042c6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801042c9:	c9                   	leave  
801042ca:	c3                   	ret    
801042cb:	90                   	nop

801042cc <strncpy>:
801042cc:	55                   	push   %ebp
801042cd:	89 e5                	mov    %esp,%ebp
801042cf:	56                   	push   %esi
801042d0:	53                   	push   %ebx
801042d1:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801042d4:	8b 4d 10             	mov    0x10(%ebp),%ecx
801042d7:	8b 55 08             	mov    0x8(%ebp),%edx
801042da:	eb 0c                	jmp    801042e8 <strncpy+0x1c>
801042dc:	43                   	inc    %ebx
801042dd:	42                   	inc    %edx
801042de:	8a 43 ff             	mov    -0x1(%ebx),%al
801042e1:	88 42 ff             	mov    %al,-0x1(%edx)
801042e4:	84 c0                	test   %al,%al
801042e6:	74 10                	je     801042f8 <strncpy+0x2c>
801042e8:	89 ce                	mov    %ecx,%esi
801042ea:	49                   	dec    %ecx
801042eb:	85 f6                	test   %esi,%esi
801042ed:	7f ed                	jg     801042dc <strncpy+0x10>
801042ef:	8b 45 08             	mov    0x8(%ebp),%eax
801042f2:	5b                   	pop    %ebx
801042f3:	5e                   	pop    %esi
801042f4:	5d                   	pop    %ebp
801042f5:	c3                   	ret    
801042f6:	66 90                	xchg   %ax,%ax
801042f8:	8d 5c 32 ff          	lea    -0x1(%edx,%esi,1),%ebx
801042fc:	85 c9                	test   %ecx,%ecx
801042fe:	74 ef                	je     801042ef <strncpy+0x23>
80104300:	42                   	inc    %edx
80104301:	c6 42 ff 00          	movb   $0x0,-0x1(%edx)
80104305:	89 d9                	mov    %ebx,%ecx
80104307:	29 d1                	sub    %edx,%ecx
80104309:	85 c9                	test   %ecx,%ecx
8010430b:	7f f3                	jg     80104300 <strncpy+0x34>
8010430d:	8b 45 08             	mov    0x8(%ebp),%eax
80104310:	5b                   	pop    %ebx
80104311:	5e                   	pop    %esi
80104312:	5d                   	pop    %ebp
80104313:	c3                   	ret    

80104314 <safestrcpy>:
80104314:	55                   	push   %ebp
80104315:	89 e5                	mov    %esp,%ebp
80104317:	56                   	push   %esi
80104318:	53                   	push   %ebx
80104319:	8b 45 08             	mov    0x8(%ebp),%eax
8010431c:	8b 55 0c             	mov    0xc(%ebp),%edx
8010431f:	8b 4d 10             	mov    0x10(%ebp),%ecx
80104322:	85 c9                	test   %ecx,%ecx
80104324:	7e 1d                	jle    80104343 <safestrcpy+0x2f>
80104326:	8d 74 0a ff          	lea    -0x1(%edx,%ecx,1),%esi
8010432a:	89 c1                	mov    %eax,%ecx
8010432c:	eb 0e                	jmp    8010433c <safestrcpy+0x28>
8010432e:	66 90                	xchg   %ax,%ax
80104330:	42                   	inc    %edx
80104331:	41                   	inc    %ecx
80104332:	8a 5a ff             	mov    -0x1(%edx),%bl
80104335:	88 59 ff             	mov    %bl,-0x1(%ecx)
80104338:	84 db                	test   %bl,%bl
8010433a:	74 04                	je     80104340 <safestrcpy+0x2c>
8010433c:	39 f2                	cmp    %esi,%edx
8010433e:	75 f0                	jne    80104330 <safestrcpy+0x1c>
80104340:	c6 01 00             	movb   $0x0,(%ecx)
80104343:	5b                   	pop    %ebx
80104344:	5e                   	pop    %esi
80104345:	5d                   	pop    %ebp
80104346:	c3                   	ret    
80104347:	90                   	nop

80104348 <strlen>:
80104348:	55                   	push   %ebp
80104349:	89 e5                	mov    %esp,%ebp
8010434b:	8b 55 08             	mov    0x8(%ebp),%edx
8010434e:	31 c0                	xor    %eax,%eax
80104350:	80 3a 00             	cmpb   $0x0,(%edx)
80104353:	74 0a                	je     8010435f <strlen+0x17>
80104355:	8d 76 00             	lea    0x0(%esi),%esi
80104358:	40                   	inc    %eax
80104359:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
8010435d:	75 f9                	jne    80104358 <strlen+0x10>
8010435f:	5d                   	pop    %ebp
80104360:	c3                   	ret    

80104361 <swtch>:
80104361:	8b 44 24 04          	mov    0x4(%esp),%eax
80104365:	8b 54 24 08          	mov    0x8(%esp),%edx
80104369:	55                   	push   %ebp
8010436a:	53                   	push   %ebx
8010436b:	56                   	push   %esi
8010436c:	57                   	push   %edi
8010436d:	89 20                	mov    %esp,(%eax)
8010436f:	89 d4                	mov    %edx,%esp
80104371:	5f                   	pop    %edi
80104372:	5e                   	pop    %esi
80104373:	5b                   	pop    %ebx
80104374:	5d                   	pop    %ebp
80104375:	c3                   	ret    
80104376:	66 90                	xchg   %ax,%ax

80104378 <fetchint>:
80104378:	55                   	push   %ebp
80104379:	89 e5                	mov    %esp,%ebp
8010437b:	53                   	push   %ebx
8010437c:	50                   	push   %eax
8010437d:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104380:	e8 8f f1 ff ff       	call   80103514 <myproc>
80104385:	8b 00                	mov    (%eax),%eax
80104387:	39 c3                	cmp    %eax,%ebx
80104389:	73 15                	jae    801043a0 <fetchint+0x28>
8010438b:	8d 53 04             	lea    0x4(%ebx),%edx
8010438e:	39 d0                	cmp    %edx,%eax
80104390:	72 0e                	jb     801043a0 <fetchint+0x28>
80104392:	8b 13                	mov    (%ebx),%edx
80104394:	8b 45 0c             	mov    0xc(%ebp),%eax
80104397:	89 10                	mov    %edx,(%eax)
80104399:	31 c0                	xor    %eax,%eax
8010439b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010439e:	c9                   	leave  
8010439f:	c3                   	ret    
801043a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801043a5:	eb f4                	jmp    8010439b <fetchint+0x23>
801043a7:	90                   	nop

801043a8 <fetchstr>:
801043a8:	55                   	push   %ebp
801043a9:	89 e5                	mov    %esp,%ebp
801043ab:	53                   	push   %ebx
801043ac:	50                   	push   %eax
801043ad:	8b 5d 08             	mov    0x8(%ebp),%ebx
801043b0:	e8 5f f1 ff ff       	call   80103514 <myproc>
801043b5:	3b 18                	cmp    (%eax),%ebx
801043b7:	73 23                	jae    801043dc <fetchstr+0x34>
801043b9:	8b 55 0c             	mov    0xc(%ebp),%edx
801043bc:	89 1a                	mov    %ebx,(%edx)
801043be:	8b 10                	mov    (%eax),%edx
801043c0:	39 d3                	cmp    %edx,%ebx
801043c2:	73 18                	jae    801043dc <fetchstr+0x34>
801043c4:	89 d8                	mov    %ebx,%eax
801043c6:	eb 05                	jmp    801043cd <fetchstr+0x25>
801043c8:	40                   	inc    %eax
801043c9:	39 d0                	cmp    %edx,%eax
801043cb:	73 0f                	jae    801043dc <fetchstr+0x34>
801043cd:	80 38 00             	cmpb   $0x0,(%eax)
801043d0:	75 f6                	jne    801043c8 <fetchstr+0x20>
801043d2:	29 d8                	sub    %ebx,%eax
801043d4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801043d7:	c9                   	leave  
801043d8:	c3                   	ret    
801043d9:	8d 76 00             	lea    0x0(%esi),%esi
801043dc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801043e1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801043e4:	c9                   	leave  
801043e5:	c3                   	ret    
801043e6:	66 90                	xchg   %ax,%ax

801043e8 <argint>:
801043e8:	55                   	push   %ebp
801043e9:	89 e5                	mov    %esp,%ebp
801043eb:	56                   	push   %esi
801043ec:	53                   	push   %ebx
801043ed:	e8 22 f1 ff ff       	call   80103514 <myproc>
801043f2:	8b 40 1c             	mov    0x1c(%eax),%eax
801043f5:	8b 40 44             	mov    0x44(%eax),%eax
801043f8:	8b 55 08             	mov    0x8(%ebp),%edx
801043fb:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
801043fe:	8d 73 04             	lea    0x4(%ebx),%esi
80104401:	e8 0e f1 ff ff       	call   80103514 <myproc>
80104406:	8b 00                	mov    (%eax),%eax
80104408:	39 c6                	cmp    %eax,%esi
8010440a:	73 18                	jae    80104424 <argint+0x3c>
8010440c:	8d 53 08             	lea    0x8(%ebx),%edx
8010440f:	39 d0                	cmp    %edx,%eax
80104411:	72 11                	jb     80104424 <argint+0x3c>
80104413:	8b 53 04             	mov    0x4(%ebx),%edx
80104416:	8b 45 0c             	mov    0xc(%ebp),%eax
80104419:	89 10                	mov    %edx,(%eax)
8010441b:	31 c0                	xor    %eax,%eax
8010441d:	5b                   	pop    %ebx
8010441e:	5e                   	pop    %esi
8010441f:	5d                   	pop    %ebp
80104420:	c3                   	ret    
80104421:	8d 76 00             	lea    0x0(%esi),%esi
80104424:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104429:	eb f2                	jmp    8010441d <argint+0x35>
8010442b:	90                   	nop

8010442c <argptr>:
8010442c:	55                   	push   %ebp
8010442d:	89 e5                	mov    %esp,%ebp
8010442f:	57                   	push   %edi
80104430:	56                   	push   %esi
80104431:	53                   	push   %ebx
80104432:	83 ec 0c             	sub    $0xc,%esp
80104435:	e8 da f0 ff ff       	call   80103514 <myproc>
8010443a:	89 c6                	mov    %eax,%esi
8010443c:	e8 d3 f0 ff ff       	call   80103514 <myproc>
80104441:	8b 40 1c             	mov    0x1c(%eax),%eax
80104444:	8b 40 44             	mov    0x44(%eax),%eax
80104447:	8b 55 08             	mov    0x8(%ebp),%edx
8010444a:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
8010444d:	8d 7b 04             	lea    0x4(%ebx),%edi
80104450:	e8 bf f0 ff ff       	call   80103514 <myproc>
80104455:	8b 00                	mov    (%eax),%eax
80104457:	39 c7                	cmp    %eax,%edi
80104459:	73 31                	jae    8010448c <argptr+0x60>
8010445b:	8d 4b 08             	lea    0x8(%ebx),%ecx
8010445e:	39 c8                	cmp    %ecx,%eax
80104460:	72 2a                	jb     8010448c <argptr+0x60>
80104462:	8b 43 04             	mov    0x4(%ebx),%eax
80104465:	8b 55 10             	mov    0x10(%ebp),%edx
80104468:	85 d2                	test   %edx,%edx
8010446a:	78 20                	js     8010448c <argptr+0x60>
8010446c:	8b 16                	mov    (%esi),%edx
8010446e:	39 d0                	cmp    %edx,%eax
80104470:	73 1a                	jae    8010448c <argptr+0x60>
80104472:	8b 5d 10             	mov    0x10(%ebp),%ebx
80104475:	01 c3                	add    %eax,%ebx
80104477:	39 da                	cmp    %ebx,%edx
80104479:	72 11                	jb     8010448c <argptr+0x60>
8010447b:	8b 55 0c             	mov    0xc(%ebp),%edx
8010447e:	89 02                	mov    %eax,(%edx)
80104480:	31 c0                	xor    %eax,%eax
80104482:	83 c4 0c             	add    $0xc,%esp
80104485:	5b                   	pop    %ebx
80104486:	5e                   	pop    %esi
80104487:	5f                   	pop    %edi
80104488:	5d                   	pop    %ebp
80104489:	c3                   	ret    
8010448a:	66 90                	xchg   %ax,%ax
8010448c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104491:	eb ef                	jmp    80104482 <argptr+0x56>
80104493:	90                   	nop

80104494 <argstr>:
80104494:	55                   	push   %ebp
80104495:	89 e5                	mov    %esp,%ebp
80104497:	56                   	push   %esi
80104498:	53                   	push   %ebx
80104499:	e8 76 f0 ff ff       	call   80103514 <myproc>
8010449e:	8b 40 1c             	mov    0x1c(%eax),%eax
801044a1:	8b 40 44             	mov    0x44(%eax),%eax
801044a4:	8b 55 08             	mov    0x8(%ebp),%edx
801044a7:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
801044aa:	8d 73 04             	lea    0x4(%ebx),%esi
801044ad:	e8 62 f0 ff ff       	call   80103514 <myproc>
801044b2:	8b 00                	mov    (%eax),%eax
801044b4:	39 c6                	cmp    %eax,%esi
801044b6:	73 34                	jae    801044ec <argstr+0x58>
801044b8:	8d 53 08             	lea    0x8(%ebx),%edx
801044bb:	39 d0                	cmp    %edx,%eax
801044bd:	72 2d                	jb     801044ec <argstr+0x58>
801044bf:	8b 5b 04             	mov    0x4(%ebx),%ebx
801044c2:	e8 4d f0 ff ff       	call   80103514 <myproc>
801044c7:	3b 18                	cmp    (%eax),%ebx
801044c9:	73 21                	jae    801044ec <argstr+0x58>
801044cb:	8b 55 0c             	mov    0xc(%ebp),%edx
801044ce:	89 1a                	mov    %ebx,(%edx)
801044d0:	8b 10                	mov    (%eax),%edx
801044d2:	39 d3                	cmp    %edx,%ebx
801044d4:	73 16                	jae    801044ec <argstr+0x58>
801044d6:	89 d8                	mov    %ebx,%eax
801044d8:	eb 07                	jmp    801044e1 <argstr+0x4d>
801044da:	66 90                	xchg   %ax,%ax
801044dc:	40                   	inc    %eax
801044dd:	39 d0                	cmp    %edx,%eax
801044df:	73 0b                	jae    801044ec <argstr+0x58>
801044e1:	80 38 00             	cmpb   $0x0,(%eax)
801044e4:	75 f6                	jne    801044dc <argstr+0x48>
801044e6:	29 d8                	sub    %ebx,%eax
801044e8:	5b                   	pop    %ebx
801044e9:	5e                   	pop    %esi
801044ea:	5d                   	pop    %ebp
801044eb:	c3                   	ret    
801044ec:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801044f1:	5b                   	pop    %ebx
801044f2:	5e                   	pop    %esi
801044f3:	5d                   	pop    %ebp
801044f4:	c3                   	ret    
801044f5:	8d 76 00             	lea    0x0(%esi),%esi

801044f8 <syscall>:
801044f8:	55                   	push   %ebp
801044f9:	89 e5                	mov    %esp,%ebp
801044fb:	53                   	push   %ebx
801044fc:	50                   	push   %eax
801044fd:	e8 12 f0 ff ff       	call   80103514 <myproc>
80104502:	89 c3                	mov    %eax,%ebx
80104504:	8b 40 1c             	mov    0x1c(%eax),%eax
80104507:	8b 40 1c             	mov    0x1c(%eax),%eax
8010450a:	8d 50 ff             	lea    -0x1(%eax),%edx
8010450d:	83 fa 17             	cmp    $0x17,%edx
80104510:	77 1a                	ja     8010452c <syscall+0x34>
80104512:	8b 14 85 c0 71 10 80 	mov    -0x7fef8e40(,%eax,4),%edx
80104519:	85 d2                	test   %edx,%edx
8010451b:	74 0f                	je     8010452c <syscall+0x34>
8010451d:	ff d2                	call   *%edx
8010451f:	89 c2                	mov    %eax,%edx
80104521:	8b 43 1c             	mov    0x1c(%ebx),%eax
80104524:	89 50 1c             	mov    %edx,0x1c(%eax)
80104527:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010452a:	c9                   	leave  
8010452b:	c3                   	ret    
8010452c:	50                   	push   %eax
8010452d:	8d 43 70             	lea    0x70(%ebx),%eax
80104530:	50                   	push   %eax
80104531:	ff 73 10             	pushl  0x10(%ebx)
80104534:	68 9d 71 10 80       	push   $0x8010719d
80104539:	e8 ea c0 ff ff       	call   80100628 <cprintf>
8010453e:	8b 43 1c             	mov    0x1c(%ebx),%eax
80104541:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
80104548:	83 c4 10             	add    $0x10,%esp
8010454b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010454e:	c9                   	leave  
8010454f:	c3                   	ret    

80104550 <create>:
80104550:	55                   	push   %ebp
80104551:	89 e5                	mov    %esp,%ebp
80104553:	57                   	push   %edi
80104554:	56                   	push   %esi
80104555:	53                   	push   %ebx
80104556:	83 ec 34             	sub    $0x34,%esp
80104559:	89 55 d4             	mov    %edx,-0x2c(%ebp)
8010455c:	89 4d d0             	mov    %ecx,-0x30(%ebp)
8010455f:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104562:	89 4d cc             	mov    %ecx,-0x34(%ebp)
80104565:	8d 7d da             	lea    -0x26(%ebp),%edi
80104568:	57                   	push   %edi
80104569:	50                   	push   %eax
8010456a:	e8 49 d9 ff ff       	call   80101eb8 <nameiparent>
8010456f:	83 c4 10             	add    $0x10,%esp
80104572:	85 c0                	test   %eax,%eax
80104574:	74 5a                	je     801045d0 <create+0x80>
80104576:	89 c3                	mov    %eax,%ebx
80104578:	83 ec 0c             	sub    $0xc,%esp
8010457b:	50                   	push   %eax
8010457c:	e8 93 d0 ff ff       	call   80101614 <ilock>
80104581:	83 c4 0c             	add    $0xc,%esp
80104584:	6a 00                	push   $0x0
80104586:	57                   	push   %edi
80104587:	53                   	push   %ebx
80104588:	e8 8b d5 ff ff       	call   80101b18 <dirlookup>
8010458d:	89 c6                	mov    %eax,%esi
8010458f:	83 c4 10             	add    $0x10,%esp
80104592:	85 c0                	test   %eax,%eax
80104594:	74 46                	je     801045dc <create+0x8c>
80104596:	83 ec 0c             	sub    $0xc,%esp
80104599:	53                   	push   %ebx
8010459a:	e8 c9 d2 ff ff       	call   80101868 <iunlockput>
8010459f:	89 34 24             	mov    %esi,(%esp)
801045a2:	e8 6d d0 ff ff       	call   80101614 <ilock>
801045a7:	83 c4 10             	add    $0x10,%esp
801045aa:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
801045af:	75 13                	jne    801045c4 <create+0x74>
801045b1:	66 83 7e 50 02       	cmpw   $0x2,0x50(%esi)
801045b6:	75 0c                	jne    801045c4 <create+0x74>
801045b8:	89 f0                	mov    %esi,%eax
801045ba:	8d 65 f4             	lea    -0xc(%ebp),%esp
801045bd:	5b                   	pop    %ebx
801045be:	5e                   	pop    %esi
801045bf:	5f                   	pop    %edi
801045c0:	5d                   	pop    %ebp
801045c1:	c3                   	ret    
801045c2:	66 90                	xchg   %ax,%ax
801045c4:	83 ec 0c             	sub    $0xc,%esp
801045c7:	56                   	push   %esi
801045c8:	e8 9b d2 ff ff       	call   80101868 <iunlockput>
801045cd:	83 c4 10             	add    $0x10,%esp
801045d0:	31 f6                	xor    %esi,%esi
801045d2:	89 f0                	mov    %esi,%eax
801045d4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801045d7:	5b                   	pop    %ebx
801045d8:	5e                   	pop    %esi
801045d9:	5f                   	pop    %edi
801045da:	5d                   	pop    %ebp
801045db:	c3                   	ret    
801045dc:	83 ec 08             	sub    $0x8,%esp
801045df:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
801045e3:	50                   	push   %eax
801045e4:	ff 33                	pushl  (%ebx)
801045e6:	e8 d1 ce ff ff       	call   801014bc <ialloc>
801045eb:	89 c6                	mov    %eax,%esi
801045ed:	83 c4 10             	add    $0x10,%esp
801045f0:	85 c0                	test   %eax,%eax
801045f2:	0f 84 ad 00 00 00    	je     801046a5 <create+0x155>
801045f8:	83 ec 0c             	sub    $0xc,%esp
801045fb:	50                   	push   %eax
801045fc:	e8 13 d0 ff ff       	call   80101614 <ilock>
80104601:	8b 45 d0             	mov    -0x30(%ebp),%eax
80104604:	66 89 46 52          	mov    %ax,0x52(%esi)
80104608:	8b 45 cc             	mov    -0x34(%ebp),%eax
8010460b:	66 89 46 54          	mov    %ax,0x54(%esi)
8010460f:	66 c7 46 56 01 00    	movw   $0x1,0x56(%esi)
80104615:	89 34 24             	mov    %esi,(%esp)
80104618:	e8 4f cf ff ff       	call   8010156c <iupdate>
8010461d:	83 c4 10             	add    $0x10,%esp
80104620:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
80104625:	74 29                	je     80104650 <create+0x100>
80104627:	50                   	push   %eax
80104628:	ff 76 04             	pushl  0x4(%esi)
8010462b:	57                   	push   %edi
8010462c:	53                   	push   %ebx
8010462d:	e8 be d7 ff ff       	call   80101df0 <dirlink>
80104632:	83 c4 10             	add    $0x10,%esp
80104635:	85 c0                	test   %eax,%eax
80104637:	78 5f                	js     80104698 <create+0x148>
80104639:	83 ec 0c             	sub    $0xc,%esp
8010463c:	53                   	push   %ebx
8010463d:	e8 26 d2 ff ff       	call   80101868 <iunlockput>
80104642:	83 c4 10             	add    $0x10,%esp
80104645:	89 f0                	mov    %esi,%eax
80104647:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010464a:	5b                   	pop    %ebx
8010464b:	5e                   	pop    %esi
8010464c:	5f                   	pop    %edi
8010464d:	5d                   	pop    %ebp
8010464e:	c3                   	ret    
8010464f:	90                   	nop
80104650:	66 ff 43 56          	incw   0x56(%ebx)
80104654:	83 ec 0c             	sub    $0xc,%esp
80104657:	53                   	push   %ebx
80104658:	e8 0f cf ff ff       	call   8010156c <iupdate>
8010465d:	83 c4 0c             	add    $0xc,%esp
80104660:	ff 76 04             	pushl  0x4(%esi)
80104663:	68 40 72 10 80       	push   $0x80107240
80104668:	56                   	push   %esi
80104669:	e8 82 d7 ff ff       	call   80101df0 <dirlink>
8010466e:	83 c4 10             	add    $0x10,%esp
80104671:	85 c0                	test   %eax,%eax
80104673:	78 16                	js     8010468b <create+0x13b>
80104675:	52                   	push   %edx
80104676:	ff 73 04             	pushl  0x4(%ebx)
80104679:	68 3f 72 10 80       	push   $0x8010723f
8010467e:	56                   	push   %esi
8010467f:	e8 6c d7 ff ff       	call   80101df0 <dirlink>
80104684:	83 c4 10             	add    $0x10,%esp
80104687:	85 c0                	test   %eax,%eax
80104689:	79 9c                	jns    80104627 <create+0xd7>
8010468b:	83 ec 0c             	sub    $0xc,%esp
8010468e:	68 33 72 10 80       	push   $0x80107233
80104693:	e8 a0 bc ff ff       	call   80100338 <panic>
80104698:	83 ec 0c             	sub    $0xc,%esp
8010469b:	68 42 72 10 80       	push   $0x80107242
801046a0:	e8 93 bc ff ff       	call   80100338 <panic>
801046a5:	83 ec 0c             	sub    $0xc,%esp
801046a8:	68 24 72 10 80       	push   $0x80107224
801046ad:	e8 86 bc ff ff       	call   80100338 <panic>
801046b2:	66 90                	xchg   %ax,%ax

801046b4 <sys_dup>:
801046b4:	55                   	push   %ebp
801046b5:	89 e5                	mov    %esp,%ebp
801046b7:	56                   	push   %esi
801046b8:	53                   	push   %ebx
801046b9:	83 ec 18             	sub    $0x18,%esp
801046bc:	8d 45 f4             	lea    -0xc(%ebp),%eax
801046bf:	50                   	push   %eax
801046c0:	6a 00                	push   $0x0
801046c2:	e8 21 fd ff ff       	call   801043e8 <argint>
801046c7:	83 c4 10             	add    $0x10,%esp
801046ca:	85 c0                	test   %eax,%eax
801046cc:	78 2c                	js     801046fa <sys_dup+0x46>
801046ce:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801046d2:	77 26                	ja     801046fa <sys_dup+0x46>
801046d4:	e8 3b ee ff ff       	call   80103514 <myproc>
801046d9:	8b 55 f4             	mov    -0xc(%ebp),%edx
801046dc:	8b 74 90 2c          	mov    0x2c(%eax,%edx,4),%esi
801046e0:	85 f6                	test   %esi,%esi
801046e2:	74 16                	je     801046fa <sys_dup+0x46>
801046e4:	e8 2b ee ff ff       	call   80103514 <myproc>
801046e9:	31 db                	xor    %ebx,%ebx
801046eb:	90                   	nop
801046ec:	8b 54 98 2c          	mov    0x2c(%eax,%ebx,4),%edx
801046f0:	85 d2                	test   %edx,%edx
801046f2:	74 14                	je     80104708 <sys_dup+0x54>
801046f4:	43                   	inc    %ebx
801046f5:	83 fb 10             	cmp    $0x10,%ebx
801046f8:	75 f2                	jne    801046ec <sys_dup+0x38>
801046fa:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801046ff:	89 d8                	mov    %ebx,%eax
80104701:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104704:	5b                   	pop    %ebx
80104705:	5e                   	pop    %esi
80104706:	5d                   	pop    %ebp
80104707:	c3                   	ret    
80104708:	89 74 98 2c          	mov    %esi,0x2c(%eax,%ebx,4)
8010470c:	83 ec 0c             	sub    $0xc,%esp
8010470f:	56                   	push   %esi
80104710:	e8 eb c6 ff ff       	call   80100e00 <filedup>
80104715:	83 c4 10             	add    $0x10,%esp
80104718:	89 d8                	mov    %ebx,%eax
8010471a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010471d:	5b                   	pop    %ebx
8010471e:	5e                   	pop    %esi
8010471f:	5d                   	pop    %ebp
80104720:	c3                   	ret    
80104721:	8d 76 00             	lea    0x0(%esi),%esi

80104724 <sys_read>:
80104724:	55                   	push   %ebp
80104725:	89 e5                	mov    %esp,%ebp
80104727:	56                   	push   %esi
80104728:	53                   	push   %ebx
80104729:	83 ec 18             	sub    $0x18,%esp
8010472c:	8d 5d f4             	lea    -0xc(%ebp),%ebx
8010472f:	53                   	push   %ebx
80104730:	6a 00                	push   $0x0
80104732:	e8 b1 fc ff ff       	call   801043e8 <argint>
80104737:	83 c4 10             	add    $0x10,%esp
8010473a:	85 c0                	test   %eax,%eax
8010473c:	78 56                	js     80104794 <sys_read+0x70>
8010473e:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104742:	77 50                	ja     80104794 <sys_read+0x70>
80104744:	e8 cb ed ff ff       	call   80103514 <myproc>
80104749:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010474c:	8b 74 90 2c          	mov    0x2c(%eax,%edx,4),%esi
80104750:	85 f6                	test   %esi,%esi
80104752:	74 40                	je     80104794 <sys_read+0x70>
80104754:	83 ec 08             	sub    $0x8,%esp
80104757:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010475a:	50                   	push   %eax
8010475b:	6a 02                	push   $0x2
8010475d:	e8 86 fc ff ff       	call   801043e8 <argint>
80104762:	83 c4 10             	add    $0x10,%esp
80104765:	85 c0                	test   %eax,%eax
80104767:	78 2b                	js     80104794 <sys_read+0x70>
80104769:	52                   	push   %edx
8010476a:	ff 75 f0             	pushl  -0x10(%ebp)
8010476d:	53                   	push   %ebx
8010476e:	6a 01                	push   $0x1
80104770:	e8 b7 fc ff ff       	call   8010442c <argptr>
80104775:	83 c4 10             	add    $0x10,%esp
80104778:	85 c0                	test   %eax,%eax
8010477a:	78 18                	js     80104794 <sys_read+0x70>
8010477c:	50                   	push   %eax
8010477d:	ff 75 f0             	pushl  -0x10(%ebp)
80104780:	ff 75 f4             	pushl  -0xc(%ebp)
80104783:	56                   	push   %esi
80104784:	e8 bf c7 ff ff       	call   80100f48 <fileread>
80104789:	83 c4 10             	add    $0x10,%esp
8010478c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010478f:	5b                   	pop    %ebx
80104790:	5e                   	pop    %esi
80104791:	5d                   	pop    %ebp
80104792:	c3                   	ret    
80104793:	90                   	nop
80104794:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104799:	eb f1                	jmp    8010478c <sys_read+0x68>
8010479b:	90                   	nop

8010479c <sys_write>:
8010479c:	55                   	push   %ebp
8010479d:	89 e5                	mov    %esp,%ebp
8010479f:	56                   	push   %esi
801047a0:	53                   	push   %ebx
801047a1:	83 ec 18             	sub    $0x18,%esp
801047a4:	8d 5d f4             	lea    -0xc(%ebp),%ebx
801047a7:	53                   	push   %ebx
801047a8:	6a 00                	push   $0x0
801047aa:	e8 39 fc ff ff       	call   801043e8 <argint>
801047af:	83 c4 10             	add    $0x10,%esp
801047b2:	85 c0                	test   %eax,%eax
801047b4:	78 56                	js     8010480c <sys_write+0x70>
801047b6:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801047ba:	77 50                	ja     8010480c <sys_write+0x70>
801047bc:	e8 53 ed ff ff       	call   80103514 <myproc>
801047c1:	8b 55 f4             	mov    -0xc(%ebp),%edx
801047c4:	8b 74 90 2c          	mov    0x2c(%eax,%edx,4),%esi
801047c8:	85 f6                	test   %esi,%esi
801047ca:	74 40                	je     8010480c <sys_write+0x70>
801047cc:	83 ec 08             	sub    $0x8,%esp
801047cf:	8d 45 f0             	lea    -0x10(%ebp),%eax
801047d2:	50                   	push   %eax
801047d3:	6a 02                	push   $0x2
801047d5:	e8 0e fc ff ff       	call   801043e8 <argint>
801047da:	83 c4 10             	add    $0x10,%esp
801047dd:	85 c0                	test   %eax,%eax
801047df:	78 2b                	js     8010480c <sys_write+0x70>
801047e1:	52                   	push   %edx
801047e2:	ff 75 f0             	pushl  -0x10(%ebp)
801047e5:	53                   	push   %ebx
801047e6:	6a 01                	push   $0x1
801047e8:	e8 3f fc ff ff       	call   8010442c <argptr>
801047ed:	83 c4 10             	add    $0x10,%esp
801047f0:	85 c0                	test   %eax,%eax
801047f2:	78 18                	js     8010480c <sys_write+0x70>
801047f4:	50                   	push   %eax
801047f5:	ff 75 f0             	pushl  -0x10(%ebp)
801047f8:	ff 75 f4             	pushl  -0xc(%ebp)
801047fb:	56                   	push   %esi
801047fc:	e8 d3 c7 ff ff       	call   80100fd4 <filewrite>
80104801:	83 c4 10             	add    $0x10,%esp
80104804:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104807:	5b                   	pop    %ebx
80104808:	5e                   	pop    %esi
80104809:	5d                   	pop    %ebp
8010480a:	c3                   	ret    
8010480b:	90                   	nop
8010480c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104811:	eb f1                	jmp    80104804 <sys_write+0x68>
80104813:	90                   	nop

80104814 <sys_close>:
80104814:	55                   	push   %ebp
80104815:	89 e5                	mov    %esp,%ebp
80104817:	56                   	push   %esi
80104818:	53                   	push   %ebx
80104819:	83 ec 18             	sub    $0x18,%esp
8010481c:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010481f:	50                   	push   %eax
80104820:	6a 00                	push   $0x0
80104822:	e8 c1 fb ff ff       	call   801043e8 <argint>
80104827:	83 c4 10             	add    $0x10,%esp
8010482a:	85 c0                	test   %eax,%eax
8010482c:	78 3e                	js     8010486c <sys_close+0x58>
8010482e:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104832:	77 38                	ja     8010486c <sys_close+0x58>
80104834:	e8 db ec ff ff       	call   80103514 <myproc>
80104839:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010483c:	8d 5a 08             	lea    0x8(%edx),%ebx
8010483f:	8b 74 98 0c          	mov    0xc(%eax,%ebx,4),%esi
80104843:	85 f6                	test   %esi,%esi
80104845:	74 25                	je     8010486c <sys_close+0x58>
80104847:	e8 c8 ec ff ff       	call   80103514 <myproc>
8010484c:	c7 44 98 0c 00 00 00 	movl   $0x0,0xc(%eax,%ebx,4)
80104853:	00 
80104854:	83 ec 0c             	sub    $0xc,%esp
80104857:	56                   	push   %esi
80104858:	e8 e7 c5 ff ff       	call   80100e44 <fileclose>
8010485d:	83 c4 10             	add    $0x10,%esp
80104860:	31 c0                	xor    %eax,%eax
80104862:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104865:	5b                   	pop    %ebx
80104866:	5e                   	pop    %esi
80104867:	5d                   	pop    %ebp
80104868:	c3                   	ret    
80104869:	8d 76 00             	lea    0x0(%esi),%esi
8010486c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104871:	eb ef                	jmp    80104862 <sys_close+0x4e>
80104873:	90                   	nop

80104874 <sys_fstat>:
80104874:	55                   	push   %ebp
80104875:	89 e5                	mov    %esp,%ebp
80104877:	56                   	push   %esi
80104878:	53                   	push   %ebx
80104879:	83 ec 18             	sub    $0x18,%esp
8010487c:	8d 5d f4             	lea    -0xc(%ebp),%ebx
8010487f:	53                   	push   %ebx
80104880:	6a 00                	push   $0x0
80104882:	e8 61 fb ff ff       	call   801043e8 <argint>
80104887:	83 c4 10             	add    $0x10,%esp
8010488a:	85 c0                	test   %eax,%eax
8010488c:	78 3e                	js     801048cc <sys_fstat+0x58>
8010488e:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104892:	77 38                	ja     801048cc <sys_fstat+0x58>
80104894:	e8 7b ec ff ff       	call   80103514 <myproc>
80104899:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010489c:	8b 74 90 2c          	mov    0x2c(%eax,%edx,4),%esi
801048a0:	85 f6                	test   %esi,%esi
801048a2:	74 28                	je     801048cc <sys_fstat+0x58>
801048a4:	50                   	push   %eax
801048a5:	6a 14                	push   $0x14
801048a7:	53                   	push   %ebx
801048a8:	6a 01                	push   $0x1
801048aa:	e8 7d fb ff ff       	call   8010442c <argptr>
801048af:	83 c4 10             	add    $0x10,%esp
801048b2:	85 c0                	test   %eax,%eax
801048b4:	78 16                	js     801048cc <sys_fstat+0x58>
801048b6:	83 ec 08             	sub    $0x8,%esp
801048b9:	ff 75 f4             	pushl  -0xc(%ebp)
801048bc:	56                   	push   %esi
801048bd:	e8 42 c6 ff ff       	call   80100f04 <filestat>
801048c2:	83 c4 10             	add    $0x10,%esp
801048c5:	8d 65 f8             	lea    -0x8(%ebp),%esp
801048c8:	5b                   	pop    %ebx
801048c9:	5e                   	pop    %esi
801048ca:	5d                   	pop    %ebp
801048cb:	c3                   	ret    
801048cc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048d1:	eb f2                	jmp    801048c5 <sys_fstat+0x51>
801048d3:	90                   	nop

801048d4 <sys_link>:
801048d4:	55                   	push   %ebp
801048d5:	89 e5                	mov    %esp,%ebp
801048d7:	57                   	push   %edi
801048d8:	56                   	push   %esi
801048d9:	53                   	push   %ebx
801048da:	83 ec 34             	sub    $0x34,%esp
801048dd:	8d 45 d4             	lea    -0x2c(%ebp),%eax
801048e0:	50                   	push   %eax
801048e1:	6a 00                	push   $0x0
801048e3:	e8 ac fb ff ff       	call   80104494 <argstr>
801048e8:	83 c4 10             	add    $0x10,%esp
801048eb:	85 c0                	test   %eax,%eax
801048ed:	0f 88 f2 00 00 00    	js     801049e5 <sys_link+0x111>
801048f3:	83 ec 08             	sub    $0x8,%esp
801048f6:	8d 45 d0             	lea    -0x30(%ebp),%eax
801048f9:	50                   	push   %eax
801048fa:	6a 01                	push   $0x1
801048fc:	e8 93 fb ff ff       	call   80104494 <argstr>
80104901:	83 c4 10             	add    $0x10,%esp
80104904:	85 c0                	test   %eax,%eax
80104906:	0f 88 d9 00 00 00    	js     801049e5 <sys_link+0x111>
8010490c:	e8 bb e0 ff ff       	call   801029cc <begin_op>
80104911:	83 ec 0c             	sub    $0xc,%esp
80104914:	ff 75 d4             	pushl  -0x2c(%ebp)
80104917:	e8 84 d5 ff ff       	call   80101ea0 <namei>
8010491c:	89 c3                	mov    %eax,%ebx
8010491e:	83 c4 10             	add    $0x10,%esp
80104921:	85 c0                	test   %eax,%eax
80104923:	0f 84 d6 00 00 00    	je     801049ff <sys_link+0x12b>
80104929:	83 ec 0c             	sub    $0xc,%esp
8010492c:	50                   	push   %eax
8010492d:	e8 e2 cc ff ff       	call   80101614 <ilock>
80104932:	83 c4 10             	add    $0x10,%esp
80104935:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
8010493a:	0f 84 ac 00 00 00    	je     801049ec <sys_link+0x118>
80104940:	66 ff 43 56          	incw   0x56(%ebx)
80104944:	83 ec 0c             	sub    $0xc,%esp
80104947:	53                   	push   %ebx
80104948:	e8 1f cc ff ff       	call   8010156c <iupdate>
8010494d:	89 1c 24             	mov    %ebx,(%esp)
80104950:	e8 87 cd ff ff       	call   801016dc <iunlock>
80104955:	5a                   	pop    %edx
80104956:	59                   	pop    %ecx
80104957:	8d 7d da             	lea    -0x26(%ebp),%edi
8010495a:	57                   	push   %edi
8010495b:	ff 75 d0             	pushl  -0x30(%ebp)
8010495e:	e8 55 d5 ff ff       	call   80101eb8 <nameiparent>
80104963:	89 c6                	mov    %eax,%esi
80104965:	83 c4 10             	add    $0x10,%esp
80104968:	85 c0                	test   %eax,%eax
8010496a:	74 54                	je     801049c0 <sys_link+0xec>
8010496c:	83 ec 0c             	sub    $0xc,%esp
8010496f:	50                   	push   %eax
80104970:	e8 9f cc ff ff       	call   80101614 <ilock>
80104975:	83 c4 10             	add    $0x10,%esp
80104978:	8b 03                	mov    (%ebx),%eax
8010497a:	39 06                	cmp    %eax,(%esi)
8010497c:	75 36                	jne    801049b4 <sys_link+0xe0>
8010497e:	50                   	push   %eax
8010497f:	ff 73 04             	pushl  0x4(%ebx)
80104982:	57                   	push   %edi
80104983:	56                   	push   %esi
80104984:	e8 67 d4 ff ff       	call   80101df0 <dirlink>
80104989:	83 c4 10             	add    $0x10,%esp
8010498c:	85 c0                	test   %eax,%eax
8010498e:	78 24                	js     801049b4 <sys_link+0xe0>
80104990:	83 ec 0c             	sub    $0xc,%esp
80104993:	56                   	push   %esi
80104994:	e8 cf ce ff ff       	call   80101868 <iunlockput>
80104999:	89 1c 24             	mov    %ebx,(%esp)
8010499c:	e8 7f cd ff ff       	call   80101720 <iput>
801049a1:	e8 8e e0 ff ff       	call   80102a34 <end_op>
801049a6:	83 c4 10             	add    $0x10,%esp
801049a9:	31 c0                	xor    %eax,%eax
801049ab:	8d 65 f4             	lea    -0xc(%ebp),%esp
801049ae:	5b                   	pop    %ebx
801049af:	5e                   	pop    %esi
801049b0:	5f                   	pop    %edi
801049b1:	5d                   	pop    %ebp
801049b2:	c3                   	ret    
801049b3:	90                   	nop
801049b4:	83 ec 0c             	sub    $0xc,%esp
801049b7:	56                   	push   %esi
801049b8:	e8 ab ce ff ff       	call   80101868 <iunlockput>
801049bd:	83 c4 10             	add    $0x10,%esp
801049c0:	83 ec 0c             	sub    $0xc,%esp
801049c3:	53                   	push   %ebx
801049c4:	e8 4b cc ff ff       	call   80101614 <ilock>
801049c9:	66 ff 4b 56          	decw   0x56(%ebx)
801049cd:	89 1c 24             	mov    %ebx,(%esp)
801049d0:	e8 97 cb ff ff       	call   8010156c <iupdate>
801049d5:	89 1c 24             	mov    %ebx,(%esp)
801049d8:	e8 8b ce ff ff       	call   80101868 <iunlockput>
801049dd:	e8 52 e0 ff ff       	call   80102a34 <end_op>
801049e2:	83 c4 10             	add    $0x10,%esp
801049e5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801049ea:	eb bf                	jmp    801049ab <sys_link+0xd7>
801049ec:	83 ec 0c             	sub    $0xc,%esp
801049ef:	53                   	push   %ebx
801049f0:	e8 73 ce ff ff       	call   80101868 <iunlockput>
801049f5:	e8 3a e0 ff ff       	call   80102a34 <end_op>
801049fa:	83 c4 10             	add    $0x10,%esp
801049fd:	eb e6                	jmp    801049e5 <sys_link+0x111>
801049ff:	e8 30 e0 ff ff       	call   80102a34 <end_op>
80104a04:	eb df                	jmp    801049e5 <sys_link+0x111>
80104a06:	66 90                	xchg   %ax,%ax

80104a08 <sys_unlink>:
80104a08:	55                   	push   %ebp
80104a09:	89 e5                	mov    %esp,%ebp
80104a0b:	57                   	push   %edi
80104a0c:	56                   	push   %esi
80104a0d:	53                   	push   %ebx
80104a0e:	83 ec 54             	sub    $0x54,%esp
80104a11:	8d 45 c0             	lea    -0x40(%ebp),%eax
80104a14:	50                   	push   %eax
80104a15:	6a 00                	push   $0x0
80104a17:	e8 78 fa ff ff       	call   80104494 <argstr>
80104a1c:	83 c4 10             	add    $0x10,%esp
80104a1f:	85 c0                	test   %eax,%eax
80104a21:	0f 88 50 01 00 00    	js     80104b77 <sys_unlink+0x16f>
80104a27:	e8 a0 df ff ff       	call   801029cc <begin_op>
80104a2c:	83 ec 08             	sub    $0x8,%esp
80104a2f:	8d 5d ca             	lea    -0x36(%ebp),%ebx
80104a32:	53                   	push   %ebx
80104a33:	ff 75 c0             	pushl  -0x40(%ebp)
80104a36:	e8 7d d4 ff ff       	call   80101eb8 <nameiparent>
80104a3b:	89 45 b4             	mov    %eax,-0x4c(%ebp)
80104a3e:	83 c4 10             	add    $0x10,%esp
80104a41:	85 c0                	test   %eax,%eax
80104a43:	0f 84 4f 01 00 00    	je     80104b98 <sys_unlink+0x190>
80104a49:	83 ec 0c             	sub    $0xc,%esp
80104a4c:	8b 7d b4             	mov    -0x4c(%ebp),%edi
80104a4f:	57                   	push   %edi
80104a50:	e8 bf cb ff ff       	call   80101614 <ilock>
80104a55:	59                   	pop    %ecx
80104a56:	5e                   	pop    %esi
80104a57:	68 40 72 10 80       	push   $0x80107240
80104a5c:	53                   	push   %ebx
80104a5d:	e8 9e d0 ff ff       	call   80101b00 <namecmp>
80104a62:	83 c4 10             	add    $0x10,%esp
80104a65:	85 c0                	test   %eax,%eax
80104a67:	0f 84 f7 00 00 00    	je     80104b64 <sys_unlink+0x15c>
80104a6d:	83 ec 08             	sub    $0x8,%esp
80104a70:	68 3f 72 10 80       	push   $0x8010723f
80104a75:	53                   	push   %ebx
80104a76:	e8 85 d0 ff ff       	call   80101b00 <namecmp>
80104a7b:	83 c4 10             	add    $0x10,%esp
80104a7e:	85 c0                	test   %eax,%eax
80104a80:	0f 84 de 00 00 00    	je     80104b64 <sys_unlink+0x15c>
80104a86:	52                   	push   %edx
80104a87:	8d 45 c4             	lea    -0x3c(%ebp),%eax
80104a8a:	50                   	push   %eax
80104a8b:	53                   	push   %ebx
80104a8c:	57                   	push   %edi
80104a8d:	e8 86 d0 ff ff       	call   80101b18 <dirlookup>
80104a92:	89 c3                	mov    %eax,%ebx
80104a94:	83 c4 10             	add    $0x10,%esp
80104a97:	85 c0                	test   %eax,%eax
80104a99:	0f 84 c5 00 00 00    	je     80104b64 <sys_unlink+0x15c>
80104a9f:	83 ec 0c             	sub    $0xc,%esp
80104aa2:	50                   	push   %eax
80104aa3:	e8 6c cb ff ff       	call   80101614 <ilock>
80104aa8:	83 c4 10             	add    $0x10,%esp
80104aab:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80104ab0:	0f 8e 03 01 00 00    	jle    80104bb9 <sys_unlink+0x1b1>
80104ab6:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104abb:	74 67                	je     80104b24 <sys_unlink+0x11c>
80104abd:	8d 7d d8             	lea    -0x28(%ebp),%edi
80104ac0:	50                   	push   %eax
80104ac1:	6a 10                	push   $0x10
80104ac3:	6a 00                	push   $0x0
80104ac5:	57                   	push   %edi
80104ac6:	e8 01 f7 ff ff       	call   801041cc <memset>
80104acb:	6a 10                	push   $0x10
80104acd:	ff 75 c4             	pushl  -0x3c(%ebp)
80104ad0:	57                   	push   %edi
80104ad1:	ff 75 b4             	pushl  -0x4c(%ebp)
80104ad4:	e8 0b cf ff ff       	call   801019e4 <writei>
80104ad9:	83 c4 20             	add    $0x20,%esp
80104adc:	83 f8 10             	cmp    $0x10,%eax
80104adf:	0f 85 c7 00 00 00    	jne    80104bac <sys_unlink+0x1a4>
80104ae5:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104aea:	0f 84 90 00 00 00    	je     80104b80 <sys_unlink+0x178>
80104af0:	83 ec 0c             	sub    $0xc,%esp
80104af3:	ff 75 b4             	pushl  -0x4c(%ebp)
80104af6:	e8 6d cd ff ff       	call   80101868 <iunlockput>
80104afb:	66 ff 4b 56          	decw   0x56(%ebx)
80104aff:	89 1c 24             	mov    %ebx,(%esp)
80104b02:	e8 65 ca ff ff       	call   8010156c <iupdate>
80104b07:	89 1c 24             	mov    %ebx,(%esp)
80104b0a:	e8 59 cd ff ff       	call   80101868 <iunlockput>
80104b0f:	e8 20 df ff ff       	call   80102a34 <end_op>
80104b14:	83 c4 10             	add    $0x10,%esp
80104b17:	31 c0                	xor    %eax,%eax
80104b19:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104b1c:	5b                   	pop    %ebx
80104b1d:	5e                   	pop    %esi
80104b1e:	5f                   	pop    %edi
80104b1f:	5d                   	pop    %ebp
80104b20:	c3                   	ret    
80104b21:	8d 76 00             	lea    0x0(%esi),%esi
80104b24:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
80104b28:	76 93                	jbe    80104abd <sys_unlink+0xb5>
80104b2a:	be 20 00 00 00       	mov    $0x20,%esi
80104b2f:	8d 7d d8             	lea    -0x28(%ebp),%edi
80104b32:	eb 08                	jmp    80104b3c <sys_unlink+0x134>
80104b34:	83 c6 10             	add    $0x10,%esi
80104b37:	3b 73 58             	cmp    0x58(%ebx),%esi
80104b3a:	73 84                	jae    80104ac0 <sys_unlink+0xb8>
80104b3c:	6a 10                	push   $0x10
80104b3e:	56                   	push   %esi
80104b3f:	57                   	push   %edi
80104b40:	53                   	push   %ebx
80104b41:	e8 9e cd ff ff       	call   801018e4 <readi>
80104b46:	83 c4 10             	add    $0x10,%esp
80104b49:	83 f8 10             	cmp    $0x10,%eax
80104b4c:	75 51                	jne    80104b9f <sys_unlink+0x197>
80104b4e:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80104b53:	74 df                	je     80104b34 <sys_unlink+0x12c>
80104b55:	83 ec 0c             	sub    $0xc,%esp
80104b58:	53                   	push   %ebx
80104b59:	e8 0a cd ff ff       	call   80101868 <iunlockput>
80104b5e:	83 c4 10             	add    $0x10,%esp
80104b61:	8d 76 00             	lea    0x0(%esi),%esi
80104b64:	83 ec 0c             	sub    $0xc,%esp
80104b67:	ff 75 b4             	pushl  -0x4c(%ebp)
80104b6a:	e8 f9 cc ff ff       	call   80101868 <iunlockput>
80104b6f:	e8 c0 de ff ff       	call   80102a34 <end_op>
80104b74:	83 c4 10             	add    $0x10,%esp
80104b77:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104b7c:	eb 9b                	jmp    80104b19 <sys_unlink+0x111>
80104b7e:	66 90                	xchg   %ax,%ax
80104b80:	8b 45 b4             	mov    -0x4c(%ebp),%eax
80104b83:	66 ff 48 56          	decw   0x56(%eax)
80104b87:	83 ec 0c             	sub    $0xc,%esp
80104b8a:	50                   	push   %eax
80104b8b:	e8 dc c9 ff ff       	call   8010156c <iupdate>
80104b90:	83 c4 10             	add    $0x10,%esp
80104b93:	e9 58 ff ff ff       	jmp    80104af0 <sys_unlink+0xe8>
80104b98:	e8 97 de ff ff       	call   80102a34 <end_op>
80104b9d:	eb d8                	jmp    80104b77 <sys_unlink+0x16f>
80104b9f:	83 ec 0c             	sub    $0xc,%esp
80104ba2:	68 64 72 10 80       	push   $0x80107264
80104ba7:	e8 8c b7 ff ff       	call   80100338 <panic>
80104bac:	83 ec 0c             	sub    $0xc,%esp
80104baf:	68 76 72 10 80       	push   $0x80107276
80104bb4:	e8 7f b7 ff ff       	call   80100338 <panic>
80104bb9:	83 ec 0c             	sub    $0xc,%esp
80104bbc:	68 52 72 10 80       	push   $0x80107252
80104bc1:	e8 72 b7 ff ff       	call   80100338 <panic>
80104bc6:	66 90                	xchg   %ax,%ax

80104bc8 <sys_open>:
80104bc8:	55                   	push   %ebp
80104bc9:	89 e5                	mov    %esp,%ebp
80104bcb:	57                   	push   %edi
80104bcc:	56                   	push   %esi
80104bcd:	53                   	push   %ebx
80104bce:	83 ec 24             	sub    $0x24,%esp
80104bd1:	8d 45 e0             	lea    -0x20(%ebp),%eax
80104bd4:	50                   	push   %eax
80104bd5:	6a 00                	push   $0x0
80104bd7:	e8 b8 f8 ff ff       	call   80104494 <argstr>
80104bdc:	83 c4 10             	add    $0x10,%esp
80104bdf:	85 c0                	test   %eax,%eax
80104be1:	0f 88 88 00 00 00    	js     80104c6f <sys_open+0xa7>
80104be7:	83 ec 08             	sub    $0x8,%esp
80104bea:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104bed:	50                   	push   %eax
80104bee:	6a 01                	push   $0x1
80104bf0:	e8 f3 f7 ff ff       	call   801043e8 <argint>
80104bf5:	83 c4 10             	add    $0x10,%esp
80104bf8:	85 c0                	test   %eax,%eax
80104bfa:	78 73                	js     80104c6f <sys_open+0xa7>
80104bfc:	e8 cb dd ff ff       	call   801029cc <begin_op>
80104c01:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
80104c05:	75 71                	jne    80104c78 <sys_open+0xb0>
80104c07:	83 ec 0c             	sub    $0xc,%esp
80104c0a:	ff 75 e0             	pushl  -0x20(%ebp)
80104c0d:	e8 8e d2 ff ff       	call   80101ea0 <namei>
80104c12:	89 c6                	mov    %eax,%esi
80104c14:	83 c4 10             	add    $0x10,%esp
80104c17:	85 c0                	test   %eax,%eax
80104c19:	74 7a                	je     80104c95 <sys_open+0xcd>
80104c1b:	83 ec 0c             	sub    $0xc,%esp
80104c1e:	50                   	push   %eax
80104c1f:	e8 f0 c9 ff ff       	call   80101614 <ilock>
80104c24:	83 c4 10             	add    $0x10,%esp
80104c27:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80104c2c:	0f 84 ae 00 00 00    	je     80104ce0 <sys_open+0x118>
80104c32:	e8 61 c1 ff ff       	call   80100d98 <filealloc>
80104c37:	89 c7                	mov    %eax,%edi
80104c39:	85 c0                	test   %eax,%eax
80104c3b:	74 21                	je     80104c5e <sys_open+0x96>
80104c3d:	e8 d2 e8 ff ff       	call   80103514 <myproc>
80104c42:	31 db                	xor    %ebx,%ebx
80104c44:	8b 54 98 2c          	mov    0x2c(%eax,%ebx,4),%edx
80104c48:	85 d2                	test   %edx,%edx
80104c4a:	74 50                	je     80104c9c <sys_open+0xd4>
80104c4c:	43                   	inc    %ebx
80104c4d:	83 fb 10             	cmp    $0x10,%ebx
80104c50:	75 f2                	jne    80104c44 <sys_open+0x7c>
80104c52:	83 ec 0c             	sub    $0xc,%esp
80104c55:	57                   	push   %edi
80104c56:	e8 e9 c1 ff ff       	call   80100e44 <fileclose>
80104c5b:	83 c4 10             	add    $0x10,%esp
80104c5e:	83 ec 0c             	sub    $0xc,%esp
80104c61:	56                   	push   %esi
80104c62:	e8 01 cc ff ff       	call   80101868 <iunlockput>
80104c67:	e8 c8 dd ff ff       	call   80102a34 <end_op>
80104c6c:	83 c4 10             	add    $0x10,%esp
80104c6f:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104c74:	eb 5f                	jmp    80104cd5 <sys_open+0x10d>
80104c76:	66 90                	xchg   %ax,%ax
80104c78:	83 ec 0c             	sub    $0xc,%esp
80104c7b:	6a 00                	push   $0x0
80104c7d:	31 c9                	xor    %ecx,%ecx
80104c7f:	ba 02 00 00 00       	mov    $0x2,%edx
80104c84:	8b 45 e0             	mov    -0x20(%ebp),%eax
80104c87:	e8 c4 f8 ff ff       	call   80104550 <create>
80104c8c:	89 c6                	mov    %eax,%esi
80104c8e:	83 c4 10             	add    $0x10,%esp
80104c91:	85 c0                	test   %eax,%eax
80104c93:	75 9d                	jne    80104c32 <sys_open+0x6a>
80104c95:	e8 9a dd ff ff       	call   80102a34 <end_op>
80104c9a:	eb d3                	jmp    80104c6f <sys_open+0xa7>
80104c9c:	89 7c 98 2c          	mov    %edi,0x2c(%eax,%ebx,4)
80104ca0:	83 ec 0c             	sub    $0xc,%esp
80104ca3:	56                   	push   %esi
80104ca4:	e8 33 ca ff ff       	call   801016dc <iunlock>
80104ca9:	e8 86 dd ff ff       	call   80102a34 <end_op>
80104cae:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
80104cb4:	89 77 10             	mov    %esi,0x10(%edi)
80104cb7:	c7 47 14 00 00 00 00 	movl   $0x0,0x14(%edi)
80104cbe:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80104cc1:	89 d0                	mov    %edx,%eax
80104cc3:	f7 d0                	not    %eax
80104cc5:	83 e0 01             	and    $0x1,%eax
80104cc8:	88 47 08             	mov    %al,0x8(%edi)
80104ccb:	83 c4 10             	add    $0x10,%esp
80104cce:	83 e2 03             	and    $0x3,%edx
80104cd1:	0f 95 47 09          	setne  0x9(%edi)
80104cd5:	89 d8                	mov    %ebx,%eax
80104cd7:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104cda:	5b                   	pop    %ebx
80104cdb:	5e                   	pop    %esi
80104cdc:	5f                   	pop    %edi
80104cdd:	5d                   	pop    %ebp
80104cde:	c3                   	ret    
80104cdf:	90                   	nop
80104ce0:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80104ce3:	85 c9                	test   %ecx,%ecx
80104ce5:	0f 84 47 ff ff ff    	je     80104c32 <sys_open+0x6a>
80104ceb:	e9 6e ff ff ff       	jmp    80104c5e <sys_open+0x96>

80104cf0 <sys_mkdir>:
80104cf0:	55                   	push   %ebp
80104cf1:	89 e5                	mov    %esp,%ebp
80104cf3:	83 ec 18             	sub    $0x18,%esp
80104cf6:	e8 d1 dc ff ff       	call   801029cc <begin_op>
80104cfb:	83 ec 08             	sub    $0x8,%esp
80104cfe:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104d01:	50                   	push   %eax
80104d02:	6a 00                	push   $0x0
80104d04:	e8 8b f7 ff ff       	call   80104494 <argstr>
80104d09:	83 c4 10             	add    $0x10,%esp
80104d0c:	85 c0                	test   %eax,%eax
80104d0e:	78 30                	js     80104d40 <sys_mkdir+0x50>
80104d10:	83 ec 0c             	sub    $0xc,%esp
80104d13:	6a 00                	push   $0x0
80104d15:	31 c9                	xor    %ecx,%ecx
80104d17:	ba 01 00 00 00       	mov    $0x1,%edx
80104d1c:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104d1f:	e8 2c f8 ff ff       	call   80104550 <create>
80104d24:	83 c4 10             	add    $0x10,%esp
80104d27:	85 c0                	test   %eax,%eax
80104d29:	74 15                	je     80104d40 <sys_mkdir+0x50>
80104d2b:	83 ec 0c             	sub    $0xc,%esp
80104d2e:	50                   	push   %eax
80104d2f:	e8 34 cb ff ff       	call   80101868 <iunlockput>
80104d34:	e8 fb dc ff ff       	call   80102a34 <end_op>
80104d39:	83 c4 10             	add    $0x10,%esp
80104d3c:	31 c0                	xor    %eax,%eax
80104d3e:	c9                   	leave  
80104d3f:	c3                   	ret    
80104d40:	e8 ef dc ff ff       	call   80102a34 <end_op>
80104d45:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d4a:	c9                   	leave  
80104d4b:	c3                   	ret    

80104d4c <sys_mknod>:
80104d4c:	55                   	push   %ebp
80104d4d:	89 e5                	mov    %esp,%ebp
80104d4f:	83 ec 18             	sub    $0x18,%esp
80104d52:	e8 75 dc ff ff       	call   801029cc <begin_op>
80104d57:	83 ec 08             	sub    $0x8,%esp
80104d5a:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104d5d:	50                   	push   %eax
80104d5e:	6a 00                	push   $0x0
80104d60:	e8 2f f7 ff ff       	call   80104494 <argstr>
80104d65:	83 c4 10             	add    $0x10,%esp
80104d68:	85 c0                	test   %eax,%eax
80104d6a:	78 60                	js     80104dcc <sys_mknod+0x80>
80104d6c:	83 ec 08             	sub    $0x8,%esp
80104d6f:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104d72:	50                   	push   %eax
80104d73:	6a 01                	push   $0x1
80104d75:	e8 6e f6 ff ff       	call   801043e8 <argint>
80104d7a:	83 c4 10             	add    $0x10,%esp
80104d7d:	85 c0                	test   %eax,%eax
80104d7f:	78 4b                	js     80104dcc <sys_mknod+0x80>
80104d81:	83 ec 08             	sub    $0x8,%esp
80104d84:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104d87:	50                   	push   %eax
80104d88:	6a 02                	push   $0x2
80104d8a:	e8 59 f6 ff ff       	call   801043e8 <argint>
80104d8f:	83 c4 10             	add    $0x10,%esp
80104d92:	85 c0                	test   %eax,%eax
80104d94:	78 36                	js     80104dcc <sys_mknod+0x80>
80104d96:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
80104d9a:	83 ec 0c             	sub    $0xc,%esp
80104d9d:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
80104da1:	50                   	push   %eax
80104da2:	ba 03 00 00 00       	mov    $0x3,%edx
80104da7:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104daa:	e8 a1 f7 ff ff       	call   80104550 <create>
80104daf:	83 c4 10             	add    $0x10,%esp
80104db2:	85 c0                	test   %eax,%eax
80104db4:	74 16                	je     80104dcc <sys_mknod+0x80>
80104db6:	83 ec 0c             	sub    $0xc,%esp
80104db9:	50                   	push   %eax
80104dba:	e8 a9 ca ff ff       	call   80101868 <iunlockput>
80104dbf:	e8 70 dc ff ff       	call   80102a34 <end_op>
80104dc4:	83 c4 10             	add    $0x10,%esp
80104dc7:	31 c0                	xor    %eax,%eax
80104dc9:	c9                   	leave  
80104dca:	c3                   	ret    
80104dcb:	90                   	nop
80104dcc:	e8 63 dc ff ff       	call   80102a34 <end_op>
80104dd1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104dd6:	c9                   	leave  
80104dd7:	c3                   	ret    

80104dd8 <sys_chdir>:
80104dd8:	55                   	push   %ebp
80104dd9:	89 e5                	mov    %esp,%ebp
80104ddb:	56                   	push   %esi
80104ddc:	53                   	push   %ebx
80104ddd:	83 ec 10             	sub    $0x10,%esp
80104de0:	e8 2f e7 ff ff       	call   80103514 <myproc>
80104de5:	89 c6                	mov    %eax,%esi
80104de7:	e8 e0 db ff ff       	call   801029cc <begin_op>
80104dec:	83 ec 08             	sub    $0x8,%esp
80104def:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104df2:	50                   	push   %eax
80104df3:	6a 00                	push   $0x0
80104df5:	e8 9a f6 ff ff       	call   80104494 <argstr>
80104dfa:	83 c4 10             	add    $0x10,%esp
80104dfd:	85 c0                	test   %eax,%eax
80104dff:	78 67                	js     80104e68 <sys_chdir+0x90>
80104e01:	83 ec 0c             	sub    $0xc,%esp
80104e04:	ff 75 f4             	pushl  -0xc(%ebp)
80104e07:	e8 94 d0 ff ff       	call   80101ea0 <namei>
80104e0c:	89 c3                	mov    %eax,%ebx
80104e0e:	83 c4 10             	add    $0x10,%esp
80104e11:	85 c0                	test   %eax,%eax
80104e13:	74 53                	je     80104e68 <sys_chdir+0x90>
80104e15:	83 ec 0c             	sub    $0xc,%esp
80104e18:	50                   	push   %eax
80104e19:	e8 f6 c7 ff ff       	call   80101614 <ilock>
80104e1e:	83 c4 10             	add    $0x10,%esp
80104e21:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104e26:	75 28                	jne    80104e50 <sys_chdir+0x78>
80104e28:	83 ec 0c             	sub    $0xc,%esp
80104e2b:	53                   	push   %ebx
80104e2c:	e8 ab c8 ff ff       	call   801016dc <iunlock>
80104e31:	58                   	pop    %eax
80104e32:	ff 76 6c             	pushl  0x6c(%esi)
80104e35:	e8 e6 c8 ff ff       	call   80101720 <iput>
80104e3a:	e8 f5 db ff ff       	call   80102a34 <end_op>
80104e3f:	89 5e 6c             	mov    %ebx,0x6c(%esi)
80104e42:	83 c4 10             	add    $0x10,%esp
80104e45:	31 c0                	xor    %eax,%eax
80104e47:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104e4a:	5b                   	pop    %ebx
80104e4b:	5e                   	pop    %esi
80104e4c:	5d                   	pop    %ebp
80104e4d:	c3                   	ret    
80104e4e:	66 90                	xchg   %ax,%ax
80104e50:	83 ec 0c             	sub    $0xc,%esp
80104e53:	53                   	push   %ebx
80104e54:	e8 0f ca ff ff       	call   80101868 <iunlockput>
80104e59:	e8 d6 db ff ff       	call   80102a34 <end_op>
80104e5e:	83 c4 10             	add    $0x10,%esp
80104e61:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e66:	eb df                	jmp    80104e47 <sys_chdir+0x6f>
80104e68:	e8 c7 db ff ff       	call   80102a34 <end_op>
80104e6d:	eb f2                	jmp    80104e61 <sys_chdir+0x89>
80104e6f:	90                   	nop

80104e70 <sys_exec>:
80104e70:	55                   	push   %ebp
80104e71:	89 e5                	mov    %esp,%ebp
80104e73:	57                   	push   %edi
80104e74:	56                   	push   %esi
80104e75:	53                   	push   %ebx
80104e76:	81 ec a4 00 00 00    	sub    $0xa4,%esp
80104e7c:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
80104e82:	50                   	push   %eax
80104e83:	6a 00                	push   $0x0
80104e85:	e8 0a f6 ff ff       	call   80104494 <argstr>
80104e8a:	83 c4 10             	add    $0x10,%esp
80104e8d:	85 c0                	test   %eax,%eax
80104e8f:	78 79                	js     80104f0a <sys_exec+0x9a>
80104e91:	83 ec 08             	sub    $0x8,%esp
80104e94:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
80104e9a:	50                   	push   %eax
80104e9b:	6a 01                	push   $0x1
80104e9d:	e8 46 f5 ff ff       	call   801043e8 <argint>
80104ea2:	83 c4 10             	add    $0x10,%esp
80104ea5:	85 c0                	test   %eax,%eax
80104ea7:	78 61                	js     80104f0a <sys_exec+0x9a>
80104ea9:	50                   	push   %eax
80104eaa:	68 80 00 00 00       	push   $0x80
80104eaf:	6a 00                	push   $0x0
80104eb1:	8d bd 68 ff ff ff    	lea    -0x98(%ebp),%edi
80104eb7:	57                   	push   %edi
80104eb8:	e8 0f f3 ff ff       	call   801041cc <memset>
80104ebd:	83 c4 10             	add    $0x10,%esp
80104ec0:	31 db                	xor    %ebx,%ebx
80104ec2:	31 f6                	xor    %esi,%esi
80104ec4:	83 ec 08             	sub    $0x8,%esp
80104ec7:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80104ecd:	50                   	push   %eax
80104ece:	8b 85 60 ff ff ff    	mov    -0xa0(%ebp),%eax
80104ed4:	01 d8                	add    %ebx,%eax
80104ed6:	50                   	push   %eax
80104ed7:	e8 9c f4 ff ff       	call   80104378 <fetchint>
80104edc:	83 c4 10             	add    $0x10,%esp
80104edf:	85 c0                	test   %eax,%eax
80104ee1:	78 27                	js     80104f0a <sys_exec+0x9a>
80104ee3:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
80104ee9:	85 c0                	test   %eax,%eax
80104eeb:	74 2b                	je     80104f18 <sys_exec+0xa8>
80104eed:	83 ec 08             	sub    $0x8,%esp
80104ef0:	8d 14 1f             	lea    (%edi,%ebx,1),%edx
80104ef3:	52                   	push   %edx
80104ef4:	50                   	push   %eax
80104ef5:	e8 ae f4 ff ff       	call   801043a8 <fetchstr>
80104efa:	83 c4 10             	add    $0x10,%esp
80104efd:	85 c0                	test   %eax,%eax
80104eff:	78 09                	js     80104f0a <sys_exec+0x9a>
80104f01:	46                   	inc    %esi
80104f02:	83 c3 04             	add    $0x4,%ebx
80104f05:	83 fe 20             	cmp    $0x20,%esi
80104f08:	75 ba                	jne    80104ec4 <sys_exec+0x54>
80104f0a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104f0f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104f12:	5b                   	pop    %ebx
80104f13:	5e                   	pop    %esi
80104f14:	5f                   	pop    %edi
80104f15:	5d                   	pop    %ebp
80104f16:	c3                   	ret    
80104f17:	90                   	nop
80104f18:	c7 84 b5 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%esi,4)
80104f1f:	00 00 00 00 
80104f23:	83 ec 08             	sub    $0x8,%esp
80104f26:	57                   	push   %edi
80104f27:	ff b5 5c ff ff ff    	pushl  -0xa4(%ebp)
80104f2d:	e8 ee ba ff ff       	call   80100a20 <exec>
80104f32:	83 c4 10             	add    $0x10,%esp
80104f35:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104f38:	5b                   	pop    %ebx
80104f39:	5e                   	pop    %esi
80104f3a:	5f                   	pop    %edi
80104f3b:	5d                   	pop    %ebp
80104f3c:	c3                   	ret    
80104f3d:	8d 76 00             	lea    0x0(%esi),%esi

80104f40 <sys_pipe>:
80104f40:	55                   	push   %ebp
80104f41:	89 e5                	mov    %esp,%ebp
80104f43:	57                   	push   %edi
80104f44:	56                   	push   %esi
80104f45:	53                   	push   %ebx
80104f46:	83 ec 20             	sub    $0x20,%esp
80104f49:	6a 08                	push   $0x8
80104f4b:	8d 45 dc             	lea    -0x24(%ebp),%eax
80104f4e:	50                   	push   %eax
80104f4f:	6a 00                	push   $0x0
80104f51:	e8 d6 f4 ff ff       	call   8010442c <argptr>
80104f56:	83 c4 10             	add    $0x10,%esp
80104f59:	85 c0                	test   %eax,%eax
80104f5b:	78 7d                	js     80104fda <sys_pipe+0x9a>
80104f5d:	83 ec 08             	sub    $0x8,%esp
80104f60:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104f63:	50                   	push   %eax
80104f64:	8d 45 e0             	lea    -0x20(%ebp),%eax
80104f67:	50                   	push   %eax
80104f68:	e8 77 e0 ff ff       	call   80102fe4 <pipealloc>
80104f6d:	83 c4 10             	add    $0x10,%esp
80104f70:	85 c0                	test   %eax,%eax
80104f72:	78 66                	js     80104fda <sys_pipe+0x9a>
80104f74:	8b 7d e0             	mov    -0x20(%ebp),%edi
80104f77:	e8 98 e5 ff ff       	call   80103514 <myproc>
80104f7c:	31 db                	xor    %ebx,%ebx
80104f7e:	8b 74 98 2c          	mov    0x2c(%eax,%ebx,4),%esi
80104f82:	85 f6                	test   %esi,%esi
80104f84:	74 10                	je     80104f96 <sys_pipe+0x56>
80104f86:	66 90                	xchg   %ax,%ax
80104f88:	43                   	inc    %ebx
80104f89:	83 fb 10             	cmp    $0x10,%ebx
80104f8c:	74 35                	je     80104fc3 <sys_pipe+0x83>
80104f8e:	8b 74 98 2c          	mov    0x2c(%eax,%ebx,4),%esi
80104f92:	85 f6                	test   %esi,%esi
80104f94:	75 f2                	jne    80104f88 <sys_pipe+0x48>
80104f96:	8d 73 08             	lea    0x8(%ebx),%esi
80104f99:	89 7c b0 0c          	mov    %edi,0xc(%eax,%esi,4)
80104f9d:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80104fa0:	e8 6f e5 ff ff       	call   80103514 <myproc>
80104fa5:	31 d2                	xor    %edx,%edx
80104fa7:	90                   	nop
80104fa8:	8b 4c 90 2c          	mov    0x2c(%eax,%edx,4),%ecx
80104fac:	85 c9                	test   %ecx,%ecx
80104fae:	74 34                	je     80104fe4 <sys_pipe+0xa4>
80104fb0:	42                   	inc    %edx
80104fb1:	83 fa 10             	cmp    $0x10,%edx
80104fb4:	75 f2                	jne    80104fa8 <sys_pipe+0x68>
80104fb6:	e8 59 e5 ff ff       	call   80103514 <myproc>
80104fbb:	c7 44 b0 0c 00 00 00 	movl   $0x0,0xc(%eax,%esi,4)
80104fc2:	00 
80104fc3:	83 ec 0c             	sub    $0xc,%esp
80104fc6:	ff 75 e0             	pushl  -0x20(%ebp)
80104fc9:	e8 76 be ff ff       	call   80100e44 <fileclose>
80104fce:	58                   	pop    %eax
80104fcf:	ff 75 e4             	pushl  -0x1c(%ebp)
80104fd2:	e8 6d be ff ff       	call   80100e44 <fileclose>
80104fd7:	83 c4 10             	add    $0x10,%esp
80104fda:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104fdf:	eb 14                	jmp    80104ff5 <sys_pipe+0xb5>
80104fe1:	8d 76 00             	lea    0x0(%esi),%esi
80104fe4:	89 7c 90 2c          	mov    %edi,0x2c(%eax,%edx,4)
80104fe8:	8b 45 dc             	mov    -0x24(%ebp),%eax
80104feb:	89 18                	mov    %ebx,(%eax)
80104fed:	8b 45 dc             	mov    -0x24(%ebp),%eax
80104ff0:	89 50 04             	mov    %edx,0x4(%eax)
80104ff3:	31 c0                	xor    %eax,%eax
80104ff5:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104ff8:	5b                   	pop    %ebx
80104ff9:	5e                   	pop    %esi
80104ffa:	5f                   	pop    %edi
80104ffb:	5d                   	pop    %ebp
80104ffc:	c3                   	ret    
80104ffd:	66 90                	xchg   %ax,%ax
80104fff:	90                   	nop

80105000 <sys_protect>:
80105000:	55                   	push   %ebp
80105001:	89 e5                	mov    %esp,%ebp
80105003:	56                   	push   %esi
80105004:	53                   	push   %ebx
80105005:	83 ec 10             	sub    $0x10,%esp
80105008:	89 c6                	mov    %eax,%esi
8010500a:	e8 05 e5 ff ff       	call   80103514 <myproc>
8010500f:	89 c3                	mov    %eax,%ebx
80105011:	83 ec 08             	sub    $0x8,%esp
80105014:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105017:	50                   	push   %eax
80105018:	6a 00                	push   $0x0
8010501a:	e8 c9 f3 ff ff       	call   801043e8 <argint>
8010501f:	83 c4 10             	add    $0x10,%esp
80105022:	85 c0                	test   %eax,%eax
80105024:	78 46                	js     8010506c <sys_protect+0x6c>
80105026:	83 ec 08             	sub    $0x8,%esp
80105029:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010502c:	50                   	push   %eax
8010502d:	6a 01                	push   $0x1
8010502f:	e8 b4 f3 ff ff       	call   801043e8 <argint>
80105034:	83 c4 10             	add    $0x10,%esp
80105037:	85 c0                	test   %eax,%eax
80105039:	78 31                	js     8010506c <sys_protect+0x6c>
8010503b:	83 ec 0c             	sub    $0xc,%esp
8010503e:	56                   	push   %esi
8010503f:	ff 33                	pushl  (%ebx)
80105041:	ff 75 f4             	pushl  -0xc(%ebp)
80105044:	ff 75 f0             	pushl  -0x10(%ebp)
80105047:	ff 73 04             	pushl  0x4(%ebx)
8010504a:	e8 d1 12 00 00       	call   80106320 <protectuvm>
8010504f:	83 c4 20             	add    $0x20,%esp
80105052:	85 c0                	test   %eax,%eax
80105054:	78 16                	js     8010506c <sys_protect+0x6c>
80105056:	8b 43 04             	mov    0x4(%ebx),%eax
80105059:	05 00 00 00 80       	add    $0x80000000,%eax
8010505e:	0f 22 d8             	mov    %eax,%cr3
80105061:	31 c0                	xor    %eax,%eax
80105063:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105066:	5b                   	pop    %ebx
80105067:	5e                   	pop    %esi
80105068:	5d                   	pop    %ebp
80105069:	c3                   	ret    
8010506a:	66 90                	xchg   %ax,%ax
8010506c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105071:	eb f0                	jmp    80105063 <sys_protect+0x63>
80105073:	90                   	nop

80105074 <sys_fork>:
80105074:	e9 13 e6 ff ff       	jmp    8010368c <fork>
80105079:	8d 76 00             	lea    0x0(%esi),%esi

8010507c <sys_exit>:
8010507c:	55                   	push   %ebp
8010507d:	89 e5                	mov    %esp,%ebp
8010507f:	83 ec 08             	sub    $0x8,%esp
80105082:	e8 09 e9 ff ff       	call   80103990 <exit>
80105087:	31 c0                	xor    %eax,%eax
80105089:	c9                   	leave  
8010508a:	c3                   	ret    
8010508b:	90                   	nop

8010508c <sys_wait>:
8010508c:	e9 0f ea ff ff       	jmp    80103aa0 <wait>
80105091:	8d 76 00             	lea    0x0(%esi),%esi

80105094 <sys_kill>:
80105094:	55                   	push   %ebp
80105095:	89 e5                	mov    %esp,%ebp
80105097:	83 ec 20             	sub    $0x20,%esp
8010509a:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010509d:	50                   	push   %eax
8010509e:	6a 00                	push   $0x0
801050a0:	e8 43 f3 ff ff       	call   801043e8 <argint>
801050a5:	83 c4 10             	add    $0x10,%esp
801050a8:	85 c0                	test   %eax,%eax
801050aa:	78 10                	js     801050bc <sys_kill+0x28>
801050ac:	83 ec 0c             	sub    $0xc,%esp
801050af:	ff 75 f4             	pushl  -0xc(%ebp)
801050b2:	e8 65 ec ff ff       	call   80103d1c <kill>
801050b7:	83 c4 10             	add    $0x10,%esp
801050ba:	c9                   	leave  
801050bb:	c3                   	ret    
801050bc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801050c1:	c9                   	leave  
801050c2:	c3                   	ret    
801050c3:	90                   	nop

801050c4 <sys_getpid>:
801050c4:	55                   	push   %ebp
801050c5:	89 e5                	mov    %esp,%ebp
801050c7:	83 ec 08             	sub    $0x8,%esp
801050ca:	e8 45 e4 ff ff       	call   80103514 <myproc>
801050cf:	8b 40 10             	mov    0x10(%eax),%eax
801050d2:	c9                   	leave  
801050d3:	c3                   	ret    

801050d4 <sys_sbrk>:
801050d4:	55                   	push   %ebp
801050d5:	89 e5                	mov    %esp,%ebp
801050d7:	53                   	push   %ebx
801050d8:	83 ec 1c             	sub    $0x1c,%esp
801050db:	8d 45 f4             	lea    -0xc(%ebp),%eax
801050de:	50                   	push   %eax
801050df:	6a 00                	push   $0x0
801050e1:	e8 02 f3 ff ff       	call   801043e8 <argint>
801050e6:	83 c4 10             	add    $0x10,%esp
801050e9:	85 c0                	test   %eax,%eax
801050eb:	78 23                	js     80105110 <sys_sbrk+0x3c>
801050ed:	e8 22 e4 ff ff       	call   80103514 <myproc>
801050f2:	8b 18                	mov    (%eax),%ebx
801050f4:	83 ec 0c             	sub    $0xc,%esp
801050f7:	ff 75 f4             	pushl  -0xc(%ebp)
801050fa:	e8 1d e5 ff ff       	call   8010361c <growproc>
801050ff:	83 c4 10             	add    $0x10,%esp
80105102:	85 c0                	test   %eax,%eax
80105104:	78 0a                	js     80105110 <sys_sbrk+0x3c>
80105106:	89 d8                	mov    %ebx,%eax
80105108:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010510b:	c9                   	leave  
8010510c:	c3                   	ret    
8010510d:	8d 76 00             	lea    0x0(%esi),%esi
80105110:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80105115:	eb ef                	jmp    80105106 <sys_sbrk+0x32>
80105117:	90                   	nop

80105118 <sys_sleep>:
80105118:	55                   	push   %ebp
80105119:	89 e5                	mov    %esp,%ebp
8010511b:	53                   	push   %ebx
8010511c:	83 ec 1c             	sub    $0x1c,%esp
8010511f:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105122:	50                   	push   %eax
80105123:	6a 00                	push   $0x0
80105125:	e8 be f2 ff ff       	call   801043e8 <argint>
8010512a:	83 c4 10             	add    $0x10,%esp
8010512d:	85 c0                	test   %eax,%eax
8010512f:	78 5c                	js     8010518d <sys_sleep+0x75>
80105131:	83 ec 0c             	sub    $0xc,%esp
80105134:	68 80 3d 11 80       	push   $0x80113d80
80105139:	e8 ce ef ff ff       	call   8010410c <acquire>
8010513e:	8b 1d 60 3d 11 80    	mov    0x80113d60,%ebx
80105144:	83 c4 10             	add    $0x10,%esp
80105147:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010514a:	85 d2                	test   %edx,%edx
8010514c:	75 23                	jne    80105171 <sys_sleep+0x59>
8010514e:	eb 48                	jmp    80105198 <sys_sleep+0x80>
80105150:	83 ec 08             	sub    $0x8,%esp
80105153:	68 80 3d 11 80       	push   $0x80113d80
80105158:	68 60 3d 11 80       	push   $0x80113d60
8010515d:	e8 a6 ea ff ff       	call   80103c08 <sleep>
80105162:	a1 60 3d 11 80       	mov    0x80113d60,%eax
80105167:	29 d8                	sub    %ebx,%eax
80105169:	83 c4 10             	add    $0x10,%esp
8010516c:	3b 45 f4             	cmp    -0xc(%ebp),%eax
8010516f:	73 27                	jae    80105198 <sys_sleep+0x80>
80105171:	e8 9e e3 ff ff       	call   80103514 <myproc>
80105176:	8b 40 28             	mov    0x28(%eax),%eax
80105179:	85 c0                	test   %eax,%eax
8010517b:	74 d3                	je     80105150 <sys_sleep+0x38>
8010517d:	83 ec 0c             	sub    $0xc,%esp
80105180:	68 80 3d 11 80       	push   $0x80113d80
80105185:	e8 22 ef ff ff       	call   801040ac <release>
8010518a:	83 c4 10             	add    $0x10,%esp
8010518d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105192:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105195:	c9                   	leave  
80105196:	c3                   	ret    
80105197:	90                   	nop
80105198:	83 ec 0c             	sub    $0xc,%esp
8010519b:	68 80 3d 11 80       	push   $0x80113d80
801051a0:	e8 07 ef ff ff       	call   801040ac <release>
801051a5:	83 c4 10             	add    $0x10,%esp
801051a8:	31 c0                	xor    %eax,%eax
801051aa:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801051ad:	c9                   	leave  
801051ae:	c3                   	ret    
801051af:	90                   	nop

801051b0 <sys_uptime>:
801051b0:	55                   	push   %ebp
801051b1:	89 e5                	mov    %esp,%ebp
801051b3:	53                   	push   %ebx
801051b4:	83 ec 10             	sub    $0x10,%esp
801051b7:	68 80 3d 11 80       	push   $0x80113d80
801051bc:	e8 4b ef ff ff       	call   8010410c <acquire>
801051c1:	8b 1d 60 3d 11 80    	mov    0x80113d60,%ebx
801051c7:	c7 04 24 80 3d 11 80 	movl   $0x80113d80,(%esp)
801051ce:	e8 d9 ee ff ff       	call   801040ac <release>
801051d3:	89 d8                	mov    %ebx,%eax
801051d5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801051d8:	c9                   	leave  
801051d9:	c3                   	ret    
801051da:	66 90                	xchg   %ax,%ax

801051dc <sys_mprotect>:
801051dc:	31 c0                	xor    %eax,%eax
801051de:	e9 1d fe ff ff       	jmp    80105000 <sys_protect>
801051e3:	90                   	nop

801051e4 <sys_munprotect>:
801051e4:	b8 01 00 00 00       	mov    $0x1,%eax
801051e9:	e9 12 fe ff ff       	jmp    80105000 <sys_protect>
801051ee:	66 90                	xchg   %ax,%ax

801051f0 <sys_set_priority>:
801051f0:	55                   	push   %ebp
801051f1:	89 e5                	mov    %esp,%ebp
801051f3:	83 ec 20             	sub    $0x20,%esp
801051f6:	8d 45 f0             	lea    -0x10(%ebp),%eax
801051f9:	50                   	push   %eax
801051fa:	6a 00                	push   $0x0
801051fc:	e8 e7 f1 ff ff       	call   801043e8 <argint>
80105201:	83 c4 10             	add    $0x10,%esp
80105204:	85 c0                	test   %eax,%eax
80105206:	78 28                	js     80105230 <sys_set_priority+0x40>
80105208:	83 ec 08             	sub    $0x8,%esp
8010520b:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010520e:	50                   	push   %eax
8010520f:	6a 01                	push   $0x1
80105211:	e8 d2 f1 ff ff       	call   801043e8 <argint>
80105216:	83 c4 10             	add    $0x10,%esp
80105219:	85 c0                	test   %eax,%eax
8010521b:	78 13                	js     80105230 <sys_set_priority+0x40>
8010521d:	83 ec 08             	sub    $0x8,%esp
80105220:	ff 75 f4             	pushl  -0xc(%ebp)
80105223:	ff 75 f0             	pushl  -0x10(%ebp)
80105226:	e8 3d e6 ff ff       	call   80103868 <setpriority>
8010522b:	83 c4 10             	add    $0x10,%esp
8010522e:	c9                   	leave  
8010522f:	c3                   	ret    
80105230:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105235:	c9                   	leave  
80105236:	c3                   	ret    

80105237 <alltraps>:
80105237:	1e                   	push   %ds
80105238:	06                   	push   %es
80105239:	0f a0                	push   %fs
8010523b:	0f a8                	push   %gs
8010523d:	60                   	pusha  
8010523e:	66 b8 10 00          	mov    $0x10,%ax
80105242:	8e d8                	mov    %eax,%ds
80105244:	8e c0                	mov    %eax,%es
80105246:	54                   	push   %esp
80105247:	e8 a0 00 00 00       	call   801052ec <trap>
8010524c:	83 c4 04             	add    $0x4,%esp

8010524f <trapret>:
8010524f:	61                   	popa   
80105250:	0f a9                	pop    %gs
80105252:	0f a1                	pop    %fs
80105254:	07                   	pop    %es
80105255:	1f                   	pop    %ds
80105256:	83 c4 08             	add    $0x8,%esp
80105259:	cf                   	iret   
8010525a:	66 90                	xchg   %ax,%ax

8010525c <tvinit>:
8010525c:	55                   	push   %ebp
8010525d:	89 e5                	mov    %esp,%ebp
8010525f:	83 ec 08             	sub    $0x8,%esp
80105262:	31 c0                	xor    %eax,%eax
80105264:	8b 14 85 08 a0 10 80 	mov    -0x7fef5ff8(,%eax,4),%edx
8010526b:	66 89 14 c5 c0 3d 11 	mov    %dx,-0x7feec240(,%eax,8)
80105272:	80 
80105273:	c7 04 c5 c2 3d 11 80 	movl   $0x8e000008,-0x7feec23e(,%eax,8)
8010527a:	08 00 00 8e 
8010527e:	c1 ea 10             	shr    $0x10,%edx
80105281:	66 89 14 c5 c6 3d 11 	mov    %dx,-0x7feec23a(,%eax,8)
80105288:	80 
80105289:	40                   	inc    %eax
8010528a:	3d 00 01 00 00       	cmp    $0x100,%eax
8010528f:	75 d3                	jne    80105264 <tvinit+0x8>
80105291:	a1 08 a1 10 80       	mov    0x8010a108,%eax
80105296:	66 a3 c0 3f 11 80    	mov    %ax,0x80113fc0
8010529c:	c7 05 c2 3f 11 80 08 	movl   $0xef000008,0x80113fc2
801052a3:	00 00 ef 
801052a6:	c1 e8 10             	shr    $0x10,%eax
801052a9:	66 a3 c6 3f 11 80    	mov    %ax,0x80113fc6
801052af:	83 ec 08             	sub    $0x8,%esp
801052b2:	68 85 72 10 80       	push   $0x80107285
801052b7:	68 80 3d 11 80       	push   $0x80113d80
801052bc:	e8 8b ec ff ff       	call   80103f4c <initlock>
801052c1:	83 c4 10             	add    $0x10,%esp
801052c4:	c9                   	leave  
801052c5:	c3                   	ret    
801052c6:	66 90                	xchg   %ax,%ax

801052c8 <idtinit>:
801052c8:	55                   	push   %ebp
801052c9:	89 e5                	mov    %esp,%ebp
801052cb:	83 ec 10             	sub    $0x10,%esp
801052ce:	66 c7 45 fa ff 07    	movw   $0x7ff,-0x6(%ebp)
801052d4:	b8 c0 3d 11 80       	mov    $0x80113dc0,%eax
801052d9:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
801052dd:	c1 e8 10             	shr    $0x10,%eax
801052e0:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
801052e4:	8d 45 fa             	lea    -0x6(%ebp),%eax
801052e7:	0f 01 18             	lidtl  (%eax)
801052ea:	c9                   	leave  
801052eb:	c3                   	ret    

801052ec <trap>:
801052ec:	55                   	push   %ebp
801052ed:	89 e5                	mov    %esp,%ebp
801052ef:	57                   	push   %edi
801052f0:	56                   	push   %esi
801052f1:	53                   	push   %ebx
801052f2:	83 ec 1c             	sub    $0x1c,%esp
801052f5:	8b 5d 08             	mov    0x8(%ebp),%ebx
801052f8:	8b 43 30             	mov    0x30(%ebx),%eax
801052fb:	83 f8 40             	cmp    $0x40,%eax
801052fe:	0f 84 4c 01 00 00    	je     80105450 <trap+0x164>
80105304:	83 e8 20             	sub    $0x20,%eax
80105307:	83 f8 1f             	cmp    $0x1f,%eax
8010530a:	77 7c                	ja     80105388 <trap+0x9c>
8010530c:	ff 24 85 2c 73 10 80 	jmp    *-0x7fef8cd4(,%eax,4)
80105313:	90                   	nop
80105314:	e8 db cc ff ff       	call   80101ff4 <ideintr>
80105319:	e8 e2 d2 ff ff       	call   80102600 <lapiceoi>
8010531e:	e8 f1 e1 ff ff       	call   80103514 <myproc>
80105323:	85 c0                	test   %eax,%eax
80105325:	74 1c                	je     80105343 <trap+0x57>
80105327:	e8 e8 e1 ff ff       	call   80103514 <myproc>
8010532c:	8b 50 28             	mov    0x28(%eax),%edx
8010532f:	85 d2                	test   %edx,%edx
80105331:	74 10                	je     80105343 <trap+0x57>
80105333:	8b 43 3c             	mov    0x3c(%ebx),%eax
80105336:	83 e0 03             	and    $0x3,%eax
80105339:	66 83 f8 03          	cmp    $0x3,%ax
8010533d:	0f 84 c1 01 00 00    	je     80105504 <trap+0x218>
80105343:	e8 cc e1 ff ff       	call   80103514 <myproc>
80105348:	85 c0                	test   %eax,%eax
8010534a:	74 0f                	je     8010535b <trap+0x6f>
8010534c:	e8 c3 e1 ff ff       	call   80103514 <myproc>
80105351:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
80105355:	0f 84 ad 00 00 00    	je     80105408 <trap+0x11c>
8010535b:	e8 b4 e1 ff ff       	call   80103514 <myproc>
80105360:	85 c0                	test   %eax,%eax
80105362:	74 1c                	je     80105380 <trap+0x94>
80105364:	e8 ab e1 ff ff       	call   80103514 <myproc>
80105369:	8b 40 28             	mov    0x28(%eax),%eax
8010536c:	85 c0                	test   %eax,%eax
8010536e:	74 10                	je     80105380 <trap+0x94>
80105370:	8b 43 3c             	mov    0x3c(%ebx),%eax
80105373:	83 e0 03             	and    $0x3,%eax
80105376:	66 83 f8 03          	cmp    $0x3,%ax
8010537a:	0f 84 fd 00 00 00    	je     8010547d <trap+0x191>
80105380:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105383:	5b                   	pop    %ebx
80105384:	5e                   	pop    %esi
80105385:	5f                   	pop    %edi
80105386:	5d                   	pop    %ebp
80105387:	c3                   	ret    
80105388:	e8 87 e1 ff ff       	call   80103514 <myproc>
8010538d:	8b 7b 38             	mov    0x38(%ebx),%edi
80105390:	85 c0                	test   %eax,%eax
80105392:	0f 84 82 01 00 00    	je     8010551a <trap+0x22e>
80105398:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
8010539c:	0f 84 78 01 00 00    	je     8010551a <trap+0x22e>
801053a2:	0f 20 d1             	mov    %cr2,%ecx
801053a5:	89 4d d8             	mov    %ecx,-0x28(%ebp)
801053a8:	e8 33 e1 ff ff       	call   801034e0 <cpuid>
801053ad:	89 45 dc             	mov    %eax,-0x24(%ebp)
801053b0:	8b 43 34             	mov    0x34(%ebx),%eax
801053b3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801053b6:	8b 73 30             	mov    0x30(%ebx),%esi
801053b9:	e8 56 e1 ff ff       	call   80103514 <myproc>
801053be:	89 45 e0             	mov    %eax,-0x20(%ebp)
801053c1:	e8 4e e1 ff ff       	call   80103514 <myproc>
801053c6:	8b 4d d8             	mov    -0x28(%ebp),%ecx
801053c9:	51                   	push   %ecx
801053ca:	57                   	push   %edi
801053cb:	8b 55 dc             	mov    -0x24(%ebp),%edx
801053ce:	52                   	push   %edx
801053cf:	ff 75 e4             	pushl  -0x1c(%ebp)
801053d2:	56                   	push   %esi
801053d3:	8b 75 e0             	mov    -0x20(%ebp),%esi
801053d6:	83 c6 70             	add    $0x70,%esi
801053d9:	56                   	push   %esi
801053da:	ff 70 10             	pushl  0x10(%eax)
801053dd:	68 e8 72 10 80       	push   $0x801072e8
801053e2:	e8 41 b2 ff ff       	call   80100628 <cprintf>
801053e7:	83 c4 20             	add    $0x20,%esp
801053ea:	e8 25 e1 ff ff       	call   80103514 <myproc>
801053ef:	c7 40 28 01 00 00 00 	movl   $0x1,0x28(%eax)
801053f6:	e8 19 e1 ff ff       	call   80103514 <myproc>
801053fb:	85 c0                	test   %eax,%eax
801053fd:	0f 85 24 ff ff ff    	jne    80105327 <trap+0x3b>
80105403:	e9 3b ff ff ff       	jmp    80105343 <trap+0x57>
80105408:	83 7b 30 20          	cmpl   $0x20,0x30(%ebx)
8010540c:	0f 85 49 ff ff ff    	jne    8010535b <trap+0x6f>
80105412:	e8 a9 e7 ff ff       	call   80103bc0 <yield>
80105417:	e9 3f ff ff ff       	jmp    8010535b <trap+0x6f>
8010541c:	8b 7b 38             	mov    0x38(%ebx),%edi
8010541f:	0f b7 73 3c          	movzwl 0x3c(%ebx),%esi
80105423:	e8 b8 e0 ff ff       	call   801034e0 <cpuid>
80105428:	57                   	push   %edi
80105429:	56                   	push   %esi
8010542a:	50                   	push   %eax
8010542b:	68 90 72 10 80       	push   $0x80107290
80105430:	e8 f3 b1 ff ff       	call   80100628 <cprintf>
80105435:	e8 c6 d1 ff ff       	call   80102600 <lapiceoi>
8010543a:	83 c4 10             	add    $0x10,%esp
8010543d:	e8 d2 e0 ff ff       	call   80103514 <myproc>
80105442:	85 c0                	test   %eax,%eax
80105444:	0f 85 dd fe ff ff    	jne    80105327 <trap+0x3b>
8010544a:	e9 f4 fe ff ff       	jmp    80105343 <trap+0x57>
8010544f:	90                   	nop
80105450:	e8 bf e0 ff ff       	call   80103514 <myproc>
80105455:	8b 70 28             	mov    0x28(%eax),%esi
80105458:	85 f6                	test   %esi,%esi
8010545a:	0f 85 b0 00 00 00    	jne    80105510 <trap+0x224>
80105460:	e8 af e0 ff ff       	call   80103514 <myproc>
80105465:	89 58 1c             	mov    %ebx,0x1c(%eax)
80105468:	e8 8b f0 ff ff       	call   801044f8 <syscall>
8010546d:	e8 a2 e0 ff ff       	call   80103514 <myproc>
80105472:	8b 48 28             	mov    0x28(%eax),%ecx
80105475:	85 c9                	test   %ecx,%ecx
80105477:	0f 84 03 ff ff ff    	je     80105380 <trap+0x94>
8010547d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105480:	5b                   	pop    %ebx
80105481:	5e                   	pop    %esi
80105482:	5f                   	pop    %edi
80105483:	5d                   	pop    %ebp
80105484:	e9 07 e5 ff ff       	jmp    80103990 <exit>
80105489:	8d 76 00             	lea    0x0(%esi),%esi
8010548c:	e8 f3 01 00 00       	call   80105684 <uartintr>
80105491:	e8 6a d1 ff ff       	call   80102600 <lapiceoi>
80105496:	e8 79 e0 ff ff       	call   80103514 <myproc>
8010549b:	85 c0                	test   %eax,%eax
8010549d:	0f 85 84 fe ff ff    	jne    80105327 <trap+0x3b>
801054a3:	e9 9b fe ff ff       	jmp    80105343 <trap+0x57>
801054a8:	e8 43 d0 ff ff       	call   801024f0 <kbdintr>
801054ad:	e8 4e d1 ff ff       	call   80102600 <lapiceoi>
801054b2:	e8 5d e0 ff ff       	call   80103514 <myproc>
801054b7:	85 c0                	test   %eax,%eax
801054b9:	0f 85 68 fe ff ff    	jne    80105327 <trap+0x3b>
801054bf:	e9 7f fe ff ff       	jmp    80105343 <trap+0x57>
801054c4:	e8 17 e0 ff ff       	call   801034e0 <cpuid>
801054c9:	85 c0                	test   %eax,%eax
801054cb:	0f 85 48 fe ff ff    	jne    80105319 <trap+0x2d>
801054d1:	83 ec 0c             	sub    $0xc,%esp
801054d4:	68 80 3d 11 80       	push   $0x80113d80
801054d9:	e8 2e ec ff ff       	call   8010410c <acquire>
801054de:	ff 05 60 3d 11 80    	incl   0x80113d60
801054e4:	c7 04 24 60 3d 11 80 	movl   $0x80113d60,(%esp)
801054eb:	e8 d4 e7 ff ff       	call   80103cc4 <wakeup>
801054f0:	c7 04 24 80 3d 11 80 	movl   $0x80113d80,(%esp)
801054f7:	e8 b0 eb ff ff       	call   801040ac <release>
801054fc:	83 c4 10             	add    $0x10,%esp
801054ff:	e9 15 fe ff ff       	jmp    80105319 <trap+0x2d>
80105504:	e8 87 e4 ff ff       	call   80103990 <exit>
80105509:	e9 35 fe ff ff       	jmp    80105343 <trap+0x57>
8010550e:	66 90                	xchg   %ax,%ax
80105510:	e8 7b e4 ff ff       	call   80103990 <exit>
80105515:	e9 46 ff ff ff       	jmp    80105460 <trap+0x174>
8010551a:	0f 20 d6             	mov    %cr2,%esi
8010551d:	e8 be df ff ff       	call   801034e0 <cpuid>
80105522:	83 ec 0c             	sub    $0xc,%esp
80105525:	56                   	push   %esi
80105526:	57                   	push   %edi
80105527:	50                   	push   %eax
80105528:	ff 73 30             	pushl  0x30(%ebx)
8010552b:	68 b4 72 10 80       	push   $0x801072b4
80105530:	e8 f3 b0 ff ff       	call   80100628 <cprintf>
80105535:	83 c4 14             	add    $0x14,%esp
80105538:	68 8a 72 10 80       	push   $0x8010728a
8010553d:	e8 f6 ad ff ff       	call   80100338 <panic>
80105542:	66 90                	xchg   %ax,%ax

80105544 <uartgetc>:
80105544:	a1 c0 45 11 80       	mov    0x801145c0,%eax
80105549:	85 c0                	test   %eax,%eax
8010554b:	74 17                	je     80105564 <uartgetc+0x20>
8010554d:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105552:	ec                   	in     (%dx),%al
80105553:	a8 01                	test   $0x1,%al
80105555:	74 0d                	je     80105564 <uartgetc+0x20>
80105557:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010555c:	ec                   	in     (%dx),%al
8010555d:	0f b6 c0             	movzbl %al,%eax
80105560:	c3                   	ret    
80105561:	8d 76 00             	lea    0x0(%esi),%esi
80105564:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105569:	c3                   	ret    
8010556a:	66 90                	xchg   %ax,%ax

8010556c <uartinit>:
8010556c:	55                   	push   %ebp
8010556d:	89 e5                	mov    %esp,%ebp
8010556f:	57                   	push   %edi
80105570:	56                   	push   %esi
80105571:	53                   	push   %ebx
80105572:	83 ec 1c             	sub    $0x1c,%esp
80105575:	bf fa 03 00 00       	mov    $0x3fa,%edi
8010557a:	31 c0                	xor    %eax,%eax
8010557c:	89 fa                	mov    %edi,%edx
8010557e:	ee                   	out    %al,(%dx)
8010557f:	bb fb 03 00 00       	mov    $0x3fb,%ebx
80105584:	b0 80                	mov    $0x80,%al
80105586:	89 da                	mov    %ebx,%edx
80105588:	ee                   	out    %al,(%dx)
80105589:	be f8 03 00 00       	mov    $0x3f8,%esi
8010558e:	b0 0c                	mov    $0xc,%al
80105590:	89 f2                	mov    %esi,%edx
80105592:	ee                   	out    %al,(%dx)
80105593:	b9 f9 03 00 00       	mov    $0x3f9,%ecx
80105598:	31 c0                	xor    %eax,%eax
8010559a:	89 ca                	mov    %ecx,%edx
8010559c:	ee                   	out    %al,(%dx)
8010559d:	b0 03                	mov    $0x3,%al
8010559f:	89 da                	mov    %ebx,%edx
801055a1:	ee                   	out    %al,(%dx)
801055a2:	ba fc 03 00 00       	mov    $0x3fc,%edx
801055a7:	31 c0                	xor    %eax,%eax
801055a9:	ee                   	out    %al,(%dx)
801055aa:	b0 01                	mov    $0x1,%al
801055ac:	89 ca                	mov    %ecx,%edx
801055ae:	ee                   	out    %al,(%dx)
801055af:	ba fd 03 00 00       	mov    $0x3fd,%edx
801055b4:	ec                   	in     (%dx),%al
801055b5:	fe c0                	inc    %al
801055b7:	74 71                	je     8010562a <uartinit+0xbe>
801055b9:	c7 05 c0 45 11 80 01 	movl   $0x1,0x801145c0
801055c0:	00 00 00 
801055c3:	89 fa                	mov    %edi,%edx
801055c5:	ec                   	in     (%dx),%al
801055c6:	89 f2                	mov    %esi,%edx
801055c8:	ec                   	in     (%dx),%al
801055c9:	83 ec 08             	sub    $0x8,%esp
801055cc:	6a 00                	push   $0x0
801055ce:	6a 04                	push   $0x4
801055d0:	e8 2f cc ff ff       	call   80102204 <ioapicenable>
801055d5:	83 c4 10             	add    $0x10,%esp
801055d8:	bf ac 73 10 80       	mov    $0x801073ac,%edi
801055dd:	c6 45 e7 78          	movb   $0x78,-0x19(%ebp)
801055e1:	be fd 03 00 00       	mov    $0x3fd,%esi
801055e6:	66 90                	xchg   %ax,%ax
801055e8:	a1 c0 45 11 80       	mov    0x801145c0,%eax
801055ed:	85 c0                	test   %eax,%eax
801055ef:	74 2f                	je     80105620 <uartinit+0xb4>
801055f1:	89 f2                	mov    %esi,%edx
801055f3:	ec                   	in     (%dx),%al
801055f4:	a8 20                	test   $0x20,%al
801055f6:	75 1f                	jne    80105617 <uartinit+0xab>
801055f8:	bb 80 00 00 00       	mov    $0x80,%ebx
801055fd:	8d 76 00             	lea    0x0(%esi),%esi
80105600:	83 ec 0c             	sub    $0xc,%esp
80105603:	6a 0a                	push   $0xa
80105605:	e8 0e d0 ff ff       	call   80102618 <microdelay>
8010560a:	83 c4 10             	add    $0x10,%esp
8010560d:	4b                   	dec    %ebx
8010560e:	74 07                	je     80105617 <uartinit+0xab>
80105610:	89 f2                	mov    %esi,%edx
80105612:	ec                   	in     (%dx),%al
80105613:	a8 20                	test   $0x20,%al
80105615:	74 e9                	je     80105600 <uartinit+0x94>
80105617:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010561c:	8a 45 e7             	mov    -0x19(%ebp),%al
8010561f:	ee                   	out    %al,(%dx)
80105620:	47                   	inc    %edi
80105621:	8a 07                	mov    (%edi),%al
80105623:	88 45 e7             	mov    %al,-0x19(%ebp)
80105626:	84 c0                	test   %al,%al
80105628:	75 be                	jne    801055e8 <uartinit+0x7c>
8010562a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010562d:	5b                   	pop    %ebx
8010562e:	5e                   	pop    %esi
8010562f:	5f                   	pop    %edi
80105630:	5d                   	pop    %ebp
80105631:	c3                   	ret    
80105632:	66 90                	xchg   %ax,%ax

80105634 <uartputc>:
80105634:	a1 c0 45 11 80       	mov    0x801145c0,%eax
80105639:	85 c0                	test   %eax,%eax
8010563b:	74 43                	je     80105680 <uartputc+0x4c>
8010563d:	55                   	push   %ebp
8010563e:	89 e5                	mov    %esp,%ebp
80105640:	56                   	push   %esi
80105641:	53                   	push   %ebx
80105642:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105647:	ec                   	in     (%dx),%al
80105648:	a8 20                	test   $0x20,%al
8010564a:	75 23                	jne    8010566f <uartputc+0x3b>
8010564c:	bb 80 00 00 00       	mov    $0x80,%ebx
80105651:	be fd 03 00 00       	mov    $0x3fd,%esi
80105656:	66 90                	xchg   %ax,%ax
80105658:	83 ec 0c             	sub    $0xc,%esp
8010565b:	6a 0a                	push   $0xa
8010565d:	e8 b6 cf ff ff       	call   80102618 <microdelay>
80105662:	83 c4 10             	add    $0x10,%esp
80105665:	4b                   	dec    %ebx
80105666:	74 07                	je     8010566f <uartputc+0x3b>
80105668:	89 f2                	mov    %esi,%edx
8010566a:	ec                   	in     (%dx),%al
8010566b:	a8 20                	test   $0x20,%al
8010566d:	74 e9                	je     80105658 <uartputc+0x24>
8010566f:	8b 45 08             	mov    0x8(%ebp),%eax
80105672:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105677:	ee                   	out    %al,(%dx)
80105678:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010567b:	5b                   	pop    %ebx
8010567c:	5e                   	pop    %esi
8010567d:	5d                   	pop    %ebp
8010567e:	c3                   	ret    
8010567f:	90                   	nop
80105680:	c3                   	ret    
80105681:	8d 76 00             	lea    0x0(%esi),%esi

80105684 <uartintr>:
80105684:	55                   	push   %ebp
80105685:	89 e5                	mov    %esp,%ebp
80105687:	83 ec 14             	sub    $0x14,%esp
8010568a:	68 44 55 10 80       	push   $0x80105544
8010568f:	e8 80 b1 ff ff       	call   80100814 <consoleintr>
80105694:	83 c4 10             	add    $0x10,%esp
80105697:	c9                   	leave  
80105698:	c3                   	ret    

80105699 <vector0>:
80105699:	6a 00                	push   $0x0
8010569b:	6a 00                	push   $0x0
8010569d:	e9 95 fb ff ff       	jmp    80105237 <alltraps>

801056a2 <vector1>:
801056a2:	6a 00                	push   $0x0
801056a4:	6a 01                	push   $0x1
801056a6:	e9 8c fb ff ff       	jmp    80105237 <alltraps>

801056ab <vector2>:
801056ab:	6a 00                	push   $0x0
801056ad:	6a 02                	push   $0x2
801056af:	e9 83 fb ff ff       	jmp    80105237 <alltraps>

801056b4 <vector3>:
801056b4:	6a 00                	push   $0x0
801056b6:	6a 03                	push   $0x3
801056b8:	e9 7a fb ff ff       	jmp    80105237 <alltraps>

801056bd <vector4>:
801056bd:	6a 00                	push   $0x0
801056bf:	6a 04                	push   $0x4
801056c1:	e9 71 fb ff ff       	jmp    80105237 <alltraps>

801056c6 <vector5>:
801056c6:	6a 00                	push   $0x0
801056c8:	6a 05                	push   $0x5
801056ca:	e9 68 fb ff ff       	jmp    80105237 <alltraps>

801056cf <vector6>:
801056cf:	6a 00                	push   $0x0
801056d1:	6a 06                	push   $0x6
801056d3:	e9 5f fb ff ff       	jmp    80105237 <alltraps>

801056d8 <vector7>:
801056d8:	6a 00                	push   $0x0
801056da:	6a 07                	push   $0x7
801056dc:	e9 56 fb ff ff       	jmp    80105237 <alltraps>

801056e1 <vector8>:
801056e1:	6a 08                	push   $0x8
801056e3:	e9 4f fb ff ff       	jmp    80105237 <alltraps>

801056e8 <vector9>:
801056e8:	6a 00                	push   $0x0
801056ea:	6a 09                	push   $0x9
801056ec:	e9 46 fb ff ff       	jmp    80105237 <alltraps>

801056f1 <vector10>:
801056f1:	6a 0a                	push   $0xa
801056f3:	e9 3f fb ff ff       	jmp    80105237 <alltraps>

801056f8 <vector11>:
801056f8:	6a 0b                	push   $0xb
801056fa:	e9 38 fb ff ff       	jmp    80105237 <alltraps>

801056ff <vector12>:
801056ff:	6a 0c                	push   $0xc
80105701:	e9 31 fb ff ff       	jmp    80105237 <alltraps>

80105706 <vector13>:
80105706:	6a 0d                	push   $0xd
80105708:	e9 2a fb ff ff       	jmp    80105237 <alltraps>

8010570d <vector14>:
8010570d:	6a 0e                	push   $0xe
8010570f:	e9 23 fb ff ff       	jmp    80105237 <alltraps>

80105714 <vector15>:
80105714:	6a 00                	push   $0x0
80105716:	6a 0f                	push   $0xf
80105718:	e9 1a fb ff ff       	jmp    80105237 <alltraps>

8010571d <vector16>:
8010571d:	6a 00                	push   $0x0
8010571f:	6a 10                	push   $0x10
80105721:	e9 11 fb ff ff       	jmp    80105237 <alltraps>

80105726 <vector17>:
80105726:	6a 11                	push   $0x11
80105728:	e9 0a fb ff ff       	jmp    80105237 <alltraps>

8010572d <vector18>:
8010572d:	6a 00                	push   $0x0
8010572f:	6a 12                	push   $0x12
80105731:	e9 01 fb ff ff       	jmp    80105237 <alltraps>

80105736 <vector19>:
80105736:	6a 00                	push   $0x0
80105738:	6a 13                	push   $0x13
8010573a:	e9 f8 fa ff ff       	jmp    80105237 <alltraps>

8010573f <vector20>:
8010573f:	6a 00                	push   $0x0
80105741:	6a 14                	push   $0x14
80105743:	e9 ef fa ff ff       	jmp    80105237 <alltraps>

80105748 <vector21>:
80105748:	6a 00                	push   $0x0
8010574a:	6a 15                	push   $0x15
8010574c:	e9 e6 fa ff ff       	jmp    80105237 <alltraps>

80105751 <vector22>:
80105751:	6a 00                	push   $0x0
80105753:	6a 16                	push   $0x16
80105755:	e9 dd fa ff ff       	jmp    80105237 <alltraps>

8010575a <vector23>:
8010575a:	6a 00                	push   $0x0
8010575c:	6a 17                	push   $0x17
8010575e:	e9 d4 fa ff ff       	jmp    80105237 <alltraps>

80105763 <vector24>:
80105763:	6a 00                	push   $0x0
80105765:	6a 18                	push   $0x18
80105767:	e9 cb fa ff ff       	jmp    80105237 <alltraps>

8010576c <vector25>:
8010576c:	6a 00                	push   $0x0
8010576e:	6a 19                	push   $0x19
80105770:	e9 c2 fa ff ff       	jmp    80105237 <alltraps>

80105775 <vector26>:
80105775:	6a 00                	push   $0x0
80105777:	6a 1a                	push   $0x1a
80105779:	e9 b9 fa ff ff       	jmp    80105237 <alltraps>

8010577e <vector27>:
8010577e:	6a 00                	push   $0x0
80105780:	6a 1b                	push   $0x1b
80105782:	e9 b0 fa ff ff       	jmp    80105237 <alltraps>

80105787 <vector28>:
80105787:	6a 00                	push   $0x0
80105789:	6a 1c                	push   $0x1c
8010578b:	e9 a7 fa ff ff       	jmp    80105237 <alltraps>

80105790 <vector29>:
80105790:	6a 00                	push   $0x0
80105792:	6a 1d                	push   $0x1d
80105794:	e9 9e fa ff ff       	jmp    80105237 <alltraps>

80105799 <vector30>:
80105799:	6a 00                	push   $0x0
8010579b:	6a 1e                	push   $0x1e
8010579d:	e9 95 fa ff ff       	jmp    80105237 <alltraps>

801057a2 <vector31>:
801057a2:	6a 00                	push   $0x0
801057a4:	6a 1f                	push   $0x1f
801057a6:	e9 8c fa ff ff       	jmp    80105237 <alltraps>

801057ab <vector32>:
801057ab:	6a 00                	push   $0x0
801057ad:	6a 20                	push   $0x20
801057af:	e9 83 fa ff ff       	jmp    80105237 <alltraps>

801057b4 <vector33>:
801057b4:	6a 00                	push   $0x0
801057b6:	6a 21                	push   $0x21
801057b8:	e9 7a fa ff ff       	jmp    80105237 <alltraps>

801057bd <vector34>:
801057bd:	6a 00                	push   $0x0
801057bf:	6a 22                	push   $0x22
801057c1:	e9 71 fa ff ff       	jmp    80105237 <alltraps>

801057c6 <vector35>:
801057c6:	6a 00                	push   $0x0
801057c8:	6a 23                	push   $0x23
801057ca:	e9 68 fa ff ff       	jmp    80105237 <alltraps>

801057cf <vector36>:
801057cf:	6a 00                	push   $0x0
801057d1:	6a 24                	push   $0x24
801057d3:	e9 5f fa ff ff       	jmp    80105237 <alltraps>

801057d8 <vector37>:
801057d8:	6a 00                	push   $0x0
801057da:	6a 25                	push   $0x25
801057dc:	e9 56 fa ff ff       	jmp    80105237 <alltraps>

801057e1 <vector38>:
801057e1:	6a 00                	push   $0x0
801057e3:	6a 26                	push   $0x26
801057e5:	e9 4d fa ff ff       	jmp    80105237 <alltraps>

801057ea <vector39>:
801057ea:	6a 00                	push   $0x0
801057ec:	6a 27                	push   $0x27
801057ee:	e9 44 fa ff ff       	jmp    80105237 <alltraps>

801057f3 <vector40>:
801057f3:	6a 00                	push   $0x0
801057f5:	6a 28                	push   $0x28
801057f7:	e9 3b fa ff ff       	jmp    80105237 <alltraps>

801057fc <vector41>:
801057fc:	6a 00                	push   $0x0
801057fe:	6a 29                	push   $0x29
80105800:	e9 32 fa ff ff       	jmp    80105237 <alltraps>

80105805 <vector42>:
80105805:	6a 00                	push   $0x0
80105807:	6a 2a                	push   $0x2a
80105809:	e9 29 fa ff ff       	jmp    80105237 <alltraps>

8010580e <vector43>:
8010580e:	6a 00                	push   $0x0
80105810:	6a 2b                	push   $0x2b
80105812:	e9 20 fa ff ff       	jmp    80105237 <alltraps>

80105817 <vector44>:
80105817:	6a 00                	push   $0x0
80105819:	6a 2c                	push   $0x2c
8010581b:	e9 17 fa ff ff       	jmp    80105237 <alltraps>

80105820 <vector45>:
80105820:	6a 00                	push   $0x0
80105822:	6a 2d                	push   $0x2d
80105824:	e9 0e fa ff ff       	jmp    80105237 <alltraps>

80105829 <vector46>:
80105829:	6a 00                	push   $0x0
8010582b:	6a 2e                	push   $0x2e
8010582d:	e9 05 fa ff ff       	jmp    80105237 <alltraps>

80105832 <vector47>:
80105832:	6a 00                	push   $0x0
80105834:	6a 2f                	push   $0x2f
80105836:	e9 fc f9 ff ff       	jmp    80105237 <alltraps>

8010583b <vector48>:
8010583b:	6a 00                	push   $0x0
8010583d:	6a 30                	push   $0x30
8010583f:	e9 f3 f9 ff ff       	jmp    80105237 <alltraps>

80105844 <vector49>:
80105844:	6a 00                	push   $0x0
80105846:	6a 31                	push   $0x31
80105848:	e9 ea f9 ff ff       	jmp    80105237 <alltraps>

8010584d <vector50>:
8010584d:	6a 00                	push   $0x0
8010584f:	6a 32                	push   $0x32
80105851:	e9 e1 f9 ff ff       	jmp    80105237 <alltraps>

80105856 <vector51>:
80105856:	6a 00                	push   $0x0
80105858:	6a 33                	push   $0x33
8010585a:	e9 d8 f9 ff ff       	jmp    80105237 <alltraps>

8010585f <vector52>:
8010585f:	6a 00                	push   $0x0
80105861:	6a 34                	push   $0x34
80105863:	e9 cf f9 ff ff       	jmp    80105237 <alltraps>

80105868 <vector53>:
80105868:	6a 00                	push   $0x0
8010586a:	6a 35                	push   $0x35
8010586c:	e9 c6 f9 ff ff       	jmp    80105237 <alltraps>

80105871 <vector54>:
80105871:	6a 00                	push   $0x0
80105873:	6a 36                	push   $0x36
80105875:	e9 bd f9 ff ff       	jmp    80105237 <alltraps>

8010587a <vector55>:
8010587a:	6a 00                	push   $0x0
8010587c:	6a 37                	push   $0x37
8010587e:	e9 b4 f9 ff ff       	jmp    80105237 <alltraps>

80105883 <vector56>:
80105883:	6a 00                	push   $0x0
80105885:	6a 38                	push   $0x38
80105887:	e9 ab f9 ff ff       	jmp    80105237 <alltraps>

8010588c <vector57>:
8010588c:	6a 00                	push   $0x0
8010588e:	6a 39                	push   $0x39
80105890:	e9 a2 f9 ff ff       	jmp    80105237 <alltraps>

80105895 <vector58>:
80105895:	6a 00                	push   $0x0
80105897:	6a 3a                	push   $0x3a
80105899:	e9 99 f9 ff ff       	jmp    80105237 <alltraps>

8010589e <vector59>:
8010589e:	6a 00                	push   $0x0
801058a0:	6a 3b                	push   $0x3b
801058a2:	e9 90 f9 ff ff       	jmp    80105237 <alltraps>

801058a7 <vector60>:
801058a7:	6a 00                	push   $0x0
801058a9:	6a 3c                	push   $0x3c
801058ab:	e9 87 f9 ff ff       	jmp    80105237 <alltraps>

801058b0 <vector61>:
801058b0:	6a 00                	push   $0x0
801058b2:	6a 3d                	push   $0x3d
801058b4:	e9 7e f9 ff ff       	jmp    80105237 <alltraps>

801058b9 <vector62>:
801058b9:	6a 00                	push   $0x0
801058bb:	6a 3e                	push   $0x3e
801058bd:	e9 75 f9 ff ff       	jmp    80105237 <alltraps>

801058c2 <vector63>:
801058c2:	6a 00                	push   $0x0
801058c4:	6a 3f                	push   $0x3f
801058c6:	e9 6c f9 ff ff       	jmp    80105237 <alltraps>

801058cb <vector64>:
801058cb:	6a 00                	push   $0x0
801058cd:	6a 40                	push   $0x40
801058cf:	e9 63 f9 ff ff       	jmp    80105237 <alltraps>

801058d4 <vector65>:
801058d4:	6a 00                	push   $0x0
801058d6:	6a 41                	push   $0x41
801058d8:	e9 5a f9 ff ff       	jmp    80105237 <alltraps>

801058dd <vector66>:
801058dd:	6a 00                	push   $0x0
801058df:	6a 42                	push   $0x42
801058e1:	e9 51 f9 ff ff       	jmp    80105237 <alltraps>

801058e6 <vector67>:
801058e6:	6a 00                	push   $0x0
801058e8:	6a 43                	push   $0x43
801058ea:	e9 48 f9 ff ff       	jmp    80105237 <alltraps>

801058ef <vector68>:
801058ef:	6a 00                	push   $0x0
801058f1:	6a 44                	push   $0x44
801058f3:	e9 3f f9 ff ff       	jmp    80105237 <alltraps>

801058f8 <vector69>:
801058f8:	6a 00                	push   $0x0
801058fa:	6a 45                	push   $0x45
801058fc:	e9 36 f9 ff ff       	jmp    80105237 <alltraps>

80105901 <vector70>:
80105901:	6a 00                	push   $0x0
80105903:	6a 46                	push   $0x46
80105905:	e9 2d f9 ff ff       	jmp    80105237 <alltraps>

8010590a <vector71>:
8010590a:	6a 00                	push   $0x0
8010590c:	6a 47                	push   $0x47
8010590e:	e9 24 f9 ff ff       	jmp    80105237 <alltraps>

80105913 <vector72>:
80105913:	6a 00                	push   $0x0
80105915:	6a 48                	push   $0x48
80105917:	e9 1b f9 ff ff       	jmp    80105237 <alltraps>

8010591c <vector73>:
8010591c:	6a 00                	push   $0x0
8010591e:	6a 49                	push   $0x49
80105920:	e9 12 f9 ff ff       	jmp    80105237 <alltraps>

80105925 <vector74>:
80105925:	6a 00                	push   $0x0
80105927:	6a 4a                	push   $0x4a
80105929:	e9 09 f9 ff ff       	jmp    80105237 <alltraps>

8010592e <vector75>:
8010592e:	6a 00                	push   $0x0
80105930:	6a 4b                	push   $0x4b
80105932:	e9 00 f9 ff ff       	jmp    80105237 <alltraps>

80105937 <vector76>:
80105937:	6a 00                	push   $0x0
80105939:	6a 4c                	push   $0x4c
8010593b:	e9 f7 f8 ff ff       	jmp    80105237 <alltraps>

80105940 <vector77>:
80105940:	6a 00                	push   $0x0
80105942:	6a 4d                	push   $0x4d
80105944:	e9 ee f8 ff ff       	jmp    80105237 <alltraps>

80105949 <vector78>:
80105949:	6a 00                	push   $0x0
8010594b:	6a 4e                	push   $0x4e
8010594d:	e9 e5 f8 ff ff       	jmp    80105237 <alltraps>

80105952 <vector79>:
80105952:	6a 00                	push   $0x0
80105954:	6a 4f                	push   $0x4f
80105956:	e9 dc f8 ff ff       	jmp    80105237 <alltraps>

8010595b <vector80>:
8010595b:	6a 00                	push   $0x0
8010595d:	6a 50                	push   $0x50
8010595f:	e9 d3 f8 ff ff       	jmp    80105237 <alltraps>

80105964 <vector81>:
80105964:	6a 00                	push   $0x0
80105966:	6a 51                	push   $0x51
80105968:	e9 ca f8 ff ff       	jmp    80105237 <alltraps>

8010596d <vector82>:
8010596d:	6a 00                	push   $0x0
8010596f:	6a 52                	push   $0x52
80105971:	e9 c1 f8 ff ff       	jmp    80105237 <alltraps>

80105976 <vector83>:
80105976:	6a 00                	push   $0x0
80105978:	6a 53                	push   $0x53
8010597a:	e9 b8 f8 ff ff       	jmp    80105237 <alltraps>

8010597f <vector84>:
8010597f:	6a 00                	push   $0x0
80105981:	6a 54                	push   $0x54
80105983:	e9 af f8 ff ff       	jmp    80105237 <alltraps>

80105988 <vector85>:
80105988:	6a 00                	push   $0x0
8010598a:	6a 55                	push   $0x55
8010598c:	e9 a6 f8 ff ff       	jmp    80105237 <alltraps>

80105991 <vector86>:
80105991:	6a 00                	push   $0x0
80105993:	6a 56                	push   $0x56
80105995:	e9 9d f8 ff ff       	jmp    80105237 <alltraps>

8010599a <vector87>:
8010599a:	6a 00                	push   $0x0
8010599c:	6a 57                	push   $0x57
8010599e:	e9 94 f8 ff ff       	jmp    80105237 <alltraps>

801059a3 <vector88>:
801059a3:	6a 00                	push   $0x0
801059a5:	6a 58                	push   $0x58
801059a7:	e9 8b f8 ff ff       	jmp    80105237 <alltraps>

801059ac <vector89>:
801059ac:	6a 00                	push   $0x0
801059ae:	6a 59                	push   $0x59
801059b0:	e9 82 f8 ff ff       	jmp    80105237 <alltraps>

801059b5 <vector90>:
801059b5:	6a 00                	push   $0x0
801059b7:	6a 5a                	push   $0x5a
801059b9:	e9 79 f8 ff ff       	jmp    80105237 <alltraps>

801059be <vector91>:
801059be:	6a 00                	push   $0x0
801059c0:	6a 5b                	push   $0x5b
801059c2:	e9 70 f8 ff ff       	jmp    80105237 <alltraps>

801059c7 <vector92>:
801059c7:	6a 00                	push   $0x0
801059c9:	6a 5c                	push   $0x5c
801059cb:	e9 67 f8 ff ff       	jmp    80105237 <alltraps>

801059d0 <vector93>:
801059d0:	6a 00                	push   $0x0
801059d2:	6a 5d                	push   $0x5d
801059d4:	e9 5e f8 ff ff       	jmp    80105237 <alltraps>

801059d9 <vector94>:
801059d9:	6a 00                	push   $0x0
801059db:	6a 5e                	push   $0x5e
801059dd:	e9 55 f8 ff ff       	jmp    80105237 <alltraps>

801059e2 <vector95>:
801059e2:	6a 00                	push   $0x0
801059e4:	6a 5f                	push   $0x5f
801059e6:	e9 4c f8 ff ff       	jmp    80105237 <alltraps>

801059eb <vector96>:
801059eb:	6a 00                	push   $0x0
801059ed:	6a 60                	push   $0x60
801059ef:	e9 43 f8 ff ff       	jmp    80105237 <alltraps>

801059f4 <vector97>:
801059f4:	6a 00                	push   $0x0
801059f6:	6a 61                	push   $0x61
801059f8:	e9 3a f8 ff ff       	jmp    80105237 <alltraps>

801059fd <vector98>:
801059fd:	6a 00                	push   $0x0
801059ff:	6a 62                	push   $0x62
80105a01:	e9 31 f8 ff ff       	jmp    80105237 <alltraps>

80105a06 <vector99>:
80105a06:	6a 00                	push   $0x0
80105a08:	6a 63                	push   $0x63
80105a0a:	e9 28 f8 ff ff       	jmp    80105237 <alltraps>

80105a0f <vector100>:
80105a0f:	6a 00                	push   $0x0
80105a11:	6a 64                	push   $0x64
80105a13:	e9 1f f8 ff ff       	jmp    80105237 <alltraps>

80105a18 <vector101>:
80105a18:	6a 00                	push   $0x0
80105a1a:	6a 65                	push   $0x65
80105a1c:	e9 16 f8 ff ff       	jmp    80105237 <alltraps>

80105a21 <vector102>:
80105a21:	6a 00                	push   $0x0
80105a23:	6a 66                	push   $0x66
80105a25:	e9 0d f8 ff ff       	jmp    80105237 <alltraps>

80105a2a <vector103>:
80105a2a:	6a 00                	push   $0x0
80105a2c:	6a 67                	push   $0x67
80105a2e:	e9 04 f8 ff ff       	jmp    80105237 <alltraps>

80105a33 <vector104>:
80105a33:	6a 00                	push   $0x0
80105a35:	6a 68                	push   $0x68
80105a37:	e9 fb f7 ff ff       	jmp    80105237 <alltraps>

80105a3c <vector105>:
80105a3c:	6a 00                	push   $0x0
80105a3e:	6a 69                	push   $0x69
80105a40:	e9 f2 f7 ff ff       	jmp    80105237 <alltraps>

80105a45 <vector106>:
80105a45:	6a 00                	push   $0x0
80105a47:	6a 6a                	push   $0x6a
80105a49:	e9 e9 f7 ff ff       	jmp    80105237 <alltraps>

80105a4e <vector107>:
80105a4e:	6a 00                	push   $0x0
80105a50:	6a 6b                	push   $0x6b
80105a52:	e9 e0 f7 ff ff       	jmp    80105237 <alltraps>

80105a57 <vector108>:
80105a57:	6a 00                	push   $0x0
80105a59:	6a 6c                	push   $0x6c
80105a5b:	e9 d7 f7 ff ff       	jmp    80105237 <alltraps>

80105a60 <vector109>:
80105a60:	6a 00                	push   $0x0
80105a62:	6a 6d                	push   $0x6d
80105a64:	e9 ce f7 ff ff       	jmp    80105237 <alltraps>

80105a69 <vector110>:
80105a69:	6a 00                	push   $0x0
80105a6b:	6a 6e                	push   $0x6e
80105a6d:	e9 c5 f7 ff ff       	jmp    80105237 <alltraps>

80105a72 <vector111>:
80105a72:	6a 00                	push   $0x0
80105a74:	6a 6f                	push   $0x6f
80105a76:	e9 bc f7 ff ff       	jmp    80105237 <alltraps>

80105a7b <vector112>:
80105a7b:	6a 00                	push   $0x0
80105a7d:	6a 70                	push   $0x70
80105a7f:	e9 b3 f7 ff ff       	jmp    80105237 <alltraps>

80105a84 <vector113>:
80105a84:	6a 00                	push   $0x0
80105a86:	6a 71                	push   $0x71
80105a88:	e9 aa f7 ff ff       	jmp    80105237 <alltraps>

80105a8d <vector114>:
80105a8d:	6a 00                	push   $0x0
80105a8f:	6a 72                	push   $0x72
80105a91:	e9 a1 f7 ff ff       	jmp    80105237 <alltraps>

80105a96 <vector115>:
80105a96:	6a 00                	push   $0x0
80105a98:	6a 73                	push   $0x73
80105a9a:	e9 98 f7 ff ff       	jmp    80105237 <alltraps>

80105a9f <vector116>:
80105a9f:	6a 00                	push   $0x0
80105aa1:	6a 74                	push   $0x74
80105aa3:	e9 8f f7 ff ff       	jmp    80105237 <alltraps>

80105aa8 <vector117>:
80105aa8:	6a 00                	push   $0x0
80105aaa:	6a 75                	push   $0x75
80105aac:	e9 86 f7 ff ff       	jmp    80105237 <alltraps>

80105ab1 <vector118>:
80105ab1:	6a 00                	push   $0x0
80105ab3:	6a 76                	push   $0x76
80105ab5:	e9 7d f7 ff ff       	jmp    80105237 <alltraps>

80105aba <vector119>:
80105aba:	6a 00                	push   $0x0
80105abc:	6a 77                	push   $0x77
80105abe:	e9 74 f7 ff ff       	jmp    80105237 <alltraps>

80105ac3 <vector120>:
80105ac3:	6a 00                	push   $0x0
80105ac5:	6a 78                	push   $0x78
80105ac7:	e9 6b f7 ff ff       	jmp    80105237 <alltraps>

80105acc <vector121>:
80105acc:	6a 00                	push   $0x0
80105ace:	6a 79                	push   $0x79
80105ad0:	e9 62 f7 ff ff       	jmp    80105237 <alltraps>

80105ad5 <vector122>:
80105ad5:	6a 00                	push   $0x0
80105ad7:	6a 7a                	push   $0x7a
80105ad9:	e9 59 f7 ff ff       	jmp    80105237 <alltraps>

80105ade <vector123>:
80105ade:	6a 00                	push   $0x0
80105ae0:	6a 7b                	push   $0x7b
80105ae2:	e9 50 f7 ff ff       	jmp    80105237 <alltraps>

80105ae7 <vector124>:
80105ae7:	6a 00                	push   $0x0
80105ae9:	6a 7c                	push   $0x7c
80105aeb:	e9 47 f7 ff ff       	jmp    80105237 <alltraps>

80105af0 <vector125>:
80105af0:	6a 00                	push   $0x0
80105af2:	6a 7d                	push   $0x7d
80105af4:	e9 3e f7 ff ff       	jmp    80105237 <alltraps>

80105af9 <vector126>:
80105af9:	6a 00                	push   $0x0
80105afb:	6a 7e                	push   $0x7e
80105afd:	e9 35 f7 ff ff       	jmp    80105237 <alltraps>

80105b02 <vector127>:
80105b02:	6a 00                	push   $0x0
80105b04:	6a 7f                	push   $0x7f
80105b06:	e9 2c f7 ff ff       	jmp    80105237 <alltraps>

80105b0b <vector128>:
80105b0b:	6a 00                	push   $0x0
80105b0d:	68 80 00 00 00       	push   $0x80
80105b12:	e9 20 f7 ff ff       	jmp    80105237 <alltraps>

80105b17 <vector129>:
80105b17:	6a 00                	push   $0x0
80105b19:	68 81 00 00 00       	push   $0x81
80105b1e:	e9 14 f7 ff ff       	jmp    80105237 <alltraps>

80105b23 <vector130>:
80105b23:	6a 00                	push   $0x0
80105b25:	68 82 00 00 00       	push   $0x82
80105b2a:	e9 08 f7 ff ff       	jmp    80105237 <alltraps>

80105b2f <vector131>:
80105b2f:	6a 00                	push   $0x0
80105b31:	68 83 00 00 00       	push   $0x83
80105b36:	e9 fc f6 ff ff       	jmp    80105237 <alltraps>

80105b3b <vector132>:
80105b3b:	6a 00                	push   $0x0
80105b3d:	68 84 00 00 00       	push   $0x84
80105b42:	e9 f0 f6 ff ff       	jmp    80105237 <alltraps>

80105b47 <vector133>:
80105b47:	6a 00                	push   $0x0
80105b49:	68 85 00 00 00       	push   $0x85
80105b4e:	e9 e4 f6 ff ff       	jmp    80105237 <alltraps>

80105b53 <vector134>:
80105b53:	6a 00                	push   $0x0
80105b55:	68 86 00 00 00       	push   $0x86
80105b5a:	e9 d8 f6 ff ff       	jmp    80105237 <alltraps>

80105b5f <vector135>:
80105b5f:	6a 00                	push   $0x0
80105b61:	68 87 00 00 00       	push   $0x87
80105b66:	e9 cc f6 ff ff       	jmp    80105237 <alltraps>

80105b6b <vector136>:
80105b6b:	6a 00                	push   $0x0
80105b6d:	68 88 00 00 00       	push   $0x88
80105b72:	e9 c0 f6 ff ff       	jmp    80105237 <alltraps>

80105b77 <vector137>:
80105b77:	6a 00                	push   $0x0
80105b79:	68 89 00 00 00       	push   $0x89
80105b7e:	e9 b4 f6 ff ff       	jmp    80105237 <alltraps>

80105b83 <vector138>:
80105b83:	6a 00                	push   $0x0
80105b85:	68 8a 00 00 00       	push   $0x8a
80105b8a:	e9 a8 f6 ff ff       	jmp    80105237 <alltraps>

80105b8f <vector139>:
80105b8f:	6a 00                	push   $0x0
80105b91:	68 8b 00 00 00       	push   $0x8b
80105b96:	e9 9c f6 ff ff       	jmp    80105237 <alltraps>

80105b9b <vector140>:
80105b9b:	6a 00                	push   $0x0
80105b9d:	68 8c 00 00 00       	push   $0x8c
80105ba2:	e9 90 f6 ff ff       	jmp    80105237 <alltraps>

80105ba7 <vector141>:
80105ba7:	6a 00                	push   $0x0
80105ba9:	68 8d 00 00 00       	push   $0x8d
80105bae:	e9 84 f6 ff ff       	jmp    80105237 <alltraps>

80105bb3 <vector142>:
80105bb3:	6a 00                	push   $0x0
80105bb5:	68 8e 00 00 00       	push   $0x8e
80105bba:	e9 78 f6 ff ff       	jmp    80105237 <alltraps>

80105bbf <vector143>:
80105bbf:	6a 00                	push   $0x0
80105bc1:	68 8f 00 00 00       	push   $0x8f
80105bc6:	e9 6c f6 ff ff       	jmp    80105237 <alltraps>

80105bcb <vector144>:
80105bcb:	6a 00                	push   $0x0
80105bcd:	68 90 00 00 00       	push   $0x90
80105bd2:	e9 60 f6 ff ff       	jmp    80105237 <alltraps>

80105bd7 <vector145>:
80105bd7:	6a 00                	push   $0x0
80105bd9:	68 91 00 00 00       	push   $0x91
80105bde:	e9 54 f6 ff ff       	jmp    80105237 <alltraps>

80105be3 <vector146>:
80105be3:	6a 00                	push   $0x0
80105be5:	68 92 00 00 00       	push   $0x92
80105bea:	e9 48 f6 ff ff       	jmp    80105237 <alltraps>

80105bef <vector147>:
80105bef:	6a 00                	push   $0x0
80105bf1:	68 93 00 00 00       	push   $0x93
80105bf6:	e9 3c f6 ff ff       	jmp    80105237 <alltraps>

80105bfb <vector148>:
80105bfb:	6a 00                	push   $0x0
80105bfd:	68 94 00 00 00       	push   $0x94
80105c02:	e9 30 f6 ff ff       	jmp    80105237 <alltraps>

80105c07 <vector149>:
80105c07:	6a 00                	push   $0x0
80105c09:	68 95 00 00 00       	push   $0x95
80105c0e:	e9 24 f6 ff ff       	jmp    80105237 <alltraps>

80105c13 <vector150>:
80105c13:	6a 00                	push   $0x0
80105c15:	68 96 00 00 00       	push   $0x96
80105c1a:	e9 18 f6 ff ff       	jmp    80105237 <alltraps>

80105c1f <vector151>:
80105c1f:	6a 00                	push   $0x0
80105c21:	68 97 00 00 00       	push   $0x97
80105c26:	e9 0c f6 ff ff       	jmp    80105237 <alltraps>

80105c2b <vector152>:
80105c2b:	6a 00                	push   $0x0
80105c2d:	68 98 00 00 00       	push   $0x98
80105c32:	e9 00 f6 ff ff       	jmp    80105237 <alltraps>

80105c37 <vector153>:
80105c37:	6a 00                	push   $0x0
80105c39:	68 99 00 00 00       	push   $0x99
80105c3e:	e9 f4 f5 ff ff       	jmp    80105237 <alltraps>

80105c43 <vector154>:
80105c43:	6a 00                	push   $0x0
80105c45:	68 9a 00 00 00       	push   $0x9a
80105c4a:	e9 e8 f5 ff ff       	jmp    80105237 <alltraps>

80105c4f <vector155>:
80105c4f:	6a 00                	push   $0x0
80105c51:	68 9b 00 00 00       	push   $0x9b
80105c56:	e9 dc f5 ff ff       	jmp    80105237 <alltraps>

80105c5b <vector156>:
80105c5b:	6a 00                	push   $0x0
80105c5d:	68 9c 00 00 00       	push   $0x9c
80105c62:	e9 d0 f5 ff ff       	jmp    80105237 <alltraps>

80105c67 <vector157>:
80105c67:	6a 00                	push   $0x0
80105c69:	68 9d 00 00 00       	push   $0x9d
80105c6e:	e9 c4 f5 ff ff       	jmp    80105237 <alltraps>

80105c73 <vector158>:
80105c73:	6a 00                	push   $0x0
80105c75:	68 9e 00 00 00       	push   $0x9e
80105c7a:	e9 b8 f5 ff ff       	jmp    80105237 <alltraps>

80105c7f <vector159>:
80105c7f:	6a 00                	push   $0x0
80105c81:	68 9f 00 00 00       	push   $0x9f
80105c86:	e9 ac f5 ff ff       	jmp    80105237 <alltraps>

80105c8b <vector160>:
80105c8b:	6a 00                	push   $0x0
80105c8d:	68 a0 00 00 00       	push   $0xa0
80105c92:	e9 a0 f5 ff ff       	jmp    80105237 <alltraps>

80105c97 <vector161>:
80105c97:	6a 00                	push   $0x0
80105c99:	68 a1 00 00 00       	push   $0xa1
80105c9e:	e9 94 f5 ff ff       	jmp    80105237 <alltraps>

80105ca3 <vector162>:
80105ca3:	6a 00                	push   $0x0
80105ca5:	68 a2 00 00 00       	push   $0xa2
80105caa:	e9 88 f5 ff ff       	jmp    80105237 <alltraps>

80105caf <vector163>:
80105caf:	6a 00                	push   $0x0
80105cb1:	68 a3 00 00 00       	push   $0xa3
80105cb6:	e9 7c f5 ff ff       	jmp    80105237 <alltraps>

80105cbb <vector164>:
80105cbb:	6a 00                	push   $0x0
80105cbd:	68 a4 00 00 00       	push   $0xa4
80105cc2:	e9 70 f5 ff ff       	jmp    80105237 <alltraps>

80105cc7 <vector165>:
80105cc7:	6a 00                	push   $0x0
80105cc9:	68 a5 00 00 00       	push   $0xa5
80105cce:	e9 64 f5 ff ff       	jmp    80105237 <alltraps>

80105cd3 <vector166>:
80105cd3:	6a 00                	push   $0x0
80105cd5:	68 a6 00 00 00       	push   $0xa6
80105cda:	e9 58 f5 ff ff       	jmp    80105237 <alltraps>

80105cdf <vector167>:
80105cdf:	6a 00                	push   $0x0
80105ce1:	68 a7 00 00 00       	push   $0xa7
80105ce6:	e9 4c f5 ff ff       	jmp    80105237 <alltraps>

80105ceb <vector168>:
80105ceb:	6a 00                	push   $0x0
80105ced:	68 a8 00 00 00       	push   $0xa8
80105cf2:	e9 40 f5 ff ff       	jmp    80105237 <alltraps>

80105cf7 <vector169>:
80105cf7:	6a 00                	push   $0x0
80105cf9:	68 a9 00 00 00       	push   $0xa9
80105cfe:	e9 34 f5 ff ff       	jmp    80105237 <alltraps>

80105d03 <vector170>:
80105d03:	6a 00                	push   $0x0
80105d05:	68 aa 00 00 00       	push   $0xaa
80105d0a:	e9 28 f5 ff ff       	jmp    80105237 <alltraps>

80105d0f <vector171>:
80105d0f:	6a 00                	push   $0x0
80105d11:	68 ab 00 00 00       	push   $0xab
80105d16:	e9 1c f5 ff ff       	jmp    80105237 <alltraps>

80105d1b <vector172>:
80105d1b:	6a 00                	push   $0x0
80105d1d:	68 ac 00 00 00       	push   $0xac
80105d22:	e9 10 f5 ff ff       	jmp    80105237 <alltraps>

80105d27 <vector173>:
80105d27:	6a 00                	push   $0x0
80105d29:	68 ad 00 00 00       	push   $0xad
80105d2e:	e9 04 f5 ff ff       	jmp    80105237 <alltraps>

80105d33 <vector174>:
80105d33:	6a 00                	push   $0x0
80105d35:	68 ae 00 00 00       	push   $0xae
80105d3a:	e9 f8 f4 ff ff       	jmp    80105237 <alltraps>

80105d3f <vector175>:
80105d3f:	6a 00                	push   $0x0
80105d41:	68 af 00 00 00       	push   $0xaf
80105d46:	e9 ec f4 ff ff       	jmp    80105237 <alltraps>

80105d4b <vector176>:
80105d4b:	6a 00                	push   $0x0
80105d4d:	68 b0 00 00 00       	push   $0xb0
80105d52:	e9 e0 f4 ff ff       	jmp    80105237 <alltraps>

80105d57 <vector177>:
80105d57:	6a 00                	push   $0x0
80105d59:	68 b1 00 00 00       	push   $0xb1
80105d5e:	e9 d4 f4 ff ff       	jmp    80105237 <alltraps>

80105d63 <vector178>:
80105d63:	6a 00                	push   $0x0
80105d65:	68 b2 00 00 00       	push   $0xb2
80105d6a:	e9 c8 f4 ff ff       	jmp    80105237 <alltraps>

80105d6f <vector179>:
80105d6f:	6a 00                	push   $0x0
80105d71:	68 b3 00 00 00       	push   $0xb3
80105d76:	e9 bc f4 ff ff       	jmp    80105237 <alltraps>

80105d7b <vector180>:
80105d7b:	6a 00                	push   $0x0
80105d7d:	68 b4 00 00 00       	push   $0xb4
80105d82:	e9 b0 f4 ff ff       	jmp    80105237 <alltraps>

80105d87 <vector181>:
80105d87:	6a 00                	push   $0x0
80105d89:	68 b5 00 00 00       	push   $0xb5
80105d8e:	e9 a4 f4 ff ff       	jmp    80105237 <alltraps>

80105d93 <vector182>:
80105d93:	6a 00                	push   $0x0
80105d95:	68 b6 00 00 00       	push   $0xb6
80105d9a:	e9 98 f4 ff ff       	jmp    80105237 <alltraps>

80105d9f <vector183>:
80105d9f:	6a 00                	push   $0x0
80105da1:	68 b7 00 00 00       	push   $0xb7
80105da6:	e9 8c f4 ff ff       	jmp    80105237 <alltraps>

80105dab <vector184>:
80105dab:	6a 00                	push   $0x0
80105dad:	68 b8 00 00 00       	push   $0xb8
80105db2:	e9 80 f4 ff ff       	jmp    80105237 <alltraps>

80105db7 <vector185>:
80105db7:	6a 00                	push   $0x0
80105db9:	68 b9 00 00 00       	push   $0xb9
80105dbe:	e9 74 f4 ff ff       	jmp    80105237 <alltraps>

80105dc3 <vector186>:
80105dc3:	6a 00                	push   $0x0
80105dc5:	68 ba 00 00 00       	push   $0xba
80105dca:	e9 68 f4 ff ff       	jmp    80105237 <alltraps>

80105dcf <vector187>:
80105dcf:	6a 00                	push   $0x0
80105dd1:	68 bb 00 00 00       	push   $0xbb
80105dd6:	e9 5c f4 ff ff       	jmp    80105237 <alltraps>

80105ddb <vector188>:
80105ddb:	6a 00                	push   $0x0
80105ddd:	68 bc 00 00 00       	push   $0xbc
80105de2:	e9 50 f4 ff ff       	jmp    80105237 <alltraps>

80105de7 <vector189>:
80105de7:	6a 00                	push   $0x0
80105de9:	68 bd 00 00 00       	push   $0xbd
80105dee:	e9 44 f4 ff ff       	jmp    80105237 <alltraps>

80105df3 <vector190>:
80105df3:	6a 00                	push   $0x0
80105df5:	68 be 00 00 00       	push   $0xbe
80105dfa:	e9 38 f4 ff ff       	jmp    80105237 <alltraps>

80105dff <vector191>:
80105dff:	6a 00                	push   $0x0
80105e01:	68 bf 00 00 00       	push   $0xbf
80105e06:	e9 2c f4 ff ff       	jmp    80105237 <alltraps>

80105e0b <vector192>:
80105e0b:	6a 00                	push   $0x0
80105e0d:	68 c0 00 00 00       	push   $0xc0
80105e12:	e9 20 f4 ff ff       	jmp    80105237 <alltraps>

80105e17 <vector193>:
80105e17:	6a 00                	push   $0x0
80105e19:	68 c1 00 00 00       	push   $0xc1
80105e1e:	e9 14 f4 ff ff       	jmp    80105237 <alltraps>

80105e23 <vector194>:
80105e23:	6a 00                	push   $0x0
80105e25:	68 c2 00 00 00       	push   $0xc2
80105e2a:	e9 08 f4 ff ff       	jmp    80105237 <alltraps>

80105e2f <vector195>:
80105e2f:	6a 00                	push   $0x0
80105e31:	68 c3 00 00 00       	push   $0xc3
80105e36:	e9 fc f3 ff ff       	jmp    80105237 <alltraps>

80105e3b <vector196>:
80105e3b:	6a 00                	push   $0x0
80105e3d:	68 c4 00 00 00       	push   $0xc4
80105e42:	e9 f0 f3 ff ff       	jmp    80105237 <alltraps>

80105e47 <vector197>:
80105e47:	6a 00                	push   $0x0
80105e49:	68 c5 00 00 00       	push   $0xc5
80105e4e:	e9 e4 f3 ff ff       	jmp    80105237 <alltraps>

80105e53 <vector198>:
80105e53:	6a 00                	push   $0x0
80105e55:	68 c6 00 00 00       	push   $0xc6
80105e5a:	e9 d8 f3 ff ff       	jmp    80105237 <alltraps>

80105e5f <vector199>:
80105e5f:	6a 00                	push   $0x0
80105e61:	68 c7 00 00 00       	push   $0xc7
80105e66:	e9 cc f3 ff ff       	jmp    80105237 <alltraps>

80105e6b <vector200>:
80105e6b:	6a 00                	push   $0x0
80105e6d:	68 c8 00 00 00       	push   $0xc8
80105e72:	e9 c0 f3 ff ff       	jmp    80105237 <alltraps>

80105e77 <vector201>:
80105e77:	6a 00                	push   $0x0
80105e79:	68 c9 00 00 00       	push   $0xc9
80105e7e:	e9 b4 f3 ff ff       	jmp    80105237 <alltraps>

80105e83 <vector202>:
80105e83:	6a 00                	push   $0x0
80105e85:	68 ca 00 00 00       	push   $0xca
80105e8a:	e9 a8 f3 ff ff       	jmp    80105237 <alltraps>

80105e8f <vector203>:
80105e8f:	6a 00                	push   $0x0
80105e91:	68 cb 00 00 00       	push   $0xcb
80105e96:	e9 9c f3 ff ff       	jmp    80105237 <alltraps>

80105e9b <vector204>:
80105e9b:	6a 00                	push   $0x0
80105e9d:	68 cc 00 00 00       	push   $0xcc
80105ea2:	e9 90 f3 ff ff       	jmp    80105237 <alltraps>

80105ea7 <vector205>:
80105ea7:	6a 00                	push   $0x0
80105ea9:	68 cd 00 00 00       	push   $0xcd
80105eae:	e9 84 f3 ff ff       	jmp    80105237 <alltraps>

80105eb3 <vector206>:
80105eb3:	6a 00                	push   $0x0
80105eb5:	68 ce 00 00 00       	push   $0xce
80105eba:	e9 78 f3 ff ff       	jmp    80105237 <alltraps>

80105ebf <vector207>:
80105ebf:	6a 00                	push   $0x0
80105ec1:	68 cf 00 00 00       	push   $0xcf
80105ec6:	e9 6c f3 ff ff       	jmp    80105237 <alltraps>

80105ecb <vector208>:
80105ecb:	6a 00                	push   $0x0
80105ecd:	68 d0 00 00 00       	push   $0xd0
80105ed2:	e9 60 f3 ff ff       	jmp    80105237 <alltraps>

80105ed7 <vector209>:
80105ed7:	6a 00                	push   $0x0
80105ed9:	68 d1 00 00 00       	push   $0xd1
80105ede:	e9 54 f3 ff ff       	jmp    80105237 <alltraps>

80105ee3 <vector210>:
80105ee3:	6a 00                	push   $0x0
80105ee5:	68 d2 00 00 00       	push   $0xd2
80105eea:	e9 48 f3 ff ff       	jmp    80105237 <alltraps>

80105eef <vector211>:
80105eef:	6a 00                	push   $0x0
80105ef1:	68 d3 00 00 00       	push   $0xd3
80105ef6:	e9 3c f3 ff ff       	jmp    80105237 <alltraps>

80105efb <vector212>:
80105efb:	6a 00                	push   $0x0
80105efd:	68 d4 00 00 00       	push   $0xd4
80105f02:	e9 30 f3 ff ff       	jmp    80105237 <alltraps>

80105f07 <vector213>:
80105f07:	6a 00                	push   $0x0
80105f09:	68 d5 00 00 00       	push   $0xd5
80105f0e:	e9 24 f3 ff ff       	jmp    80105237 <alltraps>

80105f13 <vector214>:
80105f13:	6a 00                	push   $0x0
80105f15:	68 d6 00 00 00       	push   $0xd6
80105f1a:	e9 18 f3 ff ff       	jmp    80105237 <alltraps>

80105f1f <vector215>:
80105f1f:	6a 00                	push   $0x0
80105f21:	68 d7 00 00 00       	push   $0xd7
80105f26:	e9 0c f3 ff ff       	jmp    80105237 <alltraps>

80105f2b <vector216>:
80105f2b:	6a 00                	push   $0x0
80105f2d:	68 d8 00 00 00       	push   $0xd8
80105f32:	e9 00 f3 ff ff       	jmp    80105237 <alltraps>

80105f37 <vector217>:
80105f37:	6a 00                	push   $0x0
80105f39:	68 d9 00 00 00       	push   $0xd9
80105f3e:	e9 f4 f2 ff ff       	jmp    80105237 <alltraps>

80105f43 <vector218>:
80105f43:	6a 00                	push   $0x0
80105f45:	68 da 00 00 00       	push   $0xda
80105f4a:	e9 e8 f2 ff ff       	jmp    80105237 <alltraps>

80105f4f <vector219>:
80105f4f:	6a 00                	push   $0x0
80105f51:	68 db 00 00 00       	push   $0xdb
80105f56:	e9 dc f2 ff ff       	jmp    80105237 <alltraps>

80105f5b <vector220>:
80105f5b:	6a 00                	push   $0x0
80105f5d:	68 dc 00 00 00       	push   $0xdc
80105f62:	e9 d0 f2 ff ff       	jmp    80105237 <alltraps>

80105f67 <vector221>:
80105f67:	6a 00                	push   $0x0
80105f69:	68 dd 00 00 00       	push   $0xdd
80105f6e:	e9 c4 f2 ff ff       	jmp    80105237 <alltraps>

80105f73 <vector222>:
80105f73:	6a 00                	push   $0x0
80105f75:	68 de 00 00 00       	push   $0xde
80105f7a:	e9 b8 f2 ff ff       	jmp    80105237 <alltraps>

80105f7f <vector223>:
80105f7f:	6a 00                	push   $0x0
80105f81:	68 df 00 00 00       	push   $0xdf
80105f86:	e9 ac f2 ff ff       	jmp    80105237 <alltraps>

80105f8b <vector224>:
80105f8b:	6a 00                	push   $0x0
80105f8d:	68 e0 00 00 00       	push   $0xe0
80105f92:	e9 a0 f2 ff ff       	jmp    80105237 <alltraps>

80105f97 <vector225>:
80105f97:	6a 00                	push   $0x0
80105f99:	68 e1 00 00 00       	push   $0xe1
80105f9e:	e9 94 f2 ff ff       	jmp    80105237 <alltraps>

80105fa3 <vector226>:
80105fa3:	6a 00                	push   $0x0
80105fa5:	68 e2 00 00 00       	push   $0xe2
80105faa:	e9 88 f2 ff ff       	jmp    80105237 <alltraps>

80105faf <vector227>:
80105faf:	6a 00                	push   $0x0
80105fb1:	68 e3 00 00 00       	push   $0xe3
80105fb6:	e9 7c f2 ff ff       	jmp    80105237 <alltraps>

80105fbb <vector228>:
80105fbb:	6a 00                	push   $0x0
80105fbd:	68 e4 00 00 00       	push   $0xe4
80105fc2:	e9 70 f2 ff ff       	jmp    80105237 <alltraps>

80105fc7 <vector229>:
80105fc7:	6a 00                	push   $0x0
80105fc9:	68 e5 00 00 00       	push   $0xe5
80105fce:	e9 64 f2 ff ff       	jmp    80105237 <alltraps>

80105fd3 <vector230>:
80105fd3:	6a 00                	push   $0x0
80105fd5:	68 e6 00 00 00       	push   $0xe6
80105fda:	e9 58 f2 ff ff       	jmp    80105237 <alltraps>

80105fdf <vector231>:
80105fdf:	6a 00                	push   $0x0
80105fe1:	68 e7 00 00 00       	push   $0xe7
80105fe6:	e9 4c f2 ff ff       	jmp    80105237 <alltraps>

80105feb <vector232>:
80105feb:	6a 00                	push   $0x0
80105fed:	68 e8 00 00 00       	push   $0xe8
80105ff2:	e9 40 f2 ff ff       	jmp    80105237 <alltraps>

80105ff7 <vector233>:
80105ff7:	6a 00                	push   $0x0
80105ff9:	68 e9 00 00 00       	push   $0xe9
80105ffe:	e9 34 f2 ff ff       	jmp    80105237 <alltraps>

80106003 <vector234>:
80106003:	6a 00                	push   $0x0
80106005:	68 ea 00 00 00       	push   $0xea
8010600a:	e9 28 f2 ff ff       	jmp    80105237 <alltraps>

8010600f <vector235>:
8010600f:	6a 00                	push   $0x0
80106011:	68 eb 00 00 00       	push   $0xeb
80106016:	e9 1c f2 ff ff       	jmp    80105237 <alltraps>

8010601b <vector236>:
8010601b:	6a 00                	push   $0x0
8010601d:	68 ec 00 00 00       	push   $0xec
80106022:	e9 10 f2 ff ff       	jmp    80105237 <alltraps>

80106027 <vector237>:
80106027:	6a 00                	push   $0x0
80106029:	68 ed 00 00 00       	push   $0xed
8010602e:	e9 04 f2 ff ff       	jmp    80105237 <alltraps>

80106033 <vector238>:
80106033:	6a 00                	push   $0x0
80106035:	68 ee 00 00 00       	push   $0xee
8010603a:	e9 f8 f1 ff ff       	jmp    80105237 <alltraps>

8010603f <vector239>:
8010603f:	6a 00                	push   $0x0
80106041:	68 ef 00 00 00       	push   $0xef
80106046:	e9 ec f1 ff ff       	jmp    80105237 <alltraps>

8010604b <vector240>:
8010604b:	6a 00                	push   $0x0
8010604d:	68 f0 00 00 00       	push   $0xf0
80106052:	e9 e0 f1 ff ff       	jmp    80105237 <alltraps>

80106057 <vector241>:
80106057:	6a 00                	push   $0x0
80106059:	68 f1 00 00 00       	push   $0xf1
8010605e:	e9 d4 f1 ff ff       	jmp    80105237 <alltraps>

80106063 <vector242>:
80106063:	6a 00                	push   $0x0
80106065:	68 f2 00 00 00       	push   $0xf2
8010606a:	e9 c8 f1 ff ff       	jmp    80105237 <alltraps>

8010606f <vector243>:
8010606f:	6a 00                	push   $0x0
80106071:	68 f3 00 00 00       	push   $0xf3
80106076:	e9 bc f1 ff ff       	jmp    80105237 <alltraps>

8010607b <vector244>:
8010607b:	6a 00                	push   $0x0
8010607d:	68 f4 00 00 00       	push   $0xf4
80106082:	e9 b0 f1 ff ff       	jmp    80105237 <alltraps>

80106087 <vector245>:
80106087:	6a 00                	push   $0x0
80106089:	68 f5 00 00 00       	push   $0xf5
8010608e:	e9 a4 f1 ff ff       	jmp    80105237 <alltraps>

80106093 <vector246>:
80106093:	6a 00                	push   $0x0
80106095:	68 f6 00 00 00       	push   $0xf6
8010609a:	e9 98 f1 ff ff       	jmp    80105237 <alltraps>

8010609f <vector247>:
8010609f:	6a 00                	push   $0x0
801060a1:	68 f7 00 00 00       	push   $0xf7
801060a6:	e9 8c f1 ff ff       	jmp    80105237 <alltraps>

801060ab <vector248>:
801060ab:	6a 00                	push   $0x0
801060ad:	68 f8 00 00 00       	push   $0xf8
801060b2:	e9 80 f1 ff ff       	jmp    80105237 <alltraps>

801060b7 <vector249>:
801060b7:	6a 00                	push   $0x0
801060b9:	68 f9 00 00 00       	push   $0xf9
801060be:	e9 74 f1 ff ff       	jmp    80105237 <alltraps>

801060c3 <vector250>:
801060c3:	6a 00                	push   $0x0
801060c5:	68 fa 00 00 00       	push   $0xfa
801060ca:	e9 68 f1 ff ff       	jmp    80105237 <alltraps>

801060cf <vector251>:
801060cf:	6a 00                	push   $0x0
801060d1:	68 fb 00 00 00       	push   $0xfb
801060d6:	e9 5c f1 ff ff       	jmp    80105237 <alltraps>

801060db <vector252>:
801060db:	6a 00                	push   $0x0
801060dd:	68 fc 00 00 00       	push   $0xfc
801060e2:	e9 50 f1 ff ff       	jmp    80105237 <alltraps>

801060e7 <vector253>:
801060e7:	6a 00                	push   $0x0
801060e9:	68 fd 00 00 00       	push   $0xfd
801060ee:	e9 44 f1 ff ff       	jmp    80105237 <alltraps>

801060f3 <vector254>:
801060f3:	6a 00                	push   $0x0
801060f5:	68 fe 00 00 00       	push   $0xfe
801060fa:	e9 38 f1 ff ff       	jmp    80105237 <alltraps>

801060ff <vector255>:
801060ff:	6a 00                	push   $0x0
80106101:	68 ff 00 00 00       	push   $0xff
80106106:	e9 2c f1 ff ff       	jmp    80105237 <alltraps>
8010610b:	90                   	nop

8010610c <deallocuvm.part.0>:
8010610c:	55                   	push   %ebp
8010610d:	89 e5                	mov    %esp,%ebp
8010610f:	57                   	push   %edi
80106110:	56                   	push   %esi
80106111:	53                   	push   %ebx
80106112:	83 ec 1c             	sub    $0x1c,%esp
80106115:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
8010611b:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80106121:	39 d3                	cmp    %edx,%ebx
80106123:	73 50                	jae    80106175 <deallocuvm.part.0+0x69>
80106125:	89 c6                	mov    %eax,%esi
80106127:	89 d7                	mov    %edx,%edi
80106129:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010612c:	eb 0c                	jmp    8010613a <deallocuvm.part.0+0x2e>
8010612e:	66 90                	xchg   %ax,%ax
80106130:	42                   	inc    %edx
80106131:	89 d3                	mov    %edx,%ebx
80106133:	c1 e3 16             	shl    $0x16,%ebx
80106136:	39 fb                	cmp    %edi,%ebx
80106138:	73 38                	jae    80106172 <deallocuvm.part.0+0x66>
8010613a:	89 da                	mov    %ebx,%edx
8010613c:	c1 ea 16             	shr    $0x16,%edx
8010613f:	8b 04 96             	mov    (%esi,%edx,4),%eax
80106142:	a8 01                	test   $0x1,%al
80106144:	74 ea                	je     80106130 <deallocuvm.part.0+0x24>
80106146:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010614b:	89 d9                	mov    %ebx,%ecx
8010614d:	c1 e9 0a             	shr    $0xa,%ecx
80106150:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
80106156:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
8010615d:	85 c0                	test   %eax,%eax
8010615f:	74 cf                	je     80106130 <deallocuvm.part.0+0x24>
80106161:	8b 10                	mov    (%eax),%edx
80106163:	f6 c2 01             	test   $0x1,%dl
80106166:	75 18                	jne    80106180 <deallocuvm.part.0+0x74>
80106168:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010616e:	39 fb                	cmp    %edi,%ebx
80106170:	72 c8                	jb     8010613a <deallocuvm.part.0+0x2e>
80106172:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80106175:	89 c8                	mov    %ecx,%eax
80106177:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010617a:	5b                   	pop    %ebx
8010617b:	5e                   	pop    %esi
8010617c:	5f                   	pop    %edi
8010617d:	5d                   	pop    %ebp
8010617e:	c3                   	ret    
8010617f:	90                   	nop
80106180:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80106186:	74 26                	je     801061ae <deallocuvm.part.0+0xa2>
80106188:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010618b:	83 ec 0c             	sub    $0xc,%esp
8010618e:	81 c2 00 00 00 80    	add    $0x80000000,%edx
80106194:	52                   	push   %edx
80106195:	e8 9e c0 ff ff       	call   80102238 <kfree>
8010619a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010619d:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
801061a3:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801061a9:	83 c4 10             	add    $0x10,%esp
801061ac:	eb 88                	jmp    80106136 <deallocuvm.part.0+0x2a>
801061ae:	83 ec 0c             	sub    $0xc,%esp
801061b1:	68 66 6d 10 80       	push   $0x80106d66
801061b6:	e8 7d a1 ff ff       	call   80100338 <panic>
801061bb:	90                   	nop

801061bc <mappages>:
801061bc:	55                   	push   %ebp
801061bd:	89 e5                	mov    %esp,%ebp
801061bf:	57                   	push   %edi
801061c0:	56                   	push   %esi
801061c1:	53                   	push   %ebx
801061c2:	83 ec 1c             	sub    $0x1c,%esp
801061c5:	89 45 e0             	mov    %eax,-0x20(%ebp)
801061c8:	89 d3                	mov    %edx,%ebx
801061ca:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
801061d0:	8d 44 0a ff          	lea    -0x1(%edx,%ecx,1),%eax
801061d4:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801061d9:	89 45 dc             	mov    %eax,-0x24(%ebp)
801061dc:	8b 45 08             	mov    0x8(%ebp),%eax
801061df:	29 d8                	sub    %ebx,%eax
801061e1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801061e4:	eb 3b                	jmp    80106221 <mappages+0x65>
801061e6:	66 90                	xchg   %ax,%ax
801061e8:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801061ed:	89 da                	mov    %ebx,%edx
801061ef:	c1 ea 0a             	shr    $0xa,%edx
801061f2:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
801061f8:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
801061ff:	85 c0                	test   %eax,%eax
80106201:	74 71                	je     80106274 <mappages+0xb8>
80106203:	f6 00 01             	testb  $0x1,(%eax)
80106206:	0f 85 82 00 00 00    	jne    8010628e <mappages+0xd2>
8010620c:	0b 75 0c             	or     0xc(%ebp),%esi
8010620f:	83 ce 01             	or     $0x1,%esi
80106212:	89 30                	mov    %esi,(%eax)
80106214:	8b 45 dc             	mov    -0x24(%ebp),%eax
80106217:	39 c3                	cmp    %eax,%ebx
80106219:	74 69                	je     80106284 <mappages+0xc8>
8010621b:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106221:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106224:	8d 34 03             	lea    (%ebx,%eax,1),%esi
80106227:	89 d8                	mov    %ebx,%eax
80106229:	c1 e8 16             	shr    $0x16,%eax
8010622c:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010622f:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
80106232:	8b 07                	mov    (%edi),%eax
80106234:	a8 01                	test   $0x1,%al
80106236:	75 b0                	jne    801061e8 <mappages+0x2c>
80106238:	e8 8b c1 ff ff       	call   801023c8 <kalloc>
8010623d:	89 c2                	mov    %eax,%edx
8010623f:	85 c0                	test   %eax,%eax
80106241:	74 31                	je     80106274 <mappages+0xb8>
80106243:	50                   	push   %eax
80106244:	68 00 10 00 00       	push   $0x1000
80106249:	6a 00                	push   $0x0
8010624b:	52                   	push   %edx
8010624c:	89 55 d8             	mov    %edx,-0x28(%ebp)
8010624f:	e8 78 df ff ff       	call   801041cc <memset>
80106254:	8b 55 d8             	mov    -0x28(%ebp),%edx
80106257:	8d 82 00 00 00 80    	lea    -0x80000000(%edx),%eax
8010625d:	83 c8 07             	or     $0x7,%eax
80106260:	89 07                	mov    %eax,(%edi)
80106262:	89 d8                	mov    %ebx,%eax
80106264:	c1 e8 0a             	shr    $0xa,%eax
80106267:	25 fc 0f 00 00       	and    $0xffc,%eax
8010626c:	01 d0                	add    %edx,%eax
8010626e:	83 c4 10             	add    $0x10,%esp
80106271:	eb 90                	jmp    80106203 <mappages+0x47>
80106273:	90                   	nop
80106274:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106279:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010627c:	5b                   	pop    %ebx
8010627d:	5e                   	pop    %esi
8010627e:	5f                   	pop    %edi
8010627f:	5d                   	pop    %ebp
80106280:	c3                   	ret    
80106281:	8d 76 00             	lea    0x0(%esi),%esi
80106284:	31 c0                	xor    %eax,%eax
80106286:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106289:	5b                   	pop    %ebx
8010628a:	5e                   	pop    %esi
8010628b:	5f                   	pop    %edi
8010628c:	5d                   	pop    %ebp
8010628d:	c3                   	ret    
8010628e:	83 ec 0c             	sub    $0xc,%esp
80106291:	68 b4 73 10 80       	push   $0x801073b4
80106296:	e8 9d a0 ff ff       	call   80100338 <panic>
8010629b:	90                   	nop

8010629c <seginit>:
8010629c:	55                   	push   %ebp
8010629d:	89 e5                	mov    %esp,%ebp
8010629f:	83 ec 18             	sub    $0x18,%esp
801062a2:	e8 39 d2 ff ff       	call   801034e0 <cpuid>
801062a7:	8d 14 80             	lea    (%eax,%eax,4),%edx
801062aa:	01 d2                	add    %edx,%edx
801062ac:	01 d0                	add    %edx,%eax
801062ae:	c1 e0 04             	shl    $0x4,%eax
801062b1:	c7 80 18 18 11 80 ff 	movl   $0xffff,-0x7feee7e8(%eax)
801062b8:	ff 00 00 
801062bb:	c7 80 1c 18 11 80 00 	movl   $0xcf9a00,-0x7feee7e4(%eax)
801062c2:	9a cf 00 
801062c5:	c7 80 20 18 11 80 ff 	movl   $0xffff,-0x7feee7e0(%eax)
801062cc:	ff 00 00 
801062cf:	c7 80 24 18 11 80 00 	movl   $0xcf9200,-0x7feee7dc(%eax)
801062d6:	92 cf 00 
801062d9:	c7 80 28 18 11 80 ff 	movl   $0xffff,-0x7feee7d8(%eax)
801062e0:	ff 00 00 
801062e3:	c7 80 2c 18 11 80 00 	movl   $0xcffa00,-0x7feee7d4(%eax)
801062ea:	fa cf 00 
801062ed:	c7 80 30 18 11 80 ff 	movl   $0xffff,-0x7feee7d0(%eax)
801062f4:	ff 00 00 
801062f7:	c7 80 34 18 11 80 00 	movl   $0xcff200,-0x7feee7cc(%eax)
801062fe:	f2 cf 00 
80106301:	05 10 18 11 80       	add    $0x80111810,%eax
80106306:	66 c7 45 f2 2f 00    	movw   $0x2f,-0xe(%ebp)
8010630c:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
80106310:	c1 e8 10             	shr    $0x10,%eax
80106313:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
80106317:	8d 45 f2             	lea    -0xe(%ebp),%eax
8010631a:	0f 01 10             	lgdtl  (%eax)
8010631d:	c9                   	leave  
8010631e:	c3                   	ret    
8010631f:	90                   	nop

80106320 <protectuvm>:
80106320:	55                   	push   %ebp
80106321:	89 e5                	mov    %esp,%ebp
80106323:	57                   	push   %edi
80106324:	56                   	push   %esi
80106325:	53                   	push   %ebx
80106326:	51                   	push   %ecx
80106327:	8b 75 08             	mov    0x8(%ebp),%esi
8010632a:	8b 5d 0c             	mov    0xc(%ebp),%ebx
8010632d:	8b 7d 10             	mov    0x10(%ebp),%edi
80106330:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80106336:	75 5f                	jne    80106397 <protectuvm+0x77>
80106338:	85 ff                	test   %edi,%edi
8010633a:	7e 5b                	jle    80106397 <protectuvm+0x77>
8010633c:	89 d8                	mov    %ebx,%eax
8010633e:	f7 d0                	not    %eax
80106340:	c1 e8 0c             	shr    $0xc,%eax
80106343:	39 f8                	cmp    %edi,%eax
80106345:	72 50                	jb     80106397 <protectuvm+0x77>
80106347:	89 f8                	mov    %edi,%eax
80106349:	c1 e0 0c             	shl    $0xc,%eax
8010634c:	01 d8                	add    %ebx,%eax
8010634e:	39 45 14             	cmp    %eax,0x14(%ebp)
80106351:	72 44                	jb     80106397 <protectuvm+0x77>
80106353:	89 da                	mov    %ebx,%edx
80106355:	31 c9                	xor    %ecx,%ecx
80106357:	eb 32                	jmp    8010638b <protectuvm+0x6b>
80106359:	8d 76 00             	lea    0x0(%esi),%esi
8010635c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106361:	89 d3                	mov    %edx,%ebx
80106363:	c1 eb 0a             	shr    $0xa,%ebx
80106366:	81 e3 fc 0f 00 00    	and    $0xffc,%ebx
8010636c:	8d 84 18 00 00 00 80 	lea    -0x80000000(%eax,%ebx,1),%eax
80106373:	85 c0                	test   %eax,%eax
80106375:	74 20                	je     80106397 <protectuvm+0x77>
80106377:	f6 00 01             	testb  $0x1,(%eax)
8010637a:	74 1b                	je     80106397 <protectuvm+0x77>
8010637c:	8d 41 01             	lea    0x1(%ecx),%eax
8010637f:	81 c2 00 10 00 00    	add    $0x1000,%edx
80106385:	39 c7                	cmp    %eax,%edi
80106387:	74 1b                	je     801063a4 <protectuvm+0x84>
80106389:	89 c1                	mov    %eax,%ecx
8010638b:	89 d0                	mov    %edx,%eax
8010638d:	c1 e8 16             	shr    $0x16,%eax
80106390:	8b 04 86             	mov    (%esi,%eax,4),%eax
80106393:	a8 01                	test   $0x1,%al
80106395:	75 c5                	jne    8010635c <protectuvm+0x3c>
80106397:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010639c:	5a                   	pop    %edx
8010639d:	5b                   	pop    %ebx
8010639e:	5e                   	pop    %esi
8010639f:	5f                   	pop    %edi
801063a0:	5d                   	pop    %ebp
801063a1:	c3                   	ret    
801063a2:	66 90                	xchg   %ax,%ax
801063a4:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801063a7:	31 ff                	xor    %edi,%edi
801063a9:	89 4d f0             	mov    %ecx,-0x10(%ebp)
801063ac:	8b 4d 18             	mov    0x18(%ebp),%ecx
801063af:	eb 35                	jmp    801063e6 <protectuvm+0xc6>
801063b1:	8d 76 00             	lea    0x0(%esi),%esi
801063b4:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801063b9:	89 da                	mov    %ebx,%edx
801063bb:	c1 ea 0a             	shr    $0xa,%edx
801063be:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
801063c4:	8d 94 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%edx
801063cb:	8b 02                	mov    (%edx),%eax
801063cd:	85 c9                	test   %ecx,%ecx
801063cf:	74 29                	je     801063fa <protectuvm+0xda>
801063d1:	83 c8 02             	or     $0x2,%eax
801063d4:	89 02                	mov    %eax,(%edx)
801063d6:	8d 47 01             	lea    0x1(%edi),%eax
801063d9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801063df:	39 7d f0             	cmp    %edi,-0x10(%ebp)
801063e2:	74 29                	je     8010640d <protectuvm+0xed>
801063e4:	89 c7                	mov    %eax,%edi
801063e6:	89 d8                	mov    %ebx,%eax
801063e8:	c1 e8 16             	shr    $0x16,%eax
801063eb:	8b 04 86             	mov    (%esi,%eax,4),%eax
801063ee:	a8 01                	test   $0x1,%al
801063f0:	75 c2                	jne    801063b4 <protectuvm+0x94>
801063f2:	31 d2                	xor    %edx,%edx
801063f4:	8b 02                	mov    (%edx),%eax
801063f6:	85 c9                	test   %ecx,%ecx
801063f8:	75 d7                	jne    801063d1 <protectuvm+0xb1>
801063fa:	83 e0 fd             	and    $0xfffffffd,%eax
801063fd:	89 02                	mov    %eax,(%edx)
801063ff:	8d 47 01             	lea    0x1(%edi),%eax
80106402:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106408:	39 7d f0             	cmp    %edi,-0x10(%ebp)
8010640b:	75 d7                	jne    801063e4 <protectuvm+0xc4>
8010640d:	31 c0                	xor    %eax,%eax
8010640f:	5a                   	pop    %edx
80106410:	5b                   	pop    %ebx
80106411:	5e                   	pop    %esi
80106412:	5f                   	pop    %edi
80106413:	5d                   	pop    %ebp
80106414:	c3                   	ret    
80106415:	8d 76 00             	lea    0x0(%esi),%esi

80106418 <switchkvm>:
80106418:	a1 c4 45 11 80       	mov    0x801145c4,%eax
8010641d:	05 00 00 00 80       	add    $0x80000000,%eax
80106422:	0f 22 d8             	mov    %eax,%cr3
80106425:	c3                   	ret    
80106426:	66 90                	xchg   %ax,%ax

80106428 <switchuvm>:
80106428:	55                   	push   %ebp
80106429:	89 e5                	mov    %esp,%ebp
8010642b:	57                   	push   %edi
8010642c:	56                   	push   %esi
8010642d:	53                   	push   %ebx
8010642e:	83 ec 1c             	sub    $0x1c,%esp
80106431:	8b 75 08             	mov    0x8(%ebp),%esi
80106434:	85 f6                	test   %esi,%esi
80106436:	0f 84 bf 00 00 00    	je     801064fb <switchuvm+0xd3>
8010643c:	8b 56 08             	mov    0x8(%esi),%edx
8010643f:	85 d2                	test   %edx,%edx
80106441:	0f 84 ce 00 00 00    	je     80106515 <switchuvm+0xed>
80106447:	8b 46 04             	mov    0x4(%esi),%eax
8010644a:	85 c0                	test   %eax,%eax
8010644c:	0f 84 b6 00 00 00    	je     80106508 <switchuvm+0xe0>
80106452:	e8 71 db ff ff       	call   80103fc8 <pushcli>
80106457:	e8 20 d0 ff ff       	call   8010347c <mycpu>
8010645c:	89 c3                	mov    %eax,%ebx
8010645e:	e8 19 d0 ff ff       	call   8010347c <mycpu>
80106463:	89 c7                	mov    %eax,%edi
80106465:	e8 12 d0 ff ff       	call   8010347c <mycpu>
8010646a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010646d:	e8 0a d0 ff ff       	call   8010347c <mycpu>
80106472:	66 c7 83 98 00 00 00 	movw   $0x67,0x98(%ebx)
80106479:	67 00 
8010647b:	83 c7 08             	add    $0x8,%edi
8010647e:	66 89 bb 9a 00 00 00 	mov    %di,0x9a(%ebx)
80106485:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80106488:	83 c1 08             	add    $0x8,%ecx
8010648b:	c1 e9 10             	shr    $0x10,%ecx
8010648e:	88 8b 9c 00 00 00    	mov    %cl,0x9c(%ebx)
80106494:	66 c7 83 9d 00 00 00 	movw   $0x4099,0x9d(%ebx)
8010649b:	99 40 
8010649d:	83 c0 08             	add    $0x8,%eax
801064a0:	c1 e8 18             	shr    $0x18,%eax
801064a3:	88 83 9f 00 00 00    	mov    %al,0x9f(%ebx)
801064a9:	e8 ce cf ff ff       	call   8010347c <mycpu>
801064ae:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
801064b5:	e8 c2 cf ff ff       	call   8010347c <mycpu>
801064ba:	66 c7 40 10 10 00    	movw   $0x10,0x10(%eax)
801064c0:	8b 5e 08             	mov    0x8(%esi),%ebx
801064c3:	e8 b4 cf ff ff       	call   8010347c <mycpu>
801064c8:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801064ce:	89 58 0c             	mov    %ebx,0xc(%eax)
801064d1:	e8 a6 cf ff ff       	call   8010347c <mycpu>
801064d6:	66 c7 40 6e ff ff    	movw   $0xffff,0x6e(%eax)
801064dc:	b8 28 00 00 00       	mov    $0x28,%eax
801064e1:	0f 00 d8             	ltr    %ax
801064e4:	8b 46 04             	mov    0x4(%esi),%eax
801064e7:	05 00 00 00 80       	add    $0x80000000,%eax
801064ec:	0f 22 d8             	mov    %eax,%cr3
801064ef:	8d 65 f4             	lea    -0xc(%ebp),%esp
801064f2:	5b                   	pop    %ebx
801064f3:	5e                   	pop    %esi
801064f4:	5f                   	pop    %edi
801064f5:	5d                   	pop    %ebp
801064f6:	e9 19 db ff ff       	jmp    80104014 <popcli>
801064fb:	83 ec 0c             	sub    $0xc,%esp
801064fe:	68 ba 73 10 80       	push   $0x801073ba
80106503:	e8 30 9e ff ff       	call   80100338 <panic>
80106508:	83 ec 0c             	sub    $0xc,%esp
8010650b:	68 e5 73 10 80       	push   $0x801073e5
80106510:	e8 23 9e ff ff       	call   80100338 <panic>
80106515:	83 ec 0c             	sub    $0xc,%esp
80106518:	68 d0 73 10 80       	push   $0x801073d0
8010651d:	e8 16 9e ff ff       	call   80100338 <panic>
80106522:	66 90                	xchg   %ax,%ax

80106524 <inituvm>:
80106524:	55                   	push   %ebp
80106525:	89 e5                	mov    %esp,%ebp
80106527:	57                   	push   %edi
80106528:	56                   	push   %esi
80106529:	53                   	push   %ebx
8010652a:	83 ec 1c             	sub    $0x1c,%esp
8010652d:	8b 45 08             	mov    0x8(%ebp),%eax
80106530:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106533:	8b 7d 0c             	mov    0xc(%ebp),%edi
80106536:	8b 75 10             	mov    0x10(%ebp),%esi
80106539:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
8010653f:	77 47                	ja     80106588 <inituvm+0x64>
80106541:	e8 82 be ff ff       	call   801023c8 <kalloc>
80106546:	89 c3                	mov    %eax,%ebx
80106548:	50                   	push   %eax
80106549:	68 00 10 00 00       	push   $0x1000
8010654e:	6a 00                	push   $0x0
80106550:	53                   	push   %ebx
80106551:	e8 76 dc ff ff       	call   801041cc <memset>
80106556:	5a                   	pop    %edx
80106557:	59                   	pop    %ecx
80106558:	6a 06                	push   $0x6
8010655a:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80106560:	50                   	push   %eax
80106561:	b9 00 10 00 00       	mov    $0x1000,%ecx
80106566:	31 d2                	xor    %edx,%edx
80106568:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010656b:	e8 4c fc ff ff       	call   801061bc <mappages>
80106570:	83 c4 10             	add    $0x10,%esp
80106573:	89 75 10             	mov    %esi,0x10(%ebp)
80106576:	89 7d 0c             	mov    %edi,0xc(%ebp)
80106579:	89 5d 08             	mov    %ebx,0x8(%ebp)
8010657c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010657f:	5b                   	pop    %ebx
80106580:	5e                   	pop    %esi
80106581:	5f                   	pop    %edi
80106582:	5d                   	pop    %ebp
80106583:	e9 c0 dc ff ff       	jmp    80104248 <memmove>
80106588:	83 ec 0c             	sub    $0xc,%esp
8010658b:	68 f9 73 10 80       	push   $0x801073f9
80106590:	e8 a3 9d ff ff       	call   80100338 <panic>
80106595:	8d 76 00             	lea    0x0(%esi),%esi

80106598 <loaduvm>:
80106598:	55                   	push   %ebp
80106599:	89 e5                	mov    %esp,%ebp
8010659b:	57                   	push   %edi
8010659c:	56                   	push   %esi
8010659d:	53                   	push   %ebx
8010659e:	83 ec 0c             	sub    $0xc,%esp
801065a1:	8b 7d 18             	mov    0x18(%ebp),%edi
801065a4:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801065a7:	81 e3 ff 0f 00 00    	and    $0xfff,%ebx
801065ad:	0f 85 9a 00 00 00    	jne    8010664d <loaduvm+0xb5>
801065b3:	85 ff                	test   %edi,%edi
801065b5:	74 7c                	je     80106633 <loaduvm+0x9b>
801065b7:	90                   	nop
801065b8:	8b 45 0c             	mov    0xc(%ebp),%eax
801065bb:	01 d8                	add    %ebx,%eax
801065bd:	89 c2                	mov    %eax,%edx
801065bf:	c1 ea 16             	shr    $0x16,%edx
801065c2:	8b 4d 08             	mov    0x8(%ebp),%ecx
801065c5:	8b 14 91             	mov    (%ecx,%edx,4),%edx
801065c8:	f6 c2 01             	test   $0x1,%dl
801065cb:	75 0f                	jne    801065dc <loaduvm+0x44>
801065cd:	83 ec 0c             	sub    $0xc,%esp
801065d0:	68 13 74 10 80       	push   $0x80107413
801065d5:	e8 5e 9d ff ff       	call   80100338 <panic>
801065da:	66 90                	xchg   %ax,%ax
801065dc:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
801065e2:	c1 e8 0a             	shr    $0xa,%eax
801065e5:	25 fc 0f 00 00       	and    $0xffc,%eax
801065ea:	8d 8c 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%ecx
801065f1:	85 c9                	test   %ecx,%ecx
801065f3:	74 d8                	je     801065cd <loaduvm+0x35>
801065f5:	89 fe                	mov    %edi,%esi
801065f7:	29 de                	sub    %ebx,%esi
801065f9:	81 fe 00 10 00 00    	cmp    $0x1000,%esi
801065ff:	76 05                	jbe    80106606 <loaduvm+0x6e>
80106601:	be 00 10 00 00       	mov    $0x1000,%esi
80106606:	56                   	push   %esi
80106607:	8b 45 14             	mov    0x14(%ebp),%eax
8010660a:	01 d8                	add    %ebx,%eax
8010660c:	50                   	push   %eax
8010660d:	8b 01                	mov    (%ecx),%eax
8010660f:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106614:	05 00 00 00 80       	add    $0x80000000,%eax
80106619:	50                   	push   %eax
8010661a:	ff 75 10             	pushl  0x10(%ebp)
8010661d:	e8 c2 b2 ff ff       	call   801018e4 <readi>
80106622:	83 c4 10             	add    $0x10,%esp
80106625:	39 f0                	cmp    %esi,%eax
80106627:	75 17                	jne    80106640 <loaduvm+0xa8>
80106629:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010662f:	39 fb                	cmp    %edi,%ebx
80106631:	72 85                	jb     801065b8 <loaduvm+0x20>
80106633:	31 c0                	xor    %eax,%eax
80106635:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106638:	5b                   	pop    %ebx
80106639:	5e                   	pop    %esi
8010663a:	5f                   	pop    %edi
8010663b:	5d                   	pop    %ebp
8010663c:	c3                   	ret    
8010663d:	8d 76 00             	lea    0x0(%esi),%esi
80106640:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106645:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106648:	5b                   	pop    %ebx
80106649:	5e                   	pop    %esi
8010664a:	5f                   	pop    %edi
8010664b:	5d                   	pop    %ebp
8010664c:	c3                   	ret    
8010664d:	83 ec 0c             	sub    $0xc,%esp
80106650:	68 b4 74 10 80       	push   $0x801074b4
80106655:	e8 de 9c ff ff       	call   80100338 <panic>
8010665a:	66 90                	xchg   %ax,%ax

8010665c <allocuvm>:
8010665c:	55                   	push   %ebp
8010665d:	89 e5                	mov    %esp,%ebp
8010665f:	57                   	push   %edi
80106660:	56                   	push   %esi
80106661:	53                   	push   %ebx
80106662:	83 ec 1c             	sub    $0x1c,%esp
80106665:	8b 75 10             	mov    0x10(%ebp),%esi
80106668:	85 f6                	test   %esi,%esi
8010666a:	0f 88 8a 00 00 00    	js     801066fa <allocuvm+0x9e>
80106670:	89 f2                	mov    %esi,%edx
80106672:	3b 75 0c             	cmp    0xc(%ebp),%esi
80106675:	0f 82 8d 00 00 00    	jb     80106708 <allocuvm+0xac>
8010667b:	8b 45 0c             	mov    0xc(%ebp),%eax
8010667e:	05 ff 0f 00 00       	add    $0xfff,%eax
80106683:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106688:	89 c7                	mov    %eax,%edi
8010668a:	39 f0                	cmp    %esi,%eax
8010668c:	73 7d                	jae    8010670b <allocuvm+0xaf>
8010668e:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80106691:	eb 3a                	jmp    801066cd <allocuvm+0x71>
80106693:	90                   	nop
80106694:	50                   	push   %eax
80106695:	68 00 10 00 00       	push   $0x1000
8010669a:	6a 00                	push   $0x0
8010669c:	53                   	push   %ebx
8010669d:	e8 2a db ff ff       	call   801041cc <memset>
801066a2:	5a                   	pop    %edx
801066a3:	59                   	pop    %ecx
801066a4:	6a 06                	push   $0x6
801066a6:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801066ac:	50                   	push   %eax
801066ad:	b9 00 10 00 00       	mov    $0x1000,%ecx
801066b2:	89 fa                	mov    %edi,%edx
801066b4:	8b 45 08             	mov    0x8(%ebp),%eax
801066b7:	e8 00 fb ff ff       	call   801061bc <mappages>
801066bc:	83 c4 10             	add    $0x10,%esp
801066bf:	85 c0                	test   %eax,%eax
801066c1:	78 55                	js     80106718 <allocuvm+0xbc>
801066c3:	81 c7 00 10 00 00    	add    $0x1000,%edi
801066c9:	39 f7                	cmp    %esi,%edi
801066cb:	73 7f                	jae    8010674c <allocuvm+0xf0>
801066cd:	e8 f6 bc ff ff       	call   801023c8 <kalloc>
801066d2:	89 c3                	mov    %eax,%ebx
801066d4:	85 c0                	test   %eax,%eax
801066d6:	75 bc                	jne    80106694 <allocuvm+0x38>
801066d8:	83 ec 0c             	sub    $0xc,%esp
801066db:	68 31 74 10 80       	push   $0x80107431
801066e0:	e8 43 9f ff ff       	call   80100628 <cprintf>
801066e5:	83 c4 10             	add    $0x10,%esp
801066e8:	3b 75 0c             	cmp    0xc(%ebp),%esi
801066eb:	74 0d                	je     801066fa <allocuvm+0x9e>
801066ed:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801066f0:	89 f2                	mov    %esi,%edx
801066f2:	8b 45 08             	mov    0x8(%ebp),%eax
801066f5:	e8 12 fa ff ff       	call   8010610c <deallocuvm.part.0>
801066fa:	31 d2                	xor    %edx,%edx
801066fc:	89 d0                	mov    %edx,%eax
801066fe:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106701:	5b                   	pop    %ebx
80106702:	5e                   	pop    %esi
80106703:	5f                   	pop    %edi
80106704:	5d                   	pop    %ebp
80106705:	c3                   	ret    
80106706:	66 90                	xchg   %ax,%ax
80106708:	8b 55 0c             	mov    0xc(%ebp),%edx
8010670b:	89 d0                	mov    %edx,%eax
8010670d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106710:	5b                   	pop    %ebx
80106711:	5e                   	pop    %esi
80106712:	5f                   	pop    %edi
80106713:	5d                   	pop    %ebp
80106714:	c3                   	ret    
80106715:	8d 76 00             	lea    0x0(%esi),%esi
80106718:	83 ec 0c             	sub    $0xc,%esp
8010671b:	68 49 74 10 80       	push   $0x80107449
80106720:	e8 03 9f ff ff       	call   80100628 <cprintf>
80106725:	83 c4 10             	add    $0x10,%esp
80106728:	3b 75 0c             	cmp    0xc(%ebp),%esi
8010672b:	74 0d                	je     8010673a <allocuvm+0xde>
8010672d:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80106730:	89 f2                	mov    %esi,%edx
80106732:	8b 45 08             	mov    0x8(%ebp),%eax
80106735:	e8 d2 f9 ff ff       	call   8010610c <deallocuvm.part.0>
8010673a:	83 ec 0c             	sub    $0xc,%esp
8010673d:	53                   	push   %ebx
8010673e:	e8 f5 ba ff ff       	call   80102238 <kfree>
80106743:	83 c4 10             	add    $0x10,%esp
80106746:	31 d2                	xor    %edx,%edx
80106748:	eb b2                	jmp    801066fc <allocuvm+0xa0>
8010674a:	66 90                	xchg   %ax,%ax
8010674c:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010674f:	89 d0                	mov    %edx,%eax
80106751:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106754:	5b                   	pop    %ebx
80106755:	5e                   	pop    %esi
80106756:	5f                   	pop    %edi
80106757:	5d                   	pop    %ebp
80106758:	c3                   	ret    
80106759:	8d 76 00             	lea    0x0(%esi),%esi

8010675c <deallocuvm>:
8010675c:	55                   	push   %ebp
8010675d:	89 e5                	mov    %esp,%ebp
8010675f:	8b 45 08             	mov    0x8(%ebp),%eax
80106762:	8b 55 0c             	mov    0xc(%ebp),%edx
80106765:	8b 4d 10             	mov    0x10(%ebp),%ecx
80106768:	39 d1                	cmp    %edx,%ecx
8010676a:	73 08                	jae    80106774 <deallocuvm+0x18>
8010676c:	5d                   	pop    %ebp
8010676d:	e9 9a f9 ff ff       	jmp    8010610c <deallocuvm.part.0>
80106772:	66 90                	xchg   %ax,%ax
80106774:	89 d0                	mov    %edx,%eax
80106776:	5d                   	pop    %ebp
80106777:	c3                   	ret    

80106778 <freevm>:
80106778:	55                   	push   %ebp
80106779:	89 e5                	mov    %esp,%ebp
8010677b:	57                   	push   %edi
8010677c:	56                   	push   %esi
8010677d:	53                   	push   %ebx
8010677e:	83 ec 0c             	sub    $0xc,%esp
80106781:	8b 75 08             	mov    0x8(%ebp),%esi
80106784:	85 f6                	test   %esi,%esi
80106786:	74 51                	je     801067d9 <freevm+0x61>
80106788:	31 c9                	xor    %ecx,%ecx
8010678a:	ba 00 00 00 80       	mov    $0x80000000,%edx
8010678f:	89 f0                	mov    %esi,%eax
80106791:	e8 76 f9 ff ff       	call   8010610c <deallocuvm.part.0>
80106796:	89 f3                	mov    %esi,%ebx
80106798:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
8010679e:	eb 07                	jmp    801067a7 <freevm+0x2f>
801067a0:	83 c3 04             	add    $0x4,%ebx
801067a3:	39 fb                	cmp    %edi,%ebx
801067a5:	74 23                	je     801067ca <freevm+0x52>
801067a7:	8b 03                	mov    (%ebx),%eax
801067a9:	a8 01                	test   $0x1,%al
801067ab:	74 f3                	je     801067a0 <freevm+0x28>
801067ad:	83 ec 0c             	sub    $0xc,%esp
801067b0:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801067b5:	05 00 00 00 80       	add    $0x80000000,%eax
801067ba:	50                   	push   %eax
801067bb:	e8 78 ba ff ff       	call   80102238 <kfree>
801067c0:	83 c4 10             	add    $0x10,%esp
801067c3:	83 c3 04             	add    $0x4,%ebx
801067c6:	39 fb                	cmp    %edi,%ebx
801067c8:	75 dd                	jne    801067a7 <freevm+0x2f>
801067ca:	89 75 08             	mov    %esi,0x8(%ebp)
801067cd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801067d0:	5b                   	pop    %ebx
801067d1:	5e                   	pop    %esi
801067d2:	5f                   	pop    %edi
801067d3:	5d                   	pop    %ebp
801067d4:	e9 5f ba ff ff       	jmp    80102238 <kfree>
801067d9:	83 ec 0c             	sub    $0xc,%esp
801067dc:	68 65 74 10 80       	push   $0x80107465
801067e1:	e8 52 9b ff ff       	call   80100338 <panic>
801067e6:	66 90                	xchg   %ax,%ax

801067e8 <setupkvm>:
801067e8:	55                   	push   %ebp
801067e9:	89 e5                	mov    %esp,%ebp
801067eb:	56                   	push   %esi
801067ec:	53                   	push   %ebx
801067ed:	e8 d6 bb ff ff       	call   801023c8 <kalloc>
801067f2:	85 c0                	test   %eax,%eax
801067f4:	74 5a                	je     80106850 <setupkvm+0x68>
801067f6:	89 c6                	mov    %eax,%esi
801067f8:	50                   	push   %eax
801067f9:	68 00 10 00 00       	push   $0x1000
801067fe:	6a 00                	push   $0x0
80106800:	56                   	push   %esi
80106801:	e8 c6 d9 ff ff       	call   801041cc <memset>
80106806:	83 c4 10             	add    $0x10,%esp
80106809:	bb 20 a4 10 80       	mov    $0x8010a420,%ebx
8010680e:	8b 43 04             	mov    0x4(%ebx),%eax
80106811:	8b 4b 08             	mov    0x8(%ebx),%ecx
80106814:	29 c1                	sub    %eax,%ecx
80106816:	8b 13                	mov    (%ebx),%edx
80106818:	83 ec 08             	sub    $0x8,%esp
8010681b:	ff 73 0c             	pushl  0xc(%ebx)
8010681e:	50                   	push   %eax
8010681f:	89 f0                	mov    %esi,%eax
80106821:	e8 96 f9 ff ff       	call   801061bc <mappages>
80106826:	83 c4 10             	add    $0x10,%esp
80106829:	85 c0                	test   %eax,%eax
8010682b:	78 17                	js     80106844 <setupkvm+0x5c>
8010682d:	83 c3 10             	add    $0x10,%ebx
80106830:	81 fb 60 a4 10 80    	cmp    $0x8010a460,%ebx
80106836:	75 d6                	jne    8010680e <setupkvm+0x26>
80106838:	89 f0                	mov    %esi,%eax
8010683a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010683d:	5b                   	pop    %ebx
8010683e:	5e                   	pop    %esi
8010683f:	5d                   	pop    %ebp
80106840:	c3                   	ret    
80106841:	8d 76 00             	lea    0x0(%esi),%esi
80106844:	83 ec 0c             	sub    $0xc,%esp
80106847:	56                   	push   %esi
80106848:	e8 2b ff ff ff       	call   80106778 <freevm>
8010684d:	83 c4 10             	add    $0x10,%esp
80106850:	31 f6                	xor    %esi,%esi
80106852:	89 f0                	mov    %esi,%eax
80106854:	8d 65 f8             	lea    -0x8(%ebp),%esp
80106857:	5b                   	pop    %ebx
80106858:	5e                   	pop    %esi
80106859:	5d                   	pop    %ebp
8010685a:	c3                   	ret    
8010685b:	90                   	nop

8010685c <kvmalloc>:
8010685c:	55                   	push   %ebp
8010685d:	89 e5                	mov    %esp,%ebp
8010685f:	83 ec 08             	sub    $0x8,%esp
80106862:	e8 81 ff ff ff       	call   801067e8 <setupkvm>
80106867:	a3 c4 45 11 80       	mov    %eax,0x801145c4
8010686c:	05 00 00 00 80       	add    $0x80000000,%eax
80106871:	0f 22 d8             	mov    %eax,%cr3
80106874:	c9                   	leave  
80106875:	c3                   	ret    
80106876:	66 90                	xchg   %ax,%ax

80106878 <clearpteu>:
80106878:	55                   	push   %ebp
80106879:	89 e5                	mov    %esp,%ebp
8010687b:	83 ec 08             	sub    $0x8,%esp
8010687e:	8b 55 0c             	mov    0xc(%ebp),%edx
80106881:	c1 ea 16             	shr    $0x16,%edx
80106884:	8b 45 08             	mov    0x8(%ebp),%eax
80106887:	8b 04 90             	mov    (%eax,%edx,4),%eax
8010688a:	a8 01                	test   $0x1,%al
8010688c:	75 0e                	jne    8010689c <clearpteu+0x24>
8010688e:	83 ec 0c             	sub    $0xc,%esp
80106891:	68 76 74 10 80       	push   $0x80107476
80106896:	e8 9d 9a ff ff       	call   80100338 <panic>
8010689b:	90                   	nop
8010689c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801068a1:	89 c2                	mov    %eax,%edx
801068a3:	8b 45 0c             	mov    0xc(%ebp),%eax
801068a6:	c1 e8 0a             	shr    $0xa,%eax
801068a9:	25 fc 0f 00 00       	and    $0xffc,%eax
801068ae:	8d 84 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%eax
801068b5:	85 c0                	test   %eax,%eax
801068b7:	74 d5                	je     8010688e <clearpteu+0x16>
801068b9:	83 20 fb             	andl   $0xfffffffb,(%eax)
801068bc:	c9                   	leave  
801068bd:	c3                   	ret    
801068be:	66 90                	xchg   %ax,%ax

801068c0 <copyuvm>:
801068c0:	55                   	push   %ebp
801068c1:	89 e5                	mov    %esp,%ebp
801068c3:	57                   	push   %edi
801068c4:	56                   	push   %esi
801068c5:	53                   	push   %ebx
801068c6:	83 ec 1c             	sub    $0x1c,%esp
801068c9:	e8 1a ff ff ff       	call   801067e8 <setupkvm>
801068ce:	89 45 e0             	mov    %eax,-0x20(%ebp)
801068d1:	85 c0                	test   %eax,%eax
801068d3:	0f 84 d5 00 00 00    	je     801069ae <copyuvm+0xee>
801068d9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801068dc:	85 db                	test   %ebx,%ebx
801068de:	0f 84 a5 00 00 00    	je     80106989 <copyuvm+0xc9>
801068e4:	31 ff                	xor    %edi,%edi
801068e6:	66 90                	xchg   %ax,%ax
801068e8:	89 f8                	mov    %edi,%eax
801068ea:	c1 e8 16             	shr    $0x16,%eax
801068ed:	8b 4d 08             	mov    0x8(%ebp),%ecx
801068f0:	8b 04 81             	mov    (%ecx,%eax,4),%eax
801068f3:	a8 01                	test   $0x1,%al
801068f5:	75 0d                	jne    80106904 <copyuvm+0x44>
801068f7:	83 ec 0c             	sub    $0xc,%esp
801068fa:	68 80 74 10 80       	push   $0x80107480
801068ff:	e8 34 9a ff ff       	call   80100338 <panic>
80106904:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106909:	89 fa                	mov    %edi,%edx
8010690b:	c1 ea 0a             	shr    $0xa,%edx
8010690e:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80106914:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
8010691b:	85 c0                	test   %eax,%eax
8010691d:	74 d8                	je     801068f7 <copyuvm+0x37>
8010691f:	8b 18                	mov    (%eax),%ebx
80106921:	f6 c3 01             	test   $0x1,%bl
80106924:	0f 84 96 00 00 00    	je     801069c0 <copyuvm+0x100>
8010692a:	89 d8                	mov    %ebx,%eax
8010692c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106931:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106934:	81 e3 ff 0f 00 00    	and    $0xfff,%ebx
8010693a:	e8 89 ba ff ff       	call   801023c8 <kalloc>
8010693f:	89 c6                	mov    %eax,%esi
80106941:	85 c0                	test   %eax,%eax
80106943:	74 5b                	je     801069a0 <copyuvm+0xe0>
80106945:	50                   	push   %eax
80106946:	68 00 10 00 00       	push   $0x1000
8010694b:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010694e:	05 00 00 00 80       	add    $0x80000000,%eax
80106953:	50                   	push   %eax
80106954:	56                   	push   %esi
80106955:	e8 ee d8 ff ff       	call   80104248 <memmove>
8010695a:	5a                   	pop    %edx
8010695b:	59                   	pop    %ecx
8010695c:	53                   	push   %ebx
8010695d:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
80106963:	50                   	push   %eax
80106964:	b9 00 10 00 00       	mov    $0x1000,%ecx
80106969:	89 fa                	mov    %edi,%edx
8010696b:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010696e:	e8 49 f8 ff ff       	call   801061bc <mappages>
80106973:	83 c4 10             	add    $0x10,%esp
80106976:	85 c0                	test   %eax,%eax
80106978:	78 1a                	js     80106994 <copyuvm+0xd4>
8010697a:	81 c7 00 10 00 00    	add    $0x1000,%edi
80106980:	3b 7d 0c             	cmp    0xc(%ebp),%edi
80106983:	0f 82 5f ff ff ff    	jb     801068e8 <copyuvm+0x28>
80106989:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010698c:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010698f:	5b                   	pop    %ebx
80106990:	5e                   	pop    %esi
80106991:	5f                   	pop    %edi
80106992:	5d                   	pop    %ebp
80106993:	c3                   	ret    
80106994:	83 ec 0c             	sub    $0xc,%esp
80106997:	56                   	push   %esi
80106998:	e8 9b b8 ff ff       	call   80102238 <kfree>
8010699d:	83 c4 10             	add    $0x10,%esp
801069a0:	83 ec 0c             	sub    $0xc,%esp
801069a3:	ff 75 e0             	pushl  -0x20(%ebp)
801069a6:	e8 cd fd ff ff       	call   80106778 <freevm>
801069ab:	83 c4 10             	add    $0x10,%esp
801069ae:	c7 45 e0 00 00 00 00 	movl   $0x0,-0x20(%ebp)
801069b5:	8b 45 e0             	mov    -0x20(%ebp),%eax
801069b8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801069bb:	5b                   	pop    %ebx
801069bc:	5e                   	pop    %esi
801069bd:	5f                   	pop    %edi
801069be:	5d                   	pop    %ebp
801069bf:	c3                   	ret    
801069c0:	83 ec 0c             	sub    $0xc,%esp
801069c3:	68 9a 74 10 80       	push   $0x8010749a
801069c8:	e8 6b 99 ff ff       	call   80100338 <panic>
801069cd:	8d 76 00             	lea    0x0(%esi),%esi

801069d0 <uva2ka>:
801069d0:	55                   	push   %ebp
801069d1:	89 e5                	mov    %esp,%ebp
801069d3:	8b 55 0c             	mov    0xc(%ebp),%edx
801069d6:	c1 ea 16             	shr    $0x16,%edx
801069d9:	8b 45 08             	mov    0x8(%ebp),%eax
801069dc:	8b 04 90             	mov    (%eax,%edx,4),%eax
801069df:	a8 01                	test   $0x1,%al
801069e1:	0f 84 f3 00 00 00    	je     80106ada <uva2ka.cold>
801069e7:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801069ec:	89 c2                	mov    %eax,%edx
801069ee:	8b 45 0c             	mov    0xc(%ebp),%eax
801069f1:	c1 e8 0c             	shr    $0xc,%eax
801069f4:	25 ff 03 00 00       	and    $0x3ff,%eax
801069f9:	8b 84 82 00 00 00 80 	mov    -0x80000000(%edx,%eax,4),%eax
80106a00:	89 c2                	mov    %eax,%edx
80106a02:	83 e2 05             	and    $0x5,%edx
80106a05:	83 fa 05             	cmp    $0x5,%edx
80106a08:	75 0e                	jne    80106a18 <uva2ka+0x48>
80106a0a:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106a0f:	05 00 00 00 80       	add    $0x80000000,%eax
80106a14:	5d                   	pop    %ebp
80106a15:	c3                   	ret    
80106a16:	66 90                	xchg   %ax,%ax
80106a18:	31 c0                	xor    %eax,%eax
80106a1a:	5d                   	pop    %ebp
80106a1b:	c3                   	ret    

80106a1c <copyout>:
80106a1c:	55                   	push   %ebp
80106a1d:	89 e5                	mov    %esp,%ebp
80106a1f:	57                   	push   %edi
80106a20:	56                   	push   %esi
80106a21:	53                   	push   %ebx
80106a22:	83 ec 0c             	sub    $0xc,%esp
80106a25:	8b 45 0c             	mov    0xc(%ebp),%eax
80106a28:	8b 7d 10             	mov    0x10(%ebp),%edi
80106a2b:	8b 4d 14             	mov    0x14(%ebp),%ecx
80106a2e:	85 c9                	test   %ecx,%ecx
80106a30:	0f 84 9a 00 00 00    	je     80106ad0 <copyout+0xb4>
80106a36:	89 fe                	mov    %edi,%esi
80106a38:	eb 45                	jmp    80106a7f <copyout+0x63>
80106a3a:	66 90                	xchg   %ax,%ax
80106a3c:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80106a42:	8d 8b 00 00 00 80    	lea    -0x80000000(%ebx),%ecx
80106a48:	81 fb 00 00 00 80    	cmp    $0x80000000,%ebx
80106a4e:	74 71                	je     80106ac1 <copyout+0xa5>
80106a50:	89 fb                	mov    %edi,%ebx
80106a52:	29 c3                	sub    %eax,%ebx
80106a54:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106a5a:	39 5d 14             	cmp    %ebx,0x14(%ebp)
80106a5d:	73 03                	jae    80106a62 <copyout+0x46>
80106a5f:	8b 5d 14             	mov    0x14(%ebp),%ebx
80106a62:	52                   	push   %edx
80106a63:	53                   	push   %ebx
80106a64:	56                   	push   %esi
80106a65:	29 f8                	sub    %edi,%eax
80106a67:	01 c1                	add    %eax,%ecx
80106a69:	51                   	push   %ecx
80106a6a:	e8 d9 d7 ff ff       	call   80104248 <memmove>
80106a6f:	01 de                	add    %ebx,%esi
80106a71:	8d 87 00 10 00 00    	lea    0x1000(%edi),%eax
80106a77:	83 c4 10             	add    $0x10,%esp
80106a7a:	29 5d 14             	sub    %ebx,0x14(%ebp)
80106a7d:	74 51                	je     80106ad0 <copyout+0xb4>
80106a7f:	89 c7                	mov    %eax,%edi
80106a81:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
80106a87:	89 c1                	mov    %eax,%ecx
80106a89:	c1 e9 16             	shr    $0x16,%ecx
80106a8c:	8b 55 08             	mov    0x8(%ebp),%edx
80106a8f:	8b 0c 8a             	mov    (%edx,%ecx,4),%ecx
80106a92:	f6 c1 01             	test   $0x1,%cl
80106a95:	0f 84 46 00 00 00    	je     80106ae1 <copyout.cold>
80106a9b:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
80106aa1:	89 fb                	mov    %edi,%ebx
80106aa3:	c1 eb 0c             	shr    $0xc,%ebx
80106aa6:	81 e3 ff 03 00 00    	and    $0x3ff,%ebx
80106aac:	8b 9c 99 00 00 00 80 	mov    -0x80000000(%ecx,%ebx,4),%ebx
80106ab3:	89 d9                	mov    %ebx,%ecx
80106ab5:	83 e1 05             	and    $0x5,%ecx
80106ab8:	83 f9 05             	cmp    $0x5,%ecx
80106abb:	0f 84 7b ff ff ff    	je     80106a3c <copyout+0x20>
80106ac1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106ac6:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106ac9:	5b                   	pop    %ebx
80106aca:	5e                   	pop    %esi
80106acb:	5f                   	pop    %edi
80106acc:	5d                   	pop    %ebp
80106acd:	c3                   	ret    
80106ace:	66 90                	xchg   %ax,%ax
80106ad0:	31 c0                	xor    %eax,%eax
80106ad2:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106ad5:	5b                   	pop    %ebx
80106ad6:	5e                   	pop    %esi
80106ad7:	5f                   	pop    %edi
80106ad8:	5d                   	pop    %ebp
80106ad9:	c3                   	ret    

80106ada <uva2ka.cold>:
80106ada:	a1 00 00 00 00       	mov    0x0,%eax
80106adf:	0f 0b                	ud2    

80106ae1 <copyout.cold>:
80106ae1:	a1 00 00 00 00       	mov    0x0,%eax
80106ae6:	0f 0b                	ud2    
