
_prottest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
   f:	83 ec 0c             	sub    $0xc,%esp
  12:	68 00 10 00 00       	push   $0x1000
  17:	e8 77 03 00 00       	call   393 <sbrk>
  1c:	83 c4 10             	add    $0x10,%esp
  1f:	83 f8 ff             	cmp    $0xffffffff,%eax
  22:	0f 84 db 00 00 00    	je     103 <main+0x103>
  28:	89 c3                	mov    %eax,%ebx
  2a:	c6 00 41             	movb   $0x41,(%eax)
  2d:	83 ec 08             	sub    $0x8,%esp
  30:	6a 01                	push   $0x1
  32:	50                   	push   %eax
  33:	e8 73 03 00 00       	call   3ab <mprotect>
  38:	83 c4 10             	add    $0x10,%esp
  3b:	85 c0                	test   %eax,%eax
  3d:	0f 84 a7 00 00 00    	je     ea <main+0xea>
  43:	50                   	push   %eax
  44:	50                   	push   %eax
  45:	68 4b 07 00 00       	push   $0x74b
  4a:	6a 01                	push   $0x1
  4c:	e8 ff 03 00 00       	call   450 <printf>
  51:	83 c4 10             	add    $0x10,%esp
  54:	e8 aa 02 00 00       	call   303 <fork>
  59:	85 c0                	test   %eax,%eax
  5b:	0f 84 b5 00 00 00    	je     116 <main+0x116>
  61:	7e 05                	jle    68 <main+0x68>
  63:	e8 ab 02 00 00       	call   313 <wait>
  68:	50                   	push   %eax
  69:	0f be 03             	movsbl (%ebx),%eax
  6c:	50                   	push   %eax
  6d:	68 5c 07 00 00       	push   $0x75c
  72:	6a 01                	push   $0x1
  74:	e8 d7 03 00 00       	call   450 <printf>
  79:	58                   	pop    %eax
  7a:	5a                   	pop    %edx
  7b:	6a 01                	push   $0x1
  7d:	53                   	push   %ebx
  7e:	e8 30 03 00 00       	call   3b3 <munprotect>
  83:	83 c4 10             	add    $0x10,%esp
  86:	85 c0                	test   %eax,%eax
  88:	0f 84 9e 00 00 00    	je     12c <main+0x12c>
  8e:	50                   	push   %eax
  8f:	50                   	push   %eax
  90:	6a 01                	push   $0x1
  92:	8d 43 01             	lea    0x1(%ebx),%eax
  95:	50                   	push   %eax
  96:	e8 10 03 00 00       	call   3ab <mprotect>
  9b:	83 c4 0c             	add    $0xc,%esp
  9e:	50                   	push   %eax
  9f:	68 8f 07 00 00       	push   $0x78f
  a4:	6a 01                	push   $0x1
  a6:	e8 a5 03 00 00       	call   450 <printf>
  ab:	5a                   	pop    %edx
  ac:	59                   	pop    %ecx
  ad:	6a 00                	push   $0x0
  af:	53                   	push   %ebx
  b0:	e8 f6 02 00 00       	call   3ab <mprotect>
  b5:	83 c4 0c             	add    $0xc,%esp
  b8:	50                   	push   %eax
  b9:	68 a7 07 00 00       	push   $0x7a7
  be:	6a 01                	push   $0x1
  c0:	e8 8b 03 00 00       	call   450 <printf>
  c5:	58                   	pop    %eax
  c6:	5a                   	pop    %edx
  c7:	6a 01                	push   $0x1
  c9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
  cf:	53                   	push   %ebx
  d0:	e8 d6 02 00 00       	call   3ab <mprotect>
  d5:	83 c4 0c             	add    $0xc,%esp
  d8:	50                   	push   %eax
  d9:	68 c1 07 00 00       	push   $0x7c1
  de:	6a 01                	push   $0x1
  e0:	e8 6b 03 00 00       	call   450 <printf>
  e5:	e8 21 02 00 00       	call   30b <exit>
  ea:	50                   	push   %eax
  eb:	0f be 03             	movsbl (%ebx),%eax
  ee:	50                   	push   %eax
  ef:	68 dc 07 00 00       	push   $0x7dc
  f4:	6a 01                	push   $0x1
  f6:	e8 55 03 00 00       	call   450 <printf>
  fb:	83 c4 10             	add    $0x10,%esp
  fe:	e9 51 ff ff ff       	jmp    54 <main+0x54>
 103:	50                   	push   %eax
 104:	50                   	push   %eax
 105:	68 34 07 00 00       	push   $0x734
 10a:	6a 01                	push   $0x1
 10c:	e8 3f 03 00 00       	call   450 <printf>
 111:	e8 f5 01 00 00       	call   30b <exit>
 116:	c6 03 42             	movb   $0x42,(%ebx)
 119:	51                   	push   %ecx
 11a:	51                   	push   %ecx
 11b:	68 fc 07 00 00       	push   $0x7fc
 120:	6a 01                	push   $0x1
 122:	e8 29 03 00 00       	call   450 <printf>
 127:	e8 df 01 00 00       	call   30b <exit>
 12c:	c6 03 43             	movb   $0x43,(%ebx)
 12f:	51                   	push   %ecx
 130:	6a 43                	push   $0x43
 132:	68 73 07 00 00       	push   $0x773
 137:	6a 01                	push   $0x1
 139:	e8 12 03 00 00       	call   450 <printf>
 13e:	83 c4 10             	add    $0x10,%esp
 141:	e9 48 ff ff ff       	jmp    8e <main+0x8e>
 146:	66 90                	xchg   %ax,%ax

00000148 <strcpy>:
 148:	55                   	push   %ebp
 149:	89 e5                	mov    %esp,%ebp
 14b:	53                   	push   %ebx
 14c:	8b 4d 08             	mov    0x8(%ebp),%ecx
 14f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 152:	31 c0                	xor    %eax,%eax
 154:	8a 14 03             	mov    (%ebx,%eax,1),%dl
 157:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 15a:	40                   	inc    %eax
 15b:	84 d2                	test   %dl,%dl
 15d:	75 f5                	jne    154 <strcpy+0xc>
 15f:	89 c8                	mov    %ecx,%eax
 161:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 164:	c9                   	leave  
 165:	c3                   	ret    
 166:	66 90                	xchg   %ax,%ax

00000168 <strcmp>:
 168:	55                   	push   %ebp
 169:	89 e5                	mov    %esp,%ebp
 16b:	53                   	push   %ebx
 16c:	8b 55 08             	mov    0x8(%ebp),%edx
 16f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 172:	0f b6 02             	movzbl (%edx),%eax
 175:	84 c0                	test   %al,%al
 177:	75 10                	jne    189 <strcmp+0x21>
 179:	eb 2a                	jmp    1a5 <strcmp+0x3d>
 17b:	90                   	nop
 17c:	42                   	inc    %edx
 17d:	8d 4b 01             	lea    0x1(%ebx),%ecx
 180:	0f b6 02             	movzbl (%edx),%eax
 183:	84 c0                	test   %al,%al
 185:	74 11                	je     198 <strcmp+0x30>
 187:	89 cb                	mov    %ecx,%ebx
 189:	0f b6 0b             	movzbl (%ebx),%ecx
 18c:	38 c1                	cmp    %al,%cl
 18e:	74 ec                	je     17c <strcmp+0x14>
 190:	29 c8                	sub    %ecx,%eax
 192:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 195:	c9                   	leave  
 196:	c3                   	ret    
 197:	90                   	nop
 198:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
 19c:	31 c0                	xor    %eax,%eax
 19e:	29 c8                	sub    %ecx,%eax
 1a0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1a3:	c9                   	leave  
 1a4:	c3                   	ret    
 1a5:	0f b6 0b             	movzbl (%ebx),%ecx
 1a8:	31 c0                	xor    %eax,%eax
 1aa:	eb e4                	jmp    190 <strcmp+0x28>

000001ac <strlen>:
 1ac:	55                   	push   %ebp
 1ad:	89 e5                	mov    %esp,%ebp
 1af:	8b 55 08             	mov    0x8(%ebp),%edx
 1b2:	80 3a 00             	cmpb   $0x0,(%edx)
 1b5:	74 15                	je     1cc <strlen+0x20>
 1b7:	31 c0                	xor    %eax,%eax
 1b9:	8d 76 00             	lea    0x0(%esi),%esi
 1bc:	40                   	inc    %eax
 1bd:	89 c1                	mov    %eax,%ecx
 1bf:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 1c3:	75 f7                	jne    1bc <strlen+0x10>
 1c5:	89 c8                	mov    %ecx,%eax
 1c7:	5d                   	pop    %ebp
 1c8:	c3                   	ret    
 1c9:	8d 76 00             	lea    0x0(%esi),%esi
 1cc:	31 c9                	xor    %ecx,%ecx
 1ce:	89 c8                	mov    %ecx,%eax
 1d0:	5d                   	pop    %ebp
 1d1:	c3                   	ret    
 1d2:	66 90                	xchg   %ax,%ax

000001d4 <memset>:
 1d4:	55                   	push   %ebp
 1d5:	89 e5                	mov    %esp,%ebp
 1d7:	57                   	push   %edi
 1d8:	8b 7d 08             	mov    0x8(%ebp),%edi
 1db:	8b 4d 10             	mov    0x10(%ebp),%ecx
 1de:	8b 45 0c             	mov    0xc(%ebp),%eax
 1e1:	fc                   	cld    
 1e2:	f3 aa                	rep stos %al,%es:(%edi)
 1e4:	8b 45 08             	mov    0x8(%ebp),%eax
 1e7:	8b 7d fc             	mov    -0x4(%ebp),%edi
 1ea:	c9                   	leave  
 1eb:	c3                   	ret    

000001ec <strchr>:
 1ec:	55                   	push   %ebp
 1ed:	89 e5                	mov    %esp,%ebp
 1ef:	8b 45 08             	mov    0x8(%ebp),%eax
 1f2:	8a 4d 0c             	mov    0xc(%ebp),%cl
 1f5:	8a 10                	mov    (%eax),%dl
 1f7:	84 d2                	test   %dl,%dl
 1f9:	75 0c                	jne    207 <strchr+0x1b>
 1fb:	eb 13                	jmp    210 <strchr+0x24>
 1fd:	8d 76 00             	lea    0x0(%esi),%esi
 200:	40                   	inc    %eax
 201:	8a 10                	mov    (%eax),%dl
 203:	84 d2                	test   %dl,%dl
 205:	74 09                	je     210 <strchr+0x24>
 207:	38 d1                	cmp    %dl,%cl
 209:	75 f5                	jne    200 <strchr+0x14>
 20b:	5d                   	pop    %ebp
 20c:	c3                   	ret    
 20d:	8d 76 00             	lea    0x0(%esi),%esi
 210:	31 c0                	xor    %eax,%eax
 212:	5d                   	pop    %ebp
 213:	c3                   	ret    

00000214 <gets>:
 214:	55                   	push   %ebp
 215:	89 e5                	mov    %esp,%ebp
 217:	57                   	push   %edi
 218:	56                   	push   %esi
 219:	53                   	push   %ebx
 21a:	83 ec 1c             	sub    $0x1c,%esp
 21d:	31 db                	xor    %ebx,%ebx
 21f:	8d 75 e7             	lea    -0x19(%ebp),%esi
 222:	eb 24                	jmp    248 <gets+0x34>
 224:	50                   	push   %eax
 225:	6a 01                	push   $0x1
 227:	56                   	push   %esi
 228:	6a 00                	push   $0x0
 22a:	e8 f4 00 00 00       	call   323 <read>
 22f:	83 c4 10             	add    $0x10,%esp
 232:	85 c0                	test   %eax,%eax
 234:	7e 1a                	jle    250 <gets+0x3c>
 236:	8a 45 e7             	mov    -0x19(%ebp),%al
 239:	8b 55 08             	mov    0x8(%ebp),%edx
 23c:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 240:	3c 0a                	cmp    $0xa,%al
 242:	74 0e                	je     252 <gets+0x3e>
 244:	3c 0d                	cmp    $0xd,%al
 246:	74 0a                	je     252 <gets+0x3e>
 248:	89 df                	mov    %ebx,%edi
 24a:	43                   	inc    %ebx
 24b:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 24e:	7c d4                	jl     224 <gets+0x10>
 250:	89 fb                	mov    %edi,%ebx
 252:	8b 45 08             	mov    0x8(%ebp),%eax
 255:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 259:	8d 65 f4             	lea    -0xc(%ebp),%esp
 25c:	5b                   	pop    %ebx
 25d:	5e                   	pop    %esi
 25e:	5f                   	pop    %edi
 25f:	5d                   	pop    %ebp
 260:	c3                   	ret    
 261:	8d 76 00             	lea    0x0(%esi),%esi

00000264 <stat>:
 264:	55                   	push   %ebp
 265:	89 e5                	mov    %esp,%ebp
 267:	56                   	push   %esi
 268:	53                   	push   %ebx
 269:	83 ec 08             	sub    $0x8,%esp
 26c:	6a 00                	push   $0x0
 26e:	ff 75 08             	pushl  0x8(%ebp)
 271:	e8 d5 00 00 00       	call   34b <open>
 276:	83 c4 10             	add    $0x10,%esp
 279:	85 c0                	test   %eax,%eax
 27b:	78 27                	js     2a4 <stat+0x40>
 27d:	89 c3                	mov    %eax,%ebx
 27f:	83 ec 08             	sub    $0x8,%esp
 282:	ff 75 0c             	pushl  0xc(%ebp)
 285:	50                   	push   %eax
 286:	e8 d8 00 00 00       	call   363 <fstat>
 28b:	89 c6                	mov    %eax,%esi
 28d:	89 1c 24             	mov    %ebx,(%esp)
 290:	e8 9e 00 00 00       	call   333 <close>
 295:	83 c4 10             	add    $0x10,%esp
 298:	89 f0                	mov    %esi,%eax
 29a:	8d 65 f8             	lea    -0x8(%ebp),%esp
 29d:	5b                   	pop    %ebx
 29e:	5e                   	pop    %esi
 29f:	5d                   	pop    %ebp
 2a0:	c3                   	ret    
 2a1:	8d 76 00             	lea    0x0(%esi),%esi
 2a4:	be ff ff ff ff       	mov    $0xffffffff,%esi
 2a9:	eb ed                	jmp    298 <stat+0x34>
 2ab:	90                   	nop

000002ac <atoi>:
 2ac:	55                   	push   %ebp
 2ad:	89 e5                	mov    %esp,%ebp
 2af:	53                   	push   %ebx
 2b0:	8b 4d 08             	mov    0x8(%ebp),%ecx
 2b3:	0f be 01             	movsbl (%ecx),%eax
 2b6:	8d 50 d0             	lea    -0x30(%eax),%edx
 2b9:	80 fa 09             	cmp    $0x9,%dl
 2bc:	ba 00 00 00 00       	mov    $0x0,%edx
 2c1:	77 16                	ja     2d9 <atoi+0x2d>
 2c3:	90                   	nop
 2c4:	41                   	inc    %ecx
 2c5:	8d 14 92             	lea    (%edx,%edx,4),%edx
 2c8:	01 d2                	add    %edx,%edx
 2ca:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 2ce:	0f be 01             	movsbl (%ecx),%eax
 2d1:	8d 58 d0             	lea    -0x30(%eax),%ebx
 2d4:	80 fb 09             	cmp    $0x9,%bl
 2d7:	76 eb                	jbe    2c4 <atoi+0x18>
 2d9:	89 d0                	mov    %edx,%eax
 2db:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2de:	c9                   	leave  
 2df:	c3                   	ret    

000002e0 <memmove>:
 2e0:	55                   	push   %ebp
 2e1:	89 e5                	mov    %esp,%ebp
 2e3:	57                   	push   %edi
 2e4:	56                   	push   %esi
 2e5:	8b 55 08             	mov    0x8(%ebp),%edx
 2e8:	8b 75 0c             	mov    0xc(%ebp),%esi
 2eb:	8b 45 10             	mov    0x10(%ebp),%eax
 2ee:	85 c0                	test   %eax,%eax
 2f0:	7e 0b                	jle    2fd <memmove+0x1d>
 2f2:	01 d0                	add    %edx,%eax
 2f4:	89 d7                	mov    %edx,%edi
 2f6:	66 90                	xchg   %ax,%ax
 2f8:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 2f9:	39 f8                	cmp    %edi,%eax
 2fb:	75 fb                	jne    2f8 <memmove+0x18>
 2fd:	89 d0                	mov    %edx,%eax
 2ff:	5e                   	pop    %esi
 300:	5f                   	pop    %edi
 301:	5d                   	pop    %ebp
 302:	c3                   	ret    

00000303 <fork>:
 303:	b8 01 00 00 00       	mov    $0x1,%eax
 308:	cd 40                	int    $0x40
 30a:	c3                   	ret    

0000030b <exit>:
 30b:	b8 02 00 00 00       	mov    $0x2,%eax
 310:	cd 40                	int    $0x40
 312:	c3                   	ret    

00000313 <wait>:
 313:	b8 03 00 00 00       	mov    $0x3,%eax
 318:	cd 40                	int    $0x40
 31a:	c3                   	ret    

0000031b <pipe>:
 31b:	b8 04 00 00 00       	mov    $0x4,%eax
 320:	cd 40                	int    $0x40
 322:	c3                   	ret    

00000323 <read>:
 323:	b8 05 00 00 00       	mov    $0x5,%eax
 328:	cd 40                	int    $0x40
 32a:	c3                   	ret    

0000032b <write>:
 32b:	b8 10 00 00 00       	mov    $0x10,%eax
 330:	cd 40                	int    $0x40
 332:	c3                   	ret    

00000333 <close>:
 333:	b8 15 00 00 00       	mov    $0x15,%eax
 338:	cd 40                	int    $0x40
 33a:	c3                   	ret    

0000033b <kill>:
 33b:	b8 06 00 00 00       	mov    $0x6,%eax
 340:	cd 40                	int    $0x40
 342:	c3                   	ret    

00000343 <exec>:
 343:	b8 07 00 00 00       	mov    $0x7,%eax
 348:	cd 40                	int    $0x40
 34a:	c3                   	ret    

0000034b <open>:
 34b:	b8 0f 00 00 00       	mov    $0xf,%eax
 350:	cd 40                	int    $0x40
 352:	c3                   	ret    

00000353 <mknod>:
 353:	b8 11 00 00 00       	mov    $0x11,%eax
 358:	cd 40                	int    $0x40
 35a:	c3                   	ret    

0000035b <unlink>:
 35b:	b8 12 00 00 00       	mov    $0x12,%eax
 360:	cd 40                	int    $0x40
 362:	c3                   	ret    

00000363 <fstat>:
 363:	b8 08 00 00 00       	mov    $0x8,%eax
 368:	cd 40                	int    $0x40
 36a:	c3                   	ret    

0000036b <link>:
 36b:	b8 13 00 00 00       	mov    $0x13,%eax
 370:	cd 40                	int    $0x40
 372:	c3                   	ret    

00000373 <mkdir>:
 373:	b8 14 00 00 00       	mov    $0x14,%eax
 378:	cd 40                	int    $0x40
 37a:	c3                   	ret    

0000037b <chdir>:
 37b:	b8 09 00 00 00       	mov    $0x9,%eax
 380:	cd 40                	int    $0x40
 382:	c3                   	ret    

00000383 <dup>:
 383:	b8 0a 00 00 00       	mov    $0xa,%eax
 388:	cd 40                	int    $0x40
 38a:	c3                   	ret    

0000038b <getpid>:
 38b:	b8 0b 00 00 00       	mov    $0xb,%eax
 390:	cd 40                	int    $0x40
 392:	c3                   	ret    

00000393 <sbrk>:
 393:	b8 0c 00 00 00       	mov    $0xc,%eax
 398:	cd 40                	int    $0x40
 39a:	c3                   	ret    

0000039b <sleep>:
 39b:	b8 0d 00 00 00       	mov    $0xd,%eax
 3a0:	cd 40                	int    $0x40
 3a2:	c3                   	ret    

000003a3 <uptime>:
 3a3:	b8 0e 00 00 00       	mov    $0xe,%eax
 3a8:	cd 40                	int    $0x40
 3aa:	c3                   	ret    

000003ab <mprotect>:
 3ab:	b8 16 00 00 00       	mov    $0x16,%eax
 3b0:	cd 40                	int    $0x40
 3b2:	c3                   	ret    

000003b3 <munprotect>:
 3b3:	b8 17 00 00 00       	mov    $0x17,%eax
 3b8:	cd 40                	int    $0x40
 3ba:	c3                   	ret    

000003bb <set_priority>:
 3bb:	b8 18 00 00 00       	mov    $0x18,%eax
 3c0:	cd 40                	int    $0x40
 3c2:	c3                   	ret    
 3c3:	90                   	nop

000003c4 <printint>:
 3c4:	55                   	push   %ebp
 3c5:	89 e5                	mov    %esp,%ebp
 3c7:	57                   	push   %edi
 3c8:	56                   	push   %esi
 3c9:	53                   	push   %ebx
 3ca:	83 ec 3c             	sub    $0x3c,%esp
 3cd:	89 45 c0             	mov    %eax,-0x40(%ebp)
 3d0:	89 cb                	mov    %ecx,%ebx
 3d2:	8b 4d 08             	mov    0x8(%ebp),%ecx
 3d5:	85 c9                	test   %ecx,%ecx
 3d7:	74 04                	je     3dd <printint+0x19>
 3d9:	85 d2                	test   %edx,%edx
 3db:	78 6b                	js     448 <printint+0x84>
 3dd:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 3e0:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 3e7:	31 c9                	xor    %ecx,%ecx
 3e9:	8d 75 d7             	lea    -0x29(%ebp),%esi
 3ec:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 3ef:	31 d2                	xor    %edx,%edx
 3f1:	f7 f3                	div    %ebx
 3f3:	89 cf                	mov    %ecx,%edi
 3f5:	8d 49 01             	lea    0x1(%ecx),%ecx
 3f8:	8a 92 80 08 00 00    	mov    0x880(%edx),%dl
 3fe:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 402:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 405:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 408:	39 da                	cmp    %ebx,%edx
 40a:	73 e0                	jae    3ec <printint+0x28>
 40c:	8b 55 08             	mov    0x8(%ebp),%edx
 40f:	85 d2                	test   %edx,%edx
 411:	74 07                	je     41a <printint+0x56>
 413:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 418:	89 cf                	mov    %ecx,%edi
 41a:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 41d:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 421:	8d 76 00             	lea    0x0(%esi),%esi
 424:	8a 07                	mov    (%edi),%al
 426:	88 45 d7             	mov    %al,-0x29(%ebp)
 429:	50                   	push   %eax
 42a:	6a 01                	push   $0x1
 42c:	56                   	push   %esi
 42d:	ff 75 c0             	pushl  -0x40(%ebp)
 430:	e8 f6 fe ff ff       	call   32b <write>
 435:	89 f8                	mov    %edi,%eax
 437:	4f                   	dec    %edi
 438:	83 c4 10             	add    $0x10,%esp
 43b:	39 d8                	cmp    %ebx,%eax
 43d:	75 e5                	jne    424 <printint+0x60>
 43f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 442:	5b                   	pop    %ebx
 443:	5e                   	pop    %esi
 444:	5f                   	pop    %edi
 445:	5d                   	pop    %ebp
 446:	c3                   	ret    
 447:	90                   	nop
 448:	f7 da                	neg    %edx
 44a:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 44d:	eb 98                	jmp    3e7 <printint+0x23>
 44f:	90                   	nop

00000450 <printf>:
 450:	55                   	push   %ebp
 451:	89 e5                	mov    %esp,%ebp
 453:	57                   	push   %edi
 454:	56                   	push   %esi
 455:	53                   	push   %ebx
 456:	83 ec 2c             	sub    $0x2c,%esp
 459:	8b 75 08             	mov    0x8(%ebp),%esi
 45c:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 45f:	8a 13                	mov    (%ebx),%dl
 461:	84 d2                	test   %dl,%dl
 463:	74 5c                	je     4c1 <printf+0x71>
 465:	43                   	inc    %ebx
 466:	8d 45 10             	lea    0x10(%ebp),%eax
 469:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 46c:	31 ff                	xor    %edi,%edi
 46e:	eb 20                	jmp    490 <printf+0x40>
 470:	83 f8 25             	cmp    $0x25,%eax
 473:	74 3f                	je     4b4 <printf+0x64>
 475:	88 55 e7             	mov    %dl,-0x19(%ebp)
 478:	50                   	push   %eax
 479:	6a 01                	push   $0x1
 47b:	8d 45 e7             	lea    -0x19(%ebp),%eax
 47e:	50                   	push   %eax
 47f:	56                   	push   %esi
 480:	e8 a6 fe ff ff       	call   32b <write>
 485:	83 c4 10             	add    $0x10,%esp
 488:	43                   	inc    %ebx
 489:	8a 53 ff             	mov    -0x1(%ebx),%dl
 48c:	84 d2                	test   %dl,%dl
 48e:	74 31                	je     4c1 <printf+0x71>
 490:	0f b6 c2             	movzbl %dl,%eax
 493:	85 ff                	test   %edi,%edi
 495:	74 d9                	je     470 <printf+0x20>
 497:	83 ff 25             	cmp    $0x25,%edi
 49a:	75 ec                	jne    488 <printf+0x38>
 49c:	83 f8 25             	cmp    $0x25,%eax
 49f:	0f 84 03 01 00 00    	je     5a8 <printf+0x158>
 4a5:	83 e8 63             	sub    $0x63,%eax
 4a8:	83 f8 15             	cmp    $0x15,%eax
 4ab:	77 1f                	ja     4cc <printf+0x7c>
 4ad:	ff 24 85 28 08 00 00 	jmp    *0x828(,%eax,4)
 4b4:	bf 25 00 00 00       	mov    $0x25,%edi
 4b9:	43                   	inc    %ebx
 4ba:	8a 53 ff             	mov    -0x1(%ebx),%dl
 4bd:	84 d2                	test   %dl,%dl
 4bf:	75 cf                	jne    490 <printf+0x40>
 4c1:	8d 65 f4             	lea    -0xc(%ebp),%esp
 4c4:	5b                   	pop    %ebx
 4c5:	5e                   	pop    %esi
 4c6:	5f                   	pop    %edi
 4c7:	5d                   	pop    %ebp
 4c8:	c3                   	ret    
 4c9:	8d 76 00             	lea    0x0(%esi),%esi
 4cc:	88 55 d0             	mov    %dl,-0x30(%ebp)
 4cf:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 4d3:	50                   	push   %eax
 4d4:	6a 01                	push   $0x1
 4d6:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4d9:	57                   	push   %edi
 4da:	56                   	push   %esi
 4db:	e8 4b fe ff ff       	call   32b <write>
 4e0:	8a 55 d0             	mov    -0x30(%ebp),%dl
 4e3:	88 55 e7             	mov    %dl,-0x19(%ebp)
 4e6:	83 c4 0c             	add    $0xc,%esp
 4e9:	6a 01                	push   $0x1
 4eb:	57                   	push   %edi
 4ec:	56                   	push   %esi
 4ed:	e8 39 fe ff ff       	call   32b <write>
 4f2:	83 c4 10             	add    $0x10,%esp
 4f5:	31 ff                	xor    %edi,%edi
 4f7:	eb 8f                	jmp    488 <printf+0x38>
 4f9:	8d 76 00             	lea    0x0(%esi),%esi
 4fc:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4ff:	8b 17                	mov    (%edi),%edx
 501:	83 ec 0c             	sub    $0xc,%esp
 504:	6a 00                	push   $0x0
 506:	b9 10 00 00 00       	mov    $0x10,%ecx
 50b:	89 f0                	mov    %esi,%eax
 50d:	e8 b2 fe ff ff       	call   3c4 <printint>
 512:	83 c7 04             	add    $0x4,%edi
 515:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 518:	83 c4 10             	add    $0x10,%esp
 51b:	31 ff                	xor    %edi,%edi
 51d:	e9 66 ff ff ff       	jmp    488 <printf+0x38>
 522:	66 90                	xchg   %ax,%ax
 524:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 527:	8b 10                	mov    (%eax),%edx
 529:	83 c0 04             	add    $0x4,%eax
 52c:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 52f:	85 d2                	test   %edx,%edx
 531:	0f 84 81 00 00 00    	je     5b8 <printf+0x168>
 537:	8a 02                	mov    (%edx),%al
 539:	84 c0                	test   %al,%al
 53b:	0f 84 80 00 00 00    	je     5c1 <printf+0x171>
 541:	8d 7d e7             	lea    -0x19(%ebp),%edi
 544:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 547:	89 d3                	mov    %edx,%ebx
 549:	8d 76 00             	lea    0x0(%esi),%esi
 54c:	88 45 e7             	mov    %al,-0x19(%ebp)
 54f:	50                   	push   %eax
 550:	6a 01                	push   $0x1
 552:	57                   	push   %edi
 553:	56                   	push   %esi
 554:	e8 d2 fd ff ff       	call   32b <write>
 559:	43                   	inc    %ebx
 55a:	8a 03                	mov    (%ebx),%al
 55c:	83 c4 10             	add    $0x10,%esp
 55f:	84 c0                	test   %al,%al
 561:	75 e9                	jne    54c <printf+0xfc>
 563:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 566:	31 ff                	xor    %edi,%edi
 568:	e9 1b ff ff ff       	jmp    488 <printf+0x38>
 56d:	8d 76 00             	lea    0x0(%esi),%esi
 570:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 573:	8b 17                	mov    (%edi),%edx
 575:	83 ec 0c             	sub    $0xc,%esp
 578:	6a 01                	push   $0x1
 57a:	b9 0a 00 00 00       	mov    $0xa,%ecx
 57f:	eb 8a                	jmp    50b <printf+0xbb>
 581:	8d 76 00             	lea    0x0(%esi),%esi
 584:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 587:	8b 00                	mov    (%eax),%eax
 589:	88 45 e7             	mov    %al,-0x19(%ebp)
 58c:	51                   	push   %ecx
 58d:	6a 01                	push   $0x1
 58f:	8d 7d e7             	lea    -0x19(%ebp),%edi
 592:	57                   	push   %edi
 593:	56                   	push   %esi
 594:	e8 92 fd ff ff       	call   32b <write>
 599:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 59d:	83 c4 10             	add    $0x10,%esp
 5a0:	31 ff                	xor    %edi,%edi
 5a2:	e9 e1 fe ff ff       	jmp    488 <printf+0x38>
 5a7:	90                   	nop
 5a8:	88 55 e7             	mov    %dl,-0x19(%ebp)
 5ab:	52                   	push   %edx
 5ac:	6a 01                	push   $0x1
 5ae:	8d 7d e7             	lea    -0x19(%ebp),%edi
 5b1:	e9 35 ff ff ff       	jmp    4eb <printf+0x9b>
 5b6:	66 90                	xchg   %ax,%ax
 5b8:	b0 28                	mov    $0x28,%al
 5ba:	ba 1e 08 00 00       	mov    $0x81e,%edx
 5bf:	eb 80                	jmp    541 <printf+0xf1>
 5c1:	31 ff                	xor    %edi,%edi
 5c3:	e9 c0 fe ff ff       	jmp    488 <printf+0x38>

000005c8 <free>:
 5c8:	55                   	push   %ebp
 5c9:	89 e5                	mov    %esp,%ebp
 5cb:	57                   	push   %edi
 5cc:	56                   	push   %esi
 5cd:	53                   	push   %ebx
 5ce:	8b 5d 08             	mov    0x8(%ebp),%ebx
 5d1:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 5d4:	a1 94 08 00 00       	mov    0x894,%eax
 5d9:	8d 76 00             	lea    0x0(%esi),%esi
 5dc:	89 c2                	mov    %eax,%edx
 5de:	8b 00                	mov    (%eax),%eax
 5e0:	39 ca                	cmp    %ecx,%edx
 5e2:	73 2c                	jae    610 <free+0x48>
 5e4:	39 c1                	cmp    %eax,%ecx
 5e6:	72 04                	jb     5ec <free+0x24>
 5e8:	39 c2                	cmp    %eax,%edx
 5ea:	72 f0                	jb     5dc <free+0x14>
 5ec:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5ef:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5f2:	39 f8                	cmp    %edi,%eax
 5f4:	74 2c                	je     622 <free+0x5a>
 5f6:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5f9:	8b 42 04             	mov    0x4(%edx),%eax
 5fc:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5ff:	39 f1                	cmp    %esi,%ecx
 601:	74 36                	je     639 <free+0x71>
 603:	89 0a                	mov    %ecx,(%edx)
 605:	89 15 94 08 00 00    	mov    %edx,0x894
 60b:	5b                   	pop    %ebx
 60c:	5e                   	pop    %esi
 60d:	5f                   	pop    %edi
 60e:	5d                   	pop    %ebp
 60f:	c3                   	ret    
 610:	39 c2                	cmp    %eax,%edx
 612:	72 c8                	jb     5dc <free+0x14>
 614:	39 c1                	cmp    %eax,%ecx
 616:	73 c4                	jae    5dc <free+0x14>
 618:	8b 73 fc             	mov    -0x4(%ebx),%esi
 61b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 61e:	39 f8                	cmp    %edi,%eax
 620:	75 d4                	jne    5f6 <free+0x2e>
 622:	03 70 04             	add    0x4(%eax),%esi
 625:	89 73 fc             	mov    %esi,-0x4(%ebx)
 628:	8b 02                	mov    (%edx),%eax
 62a:	8b 00                	mov    (%eax),%eax
 62c:	89 43 f8             	mov    %eax,-0x8(%ebx)
 62f:	8b 42 04             	mov    0x4(%edx),%eax
 632:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 635:	39 f1                	cmp    %esi,%ecx
 637:	75 ca                	jne    603 <free+0x3b>
 639:	03 43 fc             	add    -0x4(%ebx),%eax
 63c:	89 42 04             	mov    %eax,0x4(%edx)
 63f:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 642:	89 0a                	mov    %ecx,(%edx)
 644:	89 15 94 08 00 00    	mov    %edx,0x894
 64a:	5b                   	pop    %ebx
 64b:	5e                   	pop    %esi
 64c:	5f                   	pop    %edi
 64d:	5d                   	pop    %ebp
 64e:	c3                   	ret    
 64f:	90                   	nop

00000650 <malloc>:
 650:	55                   	push   %ebp
 651:	89 e5                	mov    %esp,%ebp
 653:	57                   	push   %edi
 654:	56                   	push   %esi
 655:	53                   	push   %ebx
 656:	83 ec 0c             	sub    $0xc,%esp
 659:	8b 45 08             	mov    0x8(%ebp),%eax
 65c:	8d 78 07             	lea    0x7(%eax),%edi
 65f:	c1 ef 03             	shr    $0x3,%edi
 662:	47                   	inc    %edi
 663:	8b 15 94 08 00 00    	mov    0x894,%edx
 669:	85 d2                	test   %edx,%edx
 66b:	0f 84 93 00 00 00    	je     704 <malloc+0xb4>
 671:	8b 02                	mov    (%edx),%eax
 673:	8b 48 04             	mov    0x4(%eax),%ecx
 676:	39 f9                	cmp    %edi,%ecx
 678:	73 62                	jae    6dc <malloc+0x8c>
 67a:	89 fb                	mov    %edi,%ebx
 67c:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 682:	72 78                	jb     6fc <malloc+0xac>
 684:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 68b:	eb 0e                	jmp    69b <malloc+0x4b>
 68d:	8d 76 00             	lea    0x0(%esi),%esi
 690:	89 c2                	mov    %eax,%edx
 692:	8b 02                	mov    (%edx),%eax
 694:	8b 48 04             	mov    0x4(%eax),%ecx
 697:	39 f9                	cmp    %edi,%ecx
 699:	73 41                	jae    6dc <malloc+0x8c>
 69b:	39 05 94 08 00 00    	cmp    %eax,0x894
 6a1:	75 ed                	jne    690 <malloc+0x40>
 6a3:	83 ec 0c             	sub    $0xc,%esp
 6a6:	56                   	push   %esi
 6a7:	e8 e7 fc ff ff       	call   393 <sbrk>
 6ac:	83 c4 10             	add    $0x10,%esp
 6af:	83 f8 ff             	cmp    $0xffffffff,%eax
 6b2:	74 1c                	je     6d0 <malloc+0x80>
 6b4:	89 58 04             	mov    %ebx,0x4(%eax)
 6b7:	83 ec 0c             	sub    $0xc,%esp
 6ba:	83 c0 08             	add    $0x8,%eax
 6bd:	50                   	push   %eax
 6be:	e8 05 ff ff ff       	call   5c8 <free>
 6c3:	8b 15 94 08 00 00    	mov    0x894,%edx
 6c9:	83 c4 10             	add    $0x10,%esp
 6cc:	85 d2                	test   %edx,%edx
 6ce:	75 c2                	jne    692 <malloc+0x42>
 6d0:	31 c0                	xor    %eax,%eax
 6d2:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6d5:	5b                   	pop    %ebx
 6d6:	5e                   	pop    %esi
 6d7:	5f                   	pop    %edi
 6d8:	5d                   	pop    %ebp
 6d9:	c3                   	ret    
 6da:	66 90                	xchg   %ax,%ax
 6dc:	39 cf                	cmp    %ecx,%edi
 6de:	74 4c                	je     72c <malloc+0xdc>
 6e0:	29 f9                	sub    %edi,%ecx
 6e2:	89 48 04             	mov    %ecx,0x4(%eax)
 6e5:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 6e8:	89 78 04             	mov    %edi,0x4(%eax)
 6eb:	89 15 94 08 00 00    	mov    %edx,0x894
 6f1:	83 c0 08             	add    $0x8,%eax
 6f4:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6f7:	5b                   	pop    %ebx
 6f8:	5e                   	pop    %esi
 6f9:	5f                   	pop    %edi
 6fa:	5d                   	pop    %ebp
 6fb:	c3                   	ret    
 6fc:	bb 00 10 00 00       	mov    $0x1000,%ebx
 701:	eb 81                	jmp    684 <malloc+0x34>
 703:	90                   	nop
 704:	c7 05 94 08 00 00 98 	movl   $0x898,0x894
 70b:	08 00 00 
 70e:	c7 05 98 08 00 00 98 	movl   $0x898,0x898
 715:	08 00 00 
 718:	c7 05 9c 08 00 00 00 	movl   $0x0,0x89c
 71f:	00 00 00 
 722:	b8 98 08 00 00       	mov    $0x898,%eax
 727:	e9 4e ff ff ff       	jmp    67a <malloc+0x2a>
 72c:	8b 08                	mov    (%eax),%ecx
 72e:	89 0a                	mov    %ecx,(%edx)
 730:	eb b9                	jmp    6eb <malloc+0x9b>
