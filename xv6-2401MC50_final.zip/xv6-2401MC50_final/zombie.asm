
_zombie:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	50                   	push   %eax
   f:	e8 d3 01 00 00       	call   1e7 <fork>
  14:	85 c0                	test   %eax,%eax
  16:	7e 0d                	jle    25 <main+0x25>
  18:	83 ec 0c             	sub    $0xc,%esp
  1b:	6a 05                	push   $0x5
  1d:	e8 5d 02 00 00       	call   27f <sleep>
  22:	83 c4 10             	add    $0x10,%esp
  25:	e8 c5 01 00 00       	call   1ef <exit>
  2a:	66 90                	xchg   %ax,%ax

0000002c <strcpy>:
  2c:	55                   	push   %ebp
  2d:	89 e5                	mov    %esp,%ebp
  2f:	53                   	push   %ebx
  30:	8b 4d 08             	mov    0x8(%ebp),%ecx
  33:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  36:	31 c0                	xor    %eax,%eax
  38:	8a 14 03             	mov    (%ebx,%eax,1),%dl
  3b:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  3e:	40                   	inc    %eax
  3f:	84 d2                	test   %dl,%dl
  41:	75 f5                	jne    38 <strcpy+0xc>
  43:	89 c8                	mov    %ecx,%eax
  45:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  48:	c9                   	leave  
  49:	c3                   	ret    
  4a:	66 90                	xchg   %ax,%ax

0000004c <strcmp>:
  4c:	55                   	push   %ebp
  4d:	89 e5                	mov    %esp,%ebp
  4f:	53                   	push   %ebx
  50:	8b 55 08             	mov    0x8(%ebp),%edx
  53:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  56:	0f b6 02             	movzbl (%edx),%eax
  59:	84 c0                	test   %al,%al
  5b:	75 10                	jne    6d <strcmp+0x21>
  5d:	eb 2a                	jmp    89 <strcmp+0x3d>
  5f:	90                   	nop
  60:	42                   	inc    %edx
  61:	8d 4b 01             	lea    0x1(%ebx),%ecx
  64:	0f b6 02             	movzbl (%edx),%eax
  67:	84 c0                	test   %al,%al
  69:	74 11                	je     7c <strcmp+0x30>
  6b:	89 cb                	mov    %ecx,%ebx
  6d:	0f b6 0b             	movzbl (%ebx),%ecx
  70:	38 c1                	cmp    %al,%cl
  72:	74 ec                	je     60 <strcmp+0x14>
  74:	29 c8                	sub    %ecx,%eax
  76:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  79:	c9                   	leave  
  7a:	c3                   	ret    
  7b:	90                   	nop
  7c:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
  80:	31 c0                	xor    %eax,%eax
  82:	29 c8                	sub    %ecx,%eax
  84:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  87:	c9                   	leave  
  88:	c3                   	ret    
  89:	0f b6 0b             	movzbl (%ebx),%ecx
  8c:	31 c0                	xor    %eax,%eax
  8e:	eb e4                	jmp    74 <strcmp+0x28>

00000090 <strlen>:
  90:	55                   	push   %ebp
  91:	89 e5                	mov    %esp,%ebp
  93:	8b 55 08             	mov    0x8(%ebp),%edx
  96:	80 3a 00             	cmpb   $0x0,(%edx)
  99:	74 15                	je     b0 <strlen+0x20>
  9b:	31 c0                	xor    %eax,%eax
  9d:	8d 76 00             	lea    0x0(%esi),%esi
  a0:	40                   	inc    %eax
  a1:	89 c1                	mov    %eax,%ecx
  a3:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
  a7:	75 f7                	jne    a0 <strlen+0x10>
  a9:	89 c8                	mov    %ecx,%eax
  ab:	5d                   	pop    %ebp
  ac:	c3                   	ret    
  ad:	8d 76 00             	lea    0x0(%esi),%esi
  b0:	31 c9                	xor    %ecx,%ecx
  b2:	89 c8                	mov    %ecx,%eax
  b4:	5d                   	pop    %ebp
  b5:	c3                   	ret    
  b6:	66 90                	xchg   %ax,%ax

000000b8 <memset>:
  b8:	55                   	push   %ebp
  b9:	89 e5                	mov    %esp,%ebp
  bb:	57                   	push   %edi
  bc:	8b 7d 08             	mov    0x8(%ebp),%edi
  bf:	8b 4d 10             	mov    0x10(%ebp),%ecx
  c2:	8b 45 0c             	mov    0xc(%ebp),%eax
  c5:	fc                   	cld    
  c6:	f3 aa                	rep stos %al,%es:(%edi)
  c8:	8b 45 08             	mov    0x8(%ebp),%eax
  cb:	8b 7d fc             	mov    -0x4(%ebp),%edi
  ce:	c9                   	leave  
  cf:	c3                   	ret    

000000d0 <strchr>:
  d0:	55                   	push   %ebp
  d1:	89 e5                	mov    %esp,%ebp
  d3:	8b 45 08             	mov    0x8(%ebp),%eax
  d6:	8a 4d 0c             	mov    0xc(%ebp),%cl
  d9:	8a 10                	mov    (%eax),%dl
  db:	84 d2                	test   %dl,%dl
  dd:	75 0c                	jne    eb <strchr+0x1b>
  df:	eb 13                	jmp    f4 <strchr+0x24>
  e1:	8d 76 00             	lea    0x0(%esi),%esi
  e4:	40                   	inc    %eax
  e5:	8a 10                	mov    (%eax),%dl
  e7:	84 d2                	test   %dl,%dl
  e9:	74 09                	je     f4 <strchr+0x24>
  eb:	38 d1                	cmp    %dl,%cl
  ed:	75 f5                	jne    e4 <strchr+0x14>
  ef:	5d                   	pop    %ebp
  f0:	c3                   	ret    
  f1:	8d 76 00             	lea    0x0(%esi),%esi
  f4:	31 c0                	xor    %eax,%eax
  f6:	5d                   	pop    %ebp
  f7:	c3                   	ret    

000000f8 <gets>:
  f8:	55                   	push   %ebp
  f9:	89 e5                	mov    %esp,%ebp
  fb:	57                   	push   %edi
  fc:	56                   	push   %esi
  fd:	53                   	push   %ebx
  fe:	83 ec 1c             	sub    $0x1c,%esp
 101:	31 db                	xor    %ebx,%ebx
 103:	8d 75 e7             	lea    -0x19(%ebp),%esi
 106:	eb 24                	jmp    12c <gets+0x34>
 108:	50                   	push   %eax
 109:	6a 01                	push   $0x1
 10b:	56                   	push   %esi
 10c:	6a 00                	push   $0x0
 10e:	e8 f4 00 00 00       	call   207 <read>
 113:	83 c4 10             	add    $0x10,%esp
 116:	85 c0                	test   %eax,%eax
 118:	7e 1a                	jle    134 <gets+0x3c>
 11a:	8a 45 e7             	mov    -0x19(%ebp),%al
 11d:	8b 55 08             	mov    0x8(%ebp),%edx
 120:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 124:	3c 0a                	cmp    $0xa,%al
 126:	74 0e                	je     136 <gets+0x3e>
 128:	3c 0d                	cmp    $0xd,%al
 12a:	74 0a                	je     136 <gets+0x3e>
 12c:	89 df                	mov    %ebx,%edi
 12e:	43                   	inc    %ebx
 12f:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 132:	7c d4                	jl     108 <gets+0x10>
 134:	89 fb                	mov    %edi,%ebx
 136:	8b 45 08             	mov    0x8(%ebp),%eax
 139:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 13d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 140:	5b                   	pop    %ebx
 141:	5e                   	pop    %esi
 142:	5f                   	pop    %edi
 143:	5d                   	pop    %ebp
 144:	c3                   	ret    
 145:	8d 76 00             	lea    0x0(%esi),%esi

00000148 <stat>:
 148:	55                   	push   %ebp
 149:	89 e5                	mov    %esp,%ebp
 14b:	56                   	push   %esi
 14c:	53                   	push   %ebx
 14d:	83 ec 08             	sub    $0x8,%esp
 150:	6a 00                	push   $0x0
 152:	ff 75 08             	pushl  0x8(%ebp)
 155:	e8 d5 00 00 00       	call   22f <open>
 15a:	83 c4 10             	add    $0x10,%esp
 15d:	85 c0                	test   %eax,%eax
 15f:	78 27                	js     188 <stat+0x40>
 161:	89 c3                	mov    %eax,%ebx
 163:	83 ec 08             	sub    $0x8,%esp
 166:	ff 75 0c             	pushl  0xc(%ebp)
 169:	50                   	push   %eax
 16a:	e8 d8 00 00 00       	call   247 <fstat>
 16f:	89 c6                	mov    %eax,%esi
 171:	89 1c 24             	mov    %ebx,(%esp)
 174:	e8 9e 00 00 00       	call   217 <close>
 179:	83 c4 10             	add    $0x10,%esp
 17c:	89 f0                	mov    %esi,%eax
 17e:	8d 65 f8             	lea    -0x8(%ebp),%esp
 181:	5b                   	pop    %ebx
 182:	5e                   	pop    %esi
 183:	5d                   	pop    %ebp
 184:	c3                   	ret    
 185:	8d 76 00             	lea    0x0(%esi),%esi
 188:	be ff ff ff ff       	mov    $0xffffffff,%esi
 18d:	eb ed                	jmp    17c <stat+0x34>
 18f:	90                   	nop

00000190 <atoi>:
 190:	55                   	push   %ebp
 191:	89 e5                	mov    %esp,%ebp
 193:	53                   	push   %ebx
 194:	8b 4d 08             	mov    0x8(%ebp),%ecx
 197:	0f be 01             	movsbl (%ecx),%eax
 19a:	8d 50 d0             	lea    -0x30(%eax),%edx
 19d:	80 fa 09             	cmp    $0x9,%dl
 1a0:	ba 00 00 00 00       	mov    $0x0,%edx
 1a5:	77 16                	ja     1bd <atoi+0x2d>
 1a7:	90                   	nop
 1a8:	41                   	inc    %ecx
 1a9:	8d 14 92             	lea    (%edx,%edx,4),%edx
 1ac:	01 d2                	add    %edx,%edx
 1ae:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 1b2:	0f be 01             	movsbl (%ecx),%eax
 1b5:	8d 58 d0             	lea    -0x30(%eax),%ebx
 1b8:	80 fb 09             	cmp    $0x9,%bl
 1bb:	76 eb                	jbe    1a8 <atoi+0x18>
 1bd:	89 d0                	mov    %edx,%eax
 1bf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1c2:	c9                   	leave  
 1c3:	c3                   	ret    

000001c4 <memmove>:
 1c4:	55                   	push   %ebp
 1c5:	89 e5                	mov    %esp,%ebp
 1c7:	57                   	push   %edi
 1c8:	56                   	push   %esi
 1c9:	8b 55 08             	mov    0x8(%ebp),%edx
 1cc:	8b 75 0c             	mov    0xc(%ebp),%esi
 1cf:	8b 45 10             	mov    0x10(%ebp),%eax
 1d2:	85 c0                	test   %eax,%eax
 1d4:	7e 0b                	jle    1e1 <memmove+0x1d>
 1d6:	01 d0                	add    %edx,%eax
 1d8:	89 d7                	mov    %edx,%edi
 1da:	66 90                	xchg   %ax,%ax
 1dc:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 1dd:	39 f8                	cmp    %edi,%eax
 1df:	75 fb                	jne    1dc <memmove+0x18>
 1e1:	89 d0                	mov    %edx,%eax
 1e3:	5e                   	pop    %esi
 1e4:	5f                   	pop    %edi
 1e5:	5d                   	pop    %ebp
 1e6:	c3                   	ret    

000001e7 <fork>:
 1e7:	b8 01 00 00 00       	mov    $0x1,%eax
 1ec:	cd 40                	int    $0x40
 1ee:	c3                   	ret    

000001ef <exit>:
 1ef:	b8 02 00 00 00       	mov    $0x2,%eax
 1f4:	cd 40                	int    $0x40
 1f6:	c3                   	ret    

000001f7 <wait>:
 1f7:	b8 03 00 00 00       	mov    $0x3,%eax
 1fc:	cd 40                	int    $0x40
 1fe:	c3                   	ret    

000001ff <pipe>:
 1ff:	b8 04 00 00 00       	mov    $0x4,%eax
 204:	cd 40                	int    $0x40
 206:	c3                   	ret    

00000207 <read>:
 207:	b8 05 00 00 00       	mov    $0x5,%eax
 20c:	cd 40                	int    $0x40
 20e:	c3                   	ret    

0000020f <write>:
 20f:	b8 10 00 00 00       	mov    $0x10,%eax
 214:	cd 40                	int    $0x40
 216:	c3                   	ret    

00000217 <close>:
 217:	b8 15 00 00 00       	mov    $0x15,%eax
 21c:	cd 40                	int    $0x40
 21e:	c3                   	ret    

0000021f <kill>:
 21f:	b8 06 00 00 00       	mov    $0x6,%eax
 224:	cd 40                	int    $0x40
 226:	c3                   	ret    

00000227 <exec>:
 227:	b8 07 00 00 00       	mov    $0x7,%eax
 22c:	cd 40                	int    $0x40
 22e:	c3                   	ret    

0000022f <open>:
 22f:	b8 0f 00 00 00       	mov    $0xf,%eax
 234:	cd 40                	int    $0x40
 236:	c3                   	ret    

00000237 <mknod>:
 237:	b8 11 00 00 00       	mov    $0x11,%eax
 23c:	cd 40                	int    $0x40
 23e:	c3                   	ret    

0000023f <unlink>:
 23f:	b8 12 00 00 00       	mov    $0x12,%eax
 244:	cd 40                	int    $0x40
 246:	c3                   	ret    

00000247 <fstat>:
 247:	b8 08 00 00 00       	mov    $0x8,%eax
 24c:	cd 40                	int    $0x40
 24e:	c3                   	ret    

0000024f <link>:
 24f:	b8 13 00 00 00       	mov    $0x13,%eax
 254:	cd 40                	int    $0x40
 256:	c3                   	ret    

00000257 <mkdir>:
 257:	b8 14 00 00 00       	mov    $0x14,%eax
 25c:	cd 40                	int    $0x40
 25e:	c3                   	ret    

0000025f <chdir>:
 25f:	b8 09 00 00 00       	mov    $0x9,%eax
 264:	cd 40                	int    $0x40
 266:	c3                   	ret    

00000267 <dup>:
 267:	b8 0a 00 00 00       	mov    $0xa,%eax
 26c:	cd 40                	int    $0x40
 26e:	c3                   	ret    

0000026f <getpid>:
 26f:	b8 0b 00 00 00       	mov    $0xb,%eax
 274:	cd 40                	int    $0x40
 276:	c3                   	ret    

00000277 <sbrk>:
 277:	b8 0c 00 00 00       	mov    $0xc,%eax
 27c:	cd 40                	int    $0x40
 27e:	c3                   	ret    

0000027f <sleep>:
 27f:	b8 0d 00 00 00       	mov    $0xd,%eax
 284:	cd 40                	int    $0x40
 286:	c3                   	ret    

00000287 <uptime>:
 287:	b8 0e 00 00 00       	mov    $0xe,%eax
 28c:	cd 40                	int    $0x40
 28e:	c3                   	ret    

0000028f <mprotect>:
 28f:	b8 16 00 00 00       	mov    $0x16,%eax
 294:	cd 40                	int    $0x40
 296:	c3                   	ret    

00000297 <munprotect>:
 297:	b8 17 00 00 00       	mov    $0x17,%eax
 29c:	cd 40                	int    $0x40
 29e:	c3                   	ret    

0000029f <set_priority>:
 29f:	b8 18 00 00 00       	mov    $0x18,%eax
 2a4:	cd 40                	int    $0x40
 2a6:	c3                   	ret    
 2a7:	90                   	nop

000002a8 <printint>:
 2a8:	55                   	push   %ebp
 2a9:	89 e5                	mov    %esp,%ebp
 2ab:	57                   	push   %edi
 2ac:	56                   	push   %esi
 2ad:	53                   	push   %ebx
 2ae:	83 ec 3c             	sub    $0x3c,%esp
 2b1:	89 45 c0             	mov    %eax,-0x40(%ebp)
 2b4:	89 cb                	mov    %ecx,%ebx
 2b6:	8b 4d 08             	mov    0x8(%ebp),%ecx
 2b9:	85 c9                	test   %ecx,%ecx
 2bb:	74 04                	je     2c1 <printint+0x19>
 2bd:	85 d2                	test   %edx,%edx
 2bf:	78 6b                	js     32c <printint+0x84>
 2c1:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 2c4:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 2cb:	31 c9                	xor    %ecx,%ecx
 2cd:	8d 75 d7             	lea    -0x29(%ebp),%esi
 2d0:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 2d3:	31 d2                	xor    %edx,%edx
 2d5:	f7 f3                	div    %ebx
 2d7:	89 cf                	mov    %ecx,%edi
 2d9:	8d 49 01             	lea    0x1(%ecx),%ecx
 2dc:	8a 92 78 06 00 00    	mov    0x678(%edx),%dl
 2e2:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 2e6:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 2e9:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 2ec:	39 da                	cmp    %ebx,%edx
 2ee:	73 e0                	jae    2d0 <printint+0x28>
 2f0:	8b 55 08             	mov    0x8(%ebp),%edx
 2f3:	85 d2                	test   %edx,%edx
 2f5:	74 07                	je     2fe <printint+0x56>
 2f7:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 2fc:	89 cf                	mov    %ecx,%edi
 2fe:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 301:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 305:	8d 76 00             	lea    0x0(%esi),%esi
 308:	8a 07                	mov    (%edi),%al
 30a:	88 45 d7             	mov    %al,-0x29(%ebp)
 30d:	50                   	push   %eax
 30e:	6a 01                	push   $0x1
 310:	56                   	push   %esi
 311:	ff 75 c0             	pushl  -0x40(%ebp)
 314:	e8 f6 fe ff ff       	call   20f <write>
 319:	89 f8                	mov    %edi,%eax
 31b:	4f                   	dec    %edi
 31c:	83 c4 10             	add    $0x10,%esp
 31f:	39 d8                	cmp    %ebx,%eax
 321:	75 e5                	jne    308 <printint+0x60>
 323:	8d 65 f4             	lea    -0xc(%ebp),%esp
 326:	5b                   	pop    %ebx
 327:	5e                   	pop    %esi
 328:	5f                   	pop    %edi
 329:	5d                   	pop    %ebp
 32a:	c3                   	ret    
 32b:	90                   	nop
 32c:	f7 da                	neg    %edx
 32e:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 331:	eb 98                	jmp    2cb <printint+0x23>
 333:	90                   	nop

00000334 <printf>:
 334:	55                   	push   %ebp
 335:	89 e5                	mov    %esp,%ebp
 337:	57                   	push   %edi
 338:	56                   	push   %esi
 339:	53                   	push   %ebx
 33a:	83 ec 2c             	sub    $0x2c,%esp
 33d:	8b 75 08             	mov    0x8(%ebp),%esi
 340:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 343:	8a 13                	mov    (%ebx),%dl
 345:	84 d2                	test   %dl,%dl
 347:	74 5c                	je     3a5 <printf+0x71>
 349:	43                   	inc    %ebx
 34a:	8d 45 10             	lea    0x10(%ebp),%eax
 34d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 350:	31 ff                	xor    %edi,%edi
 352:	eb 20                	jmp    374 <printf+0x40>
 354:	83 f8 25             	cmp    $0x25,%eax
 357:	74 3f                	je     398 <printf+0x64>
 359:	88 55 e7             	mov    %dl,-0x19(%ebp)
 35c:	50                   	push   %eax
 35d:	6a 01                	push   $0x1
 35f:	8d 45 e7             	lea    -0x19(%ebp),%eax
 362:	50                   	push   %eax
 363:	56                   	push   %esi
 364:	e8 a6 fe ff ff       	call   20f <write>
 369:	83 c4 10             	add    $0x10,%esp
 36c:	43                   	inc    %ebx
 36d:	8a 53 ff             	mov    -0x1(%ebx),%dl
 370:	84 d2                	test   %dl,%dl
 372:	74 31                	je     3a5 <printf+0x71>
 374:	0f b6 c2             	movzbl %dl,%eax
 377:	85 ff                	test   %edi,%edi
 379:	74 d9                	je     354 <printf+0x20>
 37b:	83 ff 25             	cmp    $0x25,%edi
 37e:	75 ec                	jne    36c <printf+0x38>
 380:	83 f8 25             	cmp    $0x25,%eax
 383:	0f 84 03 01 00 00    	je     48c <printf+0x158>
 389:	83 e8 63             	sub    $0x63,%eax
 38c:	83 f8 15             	cmp    $0x15,%eax
 38f:	77 1f                	ja     3b0 <printf+0x7c>
 391:	ff 24 85 20 06 00 00 	jmp    *0x620(,%eax,4)
 398:	bf 25 00 00 00       	mov    $0x25,%edi
 39d:	43                   	inc    %ebx
 39e:	8a 53 ff             	mov    -0x1(%ebx),%dl
 3a1:	84 d2                	test   %dl,%dl
 3a3:	75 cf                	jne    374 <printf+0x40>
 3a5:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3a8:	5b                   	pop    %ebx
 3a9:	5e                   	pop    %esi
 3aa:	5f                   	pop    %edi
 3ab:	5d                   	pop    %ebp
 3ac:	c3                   	ret    
 3ad:	8d 76 00             	lea    0x0(%esi),%esi
 3b0:	88 55 d0             	mov    %dl,-0x30(%ebp)
 3b3:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 3b7:	50                   	push   %eax
 3b8:	6a 01                	push   $0x1
 3ba:	8d 7d e7             	lea    -0x19(%ebp),%edi
 3bd:	57                   	push   %edi
 3be:	56                   	push   %esi
 3bf:	e8 4b fe ff ff       	call   20f <write>
 3c4:	8a 55 d0             	mov    -0x30(%ebp),%dl
 3c7:	88 55 e7             	mov    %dl,-0x19(%ebp)
 3ca:	83 c4 0c             	add    $0xc,%esp
 3cd:	6a 01                	push   $0x1
 3cf:	57                   	push   %edi
 3d0:	56                   	push   %esi
 3d1:	e8 39 fe ff ff       	call   20f <write>
 3d6:	83 c4 10             	add    $0x10,%esp
 3d9:	31 ff                	xor    %edi,%edi
 3db:	eb 8f                	jmp    36c <printf+0x38>
 3dd:	8d 76 00             	lea    0x0(%esi),%esi
 3e0:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 3e3:	8b 17                	mov    (%edi),%edx
 3e5:	83 ec 0c             	sub    $0xc,%esp
 3e8:	6a 00                	push   $0x0
 3ea:	b9 10 00 00 00       	mov    $0x10,%ecx
 3ef:	89 f0                	mov    %esi,%eax
 3f1:	e8 b2 fe ff ff       	call   2a8 <printint>
 3f6:	83 c7 04             	add    $0x4,%edi
 3f9:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 3fc:	83 c4 10             	add    $0x10,%esp
 3ff:	31 ff                	xor    %edi,%edi
 401:	e9 66 ff ff ff       	jmp    36c <printf+0x38>
 406:	66 90                	xchg   %ax,%ax
 408:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 40b:	8b 10                	mov    (%eax),%edx
 40d:	83 c0 04             	add    $0x4,%eax
 410:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 413:	85 d2                	test   %edx,%edx
 415:	0f 84 81 00 00 00    	je     49c <printf+0x168>
 41b:	8a 02                	mov    (%edx),%al
 41d:	84 c0                	test   %al,%al
 41f:	0f 84 80 00 00 00    	je     4a5 <printf+0x171>
 425:	8d 7d e7             	lea    -0x19(%ebp),%edi
 428:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 42b:	89 d3                	mov    %edx,%ebx
 42d:	8d 76 00             	lea    0x0(%esi),%esi
 430:	88 45 e7             	mov    %al,-0x19(%ebp)
 433:	50                   	push   %eax
 434:	6a 01                	push   $0x1
 436:	57                   	push   %edi
 437:	56                   	push   %esi
 438:	e8 d2 fd ff ff       	call   20f <write>
 43d:	43                   	inc    %ebx
 43e:	8a 03                	mov    (%ebx),%al
 440:	83 c4 10             	add    $0x10,%esp
 443:	84 c0                	test   %al,%al
 445:	75 e9                	jne    430 <printf+0xfc>
 447:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 44a:	31 ff                	xor    %edi,%edi
 44c:	e9 1b ff ff ff       	jmp    36c <printf+0x38>
 451:	8d 76 00             	lea    0x0(%esi),%esi
 454:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 457:	8b 17                	mov    (%edi),%edx
 459:	83 ec 0c             	sub    $0xc,%esp
 45c:	6a 01                	push   $0x1
 45e:	b9 0a 00 00 00       	mov    $0xa,%ecx
 463:	eb 8a                	jmp    3ef <printf+0xbb>
 465:	8d 76 00             	lea    0x0(%esi),%esi
 468:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 46b:	8b 00                	mov    (%eax),%eax
 46d:	88 45 e7             	mov    %al,-0x19(%ebp)
 470:	51                   	push   %ecx
 471:	6a 01                	push   $0x1
 473:	8d 7d e7             	lea    -0x19(%ebp),%edi
 476:	57                   	push   %edi
 477:	56                   	push   %esi
 478:	e8 92 fd ff ff       	call   20f <write>
 47d:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 481:	83 c4 10             	add    $0x10,%esp
 484:	31 ff                	xor    %edi,%edi
 486:	e9 e1 fe ff ff       	jmp    36c <printf+0x38>
 48b:	90                   	nop
 48c:	88 55 e7             	mov    %dl,-0x19(%ebp)
 48f:	52                   	push   %edx
 490:	6a 01                	push   $0x1
 492:	8d 7d e7             	lea    -0x19(%ebp),%edi
 495:	e9 35 ff ff ff       	jmp    3cf <printf+0x9b>
 49a:	66 90                	xchg   %ax,%ax
 49c:	b0 28                	mov    $0x28,%al
 49e:	ba 18 06 00 00       	mov    $0x618,%edx
 4a3:	eb 80                	jmp    425 <printf+0xf1>
 4a5:	31 ff                	xor    %edi,%edi
 4a7:	e9 c0 fe ff ff       	jmp    36c <printf+0x38>

000004ac <free>:
 4ac:	55                   	push   %ebp
 4ad:	89 e5                	mov    %esp,%ebp
 4af:	57                   	push   %edi
 4b0:	56                   	push   %esi
 4b1:	53                   	push   %ebx
 4b2:	8b 5d 08             	mov    0x8(%ebp),%ebx
 4b5:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 4b8:	a1 8c 06 00 00       	mov    0x68c,%eax
 4bd:	8d 76 00             	lea    0x0(%esi),%esi
 4c0:	89 c2                	mov    %eax,%edx
 4c2:	8b 00                	mov    (%eax),%eax
 4c4:	39 ca                	cmp    %ecx,%edx
 4c6:	73 2c                	jae    4f4 <free+0x48>
 4c8:	39 c1                	cmp    %eax,%ecx
 4ca:	72 04                	jb     4d0 <free+0x24>
 4cc:	39 c2                	cmp    %eax,%edx
 4ce:	72 f0                	jb     4c0 <free+0x14>
 4d0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 4d3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 4d6:	39 f8                	cmp    %edi,%eax
 4d8:	74 2c                	je     506 <free+0x5a>
 4da:	89 43 f8             	mov    %eax,-0x8(%ebx)
 4dd:	8b 42 04             	mov    0x4(%edx),%eax
 4e0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 4e3:	39 f1                	cmp    %esi,%ecx
 4e5:	74 36                	je     51d <free+0x71>
 4e7:	89 0a                	mov    %ecx,(%edx)
 4e9:	89 15 8c 06 00 00    	mov    %edx,0x68c
 4ef:	5b                   	pop    %ebx
 4f0:	5e                   	pop    %esi
 4f1:	5f                   	pop    %edi
 4f2:	5d                   	pop    %ebp
 4f3:	c3                   	ret    
 4f4:	39 c2                	cmp    %eax,%edx
 4f6:	72 c8                	jb     4c0 <free+0x14>
 4f8:	39 c1                	cmp    %eax,%ecx
 4fa:	73 c4                	jae    4c0 <free+0x14>
 4fc:	8b 73 fc             	mov    -0x4(%ebx),%esi
 4ff:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 502:	39 f8                	cmp    %edi,%eax
 504:	75 d4                	jne    4da <free+0x2e>
 506:	03 70 04             	add    0x4(%eax),%esi
 509:	89 73 fc             	mov    %esi,-0x4(%ebx)
 50c:	8b 02                	mov    (%edx),%eax
 50e:	8b 00                	mov    (%eax),%eax
 510:	89 43 f8             	mov    %eax,-0x8(%ebx)
 513:	8b 42 04             	mov    0x4(%edx),%eax
 516:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 519:	39 f1                	cmp    %esi,%ecx
 51b:	75 ca                	jne    4e7 <free+0x3b>
 51d:	03 43 fc             	add    -0x4(%ebx),%eax
 520:	89 42 04             	mov    %eax,0x4(%edx)
 523:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 526:	89 0a                	mov    %ecx,(%edx)
 528:	89 15 8c 06 00 00    	mov    %edx,0x68c
 52e:	5b                   	pop    %ebx
 52f:	5e                   	pop    %esi
 530:	5f                   	pop    %edi
 531:	5d                   	pop    %ebp
 532:	c3                   	ret    
 533:	90                   	nop

00000534 <malloc>:
 534:	55                   	push   %ebp
 535:	89 e5                	mov    %esp,%ebp
 537:	57                   	push   %edi
 538:	56                   	push   %esi
 539:	53                   	push   %ebx
 53a:	83 ec 0c             	sub    $0xc,%esp
 53d:	8b 45 08             	mov    0x8(%ebp),%eax
 540:	8d 78 07             	lea    0x7(%eax),%edi
 543:	c1 ef 03             	shr    $0x3,%edi
 546:	47                   	inc    %edi
 547:	8b 15 8c 06 00 00    	mov    0x68c,%edx
 54d:	85 d2                	test   %edx,%edx
 54f:	0f 84 93 00 00 00    	je     5e8 <malloc+0xb4>
 555:	8b 02                	mov    (%edx),%eax
 557:	8b 48 04             	mov    0x4(%eax),%ecx
 55a:	39 f9                	cmp    %edi,%ecx
 55c:	73 62                	jae    5c0 <malloc+0x8c>
 55e:	89 fb                	mov    %edi,%ebx
 560:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 566:	72 78                	jb     5e0 <malloc+0xac>
 568:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 56f:	eb 0e                	jmp    57f <malloc+0x4b>
 571:	8d 76 00             	lea    0x0(%esi),%esi
 574:	89 c2                	mov    %eax,%edx
 576:	8b 02                	mov    (%edx),%eax
 578:	8b 48 04             	mov    0x4(%eax),%ecx
 57b:	39 f9                	cmp    %edi,%ecx
 57d:	73 41                	jae    5c0 <malloc+0x8c>
 57f:	39 05 8c 06 00 00    	cmp    %eax,0x68c
 585:	75 ed                	jne    574 <malloc+0x40>
 587:	83 ec 0c             	sub    $0xc,%esp
 58a:	56                   	push   %esi
 58b:	e8 e7 fc ff ff       	call   277 <sbrk>
 590:	83 c4 10             	add    $0x10,%esp
 593:	83 f8 ff             	cmp    $0xffffffff,%eax
 596:	74 1c                	je     5b4 <malloc+0x80>
 598:	89 58 04             	mov    %ebx,0x4(%eax)
 59b:	83 ec 0c             	sub    $0xc,%esp
 59e:	83 c0 08             	add    $0x8,%eax
 5a1:	50                   	push   %eax
 5a2:	e8 05 ff ff ff       	call   4ac <free>
 5a7:	8b 15 8c 06 00 00    	mov    0x68c,%edx
 5ad:	83 c4 10             	add    $0x10,%esp
 5b0:	85 d2                	test   %edx,%edx
 5b2:	75 c2                	jne    576 <malloc+0x42>
 5b4:	31 c0                	xor    %eax,%eax
 5b6:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5b9:	5b                   	pop    %ebx
 5ba:	5e                   	pop    %esi
 5bb:	5f                   	pop    %edi
 5bc:	5d                   	pop    %ebp
 5bd:	c3                   	ret    
 5be:	66 90                	xchg   %ax,%ax
 5c0:	39 cf                	cmp    %ecx,%edi
 5c2:	74 4c                	je     610 <malloc+0xdc>
 5c4:	29 f9                	sub    %edi,%ecx
 5c6:	89 48 04             	mov    %ecx,0x4(%eax)
 5c9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 5cc:	89 78 04             	mov    %edi,0x4(%eax)
 5cf:	89 15 8c 06 00 00    	mov    %edx,0x68c
 5d5:	83 c0 08             	add    $0x8,%eax
 5d8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5db:	5b                   	pop    %ebx
 5dc:	5e                   	pop    %esi
 5dd:	5f                   	pop    %edi
 5de:	5d                   	pop    %ebp
 5df:	c3                   	ret    
 5e0:	bb 00 10 00 00       	mov    $0x1000,%ebx
 5e5:	eb 81                	jmp    568 <malloc+0x34>
 5e7:	90                   	nop
 5e8:	c7 05 8c 06 00 00 90 	movl   $0x690,0x68c
 5ef:	06 00 00 
 5f2:	c7 05 90 06 00 00 90 	movl   $0x690,0x690
 5f9:	06 00 00 
 5fc:	c7 05 94 06 00 00 00 	movl   $0x0,0x694
 603:	00 00 00 
 606:	b8 90 06 00 00       	mov    $0x690,%eax
 60b:	e9 4e ff ff ff       	jmp    55e <malloc+0x2a>
 610:	8b 08                	mov    (%eax),%ecx
 612:	89 0a                	mov    %ecx,(%edx)
 614:	eb b9                	jmp    5cf <malloc+0x9b>
