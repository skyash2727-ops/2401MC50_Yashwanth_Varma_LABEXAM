
_stressfs:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	81 ec 20 02 00 00    	sub    $0x220,%esp
  17:	be 0b 07 00 00       	mov    $0x70b,%esi
  1c:	b9 0a 00 00 00       	mov    $0xa,%ecx
  21:	8d bd de fd ff ff    	lea    -0x222(%ebp),%edi
  27:	f3 a4                	rep movsb %ds:(%esi),%es:(%edi)
  29:	68 e8 06 00 00       	push   $0x6e8
  2e:	6a 01                	push   $0x1
  30:	e8 cf 03 00 00       	call   404 <printf>
  35:	83 c4 0c             	add    $0xc,%esp
  38:	68 00 02 00 00       	push   $0x200
  3d:	6a 61                	push   $0x61
  3f:	8d b5 e8 fd ff ff    	lea    -0x218(%ebp),%esi
  45:	56                   	push   %esi
  46:	e8 3d 01 00 00       	call   188 <memset>
  4b:	83 c4 10             	add    $0x10,%esp
  4e:	31 db                	xor    %ebx,%ebx
  50:	e8 62 02 00 00       	call   2b7 <fork>
  55:	85 c0                	test   %eax,%eax
  57:	7f 06                	jg     5f <main+0x5f>
  59:	43                   	inc    %ebx
  5a:	83 fb 04             	cmp    $0x4,%ebx
  5d:	75 f1                	jne    50 <main+0x50>
  5f:	50                   	push   %eax
  60:	53                   	push   %ebx
  61:	68 fb 06 00 00       	push   $0x6fb
  66:	6a 01                	push   $0x1
  68:	e8 97 03 00 00       	call   404 <printf>
  6d:	00 9d e6 fd ff ff    	add    %bl,-0x21a(%ebp)
  73:	58                   	pop    %eax
  74:	5a                   	pop    %edx
  75:	68 02 02 00 00       	push   $0x202
  7a:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  80:	50                   	push   %eax
  81:	e8 79 02 00 00       	call   2ff <open>
  86:	89 c7                	mov    %eax,%edi
  88:	83 c4 10             	add    $0x10,%esp
  8b:	bb 14 00 00 00       	mov    $0x14,%ebx
  90:	50                   	push   %eax
  91:	68 00 02 00 00       	push   $0x200
  96:	56                   	push   %esi
  97:	57                   	push   %edi
  98:	e8 42 02 00 00       	call   2df <write>
  9d:	83 c4 10             	add    $0x10,%esp
  a0:	4b                   	dec    %ebx
  a1:	75 ed                	jne    90 <main+0x90>
  a3:	83 ec 0c             	sub    $0xc,%esp
  a6:	57                   	push   %edi
  a7:	e8 3b 02 00 00       	call   2e7 <close>
  ac:	5a                   	pop    %edx
  ad:	59                   	pop    %ecx
  ae:	68 05 07 00 00       	push   $0x705
  b3:	6a 01                	push   $0x1
  b5:	e8 4a 03 00 00       	call   404 <printf>
  ba:	5b                   	pop    %ebx
  bb:	5f                   	pop    %edi
  bc:	6a 00                	push   $0x0
  be:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  c4:	50                   	push   %eax
  c5:	e8 35 02 00 00       	call   2ff <open>
  ca:	89 c7                	mov    %eax,%edi
  cc:	83 c4 10             	add    $0x10,%esp
  cf:	bb 14 00 00 00       	mov    $0x14,%ebx
  d4:	50                   	push   %eax
  d5:	68 00 02 00 00       	push   $0x200
  da:	56                   	push   %esi
  db:	57                   	push   %edi
  dc:	e8 f6 01 00 00       	call   2d7 <read>
  e1:	83 c4 10             	add    $0x10,%esp
  e4:	4b                   	dec    %ebx
  e5:	75 ed                	jne    d4 <main+0xd4>
  e7:	83 ec 0c             	sub    $0xc,%esp
  ea:	57                   	push   %edi
  eb:	e8 f7 01 00 00       	call   2e7 <close>
  f0:	e8 d2 01 00 00       	call   2c7 <wait>
  f5:	e8 c5 01 00 00       	call   2bf <exit>
  fa:	66 90                	xchg   %ax,%ax

000000fc <strcpy>:
  fc:	55                   	push   %ebp
  fd:	89 e5                	mov    %esp,%ebp
  ff:	53                   	push   %ebx
 100:	8b 4d 08             	mov    0x8(%ebp),%ecx
 103:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 106:	31 c0                	xor    %eax,%eax
 108:	8a 14 03             	mov    (%ebx,%eax,1),%dl
 10b:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 10e:	40                   	inc    %eax
 10f:	84 d2                	test   %dl,%dl
 111:	75 f5                	jne    108 <strcpy+0xc>
 113:	89 c8                	mov    %ecx,%eax
 115:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 118:	c9                   	leave  
 119:	c3                   	ret    
 11a:	66 90                	xchg   %ax,%ax

0000011c <strcmp>:
 11c:	55                   	push   %ebp
 11d:	89 e5                	mov    %esp,%ebp
 11f:	53                   	push   %ebx
 120:	8b 55 08             	mov    0x8(%ebp),%edx
 123:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 126:	0f b6 02             	movzbl (%edx),%eax
 129:	84 c0                	test   %al,%al
 12b:	75 10                	jne    13d <strcmp+0x21>
 12d:	eb 2a                	jmp    159 <strcmp+0x3d>
 12f:	90                   	nop
 130:	42                   	inc    %edx
 131:	8d 4b 01             	lea    0x1(%ebx),%ecx
 134:	0f b6 02             	movzbl (%edx),%eax
 137:	84 c0                	test   %al,%al
 139:	74 11                	je     14c <strcmp+0x30>
 13b:	89 cb                	mov    %ecx,%ebx
 13d:	0f b6 0b             	movzbl (%ebx),%ecx
 140:	38 c1                	cmp    %al,%cl
 142:	74 ec                	je     130 <strcmp+0x14>
 144:	29 c8                	sub    %ecx,%eax
 146:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 149:	c9                   	leave  
 14a:	c3                   	ret    
 14b:	90                   	nop
 14c:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
 150:	31 c0                	xor    %eax,%eax
 152:	29 c8                	sub    %ecx,%eax
 154:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 157:	c9                   	leave  
 158:	c3                   	ret    
 159:	0f b6 0b             	movzbl (%ebx),%ecx
 15c:	31 c0                	xor    %eax,%eax
 15e:	eb e4                	jmp    144 <strcmp+0x28>

00000160 <strlen>:
 160:	55                   	push   %ebp
 161:	89 e5                	mov    %esp,%ebp
 163:	8b 55 08             	mov    0x8(%ebp),%edx
 166:	80 3a 00             	cmpb   $0x0,(%edx)
 169:	74 15                	je     180 <strlen+0x20>
 16b:	31 c0                	xor    %eax,%eax
 16d:	8d 76 00             	lea    0x0(%esi),%esi
 170:	40                   	inc    %eax
 171:	89 c1                	mov    %eax,%ecx
 173:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 177:	75 f7                	jne    170 <strlen+0x10>
 179:	89 c8                	mov    %ecx,%eax
 17b:	5d                   	pop    %ebp
 17c:	c3                   	ret    
 17d:	8d 76 00             	lea    0x0(%esi),%esi
 180:	31 c9                	xor    %ecx,%ecx
 182:	89 c8                	mov    %ecx,%eax
 184:	5d                   	pop    %ebp
 185:	c3                   	ret    
 186:	66 90                	xchg   %ax,%ax

00000188 <memset>:
 188:	55                   	push   %ebp
 189:	89 e5                	mov    %esp,%ebp
 18b:	57                   	push   %edi
 18c:	8b 7d 08             	mov    0x8(%ebp),%edi
 18f:	8b 4d 10             	mov    0x10(%ebp),%ecx
 192:	8b 45 0c             	mov    0xc(%ebp),%eax
 195:	fc                   	cld    
 196:	f3 aa                	rep stos %al,%es:(%edi)
 198:	8b 45 08             	mov    0x8(%ebp),%eax
 19b:	8b 7d fc             	mov    -0x4(%ebp),%edi
 19e:	c9                   	leave  
 19f:	c3                   	ret    

000001a0 <strchr>:
 1a0:	55                   	push   %ebp
 1a1:	89 e5                	mov    %esp,%ebp
 1a3:	8b 45 08             	mov    0x8(%ebp),%eax
 1a6:	8a 4d 0c             	mov    0xc(%ebp),%cl
 1a9:	8a 10                	mov    (%eax),%dl
 1ab:	84 d2                	test   %dl,%dl
 1ad:	75 0c                	jne    1bb <strchr+0x1b>
 1af:	eb 13                	jmp    1c4 <strchr+0x24>
 1b1:	8d 76 00             	lea    0x0(%esi),%esi
 1b4:	40                   	inc    %eax
 1b5:	8a 10                	mov    (%eax),%dl
 1b7:	84 d2                	test   %dl,%dl
 1b9:	74 09                	je     1c4 <strchr+0x24>
 1bb:	38 d1                	cmp    %dl,%cl
 1bd:	75 f5                	jne    1b4 <strchr+0x14>
 1bf:	5d                   	pop    %ebp
 1c0:	c3                   	ret    
 1c1:	8d 76 00             	lea    0x0(%esi),%esi
 1c4:	31 c0                	xor    %eax,%eax
 1c6:	5d                   	pop    %ebp
 1c7:	c3                   	ret    

000001c8 <gets>:
 1c8:	55                   	push   %ebp
 1c9:	89 e5                	mov    %esp,%ebp
 1cb:	57                   	push   %edi
 1cc:	56                   	push   %esi
 1cd:	53                   	push   %ebx
 1ce:	83 ec 1c             	sub    $0x1c,%esp
 1d1:	31 db                	xor    %ebx,%ebx
 1d3:	8d 75 e7             	lea    -0x19(%ebp),%esi
 1d6:	eb 24                	jmp    1fc <gets+0x34>
 1d8:	50                   	push   %eax
 1d9:	6a 01                	push   $0x1
 1db:	56                   	push   %esi
 1dc:	6a 00                	push   $0x0
 1de:	e8 f4 00 00 00       	call   2d7 <read>
 1e3:	83 c4 10             	add    $0x10,%esp
 1e6:	85 c0                	test   %eax,%eax
 1e8:	7e 1a                	jle    204 <gets+0x3c>
 1ea:	8a 45 e7             	mov    -0x19(%ebp),%al
 1ed:	8b 55 08             	mov    0x8(%ebp),%edx
 1f0:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 1f4:	3c 0a                	cmp    $0xa,%al
 1f6:	74 0e                	je     206 <gets+0x3e>
 1f8:	3c 0d                	cmp    $0xd,%al
 1fa:	74 0a                	je     206 <gets+0x3e>
 1fc:	89 df                	mov    %ebx,%edi
 1fe:	43                   	inc    %ebx
 1ff:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 202:	7c d4                	jl     1d8 <gets+0x10>
 204:	89 fb                	mov    %edi,%ebx
 206:	8b 45 08             	mov    0x8(%ebp),%eax
 209:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 20d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 210:	5b                   	pop    %ebx
 211:	5e                   	pop    %esi
 212:	5f                   	pop    %edi
 213:	5d                   	pop    %ebp
 214:	c3                   	ret    
 215:	8d 76 00             	lea    0x0(%esi),%esi

00000218 <stat>:
 218:	55                   	push   %ebp
 219:	89 e5                	mov    %esp,%ebp
 21b:	56                   	push   %esi
 21c:	53                   	push   %ebx
 21d:	83 ec 08             	sub    $0x8,%esp
 220:	6a 00                	push   $0x0
 222:	ff 75 08             	pushl  0x8(%ebp)
 225:	e8 d5 00 00 00       	call   2ff <open>
 22a:	83 c4 10             	add    $0x10,%esp
 22d:	85 c0                	test   %eax,%eax
 22f:	78 27                	js     258 <stat+0x40>
 231:	89 c3                	mov    %eax,%ebx
 233:	83 ec 08             	sub    $0x8,%esp
 236:	ff 75 0c             	pushl  0xc(%ebp)
 239:	50                   	push   %eax
 23a:	e8 d8 00 00 00       	call   317 <fstat>
 23f:	89 c6                	mov    %eax,%esi
 241:	89 1c 24             	mov    %ebx,(%esp)
 244:	e8 9e 00 00 00       	call   2e7 <close>
 249:	83 c4 10             	add    $0x10,%esp
 24c:	89 f0                	mov    %esi,%eax
 24e:	8d 65 f8             	lea    -0x8(%ebp),%esp
 251:	5b                   	pop    %ebx
 252:	5e                   	pop    %esi
 253:	5d                   	pop    %ebp
 254:	c3                   	ret    
 255:	8d 76 00             	lea    0x0(%esi),%esi
 258:	be ff ff ff ff       	mov    $0xffffffff,%esi
 25d:	eb ed                	jmp    24c <stat+0x34>
 25f:	90                   	nop

00000260 <atoi>:
 260:	55                   	push   %ebp
 261:	89 e5                	mov    %esp,%ebp
 263:	53                   	push   %ebx
 264:	8b 4d 08             	mov    0x8(%ebp),%ecx
 267:	0f be 01             	movsbl (%ecx),%eax
 26a:	8d 50 d0             	lea    -0x30(%eax),%edx
 26d:	80 fa 09             	cmp    $0x9,%dl
 270:	ba 00 00 00 00       	mov    $0x0,%edx
 275:	77 16                	ja     28d <atoi+0x2d>
 277:	90                   	nop
 278:	41                   	inc    %ecx
 279:	8d 14 92             	lea    (%edx,%edx,4),%edx
 27c:	01 d2                	add    %edx,%edx
 27e:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 282:	0f be 01             	movsbl (%ecx),%eax
 285:	8d 58 d0             	lea    -0x30(%eax),%ebx
 288:	80 fb 09             	cmp    $0x9,%bl
 28b:	76 eb                	jbe    278 <atoi+0x18>
 28d:	89 d0                	mov    %edx,%eax
 28f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 292:	c9                   	leave  
 293:	c3                   	ret    

00000294 <memmove>:
 294:	55                   	push   %ebp
 295:	89 e5                	mov    %esp,%ebp
 297:	57                   	push   %edi
 298:	56                   	push   %esi
 299:	8b 55 08             	mov    0x8(%ebp),%edx
 29c:	8b 75 0c             	mov    0xc(%ebp),%esi
 29f:	8b 45 10             	mov    0x10(%ebp),%eax
 2a2:	85 c0                	test   %eax,%eax
 2a4:	7e 0b                	jle    2b1 <memmove+0x1d>
 2a6:	01 d0                	add    %edx,%eax
 2a8:	89 d7                	mov    %edx,%edi
 2aa:	66 90                	xchg   %ax,%ax
 2ac:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 2ad:	39 f8                	cmp    %edi,%eax
 2af:	75 fb                	jne    2ac <memmove+0x18>
 2b1:	89 d0                	mov    %edx,%eax
 2b3:	5e                   	pop    %esi
 2b4:	5f                   	pop    %edi
 2b5:	5d                   	pop    %ebp
 2b6:	c3                   	ret    

000002b7 <fork>:
 2b7:	b8 01 00 00 00       	mov    $0x1,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <exit>:
 2bf:	b8 02 00 00 00       	mov    $0x2,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <wait>:
 2c7:	b8 03 00 00 00       	mov    $0x3,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <pipe>:
 2cf:	b8 04 00 00 00       	mov    $0x4,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <read>:
 2d7:	b8 05 00 00 00       	mov    $0x5,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret    

000002df <write>:
 2df:	b8 10 00 00 00       	mov    $0x10,%eax
 2e4:	cd 40                	int    $0x40
 2e6:	c3                   	ret    

000002e7 <close>:
 2e7:	b8 15 00 00 00       	mov    $0x15,%eax
 2ec:	cd 40                	int    $0x40
 2ee:	c3                   	ret    

000002ef <kill>:
 2ef:	b8 06 00 00 00       	mov    $0x6,%eax
 2f4:	cd 40                	int    $0x40
 2f6:	c3                   	ret    

000002f7 <exec>:
 2f7:	b8 07 00 00 00       	mov    $0x7,%eax
 2fc:	cd 40                	int    $0x40
 2fe:	c3                   	ret    

000002ff <open>:
 2ff:	b8 0f 00 00 00       	mov    $0xf,%eax
 304:	cd 40                	int    $0x40
 306:	c3                   	ret    

00000307 <mknod>:
 307:	b8 11 00 00 00       	mov    $0x11,%eax
 30c:	cd 40                	int    $0x40
 30e:	c3                   	ret    

0000030f <unlink>:
 30f:	b8 12 00 00 00       	mov    $0x12,%eax
 314:	cd 40                	int    $0x40
 316:	c3                   	ret    

00000317 <fstat>:
 317:	b8 08 00 00 00       	mov    $0x8,%eax
 31c:	cd 40                	int    $0x40
 31e:	c3                   	ret    

0000031f <link>:
 31f:	b8 13 00 00 00       	mov    $0x13,%eax
 324:	cd 40                	int    $0x40
 326:	c3                   	ret    

00000327 <mkdir>:
 327:	b8 14 00 00 00       	mov    $0x14,%eax
 32c:	cd 40                	int    $0x40
 32e:	c3                   	ret    

0000032f <chdir>:
 32f:	b8 09 00 00 00       	mov    $0x9,%eax
 334:	cd 40                	int    $0x40
 336:	c3                   	ret    

00000337 <dup>:
 337:	b8 0a 00 00 00       	mov    $0xa,%eax
 33c:	cd 40                	int    $0x40
 33e:	c3                   	ret    

0000033f <getpid>:
 33f:	b8 0b 00 00 00       	mov    $0xb,%eax
 344:	cd 40                	int    $0x40
 346:	c3                   	ret    

00000347 <sbrk>:
 347:	b8 0c 00 00 00       	mov    $0xc,%eax
 34c:	cd 40                	int    $0x40
 34e:	c3                   	ret    

0000034f <sleep>:
 34f:	b8 0d 00 00 00       	mov    $0xd,%eax
 354:	cd 40                	int    $0x40
 356:	c3                   	ret    

00000357 <uptime>:
 357:	b8 0e 00 00 00       	mov    $0xe,%eax
 35c:	cd 40                	int    $0x40
 35e:	c3                   	ret    

0000035f <mprotect>:
 35f:	b8 16 00 00 00       	mov    $0x16,%eax
 364:	cd 40                	int    $0x40
 366:	c3                   	ret    

00000367 <munprotect>:
 367:	b8 17 00 00 00       	mov    $0x17,%eax
 36c:	cd 40                	int    $0x40
 36e:	c3                   	ret    

0000036f <set_priority>:
 36f:	b8 18 00 00 00       	mov    $0x18,%eax
 374:	cd 40                	int    $0x40
 376:	c3                   	ret    
 377:	90                   	nop

00000378 <printint>:
 378:	55                   	push   %ebp
 379:	89 e5                	mov    %esp,%ebp
 37b:	57                   	push   %edi
 37c:	56                   	push   %esi
 37d:	53                   	push   %ebx
 37e:	83 ec 3c             	sub    $0x3c,%esp
 381:	89 45 c0             	mov    %eax,-0x40(%ebp)
 384:	89 cb                	mov    %ecx,%ebx
 386:	8b 4d 08             	mov    0x8(%ebp),%ecx
 389:	85 c9                	test   %ecx,%ecx
 38b:	74 04                	je     391 <printint+0x19>
 38d:	85 d2                	test   %edx,%edx
 38f:	78 6b                	js     3fc <printint+0x84>
 391:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 394:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 39b:	31 c9                	xor    %ecx,%ecx
 39d:	8d 75 d7             	lea    -0x29(%ebp),%esi
 3a0:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 3a3:	31 d2                	xor    %edx,%edx
 3a5:	f7 f3                	div    %ebx
 3a7:	89 cf                	mov    %ecx,%edi
 3a9:	8d 49 01             	lea    0x1(%ecx),%ecx
 3ac:	8a 92 74 07 00 00    	mov    0x774(%edx),%dl
 3b2:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 3b6:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 3b9:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 3bc:	39 da                	cmp    %ebx,%edx
 3be:	73 e0                	jae    3a0 <printint+0x28>
 3c0:	8b 55 08             	mov    0x8(%ebp),%edx
 3c3:	85 d2                	test   %edx,%edx
 3c5:	74 07                	je     3ce <printint+0x56>
 3c7:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 3cc:	89 cf                	mov    %ecx,%edi
 3ce:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 3d1:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 3d5:	8d 76 00             	lea    0x0(%esi),%esi
 3d8:	8a 07                	mov    (%edi),%al
 3da:	88 45 d7             	mov    %al,-0x29(%ebp)
 3dd:	50                   	push   %eax
 3de:	6a 01                	push   $0x1
 3e0:	56                   	push   %esi
 3e1:	ff 75 c0             	pushl  -0x40(%ebp)
 3e4:	e8 f6 fe ff ff       	call   2df <write>
 3e9:	89 f8                	mov    %edi,%eax
 3eb:	4f                   	dec    %edi
 3ec:	83 c4 10             	add    $0x10,%esp
 3ef:	39 d8                	cmp    %ebx,%eax
 3f1:	75 e5                	jne    3d8 <printint+0x60>
 3f3:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3f6:	5b                   	pop    %ebx
 3f7:	5e                   	pop    %esi
 3f8:	5f                   	pop    %edi
 3f9:	5d                   	pop    %ebp
 3fa:	c3                   	ret    
 3fb:	90                   	nop
 3fc:	f7 da                	neg    %edx
 3fe:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 401:	eb 98                	jmp    39b <printint+0x23>
 403:	90                   	nop

00000404 <printf>:
 404:	55                   	push   %ebp
 405:	89 e5                	mov    %esp,%ebp
 407:	57                   	push   %edi
 408:	56                   	push   %esi
 409:	53                   	push   %ebx
 40a:	83 ec 2c             	sub    $0x2c,%esp
 40d:	8b 75 08             	mov    0x8(%ebp),%esi
 410:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 413:	8a 13                	mov    (%ebx),%dl
 415:	84 d2                	test   %dl,%dl
 417:	74 5c                	je     475 <printf+0x71>
 419:	43                   	inc    %ebx
 41a:	8d 45 10             	lea    0x10(%ebp),%eax
 41d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 420:	31 ff                	xor    %edi,%edi
 422:	eb 20                	jmp    444 <printf+0x40>
 424:	83 f8 25             	cmp    $0x25,%eax
 427:	74 3f                	je     468 <printf+0x64>
 429:	88 55 e7             	mov    %dl,-0x19(%ebp)
 42c:	50                   	push   %eax
 42d:	6a 01                	push   $0x1
 42f:	8d 45 e7             	lea    -0x19(%ebp),%eax
 432:	50                   	push   %eax
 433:	56                   	push   %esi
 434:	e8 a6 fe ff ff       	call   2df <write>
 439:	83 c4 10             	add    $0x10,%esp
 43c:	43                   	inc    %ebx
 43d:	8a 53 ff             	mov    -0x1(%ebx),%dl
 440:	84 d2                	test   %dl,%dl
 442:	74 31                	je     475 <printf+0x71>
 444:	0f b6 c2             	movzbl %dl,%eax
 447:	85 ff                	test   %edi,%edi
 449:	74 d9                	je     424 <printf+0x20>
 44b:	83 ff 25             	cmp    $0x25,%edi
 44e:	75 ec                	jne    43c <printf+0x38>
 450:	83 f8 25             	cmp    $0x25,%eax
 453:	0f 84 03 01 00 00    	je     55c <printf+0x158>
 459:	83 e8 63             	sub    $0x63,%eax
 45c:	83 f8 15             	cmp    $0x15,%eax
 45f:	77 1f                	ja     480 <printf+0x7c>
 461:	ff 24 85 1c 07 00 00 	jmp    *0x71c(,%eax,4)
 468:	bf 25 00 00 00       	mov    $0x25,%edi
 46d:	43                   	inc    %ebx
 46e:	8a 53 ff             	mov    -0x1(%ebx),%dl
 471:	84 d2                	test   %dl,%dl
 473:	75 cf                	jne    444 <printf+0x40>
 475:	8d 65 f4             	lea    -0xc(%ebp),%esp
 478:	5b                   	pop    %ebx
 479:	5e                   	pop    %esi
 47a:	5f                   	pop    %edi
 47b:	5d                   	pop    %ebp
 47c:	c3                   	ret    
 47d:	8d 76 00             	lea    0x0(%esi),%esi
 480:	88 55 d0             	mov    %dl,-0x30(%ebp)
 483:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 487:	50                   	push   %eax
 488:	6a 01                	push   $0x1
 48a:	8d 7d e7             	lea    -0x19(%ebp),%edi
 48d:	57                   	push   %edi
 48e:	56                   	push   %esi
 48f:	e8 4b fe ff ff       	call   2df <write>
 494:	8a 55 d0             	mov    -0x30(%ebp),%dl
 497:	88 55 e7             	mov    %dl,-0x19(%ebp)
 49a:	83 c4 0c             	add    $0xc,%esp
 49d:	6a 01                	push   $0x1
 49f:	57                   	push   %edi
 4a0:	56                   	push   %esi
 4a1:	e8 39 fe ff ff       	call   2df <write>
 4a6:	83 c4 10             	add    $0x10,%esp
 4a9:	31 ff                	xor    %edi,%edi
 4ab:	eb 8f                	jmp    43c <printf+0x38>
 4ad:	8d 76 00             	lea    0x0(%esi),%esi
 4b0:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4b3:	8b 17                	mov    (%edi),%edx
 4b5:	83 ec 0c             	sub    $0xc,%esp
 4b8:	6a 00                	push   $0x0
 4ba:	b9 10 00 00 00       	mov    $0x10,%ecx
 4bf:	89 f0                	mov    %esi,%eax
 4c1:	e8 b2 fe ff ff       	call   378 <printint>
 4c6:	83 c7 04             	add    $0x4,%edi
 4c9:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4cc:	83 c4 10             	add    $0x10,%esp
 4cf:	31 ff                	xor    %edi,%edi
 4d1:	e9 66 ff ff ff       	jmp    43c <printf+0x38>
 4d6:	66 90                	xchg   %ax,%ax
 4d8:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 4db:	8b 10                	mov    (%eax),%edx
 4dd:	83 c0 04             	add    $0x4,%eax
 4e0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4e3:	85 d2                	test   %edx,%edx
 4e5:	0f 84 81 00 00 00    	je     56c <printf+0x168>
 4eb:	8a 02                	mov    (%edx),%al
 4ed:	84 c0                	test   %al,%al
 4ef:	0f 84 80 00 00 00    	je     575 <printf+0x171>
 4f5:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4f8:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 4fb:	89 d3                	mov    %edx,%ebx
 4fd:	8d 76 00             	lea    0x0(%esi),%esi
 500:	88 45 e7             	mov    %al,-0x19(%ebp)
 503:	50                   	push   %eax
 504:	6a 01                	push   $0x1
 506:	57                   	push   %edi
 507:	56                   	push   %esi
 508:	e8 d2 fd ff ff       	call   2df <write>
 50d:	43                   	inc    %ebx
 50e:	8a 03                	mov    (%ebx),%al
 510:	83 c4 10             	add    $0x10,%esp
 513:	84 c0                	test   %al,%al
 515:	75 e9                	jne    500 <printf+0xfc>
 517:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 51a:	31 ff                	xor    %edi,%edi
 51c:	e9 1b ff ff ff       	jmp    43c <printf+0x38>
 521:	8d 76 00             	lea    0x0(%esi),%esi
 524:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 527:	8b 17                	mov    (%edi),%edx
 529:	83 ec 0c             	sub    $0xc,%esp
 52c:	6a 01                	push   $0x1
 52e:	b9 0a 00 00 00       	mov    $0xa,%ecx
 533:	eb 8a                	jmp    4bf <printf+0xbb>
 535:	8d 76 00             	lea    0x0(%esi),%esi
 538:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 53b:	8b 00                	mov    (%eax),%eax
 53d:	88 45 e7             	mov    %al,-0x19(%ebp)
 540:	51                   	push   %ecx
 541:	6a 01                	push   $0x1
 543:	8d 7d e7             	lea    -0x19(%ebp),%edi
 546:	57                   	push   %edi
 547:	56                   	push   %esi
 548:	e8 92 fd ff ff       	call   2df <write>
 54d:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 551:	83 c4 10             	add    $0x10,%esp
 554:	31 ff                	xor    %edi,%edi
 556:	e9 e1 fe ff ff       	jmp    43c <printf+0x38>
 55b:	90                   	nop
 55c:	88 55 e7             	mov    %dl,-0x19(%ebp)
 55f:	52                   	push   %edx
 560:	6a 01                	push   $0x1
 562:	8d 7d e7             	lea    -0x19(%ebp),%edi
 565:	e9 35 ff ff ff       	jmp    49f <printf+0x9b>
 56a:	66 90                	xchg   %ax,%ax
 56c:	b0 28                	mov    $0x28,%al
 56e:	ba 15 07 00 00       	mov    $0x715,%edx
 573:	eb 80                	jmp    4f5 <printf+0xf1>
 575:	31 ff                	xor    %edi,%edi
 577:	e9 c0 fe ff ff       	jmp    43c <printf+0x38>

0000057c <free>:
 57c:	55                   	push   %ebp
 57d:	89 e5                	mov    %esp,%ebp
 57f:	57                   	push   %edi
 580:	56                   	push   %esi
 581:	53                   	push   %ebx
 582:	8b 5d 08             	mov    0x8(%ebp),%ebx
 585:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 588:	a1 88 07 00 00       	mov    0x788,%eax
 58d:	8d 76 00             	lea    0x0(%esi),%esi
 590:	89 c2                	mov    %eax,%edx
 592:	8b 00                	mov    (%eax),%eax
 594:	39 ca                	cmp    %ecx,%edx
 596:	73 2c                	jae    5c4 <free+0x48>
 598:	39 c1                	cmp    %eax,%ecx
 59a:	72 04                	jb     5a0 <free+0x24>
 59c:	39 c2                	cmp    %eax,%edx
 59e:	72 f0                	jb     590 <free+0x14>
 5a0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5a3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5a6:	39 f8                	cmp    %edi,%eax
 5a8:	74 2c                	je     5d6 <free+0x5a>
 5aa:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5ad:	8b 42 04             	mov    0x4(%edx),%eax
 5b0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5b3:	39 f1                	cmp    %esi,%ecx
 5b5:	74 36                	je     5ed <free+0x71>
 5b7:	89 0a                	mov    %ecx,(%edx)
 5b9:	89 15 88 07 00 00    	mov    %edx,0x788
 5bf:	5b                   	pop    %ebx
 5c0:	5e                   	pop    %esi
 5c1:	5f                   	pop    %edi
 5c2:	5d                   	pop    %ebp
 5c3:	c3                   	ret    
 5c4:	39 c2                	cmp    %eax,%edx
 5c6:	72 c8                	jb     590 <free+0x14>
 5c8:	39 c1                	cmp    %eax,%ecx
 5ca:	73 c4                	jae    590 <free+0x14>
 5cc:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5cf:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5d2:	39 f8                	cmp    %edi,%eax
 5d4:	75 d4                	jne    5aa <free+0x2e>
 5d6:	03 70 04             	add    0x4(%eax),%esi
 5d9:	89 73 fc             	mov    %esi,-0x4(%ebx)
 5dc:	8b 02                	mov    (%edx),%eax
 5de:	8b 00                	mov    (%eax),%eax
 5e0:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5e3:	8b 42 04             	mov    0x4(%edx),%eax
 5e6:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5e9:	39 f1                	cmp    %esi,%ecx
 5eb:	75 ca                	jne    5b7 <free+0x3b>
 5ed:	03 43 fc             	add    -0x4(%ebx),%eax
 5f0:	89 42 04             	mov    %eax,0x4(%edx)
 5f3:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 5f6:	89 0a                	mov    %ecx,(%edx)
 5f8:	89 15 88 07 00 00    	mov    %edx,0x788
 5fe:	5b                   	pop    %ebx
 5ff:	5e                   	pop    %esi
 600:	5f                   	pop    %edi
 601:	5d                   	pop    %ebp
 602:	c3                   	ret    
 603:	90                   	nop

00000604 <malloc>:
 604:	55                   	push   %ebp
 605:	89 e5                	mov    %esp,%ebp
 607:	57                   	push   %edi
 608:	56                   	push   %esi
 609:	53                   	push   %ebx
 60a:	83 ec 0c             	sub    $0xc,%esp
 60d:	8b 45 08             	mov    0x8(%ebp),%eax
 610:	8d 78 07             	lea    0x7(%eax),%edi
 613:	c1 ef 03             	shr    $0x3,%edi
 616:	47                   	inc    %edi
 617:	8b 15 88 07 00 00    	mov    0x788,%edx
 61d:	85 d2                	test   %edx,%edx
 61f:	0f 84 93 00 00 00    	je     6b8 <malloc+0xb4>
 625:	8b 02                	mov    (%edx),%eax
 627:	8b 48 04             	mov    0x4(%eax),%ecx
 62a:	39 f9                	cmp    %edi,%ecx
 62c:	73 62                	jae    690 <malloc+0x8c>
 62e:	89 fb                	mov    %edi,%ebx
 630:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 636:	72 78                	jb     6b0 <malloc+0xac>
 638:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 63f:	eb 0e                	jmp    64f <malloc+0x4b>
 641:	8d 76 00             	lea    0x0(%esi),%esi
 644:	89 c2                	mov    %eax,%edx
 646:	8b 02                	mov    (%edx),%eax
 648:	8b 48 04             	mov    0x4(%eax),%ecx
 64b:	39 f9                	cmp    %edi,%ecx
 64d:	73 41                	jae    690 <malloc+0x8c>
 64f:	39 05 88 07 00 00    	cmp    %eax,0x788
 655:	75 ed                	jne    644 <malloc+0x40>
 657:	83 ec 0c             	sub    $0xc,%esp
 65a:	56                   	push   %esi
 65b:	e8 e7 fc ff ff       	call   347 <sbrk>
 660:	83 c4 10             	add    $0x10,%esp
 663:	83 f8 ff             	cmp    $0xffffffff,%eax
 666:	74 1c                	je     684 <malloc+0x80>
 668:	89 58 04             	mov    %ebx,0x4(%eax)
 66b:	83 ec 0c             	sub    $0xc,%esp
 66e:	83 c0 08             	add    $0x8,%eax
 671:	50                   	push   %eax
 672:	e8 05 ff ff ff       	call   57c <free>
 677:	8b 15 88 07 00 00    	mov    0x788,%edx
 67d:	83 c4 10             	add    $0x10,%esp
 680:	85 d2                	test   %edx,%edx
 682:	75 c2                	jne    646 <malloc+0x42>
 684:	31 c0                	xor    %eax,%eax
 686:	8d 65 f4             	lea    -0xc(%ebp),%esp
 689:	5b                   	pop    %ebx
 68a:	5e                   	pop    %esi
 68b:	5f                   	pop    %edi
 68c:	5d                   	pop    %ebp
 68d:	c3                   	ret    
 68e:	66 90                	xchg   %ax,%ax
 690:	39 cf                	cmp    %ecx,%edi
 692:	74 4c                	je     6e0 <malloc+0xdc>
 694:	29 f9                	sub    %edi,%ecx
 696:	89 48 04             	mov    %ecx,0x4(%eax)
 699:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 69c:	89 78 04             	mov    %edi,0x4(%eax)
 69f:	89 15 88 07 00 00    	mov    %edx,0x788
 6a5:	83 c0 08             	add    $0x8,%eax
 6a8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6ab:	5b                   	pop    %ebx
 6ac:	5e                   	pop    %esi
 6ad:	5f                   	pop    %edi
 6ae:	5d                   	pop    %ebp
 6af:	c3                   	ret    
 6b0:	bb 00 10 00 00       	mov    $0x1000,%ebx
 6b5:	eb 81                	jmp    638 <malloc+0x34>
 6b7:	90                   	nop
 6b8:	c7 05 88 07 00 00 8c 	movl   $0x78c,0x788
 6bf:	07 00 00 
 6c2:	c7 05 8c 07 00 00 8c 	movl   $0x78c,0x78c
 6c9:	07 00 00 
 6cc:	c7 05 90 07 00 00 00 	movl   $0x0,0x790
 6d3:	00 00 00 
 6d6:	b8 8c 07 00 00       	mov    $0x78c,%eax
 6db:	e9 4e ff ff ff       	jmp    62e <malloc+0x2a>
 6e0:	8b 08                	mov    (%eax),%ecx
 6e2:	89 0a                	mov    %ecx,(%edx)
 6e4:	eb b9                	jmp    69f <malloc+0x9b>
